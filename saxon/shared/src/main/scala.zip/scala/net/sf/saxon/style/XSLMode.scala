////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.expr.accum.Accumulator
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.om.StandardNames
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans._
import net.sf.saxon.trans.rules._
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace
import java.util

/**
 * Handler for xsl:mode elements in stylesheet.
 * The xsl:mode element defines the properties of a mode. The mode is identified
 * by the name attribute, defaulting to the unnamed default mode (which may also be
 * written "#default").
 * <p>The attribute streamable="yes|no" which
 * indicates whether templates in this mode are to be processed by streaming.</p>
 * <p>The attribute on-no-match indicates which family of template rules
 * should be used to process nodes when there is no explicit match</p>
 */
class XSLMode extends StyleElement {
  private var mode = null
  private var accumulators = null
  private var prepared = false
  private var streamable = false
  private var failOnMultipleMatch = false
  private var warningOnNoMatch = false
  private var warningOnMultipleMatch = true
  private var traceMatching = false
  private var defaultRules = TextOnlyCopyRuleSet.getInstance

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  /**
   * Determine whether this node is an instruction.
   *
   * @return false - it is a declaration
   */
  override def isInstruction = false

  /**
   * Get a name identifying the object of the expression, for example a function name, template name,
   * variable name, key name, element name, etc. This is used only where the name is known statically.
   * If there is no name, the value will be null.
   */
  override def getObjectName: StructuredQName = {
    var qn = super.getObjectName
    if (qn == null) {
      val nameAtt = Whitespace.trim(getAttributeValue("", "name"))
      if (nameAtt == null) return Mode.UNNAMED_MODE_NAME
      qn = makeQName(nameAtt, null, "name")
      setObjectName(qn)
    }
    qn
  }

  /**
   * Method supplied by declaration elements to add themselves to a stylesheet-level index
   *
   * @param decl the Declaration being indexed. (This corresponds to the StyleElement object
   *             except in cases where one module is imported several times with different precedence.)
   * @param top  the outermost XSLStylesheet element
   * @throws XPathException if any error is encountered
   */
  @throws[XPathException]
  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = {
    val name = getObjectName
    val sName = new SymbolicName(StandardNames.XSL_MODE, name)
    val componentIndex = top.getStylesheetPackage.getComponentIndex
    // see if there is already a named template with this precedence
    if (!(name == Mode.UNNAMED_MODE_NAME)) {
      val other = componentIndex.get(sName)
      if (other != null && (other.getDeclaringPackage ne top.getStylesheetPackage)) compileError("Mode " + name.getDisplayName + " conflicts with a public named mode in package " + other.getDeclaringPackage.getPackageName, "XTSE3050")
    }
    mode = top.getRuleManager.obtainMode(name, true).asInstanceOf[SimpleMode]
    if (name == Mode.UNNAMED_MODE_NAME) top.getRuleManager.setUnnamedModeExplicit(true)
    else if (mode.getDeclaringComponent.getDeclaringPackage ne getContainingPackage) compileError("Mode name conflicts with a mode in a used package", "XTSE3050")
    else {
      top.indexMode(decl)
      val declaredVisibility = getDeclaredVisibility
      val actualVisibility = if (declaredVisibility == null) Visibility.PRIVATE
      else declaredVisibility
      val provenance = if (declaredVisibility == null) VisibilityProvenance.DEFAULTED
      else VisibilityProvenance.EXPLICIT
      mode.getDeclaringComponent.setVisibility(actualVisibility, provenance)
      top.indexMode(decl)
    }
  }

  override def prepareAttributes(): Unit = {
    var nameAtt = null
    var visibilityAtt = null
    var extraAsAtt = null
    if (prepared) return
    prepared = true
    var visibility = Visibility.PRIVATE
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "streamable" =>
          streamable = processStreamableAtt(value)
        case "name" =>
          nameAtt = Whitespace.trim(value)
          if (!(nameAtt == "#default")) setObjectName(makeQName(nameAtt, null, "name"))
        case "use-accumulators" =>
          accumulators = getPrincipalStylesheetModule.getStylesheetPackage.getAccumulatorRegistry.getUsedAccumulators(value, this)
        case "on-multiple-match" =>
          Whitespace.trim(value) match {
            case "fail" =>
              failOnMultipleMatch = true
            case "use-last" =>
              failOnMultipleMatch = false
            case _ =>
              invalidAttribute(f, "fail|use-last")
          }
        case "on-no-match" =>
          Whitespace.trim(value) match {
            case "text-only-copy" =>
            // no action, this is the default
            case "shallow-copy" =>
              defaultRules = ShallowCopyRuleSet.getInstance
            case "deep-copy" =>
              defaultRules = DeepCopyRuleSet.getInstance
            case "shallow-skip" =>
              defaultRules = ShallowSkipRuleSet.getInstance
            case "deep-skip" =>
              defaultRules = DeepSkipRuleSet.getInstance
            case "fail" =>
              defaultRules = FailRuleSet.getInstance
            case _ =>
              invalidAttribute(f, "text-only-copy|shallow-copy|deep-copy|shallow-skip|deep-skip|fail")
          }
        case "warning-on-multiple-match" =>
          warningOnMultipleMatch = processBooleanAttribute("warning-on-multiple-match", value)
        case "warning-on-no-match" =>
          warningOnNoMatch = processBooleanAttribute("warning-on-no-match", value)
        case "typed" =>
          checkAttributeValue("typed", Whitespace.trim(value), false, Array[String]("0", "1", "false", "lax", "no", "strict", "true", "unspecified", "yes"))
        case "visibility" =>
          visibilityAtt = Whitespace.trim(value)
          visibility = interpretVisibilityValue(visibilityAtt, "")
          if (visibility eq Visibility.ABSTRACT) invalidAttribute(f, "public|private|final")
          mode.setDeclaredVisibility(visibility)
        case _ =>
          if (attName.hasURI(NamespaceConstant.SAXON)) {
            isExtensionAttributeAllowed(attName.getDisplayName)
            if (attName.getLocalPart == "trace") traceMatching = processBooleanAttribute("saxon:trace", value)
            else if (attName.getLocalPart == "as") extraAsAtt = value
          }
          else checkUnknownAttribute(attName)
      }
    }
    if (nameAtt == null && visibilityAtt != null && (mode.getDeclaredVisibility ne Visibility.PRIVATE)) compileError("The unnamed mode must be private", "XTSE0020")
    val manager = getCompilation.getPrincipalStylesheetModule.getRuleManager
    if (getObjectName == null) mode = manager.getUnnamedMode
    else {
      val m = manager.obtainMode(getObjectName, true)
      if (m.isInstanceOf[SimpleMode]) mode = m.asInstanceOf[SimpleMode]
      else {
        compileError("Mode name refers to an overridden mode")
        mode = manager.getUnnamedMode
      }
    }
    mode.setStreamable(streamable)
    if (streamable) {
      val omniMode = manager.obtainMode(Mode.OMNI_MODE, true)
      omniMode.setStreamable(true)
    }
    if (warningOnNoMatch) defaultRules = new RuleSetWithWarnings(defaultRules)
    mode.setBuiltInRuleSet(defaultRules)
    var recoveryPolicy = null
    if (failOnMultipleMatch) recoveryPolicy = RecoveryPolicy.DO_NOT_RECOVER
    else if (warningOnMultipleMatch) recoveryPolicy = RecoveryPolicy.RECOVER_WITH_WARNINGS
    else recoveryPolicy = RecoveryPolicy.RECOVER_SILENTLY
    mode.setRecoveryPolicy(recoveryPolicy)
    mode.obtainDeclaringComponent(this)
    mode.setModeTracing(traceMatching)
    if (extraAsAtt != null) {
      var extraResultType = null
      try extraResultType = makeExtendedSequenceType(extraAsAtt)
      catch {
        case e: XPathException =>
          compileErrorInAttribute(e.getMessage, e.getErrorCodeLocalPart, "saxon:as")
          extraResultType = SequenceType.ANY_SEQUENCE // error recovery
      }
      mode.setDefaultResultType(extraResultType)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    checkTopLevel("XTSE0010", false)
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val attValue = att.getValue
      if (f == "streamable" || f == "on-multiple-match" || f == "on-no-match" || f == "warning-on-multiple-match" || f == "warning-on-no-match" || f == "typed") {
        val trimmed = Whitespace.trim(attValue)
        var normalizedAtt = null
        if ("true" == trimmed || "1" == trimmed) normalizedAtt = "yes"
        else if ("false" == trimmed || "0" == trimmed) normalizedAtt = "no"
        else normalizedAtt = trimmed
        mode.getActivePart.setExplicitProperty(f, normalizedAtt, decl.getPrecedence)
        if (mode.isMustBeTyped && getContainingPackage.getTargetEdition.matches("JS\\d?")) compileWarning("In Saxon-JS, all data is untyped", "XTTE3110")
      }
      else if (f == "use-accumulators" && accumulators != null /*Can be null after an error*/ ) {
        val names = new Array[String](accumulators.size)
        var i = 0
        import scala.collection.JavaConversions._
        for (acc <- accumulators) {
          names({
            i += 1; i - 1
          }) = acc.getAccumulatorName.getEQName
        }
        util.Arrays.sort(names)
        val allNames = util.Arrays.toString(names)
        mode.getActivePart.setExplicitProperty(f, allNames, decl.getPrecedence)
      }
    }
    checkEmpty()
    checkTopLevel("XTSE0010", false)
  }

  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = {
    val pack = getPrincipalStylesheetModule.getStylesheetPackage
    val c = pack.getComponent(mode.getSymbolicName)
    if (c == null) throw new AssertionError
    if (accumulators != null) mode.setAccumulators(accumulators)
  }
}