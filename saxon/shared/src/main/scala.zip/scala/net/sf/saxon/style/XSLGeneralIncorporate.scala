////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.functions.DocumentFn
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.DocumentURI
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.linked.DocumentImpl
import net.sf.saxon.tree.linked.ElementImpl
import net.sf.saxon.value.Whitespace
import javax.xml.transform.Source
import javax.xml.transform.URIResolver

/**
 * Abstract class to represent an xsl:include or xsl:import element in the stylesheet.
 * The xsl:include and xsl:import elements have mandatory attribute href
 */
abstract class XSLGeneralIncorporate extends StyleElement {
  private var href = null
  private var targetDoc = null

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  /**
   * isImport() returns true if this is an xsl:import declaration rather than an xsl:include
   *
   * @return true if this is an xsl:import declaration, false if it is an xsl:include
   */
  def isImport

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "href") href = Whitespace.trim(value)
      else checkUnknownAttribute(attName)
    }
    if (href == null) reportAbsence("href")
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = validateInstruction()

  def validateInstruction() = {
    checkEmpty()
    checkTopLevel(if (isImport) "XTSE0190"
    else "XTSE0170", false)
  }

  /**
   * Get the included or imported stylesheet module
   *
   * @param importer   the module that requested the include or import (used to check for cycles)
   * @param precedence the import precedence to be allocated to the included or imported module
   * @return the xsl:stylesheet element at the root of the included/imported module
   */
  /*@Nullable*/ def getIncludedStylesheet(importer: StylesheetModule, precedence: Int): StylesheetModule = {
    if (href == null) { // error already reported
      return null
    }
    //checkEmpty();
    //checkTopLevel((this instanceof XSLInclude ? "XTSE0170" : "XTSE0190"));
    try {
      val psm = importer.getPrincipalStylesheetModule
      //PreparedStylesheet pss = psm.getPreparedStylesheet();
      val resolver = getCompilation.getCompilerInfo.getURIResolver
      val config = getConfiguration
      var includedSheet = null
      var incModule = null
      val key = DocumentFn.computeDocumentKey(href, getBaseURI, getCompilation.getPackageData, resolver, false)
      includedSheet = psm.getStylesheetDocument(key).asInstanceOf[XSLStylesheet]
      if (includedSheet != null) { // we already have the stylesheet document in cache; but we need to create a new module,
        // because the import precedence might be different. See test impincl30.
        incModule = new StylesheetModule(includedSheet, precedence)
        incModule.setImporter(importer)
        // check for recursion
        if (checkForRecursion(importer, incModule.getRootElement)) return null
      }
      else { //                Map<DocumentURI, TreeInfo> map = getCompilation().getStylesheetModules();
        //                DocumentImpl includedDoc = (DocumentImpl)map.get(key);
        var includedDoc = targetDoc
        assert(includedDoc != null)
        var outermost = includedDoc.getDocumentElement
        if (outermost.isInstanceOf[LiteralResultElement]) {
          includedDoc = outermost.asInstanceOf[LiteralResultElement].makeStylesheet(false)
          outermost = includedDoc.getDocumentElement
        }
        if (!outermost.isInstanceOf[XSLStylesheet]) {
          val verb = if (this.isInstanceOf[XSLImport]) "Imported"
          else "Included"
          compileError(verb + " document " + href + " is not a stylesheet", "XTSE0165")
          return null
        }
        includedSheet = outermost.asInstanceOf[XSLStylesheet]
        psm.putStylesheetDocument(key, includedSheet)
        incModule = new StylesheetModule(includedSheet, precedence)
        incModule.setImporter(importer)
        val decl = new ComponentDeclaration(incModule, includedSheet)
        includedSheet.validate(decl)
        if (includedSheet.validationError != null) if (reportingCircumstances eq OnFailure.REPORT_ALWAYS) includedSheet.compileError(includedSheet.validationError)
        else if (includedSheet.reportingCircumstances eq OnFailure.REPORT_UNLESS_FORWARDS_COMPATIBLE) { // not sure if this can still happen
          /*&& !incSheet.forwardsCompatibleModeIsEnabled()*/ includedSheet.compileError(includedSheet.validationError)
        }
      }
      incModule.spliceIncludes() // resolve any nested imports and includes;
      // Check the consistency of input-type-annotations
      //assert thisSheet != null;
      importer.setInputTypeAnnotations(includedSheet.getInputTypeAnnotationsAttribute | incModule.getInputTypeAnnotations)
      incModule
    } catch {
      case err: XPathException =>
        err.setErrorCode("XTSE0165")
        err.setIsStaticError(true)
        compileError(err)
        null
    }
  }

  def setTargetDocument(doc: DocumentImpl) = this.targetDoc = doc

  private def checkForRecursion(importer: StylesheetModule, source: Source): Boolean = {
    var anc = importer
    if (source.getSystemId != null) while ( {
      anc != null
    }) {
      if (DocumentURI.normalizeURI(source.getSystemId) == DocumentURI.normalizeURI(anc.getRootElement.getSystemId)) {
        compileError("A stylesheet cannot " + getLocalPart + " itself", if (this.isInstanceOf[XSLInclude]) "XTSE0180"
        else "XTSE0210")
        return true
      }
      anc = anc.getImporter
    }
    false
  }

  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = {
    // no action. The node will never be compiled, because it replaces itself
    // by the contents of the included file.
  }
}