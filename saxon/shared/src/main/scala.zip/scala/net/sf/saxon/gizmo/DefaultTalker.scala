////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package net.sf.saxon.gizmo

import java.io.InputStream
import java.io.PrintStream
import java.util.NoSuchElementException
import java.util.Scanner


class DefaultTalker() extends Talker {
  new DefaultTalker(System.in, System.out)
  private var in = null
  private var output = null

  def this(in: InputStream, out: PrintStream) {
    this()
    this.in = new Scanner(in)
    this.output = out
  }

  /**
   * Send some output to the user and get some input back
   *
   * @param message output to be sent to the user
   * @return the user's response
   */
  override def exchange(message: String): String = {
    if (message != null && !message.isEmpty) output.println(message)
    try {
      val response = in.nextLine
      if (response == null) ""
      else response.trim
    } catch {
      case e: NoSuchElementException =>
        ""
    }
  }
}

