////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NamespaceBinding
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * An xsl:namespace-alias element in the stylesheet. <br>
 */
class XSLNamespaceAlias extends StyleElement {
  private var stylesheetURI = null
  private var resultNamespaceBinding = null

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  override def prepareAttributes(): Unit = {
    var stylesheetPrefix = null
    var resultPrefix = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "stylesheet-prefix") stylesheetPrefix = Whitespace.trim(value)
      else if (f == "result-prefix") resultPrefix = Whitespace.trim(value)
      else checkUnknownAttribute(attName)
    }
    if (stylesheetPrefix == null) {
      reportAbsence("stylesheet-prefix")
      stylesheetPrefix = ""
    }
    if (stylesheetPrefix == "#default") stylesheetPrefix = ""
    if (resultPrefix == null) {
      reportAbsence("result-prefix")
      resultPrefix = ""
    }
    if (resultPrefix == "#default") resultPrefix = ""
    stylesheetURI = getURIForPrefix(stylesheetPrefix, true)
    if (stylesheetURI == null) {
      compileError("stylesheet-prefix " + stylesheetPrefix + " has not been declared", "XTSE0812")
      // recovery action
      stylesheetURI = ""
      resultNamespaceBinding = NamespaceBinding.DEFAULT_UNDECLARATION
      return
    }
    var resultURI = getURIForPrefix(resultPrefix, true)
    if (resultURI == null) {
      compileError("result-prefix " + resultPrefix + " has not been declared", "XTSE0812")
      stylesheetURI = ""
      resultURI = ""
    }
    resultNamespaceBinding = new NamespaceBinding(resultPrefix, resultURI)
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = checkTopLevel("XTSE0010", false)

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = null

  @throws[XPathException]
  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = top.addNamespaceAlias(decl)

  def getStylesheetURI = stylesheetURI

  def getResultNamespaceBinding = resultNamespaceBinding
}