////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.WherePopulated
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * An xsl:where-populated element in the stylesheet.
 */
final class XSLWherePopulated extends StyleElement {
  private var select = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return in XSLT 2.0, false. In XSLT 3.0 true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  /**
   * Determine whether this type of element is allowed to contain an xsl:fallback
   * instruction
   */
  override def mayContainFallback = true

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    // no action
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    if (select == null) select = compileSequenceConstructor(exec, decl, false)
    new WherePopulated(select)
  }
}