////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

/**
 * A QName triple (prefix, URI, local) with the additional ability to hold an integer fingerprint.
 * The integer fingerprint provides a fast way of checking equality. A FingerprintedQName makes sense
 * only in the context of a known NamePool, and instances must be compared only if they relate to the
 * same NamePool. The fingerprint is optional, and is used only if present.
 */
object FingerprintedQName {
  /**
   * Make a FingerprintedQName from a Clark name
   *
   * @param expandedName the name in Clark notation "{uri}local" if in a namespace, or "local" otherwise.
   *                     The format "{}local" is also accepted for a name in no namespace.
   * @return the constructed FingerprintedQName
   * @throws IllegalArgumentException if the Clark name is malformed
   */
    def fromClarkName(expandedName: String) = {
      var namespace = null
      var localName = null
      if (expandedName.charAt(0) == '{') {
        val closeBrace = expandedName.indexOf('}')
        if (closeBrace < 0) throw new IllegalArgumentException("No closing '}' in Clark name")
        namespace = expandedName.substring(1, closeBrace)
        if (closeBrace == expandedName.length) throw new IllegalArgumentException("Missing local part in Clark name")
        localName = expandedName.substring(closeBrace + 1)
      }
      else {
        namespace = ""
        localName = expandedName
      }
      new FingerprintedQName("", namespace, localName)
    }

  /**
   * Make a FingerprintedQName from a Clark name
   *
   * @param expandedName the name in EQName notation "Q{uri}local" if in a namespace, or "local" otherwise.
   *                     The format "Q{}local" is also accepted for a name in no namespace.
   * @return the constructed FingerprintedQName
   * @throws IllegalArgumentException if the EQName name is malformed
   */
  def fromEQName(expandedName: String) = {
    var namespace = null
    var localName = null
    if (expandedName.startsWith("Q{")) {
      val closeBrace = expandedName.indexOf('}', 2)
      if (closeBrace < 0) throw new IllegalArgumentException("No closing '}' in EQName")
      namespace = expandedName.substring(2, closeBrace)
      if (closeBrace == expandedName.length) throw new IllegalArgumentException("Missing local part in EQName")
      localName = expandedName.substring(closeBrace + 1)
    }
    else {
      namespace = ""
      localName = expandedName
    }
    new FingerprintedQName("", namespace, localName)
  }
}

class FingerprintedQName extends NodeName {
  private var qName = null
  private var fingerprint = -1

  def this(prefix: String, uri: String, localName: String) {
    this()
    qName = new StructuredQName(prefix, uri, localName)
  }

  def this(prefix: String, uri: String, localName: String, fingerprint: Int) {
    this()
    qName = new StructuredQName(prefix, uri, localName)
    this.fingerprint = fingerprint
  }

  def this(prefix: String, uri: String, localName: String, pool: NamePool) {
    this()
    qName = new StructuredQName(prefix, uri, localName)
    this.fingerprint = pool.allocateFingerprint(uri, localName)
  }

  def this(qName: StructuredQName, fingerprint: Int) {
    this()
    this.qName = qName
    this.fingerprint = fingerprint
  }

  def this(qName: StructuredQName, pool: NamePool) {
    this()
    this.qName = qName
    this.fingerprint = pool.allocateFingerprint(qName.getURI, qName.getLocalPart)
  }

  /**
   * Ask whether this node name representation has a known namecode and fingerprint
   *
   * @return true if the methods getFingerprint() and getNameCode() will
   *         return a result other than -1
   */
  override def hasFingerprint = fingerprint != -1

  /**
   * Get the fingerprint of this name if known. This method should not to any work to allocate
   * a fingerprint if none is already available
   *
   * @return the fingerprint if known; otherwise -1
   */
  override def getFingerprint = fingerprint

  /**
   * Get the fingerprint of this name, allocating a new code from the namepool if necessary
   *
   * @param pool the NamePool used to allocate the name
   * @return a fingerprint for this name, newly allocated if necessary
   */
  override def obtainFingerprint(pool: NamePool) = {
    if (fingerprint == -1) fingerprint = pool.allocateFingerprint(getURI, getLocalPart)
    fingerprint
  }

  /**
   * Get the display name, that is the lexical QName in the form [prefix:]local-part
   *
   * @return the lexical QName
   */
  override def getDisplayName = qName.getDisplayName

  /**
   * Get the prefix of the QName.
   *
   * @return the prefix. Returns the empty string if the name is unprefixed.
   */
  override def getPrefix = qName.getPrefix

  /**
   * Get the namespace URI of the QName.
   *
   * @return the URI. Returns the empty string to represent the no-namespace
   */
  override def getURI = qName.getURI

  /**
   * Get the local part of the QName
   *
   * @return the local part of the QName
   */
  override def getLocalPart = qName.getLocalPart

  /**
   * Get the name in the form of a StructuredQName
   *
   * @return the name in the form of a StructuredQName
   */
  override def getStructuredQName = qName

  /**
   * Test whether this name is in a given namespace
   *
   * @param ns the namespace to be tested against
   * @return true if the name is in the specified namespace
   */
  override def hasURI(ns: String) = qName.hasURI(ns)

  /**
   * Get a {@link NamespaceBinding} whose (prefix, uri) pair are the prefix and URI of this
   * node name
   *
   * @return the corresponding NamespaceBinding
   */
  override def getNamespaceBinding = qName.getNamespaceBinding

  /**
   * Get a hashCode that offers the guarantee that if A.isIdentical(B), then A.identityHashCode() == B.identityHashCode()
   *
   * @return a hashCode suitable for use when testing for identity.
   */
  override def identityHashCode = 0

  override def equals(/*@NotNull*/ other: Any) = if (other.isInstanceOf[NodeName]) if (fingerprint != -1 && other.asInstanceOf[NodeName].hasFingerprint()) getFingerprint == other.asInstanceOf[NodeName].getFingerprint()
  else getLocalPart == other.asInstanceOf[NodeName].getLocalPart() && hasURI(other.asInstanceOf[NodeName].getURI())
  else false

  /**
   * Returns a hash code value for the object.
   */
  override def hashCode = qName.hashCode

  /**
   * Determine whether two IdentityComparable objects are identical. This is a stronger
   * test than equality (even schema-equality); for example two dateTime values are not identical unless
   * they are in the same timezone.
   *
   * @param other the other value
   * @return true if the tConfiguration.scalawo values are indentical, false otherwise
   */
  override def isIdentical(other: IdentityComparable) = other.isInstanceOf[NodeName] && this == other && this.getPrefix == other.asInstanceOf[NodeName].getPrefix()

  override def toString = qName.getDisplayName
}