////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.sort.AtomicMatchKey
import net.sf.saxon.expr.sort.AtomicSortComparer
import net.sf.saxon.expr.sort.DoubleSortComparer
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ValidationException
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * A numeric (double precision floating point) value
 */
object DoubleValue {
  val ZERO = new DoubleValue(0.0)
  val NEGATIVE_ZERO = new DoubleValue(-0.0)
  val ONE = new DoubleValue(1.0)
  val NaN = new DoubleValue(Double.NaN)

  /**
   * Static factory method (for convenience in compiled bytecode)
   *
   * @param value the value of the double
   * @return a new DoubleValue
   */
  def makeDoubleValue(value: Double) = new DoubleValue(value)

  /**
   * Internal method used for conversion of a double to a string
   *
   * @param value the actual value
   * @return the value converted to a string, according to the XPath casting rules.
   */
  def doubleToString(value: Double) = FloatingPointConverter.appendDouble(new FastStringBuffer(FastStringBuffer.C16), value, false)
}

final class DoubleValue extends NumericValue {
  private var value = .0

  /**
   * Constructor supplying a double
   *
   * @param value the value of the NumericValue
   */
  def this(value: Double) {
    this()
    this.value = value
    typeLabel = BuiltInAtomicType.DOUBLE
  }

  /**
   * Constructor supplying a double and an AtomicType, for creating
   * a value that belongs to a user-defined subtype of xs:double. It is
   * the caller's responsibility to ensure that the supplied value conforms
   * to the supplied type.
   *
   * @param value the value of the NumericValue
   * @param type  the type of the value. This must be a subtype of xs:double, and the
   *              value must conform to this type. The methosd does not check these conditions.
   */
  def this(value: Double, `type`: AtomicType) {
    this()
    this.value = value
    typeLabel = `type`
  }

  /**
   * Create a copy of this atomic value, with a different type label
   *
   * @param typeLabel the type label of the new copy. The caller is responsible for checking that
   *                  the value actually conforms to this type.
   */
  /*@NotNull*/ override def copyAsSubType(typeLabel: AtomicType) = {
    val v = new DoubleValue(value)
    v.typeLabel = typeLabel
    v
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.DOUBLE

  /**
   * Return this numeric value as a double
   *
   * @return the value as a double
   */
  override def getDoubleValue = value

  /**
   * Get the numeric value converted to a float
   *
   * @return a float representing this numeric value; NaN if it cannot be converted
   */
  override def getFloatValue = value.toFloat

  /**
   * Get the numeric value converted to a decimal
   *
   * @return a decimal representing this numeric value;
   * @throws ValidationException
   * if the value cannot be converted, for example if it is NaN or infinite
   */
  @throws[ValidationException]
  override def getDecimalValue = try new BigDecimal(value)
  catch {
    case e: NumberFormatException =>
      throw new ValidationException(e)
  }

  /**
   * Return the numeric value as a Java long.
   *
   * @return the numeric value as a Java long. This performs truncation
   *         towards zero.
   * @throws net.sf.saxon.trans.XPathException
   * if the value cannot be converted
   */
  @throws[XPathException]
  override def longValue = value.toLong

  /**
   * Get the hashCode. This must conform to the rules for other NumericValue hashcodes
   *
   * @see NumericValue#hashCode
   */
  override def hashCode = if (value > Integer.MIN_VALUE && value < Integer.MAX_VALUE) value.toInt
  else Double.valueOf(value).hashCode

  /**
   * Test whether the value is the double/float value NaN
   */
  override def isNaN = Double.isNaN(value)

  /**
   * Get the effective boolean value
   *
   * @return the effective boolean value (true unless the value is zero or NaN)
   */
  override def effectiveBooleanValue = value != 0.0 && !Double.isNaN(value)

  /**
   * Convert the double to a string according to the XPath 2.0 rules
   *
   * @return the string value
   */
  override def getPrimitiveStringValue = DoubleValue.doubleToString(value)

  /**
   * Get the canonical lexical representation as defined in XML Schema. This is not always the same
   * as the result of casting to a string according to the XPath rules. For xs:double, the canonical
   * representation always uses exponential notation.
   */
  override def getCanonicalLexicalRepresentation = {
    val fsb = new FastStringBuffer(FastStringBuffer.C16)
    FloatingPointConverter.appendDouble(fsb, value, true)
  }

  /**
   * Negate the value
   */
  override def negate = new DoubleValue(-value)

  /**
   * Implement the XPath floor() function
   */
  override def floor = new DoubleValue(Math.floor(value))

  /**
   * Implement the XPath ceiling() function
   */
  override def ceiling = new DoubleValue(Math.ceil(value))

  /**
   * Implement the XPath round() function
   */
  override def round(scale: Int): NumericValue = {
    if (Double.isNaN(value)) return this
    if (Double.isInfinite(value)) return this
    if (value == 0.0) return this // handles the negative zero case
    if (scale == 0 && value > Long.MIN_VALUE && value < Long.MAX_VALUE) {
      if (value >= -0.5 && value < 0.0) return new DoubleValue(-0.0)
      return new DoubleValue(value.round)
    }
    // Convert to a scaled integer, by multiplying by 10^scale
    val factor = Math.pow(10, scale + 1)
    var d = Math.abs(value * factor)
    if (Double.isInfinite(d)) { // double arithmetic has overflowed - do it in decimal
      var dec = new BigDecimal(value)
      dec = dec.setScale(scale, RoundingMode.HALF_UP)
      return new DoubleValue(dec.doubleValue)
    }
    // Now apply any rounding needed, using the "round half to even" rule***CHANGE
    val rem = d % 10
    if (rem >= 5) d += 10 - rem
    else if (rem < 5) d -= rem
    // Now convert back to the original magnitude
    d /= factor
    if (value < 0) d = -d
    new DoubleValue(d)
  }

  /**
   * Implement the XPath round-to-half-even() function
   */
  override def roundHalfToEven(scale: Int): NumericValue = {
    if (Double.isNaN(value)) return this
    if (Double.isInfinite(value)) return this
    if (value == 0.0) return this
    val factor = Math.pow(10, scale + 1)
    var d = Math.abs(value * factor)
    if (Double.isInfinite(d)) {
      var dec = new BigDecimal(value)
      dec = dec.setScale(scale, RoundingMode.HALF_EVEN)
      return new DoubleValue(dec.doubleValue)
    }
    // Now apply any rounding needed, using the "round half to even" rule
    val rem = d % 10
    if (rem > 5) d += 10 - rem
    else if (rem < 5) d -= rem
    else { // round half to even - check the last bit
      if ((d % 20) == 15) d += 5
      else d -= 5
    }
    d /= factor
    if (value < 0) d = -d
    new DoubleValue(d)
  }

  /**
   * Determine whether the value is negative, zero, or positive
   *
   * @return -1 if negative, 0 if zero (including negative zero) or NaN, +1 if positive
   */
  override def signum: Int = {
    if (Double.isNaN(value)) return 0
    if (value > 0) 1
    else if (value == 0) 0
    else -1
  }

  /**
   * Ask whether this value is negative zero
   *
   * @return true if this value is float or double negative zero
   */
  override def isNegativeZero = value == 0.0 && ((Double.doubleToLongBits(value) & FloatingPointConverter.DOUBLE_SIGN_MASK) ne 0)

  /**
   * Determine whether the value is a whole number, that is, whether it compares
   * equal to some integer
   */
  override def isWholeNumber = value == Math.floor(value) && !Double.isInfinite(value)

  /**
   * Test whether a number is a possible subscript into a sequence, that is,
   * a whole number greater than zero and less than 2^31
   *
   *
   * @return the number as an int if it is a possible subscript, or -1 otherwise
   */
  override def asSubscript = if (isWholeNumber && value > 0 && value <= Integer.MAX_VALUE) value.toInt
  else -1

  /**
   * Get the absolute value as defined by the XPath abs() function
   *
   * @return the absolute value
   * @since 9.2
   */
  override def abs = if (value > 0.0) this
  else new DoubleValue(Math.abs(value))

  /**
   * Compare the value to a long.
   *
   * @param other the value to be compared with
   * @return -1 if this is less, 0 if this is equal, +1 if this is greater or if this is NaN
   */
  override def compareTo(other: Long): Int = {
    val otherDouble = other.toDouble
    if (value == otherDouble) return 0
    if (value < otherDouble) -1
    else +1
  }

  /**
   * Get an object that implements XML Schema comparison semantics
   */
  override def getSchemaComparable = { // Convert negative to positive zero because Double.compareTo() does the wrong thing
    // Note that for NaN, we return NaN, and rely on the user of the Comparable to use it in a way
    // that ensures NaN != NaN.
    if (value == 0.0) 0.0
    else value
  }

  /**
   * Get a value whose equals() method follows the "same key" rules for comparing the keys of a map.
   *
   * @return a value with the property that the equals() and hashCode() methods follow the rules for comparing
   *         keys in maps.
   */
  override def asMapKey = if (isNaN) AtomicSortComparer.COLLATION_KEY_NaN
  else if (Double.isInfinite(value)) this
  else try new BigDecimalValue(value)
  catch {
    case e: ValidationException =>
      // We have already ruled out the values that fail (NaN and INF)
      throw new AssertionError(e)
  }

  /**
   * Determine whether two atomic values are identical, as determined by XML Schema rules. This is a stronger
   * test than equality (even schema-equality); for example two dateTime values are not identical unless
   * they are in the same timezone.
   * <p>Note that even this check ignores the type annotation of the value. The integer 3 and the short 3
   * are considered identical, even though they are not fully interchangeable. "Identical" means the
   * same point in the value space, regardless of type annotation.</p>
   * <p>NaN is identical to itself.</p>
   *
   * @param v the other value to be compared with this one
   * @return true if the two values are identical, false otherwise.
   */
  override def isIdentical(v: AtomicValue) = v.isInstanceOf[DoubleValue] && DoubleSortComparer.getInstance.comparesEqual(this, v)

  /*
       * Diagnostic method: print the sign, exponent, and significand
       * @param d the double to be diagnosed
       */
  //    public static void printInternalForm(double d) {
  //        System.err.println("==== Double " + d + " ====");
  //        long bits = Double.doubleToLongBits(d);
  //        System.err.println("Internal form: " + Long.toHexString(bits));
  //        if (bits == 0x7ff0000000000000L) {
  //            System.err.println("+Infinity");
  //        } else if (bits == 0xfff0000000000000L) {
  //            System.err.println("-Infinity");
  //        } else if (bits == 0x7ff8000000000000L) {
  //            System.err.println("NaN");
  //        } else {
  //            int s = ((bits >> 63) == 0) ? 1 : -1;
  //            int e = (int)((bits >> 52) & 0x7ffL);
  //            long m = (e == 0) ?
  //                             (bits & 0xfffffffffffffL) << 1 :
  //                             (bits & 0xfffffffffffffL) | 0x10000000000000L;
  //            int exponent = e-1075;
  //            System.err.println("Sign: " + s);
  //            System.err.println("Raw Exponent: " + e);
  //            System.err.println("Exponent: " + exponent);
  //            System.err.println("Significand: " + m);
  //            BigDecimal dec = BigDecimal.valueOf(m);
  //            if (exponent > 0) {
  //                dec = dec.multiply(new BigDecimal(BigInteger.valueOf(2).pow(exponent)));
  //            } else {
  //                // Next line is sometimes failing, e.g. on -3.62e-5. Not investigated.
  //                dec = dec.divide(new BigDecimal(BigInteger.valueOf(2).pow(-exponent)), BigDecimal.ROUND_HALF_EVEN);
  //            }
  //            System.err.println("Exact value: " + (s>0?"":"-") + dec);
  //        }
  //    }
  //    public static DoubleValue fromInternalForm(String hex) {
  //        return new DoubleValue(Double.longBitsToDouble(Long.parseLong(hex, 16)));
  //
}