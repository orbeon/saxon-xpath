////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.Calculator
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ValidationFailure
import net.sf.saxon.om.SequenceTool
import net.sf.saxon.om.StandardNames
import net.sf.saxon.trans.XPathException
import java.math.BigDecimal
import java.math.BigInteger

/**
 * An integer value: note this is a subtype of decimal in XML Schema, not a primitive type.
 * The abstract class IntegerValue is used to represent any xs:integer value; this implementation
 * is used for values that do not fit comfortably in a Java long; including the built-in subtype xs:unsignedLong
 */
object BigIntegerValue {
  private val MAX_INT = BigInteger.valueOf(Integer.MAX_VALUE)
  private val MIN_INT = BigInteger.valueOf(Integer.MIN_VALUE)
  val MAX_LONG = BigInteger.valueOf(Long.MAX_VALUE)
  val MIN_LONG = BigInteger.valueOf(Long.MIN_VALUE)
  /*@NotNull*/ val MAX_UNSIGNED_LONG = new BigInteger("18446744073709551615")
  val ZERO = new BigIntegerValue(BigInteger.ZERO)

  /**
   * A Comparable that performs comparison of BigInteger values either with other
   * BigInteger values or with other representations of XPath numeric values
   */
  protected class BigIntegerComparable(var value: BigIntegerValue) extends Comparable[_] {
    def asBigInteger = value.asBigInteger

    override def compareTo(o: Any) = if (o.isInstanceOf[Int64Value.Int64Comparable]) asBigInteger.compareTo(BigInteger.valueOf(o.asInstanceOf[Int64Value.Int64Comparable].asLong()))
    else if (o.isInstanceOf[BigIntegerValue.BigIntegerComparable]) asBigInteger.compareTo(o.asInstanceOf[BigIntegerValue.BigIntegerComparable].asBigInteger)
    else if (o.isInstanceOf[BigDecimalValue.DecimalComparable]) value.getDecimalValue.compareTo(o.asInstanceOf[BigDecimalValue.DecimalComparable].asBigDecimal)
    else SequenceTool.INDETERMINATE_ORDERING

    override def equals(o: Any) = compareTo(o) == 0

    override def hashCode: Int = { // Must align with hashCodes for other subtypes of xs:decimal
      val big = value.asBigInteger
      if (big.compareTo(MAX_LONG) < 0 && big.compareTo(MIN_LONG) > 0) {
        val iv = new Int64Value(big.longValue)
        return iv.hashCode
      }
      big.hashCode
    }
  }

}

final class BigIntegerValue extends IntegerValue {
  private var value = null

  /**
   * Construct an xs:integer value from a Java BigInteger
   *
   * @param value the supplied BigInteger
   */
  def this(value: BigInteger) {
    this()
    this.value = value
    typeLabel = BuiltInAtomicType.INTEGER
  }

  /**
   * Construct an xs:integer value from a Java BigInteger, supplying a type label.
   * It is the caller's responsibility to ensure that the supplied value conforms
   * with the rules for the specified type.
   *
   * @param value     the value of the integer
   * @param typeLabel the type, which must represent a type derived from xs:integer
   */
  def this(value: BigInteger, typeLabel: AtomicType) {
    this()
    this.value = value
    this.typeLabel = typeLabel
  }

  /**
   * Construct an xs:integer value from a Java long. Note: normally, if the value fits in a long,
   * then an Int64Value should be used. This constructor is largely for internal use, when operations
   * are required that require two integers to use the same implementation class to be used.
   *
   * @param value the supplied Java long
   */
  def this(value: Long) {
    this()
    this.value = BigInteger.valueOf(value)
    typeLabel = BuiltInAtomicType.INTEGER
  }

  /**
   * Create a copy of this atomic value, with a different type label
   *
   * @param typeLabel the type label of the new copy. The caller is responsible for checking that
   *                  the value actually conforms to this type.
   */
  override def copyAsSubType(typeLabel: AtomicType) = if (typeLabel.getPrimitiveType == StandardNames.XS_INTEGER) {
    val v = new BigIntegerValue(value)
    v.typeLabel = typeLabel
    v
  }
  else new BigDecimalValue(new BigDecimal(value))

  /**
   * This class allows subtypes of xs:integer to be held, as well as xs:integer values.
   * This method sets the required type label. Note that this method modifies the value in situ.
   *
   * @param type the subtype of integer required
   * @return null if the operation succeeds, or a ValidationException if the value is out of range
   */
  /*@Nullable*/ override def convertToSubType(`type`: BuiltInAtomicType, validate: Boolean): ValidationFailure = {
    if (!validate) {
      typeLabel = `type`
      return null
    }
    if (IntegerValue.checkBigRange(value, `type`)) {
      typeLabel = `type`
      null
    }
    else {
      val err = new ValidationFailure("Integer value is out of range for subtype " + `type`.getDisplayName)
      err.setErrorCode("FORG0001")
      err
    }
  }

  /**
   * This class allows subtypes of xs:integer to be held, as well as xs:integer values.
   * This method checks that the value is valid against the rules for a given subtype.
   *
   * @param type the subtype of integer required
   * @return null if the operation succeeds, or a ValidationException if the value is out of range
   */
  override def validateAgainstSubType(`type`: BuiltInAtomicType) = if (IntegerValue.checkBigRange(value, `type`)) {
    typeLabel = `type`
    null
  }
  else {
    val err = new ValidationFailure("Integer value is out of range for subtype " + `type`.getDisplayName)
    err.setErrorCode("FORG0001")
    err
  }

  /**
   * Get the hashCode. This must conform to the rules for other NumericValue hashcodes
   *
   * @see NumericValue#hashCode
   */
  override def hashCode = if (value.compareTo(BigIntegerValue.MIN_INT) >= 0 && value.compareTo(BigIntegerValue.MAX_INT) <= 0) value.intValue
  else Double.valueOf(getDoubleValue).hashCode

  /**
   * Get the value as a long
   *
   * @return the value of the xs:integer, as a Java long
   */
  override def longValue = value.longValue

  /**
   * Get the value as a BigInteger
   *
   * @return the value of the xs:integer as a Java BigInteger
   */
  override def asBigInteger = value

  /**
   * Test whether the value is within the range that can be held in a 64-bit signed integer
   *
   * @return true if the value is within range for a long
   */
  def isWithinLongRange = value.compareTo(BigIntegerValue.MIN_LONG) >= 0 && value.compareTo(BigIntegerValue.MAX_LONG) <= 0

  /**
   * Convert the value to a BigDecimal
   *
   * @return the resulting BigDecimal
   */
  def asDecimal = new BigDecimal(value)

  /**
   * Return the effective boolean value of this integer
   *
   * @return false if the integer is zero, otherwise true
   */
  override def effectiveBooleanValue = value.compareTo(BigInteger.ZERO) != 0

  /**
   * Compare the value to another numeric value
   *
   * @param other the numeric value to be compared to this value
   * @return -1 if this value is less than the other, 0 if they are equal,
   *         +1 if this value is greater
   */
  override def compareTo(other: NumericValue) = if (other.isInstanceOf[BigIntegerValue]) value.compareTo(other.asInstanceOf[BigIntegerValue].value)
  else if (other.isInstanceOf[Int64Value]) value.compareTo(BigInteger.valueOf(other.asInstanceOf[Int64Value].longValue()))
  else if (other.isInstanceOf[BigDecimalValue]) asDecimal.compareTo(other.asInstanceOf[BigDecimalValue].getDecimalValue)
  else super.compareTo(other)

  /**
   * Compare the value to a long
   *
   * @param other the value to be compared with
   * @return -1 if this is less, 0 if this is equal, +1 if this is greater or if this is NaN
   */
  override def compareTo(other: Long): Int = {
    if (other == 0) return value.signum
    value.compareTo(BigInteger.valueOf(other))
  }

  /**
   * Get the value as a String
   *
   * @return a String representation of the value
   */
  override def getPrimitiveStringValue = value.toString

  /**
   * Get the numeric value as a double
   *
   * @return A double representing this numeric value; NaN if it cannot be
   *         converted
   */
  override def getDoubleValue = value.doubleValue

  /**
   * Get the numeric value converted to a decimal
   *
   * @return a decimal representing this numeric value;
   */
  override def getDecimalValue = new BigDecimal(value)

  /**
   * Get the numeric value converted to a float
   *
   * @return a float representing this numeric value; NaN if it cannot be converted
   */
  override def getFloatValue = getDoubleValue.toFloat

  /**
   * Negate the value
   *
   * @return the result of inverting the sign of the value
   */
  override def negate = new BigIntegerValue(value.negate)

  /**
   * Implement the XPath floor() function
   *
   * @return the integer value, unchanged
   */
  override def floor = this

  /**
   * Implement the XPath ceiling() function
   *
   * @return the integer value, unchanged
   */
  override def ceiling = this

  /**
   * Implement the XPath round() function
   *
   * @return the integer value, unchanged
   */
  override def round(scale: Int) = if (scale >= 0) this
  else {
    val factor = BigInteger.valueOf(10).pow(-scale)
    val pair = value.divideAndRemainder(factor)
    val up = pair(1).compareTo(factor.divide(BigInteger.valueOf(2)))
    if (up >= 0) { // remainder is > .5
      pair(0) = pair(0).add(BigInteger.valueOf(1))
    }
    makeIntegerValue(pair(0).multiply(factor))
  }

  /**
   * Implement the XPath round-to-half-even() function
   *
   * @param scale number of digits required after the decimal point; the
   *              value -2 (for example) means round to a multiple of 100
   * @return if the scale is &gt;=0, return this value unchanged. Otherwise
   *         round it to a multiple of 10**-scale
   */
  override def roundHalfToEven(scale: Int) = if (scale >= 0) this
  else {
    val factor = BigInteger.valueOf(10).pow(-scale)
    val pair = value.divideAndRemainder(factor)
    val up = pair(1).compareTo(factor.divide(BigInteger.valueOf(2)))
    if (up > 0) pair(0) = pair(0).add(BigInteger.valueOf(1))
    else if (up == 0) { // remainder == .5
      if (pair(0).mod(BigInteger.valueOf(2)).signum != 0) { // last digit of quotient is odd: make it even
        pair(0) = pair(0).add(BigInteger.valueOf(1))
      }
    }
    makeIntegerValue(pair(0).multiply(factor))
  }

  /**
   * Determine whether the value is negative, zero, or positive
   *
   * @return -1 if negative, 0 if zero, +1 if positive, NaN if NaN
   */
  override def signum = value.signum

  /**
   * Get the absolute value as defined by the XPath abs() function
   *
   * @return the absolute value
   */
  override def abs = if (value.signum >= 0) this
  else new BigIntegerValue(value.abs)

  /**
   * Determine whether the value is a whole number, that is, whether it compares
   * equal to some integer
   *
   * @return always true for this implementation
   */
  override def isWholeNumber = true

  /**
   * Test whether a number is a possible subscript into a sequence, that is,
   * a whole number greater than zero and less than 2^31
   *
   *
   * @return the number as an int if it is a possible subscript, or -1 otherwise
   */
  override def asSubscript = if (value.compareTo(BigInteger.ZERO) > 0 && value.compareTo(BigIntegerValue.MAX_INT) <= 0) longValue.toInt
  else -1

  /**
   * Add another integer
   */
  override def plus(other: IntegerValue) = if (other.isInstanceOf[BigIntegerValue]) makeIntegerValue(value.add(other.asInstanceOf[BigIntegerValue].value))
  else { //noinspection RedundantCast
    makeIntegerValue(value.add(BigInteger.valueOf(other.asInstanceOf[Int64Value].longValue())))
  }

  /**
   * Subtract another integer
   */
  override def minus(other: IntegerValue) = if (other.isInstanceOf[BigIntegerValue]) makeIntegerValue(value.subtract(other.asInstanceOf[BigIntegerValue].value))
  else makeIntegerValue(value.subtract(BigInteger.valueOf(other.asInstanceOf[Int64Value].longValue())))

  /**
   * Multiply by another integer
   */
  override def times(other: IntegerValue) = if (other.isInstanceOf[BigIntegerValue]) makeIntegerValue(value.multiply(other.asInstanceOf[BigIntegerValue].value))
  else makeIntegerValue(value.multiply(BigInteger.valueOf(other.asInstanceOf[Int64Value].longValue())))

  /**
   * Divide by another integer
   *
   * @throws net.sf.saxon.trans.XPathException
   * if the other integer is zero
   */
  @throws[XPathException]
  override def div(other: IntegerValue) = {
    var oi = null
    if (other.isInstanceOf[BigIntegerValue]) oi = other.asInstanceOf[BigIntegerValue].value
    else oi = BigInteger.valueOf(other.longValue)
    val a = new BigDecimalValue(new BigDecimal(value))
    val b = new BigDecimalValue(new BigDecimal(oi))
    Calculator.decimalDivide(a, b)
  }

  /**
   * Take modulo another integer
   *
   * @throws net.sf.saxon.trans.XPathException
   * if the other integer is zero
   */
  @throws[XPathException]
  override def mod(other: IntegerValue) = try if (other.isInstanceOf[BigIntegerValue]) makeIntegerValue(value.remainder(other.asInstanceOf[BigIntegerValue].value))
  else makeIntegerValue(value.remainder(BigInteger.valueOf(other.longValue)))
  catch {
    case err: ArithmeticException =>
      var e = null
      if (BigInteger.valueOf(other.longValue).signum == 0) e = new XPathException("Integer modulo zero", "FOAR0001")
      else e = new XPathException("Integer mod operation failure", err)
      throw e
  }

  /**
   * Integer divide by another integer
   *
   * @throws net.sf.saxon.trans.XPathException
   * if the other integer is zero
   */
  @throws[XPathException]
  override def idiv(other: IntegerValue) = {
    var oi = null
    if (other.isInstanceOf[BigIntegerValue]) oi = other.asInstanceOf[BigIntegerValue].value
    else oi = BigInteger.valueOf(other.longValue)
    try makeIntegerValue(value.divide(oi))
    catch {
      case err: ArithmeticException =>
        var e = null
        if ("/ by zero" == err.getMessage) e = new XPathException("Integer division by zero", "FOAR0001")
        else e = new XPathException("Integer division failure", err)
        throw e
    }
  }

  /**
   * Get an object that implements XML Schema comparison semantics
   */
  override def getSchemaComparable = new BigIntegerValue.BigIntegerComparable(this)

  /**
   * Reduce a value to its simplest form.
   */
  override def reduce: IntegerValue = {
    if (compareTo(Long.MAX_VALUE) < 0 && compareTo(Long.MIN_VALUE) > 0) {
      val iv = new Int64Value(longValue)
      iv.setTypeLabel(typeLabel)
      return iv
    }
    this
  }

  override def asAtomic = this
}