////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.instruct.Choose
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.BooleanValue
import java.util

/**
 * An xsl:choose elements in the stylesheet. <br>
 */
class XSLChoose extends StyleElement {
  private var otherwise = null
  private var numberOfWhens = 0

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    import scala.collection.JavaConversions._
    for (curr <- children) {
      if (curr.isInstanceOf[XSLWhen]) {
        if (otherwise != null) otherwise.compileError("xsl:otherwise must come last", "XTSE0010")
        numberOfWhens += 1
      }
      else if (curr.isInstanceOf[XSLOtherwise]) if (otherwise != null) curr.asInstanceOf[XSLOtherwise].compileError("Only one xsl:otherwise is allowed in an xsl:choose", "XTSE0010")
      else otherwise = curr.asInstanceOf[StyleElement]
      else if (curr.isInstanceOf[StyleElement]) curr.asInstanceOf[StyleElement].compileError("Only xsl:when and xsl:otherwise are allowed here", "XTSE0010")
      else compileError("Only xsl:when and xsl:otherwise are allowed within xsl:choose", "XTSE0010")
    }
    if (numberOfWhens == 0) compileError("xsl:choose must contain at least one xsl:when", "XTSE0010")
  }

  /**
   * Mark tail-recursive calls on templates and functions.
   */
  override def markTailCalls = {
    var found = false
    import scala.collection.JavaConversions._
    for (curr <- children(classOf[StyleElement].isInstance)) {
      found |= curr.asInstanceOf[StyleElement].markTailCalls
    }
    found
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = {
    var entries = numberOfWhens + (if (otherwise == null) 0
    else 1)
    var conditions = new Array[Expression](entries)
    var actions = new Array[Expression](entries)
    var w = 0
    import scala.collection.JavaConversions._
    for (curr <- children) {
      if (curr.isInstanceOf[XSLWhen]) {
        conditions(w) = curr.asInstanceOf[XSLWhen].getCondition
        var b = curr.asInstanceOf[XSLWhen].compileSequenceConstructor(exec, decl, true)
        if (b == null) b = Literal.makeEmptySequence
        try {
          b = b.simplify
          actions(w) = b
        } catch {
          case e: XPathException =>
            compileError(e)
        }
        if (getCompilation.getCompilerInfo.isCompileWithTracing) actions(w) = makeTraceInstruction(curr.asInstanceOf[XSLWhen], actions(w))
        // Optimize for constant conditions (true or false)
        if (conditions(w).isInstanceOf[Literal] && conditions(w).asInstanceOf[Literal].getValue.isInstanceOf[BooleanValue]) if ((conditions(w).asInstanceOf[Literal]).getValue.asInstanceOf[BooleanValue].getBooleanValue) { // constant true: truncate the tests here
          entries = w + 1
          break //todo: break is not supported
        }
        else { // constant false: omit this test
          w -= 1
          entries -= 1
        }
        w += 1
      }
      else if (curr.isInstanceOf[XSLOtherwise]) {
        val otherwise = Literal.makeLiteral(BooleanValue.TRUE)
        otherwise.setRetainedStaticContext(makeRetainedStaticContext)
        conditions(w) = otherwise
        var b = curr.asInstanceOf[XSLOtherwise].compileSequenceConstructor(exec, decl, true)
        if (b == null) {
          b = Literal.makeEmptySequence
          b.setRetainedStaticContext(makeRetainedStaticContext)
        }
        try {
          b = b.simplify
          actions(w) = b
        } catch {
          case e: XPathException =>
            compileError(e)
        }
        if (getCompilation.getCompilerInfo.isCompileWithTracing) actions(w) = makeTraceInstruction(curr.asInstanceOf[XSLOtherwise], actions(w))
        w += 1
      }
      else {
        // Ignore: problem has already been reported.
      }
    }
    if (conditions.length != entries) { // we've optimized some entries away
      if (entries == 0) return null // return a no-op
      if (entries == 1 && conditions(0).isInstanceOf[Literal] && conditions(0).asInstanceOf[Literal].getValue.isInstanceOf[BooleanValue]) if ((conditions(0).asInstanceOf[Literal]).getValue.asInstanceOf[BooleanValue].getBooleanValue) { // only one condition left, and it's known to be true: return the corresponding action
        return actions(0)
      }
      else { // but if it's false, return a no-op
        return null
      }
      conditions = util.Arrays.copyOf(conditions, entries)
      actions = util.Arrays.copyOf(actions, entries)
    }
    val choose = new Choose(conditions, actions)
    choose.setInstruction(true)
    choose
  }
}