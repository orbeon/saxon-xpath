////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.Choose
import net.sf.saxon.expr.instruct.ValueOf
import net.sf.saxon.expr.parser._
import net.sf.saxon.functions.Error
import net.sf.saxon.ma.arrays.ArrayItemType
import net.sf.saxon.ma.map.MapType
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.pattern.NameTest
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.pattern.NodeTest
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AtomizingIterator
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.tree.iter.UntypedAtomizingIterator
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.EmptySequence
import java.util

/**
 * An Atomizer is an expression corresponding essentially to the fn:data() function: it
 * maps a sequence by replacing nodes with their typed values
 */
object Atomizer {
  /**
   * Make an atomizer with a given operand
   *
   * @param sequence the operand
   * @param role     (may be null) additional information for diagnostics
   * @return an Atomizer that atomizes the given operand, or another expression that returns the same result
   */
    def makeAtomizer(sequence: Expression, role: RoleDiagnostic) = if (sequence.isInstanceOf[Literal] && sequence.asInstanceOf[Literal].getValue.isInstanceOf[AtomicSequence]) sequence
    else new Atomizer(sequence, role)

  /**
   * Compute the type that will result from atomizing the result of a given expression
   *
   * @param operand       the given expression
   * @param alwaysUntyped true if it is known that nodes will always be untyped
   * @param th            the type hierarchy cache
   * @return the item type of the result of evaluating the operand expression, after atomization, or
   *         xs:error if it is known that atomization will return an error
   */
  def getAtomizedItemType(operand: Expression, alwaysUntyped: Boolean, th: TypeHierarchy): ItemType = {
    val in = operand.getItemType
    if (in.isPlainType) return in
    else if (in.isInstanceOf[NodeTest]) {
      val kinds = in.getUType
      if (alwaysUntyped) { // Some node-kinds always have a typed value that's a string
        if (STRING_KINDS.subsumes(kinds)) return BuiltInAtomicType.STRING
        // Some node-kinds are always untyped atomic; some are untypedAtomic provided that the configuration
        // is untyped
        if (UNTYPED_IF_UNTYPED_KINDS.subsumes(kinds)) return BuiltInAtomicType.UNTYPED_ATOMIC
      }
      else if (UNTYPED_KINDS.subsumes(kinds)) return BuiltInAtomicType.UNTYPED_ATOMIC
      return in.getAtomizedItemType
    }
    else if (in.isInstanceOf[JavaExternalObjectType]) return in.getAtomizedItemType
    else if (in.isInstanceOf[ArrayItemType]) {
      val ait = in.asInstanceOf[ArrayItemType].getMemberType.getPrimaryType.getAtomizedItemType
      return if (ait == null) ErrorType.getInstance
      else ait
    }
    else if (in.isInstanceOf[FunctionItemType]) return ErrorType.getInstance
    BuiltInAtomicType.ANY_ATOMIC
  }

  /**
   * Node kinds whose typed value is always a string
   */
  val STRING_KINDS = UType.NAMESPACE.union(UType.COMMENT).union(UType.PI)
  /**
   * Node kinds whose typed value is always untypedAtomic
   */
  val UNTYPED_KINDS = UType.TEXT.union(UType.DOCUMENT)
  /**
   * Node kinds whose typed value is untypedAtomic if the configuration is untyped
   */
  val UNTYPED_IF_UNTYPED_KINDS = UType.TEXT.union(UType.ELEMENT).union(UType.DOCUMENT).union(UType.ATTRIBUTE)

  /**
   * Get an iterator that returns the result of atomizing the sequence delivered by the supplied
   * iterator
   *
   * @param base     the supplied iterator, the input to atomization
   * @param oneToOne this can safely be set to true if it is known that all nodes in the base sequence will
   *                 be untyped and that there will be no arrays in the base sequence; but it is always OK
   *                 to set it to false.
   * @return an iterator that returns atomic values, the result of the atomization
   * @throws net.sf.saxon.trans.XPathException
   * if a dynamic evaluation error occurs
   */
  @throws[XPathException]
  def getAtomizingIterator(base: SequenceIterator, oneToOne: Boolean): SequenceIterator = {
    val properties = base.getProperties
    if (properties.contains(SequenceIterator.Property.LAST_POSITION_FINDER)) {
      val count = base.asInstanceOf[LastPositionFinder].getLength
      if (count == 0) return EmptyIterator.emptyIterator
      else if (count == 1) {
        val first = base.next
        return first.atomize.iterate
      }
    }
    else if (properties.contains(SequenceIterator.Property.ATOMIZING)) return new AxisAtomizingIterator(base.asInstanceOf[AtomizedValueIterator])
    if (oneToOne) new UntypedAtomizingIterator(base)
    else new AtomizingIterator(base)
  }

  @throws[XPathException]
  def atomize(sequence: Sequence) = if (sequence.isInstanceOf[AtomicSequence]) sequence.asInstanceOf[AtomicSequence]
  else if (sequence.isInstanceOf[EmptySequence[_ <: Item]]) EmptyAtomicSequence.getInstance
  else {
    val iter = getAtomizingIterator(sequence.iterate, false)
    new AtomicArray(iter)
  }
}

final class Atomizer(val sequence: Expression, val role: RoleDiagnostic)

/**
 * Constructor
 *
 * @param sequence the sequence to be atomized
 * @param role     (may be null) additional information for use in diagnostics
 */
  extends UnaryExpression(sequence) {
  this.roleDiagnostic = roleDiagnostic
  sequence.setFlattened(true)
  private var untyped = false //set to true if it is known that the nodes being atomized will be untyped
  private var singleValued = false // set to true if all atomized nodes will atomize to a single atomic value
  private var operandItemType = null
  private var roleDiagnostic = null

  override protected def getOperandRole = OperandRole.ATOMIC_SEQUENCE

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD | WATCH_METHOD

  def getOperandItemType = {
    if (operandItemType == null) operandItemType = getBaseExpression.getItemType
    operandItemType
  }

  def setRoleDiagnostic(role: RoleDiagnostic) = this.roleDiagnostic = role

  /**
   * Simplify an expression
   *
   */
  /*@NotNull*/ @throws[XPathException]
  override def simplify: Expression = { //untyped = !getContainer().getPackageData().isSchemaAware();
    untyped = !getPackageData.isSchemaAware
    computeSingleValued(getConfiguration.getTypeHierarchy)
    val operand = getBaseExpression.simplify
    if (operand.isInstanceOf[Literal]) {
      val `val` = operand.asInstanceOf[Literal].getValue
      if (`val`.isInstanceOf[AtomicValue]) return operand
      val iter = `val`.iterate
      var i = null
      while ( {
        (i = iter.next) != null
      }) {
        if (i.isInstanceOf[NodeInfo]) return this
        if (i.isInstanceOf[Function]) if (i.asInstanceOf[Function].isArray) return this
        else if (i.asInstanceOf[Function].isMap) {
          val err = new XPathException(expandMessage("Cannot atomize a map (" + i.toShortString + ")"), "FOTY0013")
          err.setIsTypeError(true)
          err.setLocation(getLocation)
          throw err
        }
        else {
          val err = new XPathException(expandMessage("Cannot atomize a function item"), "FOTY0013")
          err.setIsTypeError(true)
          err.setLocation(getLocation)
          throw err
        }
      }
      // if all items in the sequence are atomic (they generally will be, since this is
      // done at compile time), then return the sequence
      return operand
    }
    else if (operand.isInstanceOf[ValueOf] && !ReceiverOption.contains((operand.asInstanceOf[ValueOf]).getOptions, ReceiverOption.DISABLE_ESCAPING)) { // XSLT users tend to use ValueOf unnecessarily
      return operand.asInstanceOf[ValueOf].convertToCastAsString
    }
    setBaseExpression(operand)
    this
  }

  /**
   * Type-check the expression
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    getOperand.typeCheck(visitor, contextInfo)
    untyped = untyped | !visitor.getStaticContext.getPackageData.isSchemaAware
    // If the configuration allows typed data, check whether the content type of these particular nodes is untyped
    val th = visitor.getConfiguration.getTypeHierarchy
    computeSingleValued(th)
    resetLocalStaticProperties()
    val operandType = getOperandItemType
    if (th.isSubType(operandType, BuiltInAtomicType.ANY_ATOMIC)) return getBaseExpression
    if (!operandType.isAtomizable(th)) {
      var err = null
      if (operandType.isInstanceOf[FunctionItemType]) {
        val thing = if (operandType.isInstanceOf[MapType]) "map"
        else "function item"
        err = new XPathException(expandMessage("Cannot atomize a " + thing), "FOTY0013")
      }
      else err = new XPathException(expandMessage("Cannot atomize an element that is defined in the schema to have element-only content"), "FOTY0012")
      err.setIsTypeError(true)
      err.setLocation(getLocation)
      throw err
    }
    getBaseExpression.setFlattened(true)
    this
  }

  private def computeSingleValued(th: TypeHierarchy) = {
    val operandType = getOperandItemType
    if (th.relationship(operandType, ArrayItemType.ANY_ARRAY_TYPE) ne Affinity.DISJOINT) singleValued = false
    else {
      singleValued = untyped
      if (!singleValued) {
        val nodeType = getBaseExpression.getItemType
        if (nodeType.isInstanceOf[NodeTest]) {
          val st = nodeType.asInstanceOf[NodeTest].getContentType
          if ((st eq Untyped.getInstance) || st.isAtomicType || (st.isComplexType && (st ne AnyType.getInstance))) singleValued = true
          if (!nodeType.getUType.overlaps(UType.ELEMENT.union(UType.ATTRIBUTE))) singleValued = true
        }
      }
    }
  }

  /**
   * Expand an error message with information about the context in which atomization is taking place
   *
   * @param message the message to be expanded
   */
  private def expandMessage(message: String) = if (roleDiagnostic == null) message
  else message + ". Found while atomizing the " + roleDiagnostic.getMessage

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor     an expression visitor
   * @param contextInfo the static type of "." at the point where this expression is invoked.
   *                    The parameter is set to null if it is known statically that the context item will be undefined.
   *                    If the type of the context item is not known statically, the argument is set to
   *                    { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws net.sf.saxon.trans.XPathException
   * if an error is discovered during this phase
   * (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val exp = super.optimize(visitor, contextInfo)
    if (exp eq this) {
      val th = visitor.getConfiguration.getTypeHierarchy
      val operand = getBaseExpression
      if (th.isSubType(operand.getItemType, BuiltInAtomicType.ANY_ATOMIC)) return operand
      if (operand.isInstanceOf[ValueOf] && !ReceiverOption.contains((operand.asInstanceOf[ValueOf]).getOptions, ReceiverOption.DISABLE_ESCAPING)) {
        val cast = operand.asInstanceOf[ValueOf].convertToCastAsString
        return cast.optimize(visitor, contextInfo)
      }
      if (operand.isInstanceOf[LetExpression] || operand.isInstanceOf[ForExpression]) { // replace data(let $x := y return z) by (let $x := y return data(z))
        val action = operand.asInstanceOf[Assignation].getAction
        operand.asInstanceOf[Assignation].setAction(new Atomizer(action, roleDiagnostic))
        return operand.optimize(visitor, contextInfo)
      }
      if (operand.isInstanceOf[Choose]) { // replace data(if x then y else z) by (if x then data(y) else data(z)
        operand.asInstanceOf[Choose].atomizeActions()
        return operand.optimize(visitor, contextInfo)
      }
      if (operand.isInstanceOf[Block]) { // replace data((x,y,z)) by (data(x), data(y), data(z)) as some of the atomizers
        // may prove to be redundant. (Also, it helps streaming)
        val children = operand.asInstanceOf[Block].getOperanda
        val atomizedChildren = new Array[Expression](children.length)
        for (i <- 0 until children.length) {
          atomizedChildren(i) = new Atomizer(children(i).getChildExpression, roleDiagnostic)
        }
        val newBlock = new Block(atomizedChildren)
        return newBlock.typeCheck(visitor, contextInfo).optimize(visitor, contextInfo)
      }
      if (untyped && operand.isInstanceOf[AxisExpression] && operand.asInstanceOf[AxisExpression].getAxis == AxisInfo.ATTRIBUTE && operand.asInstanceOf[AxisExpression].getNodeTest.isInstanceOf[NameTest] && !(operand.asInstanceOf[AxisExpression]).isContextPossiblyUndefined) {
        val name = operand.asInstanceOf[AxisExpression].getNodeTest.getMatchingNodeName
        val qName = new FingerprintedQName(name, visitor.getConfiguration.getNamePool)
        val ag = new AttributeGetter(qName)
        var checks = 0
        if (!(operand.asInstanceOf[AxisExpression]).getContextItemType.isInstanceOf[NodeTest]) checks = AttributeGetter.CHECK_CONTEXT_ITEM_IS_NODE
        ag.setRequiredChecks(checks)
        ExpressionTool.copyLocationInfo(this, ag)
        return ag
      }
    }
    exp
  }

  /**
   * Ask whether it is known that any nodes in the input will always be untyped
   *
   * @return true if it is known that all nodes in the input will be untyped
   */
  def isUntyped = untyped

  /**
   * Determine the special properties of this expression
   *
   * @return { @link StaticProperty#NO_NODES_NEWLY_CREATED}.
   */
  override def computeSpecialProperties = {
    var p = super.computeSpecialProperties
    p &= ~StaticProperty.NODESET_PROPERTIES
    p | StaticProperty.NO_NODES_NEWLY_CREATED
  }

  /**
   * Reset the static properties of the expression to -1, so that they have to be recomputed
   * next time they are used.
   */
  override def resetLocalStaticProperties() = {
    super.resetLocalStaticProperties()
    operandItemType = null
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be rebound
   */
  override def copy(rebindings: RebindingMap) = {
    val copy = new Atomizer(getBaseExpression.copy(rebindings), roleDiagnostic)
    copy.untyped = untyped
    copy.singleValued = singleValued
    ExpressionTool.copyLocationInfo(this, copy)
    copy
  }

  override def getStreamerName = "Atomizer"

  /**
   * Iterate over the sequence of values
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = try {
    val base = getBaseExpression.iterate(context)
    Atomizer.getAtomizingIterator(base, untyped && operandItemType.isInstanceOf[NodeTest])
  } catch {
    case e: XPathException =>
      if (roleDiagnostic == null || e.isInstanceOf[Error.UserDefinedXPathException]) throw e
      else {
        val message = expandMessage(e.getMessage)
        val e2 = new XPathException(message, e.getErrorCodeLocalPart, e.getLocator)
        e2.setXPathContext(context)
        e2.maybeSetLocation(getLocation)
        throw e2
      }
  }

  /**
   * Evaluate as an Item. This should only be called if the Atomizer has cardinality zero-or-one,
   * which will only be the case if the underlying expression has cardinality zero-or-one.
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext) = {
    val i = getBaseExpression.evaluateItem(context)
    if (i == null) null
    else i.atomize.head
  }

  /**
   * Determine the data type of the items returned by the expression, if possible
   *
   * @return a value such as Type.STRING, Type.BOOLEAN, Type.NUMBER. For this class, the
   *         result is always an atomic type, but it might be more specific.
   */
  override def getItemType = {
    operandItemType = getBaseExpression.getItemType
    val th = getConfiguration.getTypeHierarchy
    Atomizer.getAtomizedItemType(getBaseExpression, untyped, th)
  }

  /**
   * Determine the static cardinality of the expression
   */
  override def computeCardinality: Int = {
    val in = getOperandItemType
    val operand = getBaseExpression
    if (singleValued) return operand.getCardinality
    else if (untyped && in.isInstanceOf[NodeTest]) return operand.getCardinality
    else if (Cardinality.allowsMany(operand.getCardinality)) return StaticProperty.ALLOWS_ZERO_OR_MORE
    else if (in.isPlainType) return operand.getCardinality
    else if (in.isInstanceOf[NodeTest]) {
      val schemaType = in.asInstanceOf[NodeTest].getContentType
      if (schemaType.isAtomicType) { // can return at most one atomic value per node
        return operand.getCardinality
      }
    }
    StaticProperty.ALLOWS_ZERO_OR_MORE
  }

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   * <p>The default implementation of this method assumes that an expression does no navigation other than
   * the navigation done by evaluating its subexpressions, and that the subexpressions are evaluated in the
   * same context as the containing expression. The method must be overridden for any expression
   * where these assumptions do not hold. For example, implementations exist for AxisExpression, ParentExpression,
   * and RootExpression (because they perform navigation), and for the doc(), document(), and collection()
   * functions because they create a new navigation root. Implementations also exist for PathExpression and
   * FilterExpression because they have subexpressions that are evaluated in a different context from the
   * calling expression.</p>
   *
   * @param pathMap        the PathMap to which the expression should be added
   * @param pathMapNodeSet the PathMapNodeSet to which the paths embodied in this expression should be added
   * @return the pathMapNodeSet representing the points in the source document that are both reachable by this
   *         expression, and that represent possible results of this expression. For an expression that does
   *         navigation, it represents the end of the arc in the path map that describes the navigation route. For other
   *         expressions, it is the same as the input pathMapNode.
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = {
    val result = getBaseExpression.addToPathMap(pathMap, pathMapNodeSet)
    if (result != null) {
      val th = getConfiguration.getTypeHierarchy
      val operandItemType = getBaseExpression.getItemType
      if ((th.relationship(NodeKindTest.ELEMENT, operandItemType) ne Affinity.DISJOINT) || (th.relationship(NodeKindTest.DOCUMENT, operandItemType) ne Affinity.DISJOINT)) result.setAtomized()
    }
    null
  }

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  override def getExpressionName = "data"

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   */
  override def toString = "data(" + getBaseExpression.toString + ")"

  override def toShortString = getBaseExpression.toShortString

  override protected def emitExtraAttributes(out: ExpressionPresenter) = if (roleDiagnostic != null) out.emitAttribute("diag", roleDiagnostic.save)
}