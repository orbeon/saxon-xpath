////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.expr._
import net.sf.saxon.expr.instruct.GlobalVariable
import net.sf.saxon.expr.parser.OptimizerOptions
import net.sf.saxon.expr.parser.RetainedStaticContext
import net.sf.saxon.functions.FunctionLibrary
import net.sf.saxon.functions.FunctionLibraryList
import net.sf.saxon.functions.SystemFunction
import net.sf.saxon.functions.registry.VendorFunctionSetHE
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.AnyItemType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.Type
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NamespaceResolver
import net.sf.saxon.om.StandardNames
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.pattern.NameTest
import net.sf.saxon.s9api.Location
import net.sf.saxon.s9api.UnprefixedElementMatchingPolicy
import net.sf.saxon.trans._
import net.sf.saxon.tree.AttributeLocation
import net.sf.saxon.tree.iter.AxisIterator
import java.util

/**
 * An ExpressionContext represents the context for an XPath expression written
 * in the stylesheet.
 */
class ExpressionContext(var element: StyleElement, var attributeName: StructuredQName)

/**
 * Create a static context for XPath expressions in an XSLT stylesheet
 *
 * @param styleElement  the element on which the XPath expression appears
 * @param attributeName the name of the attribute in which the XPath expression appears; or null
 *                      if the expression appears in a text node
 */
  extends StaticContext {
  private var containingLocation = null
  private var retainedStaticContext = null

  /**
   * Get the system configuration
   */
  override def getConfiguration = element.getConfiguration

  /**
   * Get the containing XSLT package
   *
   * @return the containing XSLT package
   */
  override def getPackageData = element.getPackageData

  /**
   * Ask whether expressions compiled under this static context are schema-aware.
   * They must be schema-aware if the expression is to handle typed (validated) nodes
   *
   * @return true if expressions are schema-aware
   */
  def isSchemaAware = element.isSchemaAware

  /**
   * Construct a dynamic context for early evaluation of constant subexpressions
   */
  override def makeEarlyEvaluationContext = new EarlyEvaluationContext(getConfiguration)

  /**
   * Construct a RetainedStaticContext, which extracts information from this StaticContext
   * to provide the subset of static context information that is potentially needed
   * during expression evaluation
   *
   * @return a RetainedStaticContext object: either a newly created one, or one that is
   *         reused from a previous invocation.
   */
  override def makeRetainedStaticContext = {
    if (retainedStaticContext == null) if (element.changesRetainedStaticContext || !element.getParent.isInstanceOf[StyleElement]) retainedStaticContext = new RetainedStaticContext(this)
    else retainedStaticContext = element.getParent.asInstanceOf[StyleElement].getStaticContext.makeRetainedStaticContext
    retainedStaticContext
  }

  /**
   * Get the containing location of an XPath expression within the stylesheet
   *
   * @return a Location that identifies the containing element, together with the name of the
   *         attribute holding the XPath expression in question.
   */
  override def getContainingLocation = {
    if (containingLocation == null) if (attributeName == null) containingLocation = element
    else containingLocation = new AttributeLocation(element, attributeName)
    containingLocation
  }

  /**
   * Issue a compile-time warning
   */
  override def issueWarning(s: String, locator: Location) = element.compileWarning(s, SaxonErrorCode.SXWN9000, locator)

  /**
   * Get the System ID of the entity containing the expression (used for diagnostics)
   */
  override def getSystemId = element.getSystemId

  /**
   * Get the Base URI of the element containing the expression, for resolving any
   * relative URI's used in the expression.
   * Used by the document() function.
   */
  override def getStaticBaseURI = element.getBaseURI

  /**
   * Get a copy of the NamespaceResolver suitable for saving in the executable code
   *
   * @return a NamespaceResolver
   */
  override def getNamespaceResolver = element.getAllNamespaces

  /**
   * Get the required type of the context item. If no type has been explicitly declared for the context
   * item, an instance of AnyItemType (representing the type item()) is returned.
   *
   * @return the required type of the context item
   * @since 9.3
   */
  override def getRequiredContextItemType = AnyItemType.getInstance

  /**
   * Get a DecimalFormatManager to resolve the names of decimal formats used in calls
   * to the format-number() function.
   *
   * @return the decimal format manager for this static context, or null if named decimal
   *         formats are not supported in this environment.
   */
  override def getDecimalFormatManager = element.getCompilation.getPrincipalStylesheetModule.getDecimalFormatManager

  /**
   * Get the optimization options in use. By default these are taken from the
   * {@link Configuration}
   *
   * @return the optimization options in use
   * @since 9.9
   */
  override def getOptimizerOptions = element.getCompilation.getCompilerInfo.getOptimizerOptions

  /**
   * Bind a variable to an object that can be used to refer to it
   *
   * @param qName the name of the variable
   * @return a VariableDeclaration object that can be used to identify it in the Bindery,
   * @throws XPathException if the variable has not been declared
   */
  @throws[XPathException]
  override def bindVariable(qName: StructuredQName): Expression = {
    val sourceBinding = element.bindVariable(qName)
    if (sourceBinding == null) {
      if (qName.hasURI(NamespaceConstant.XSLT) && qName.getLocalPart == "original") {
        element.getXslOriginal(StandardNames.XSL_VARIABLE)
        return new GlobalVariableReference(qName)
      }
      // it might have been declared in an imported package or query
      val sn = new SymbolicName(StandardNames.XSL_VARIABLE, qName)
      val comp = element.getCompilation.getPrincipalStylesheetModule.getComponent(sn)
      if (comp != null) { // test variable-0118
        // See tests variable-0118 and variable-0120
        element.iterateAxis(AxisInfo.ANCESTOR_OR_SELF).forEachOrFail((parent: Item) => {
          def foo(parent: Item) = {
            if (parent.isInstanceOf[XSLGlobalVariable] && parent.asInstanceOf[XSLGlobalVariable].getVariableQName == qName) {
              val err = new XPathException("Variable " + qName.getDisplayName + " cannot be used within its own declaration", "XPST0008")
              err.setIsStaticError(true)
              throw err
            }
          }

          foo(parent)
        })
        val `var` = comp.getActor.asInstanceOf[GlobalVariable]
        val vref = new GlobalVariableReference(`var`)
        vref.setStaticType(`var`.getRequiredType, null, 0)
        return vref
      }
      // it might be an implicit error variable in try/catch
      if (getXPathVersion >= 30 && qName.hasURI(NamespaceConstant.ERR)) {
        val catchers = element.iterateAxis(AxisInfo.ANCESTOR_OR_SELF, new NameTest(Type.ELEMENT, StandardNames.XSL_CATCH, element.getNamePool))
        val catcher = catchers.next.asInstanceOf[StyleElement]
        if (catcher != null) for (errorVariable <- StandardNames.errorVariables) {
          if (errorVariable.getLocalPart == qName.getLocalPart) {
            val f = VendorFunctionSetHE.getInstance.makeFunction("dynamic-error-info", 1)
            return f.makeFunctionCall(new StringLiteral(qName.getLocalPart))
          }
        }
      }
      val err = new XPathException("Variable " + qName.getDisplayName + " has not been declared (or its declaration is not in scope)", "XPST0008")
      err.setIsStaticError(true)
      throw err
    }
    var `var` = null
    if (sourceBinding.hasProperty(SourceBinding.BindingProperty.IMPLICITLY_DECLARED)) { // Used for the $value variable in xsl:accumulator-rule
      val supRef = new SuppliedParameterReference(0)
      supRef.setSuppliedType(sourceBinding.getDeclaredType)
      return supRef
    }
    if (sourceBinding.hasProperty(SourceBinding.BindingProperty.GLOBAL)) {
      `var` = new GlobalVariableReference(qName)
      //SourceBinding binding = ((XSLGlobalVariable) sourceBinding.getSourceElement()).sourceBinding;
      val compiledVar = sourceBinding.getSourceElement.asInstanceOf[XSLGlobalVariable].getCompiledVariable
      if (compiledVar != null && element.getCompilation.getCompilerInfo.isJustInTimeCompilation) {
        `var`.fixup(compiledVar)
        `var`.setStaticType(compiledVar.getRequiredType, sourceBinding.getConstantValue, 0)
      }
      else sourceBinding.registerReference(`var`)
      `var`
    }
    else {
      `var` = new LocalVariableReference(qName)
      sourceBinding.registerReference(`var`)
      `var`
    }
  }

  /**
   * Get the function library containing all the in-scope functions available in this static
   * context
   */
  override def getFunctionLibrary: FunctionLibrary = {
    val lib = element.getContainingPackage.getFunctionLibrary
    val containingOverride = element.findAncestorElement(StandardNames.XSL_OVERRIDE)
    if (containingOverride != null) { // Within xsl:override, recognize the function name xsl:original
      val libList = new FunctionLibraryList
      libList.addFunctionLibrary(lib)
      containingOverride.asInstanceOf[XSLOverride].addXSLOverrideFunctionLibrary(libList)
      return libList
    }
    lib
  }

  /**
   * Get the default collation. Return null if no default collation has been defined
   */
  override def getDefaultCollationName = element.getDefaultCollationName

  /**
   * Get the default XPath namespace for elements and types
   * Return NamespaceConstant.NULL for the non-namespace
   */
  override def getDefaultElementNamespace = element.getDefaultXPathNamespace

  /**
   * Get the default function namespace
   */
  override def getDefaultFunctionNamespace = NamespaceConstant.FN

  /**
   * Determine whether Backwards Compatible Mode is used
   */
  override def isInBackwardsCompatibleMode = element.xPath10ModeIsEnabled

  /**
   * Get the XPath language level supported, as an integer (being the actual version
   * number times ten). In Saxon 9.9, for XSLT, the possible values are
   * 30 (XPath 3.0), 31 (XPath 3.1), and 305 (XPath 3.0 plus the extensions defined in XSLT 3.0).
   *
   * @return the XPath language level; the return value will be either 30, 305, or 31
   * @since 9.7
   */
  override def getXPathVersion = getConfiguration.getConfigurationProperty(Feature.XPATH_VERSION_FOR_XSLT)

  /**
   * Test whether a schema has been imported for a given namespace
   *
   * @param namespace the target namespace of the required schema
   * @return true if a schema for this namespace has been imported
   */
  override def isImportedSchema(namespace: String) = { //if (Configuration.USE_PACKAGE_BINDING) {
    element.getPrincipalStylesheetModule.isImportedSchema(namespace)
    //} else {
    //    return getConfiguration().
    //}
  }

  /**
   * Get the set of imported schemas
   *
   * @return a Set, the set of URIs representing the names of imported schemas
   */
  override def getImportedSchemaNamespaces = element.getPrincipalStylesheetModule.getImportedSchemaTable

  /**
   * Get the KeyManager, containing definitions of keys available for use.
   *
   * @return the KeyManager. This is used to resolve key names, both explicit calls
   *         on key() used in XSLT, and system-generated calls on key() which may
   *         also appear in XQuery and XPath
   */
  override def getKeyManager = element.getCompilation.getPrincipalStylesheetModule.getKeyManager

  /**
   * Get the stylesheet element containing this XPath expression
   *
   * @return the element in the tree representation of the source stylesheet
   */
  def getStyleElement = element

  /**
   * Get type alias. This is a Saxon extension. A type alias is a QName which can
   * be used as a shorthand for an itemtype, using the syntax ~typename anywhere that
   * an item type is permitted.
   *
   * @param typeName the name of the type alias
   * @return the corresponding item type, if the name is recognised; otherwise null.
   */
  override def resolveTypeAlias(typeName: StructuredQName) = getPackageData.obtainTypeAliasManager.getItemType(typeName)

  /**
   * Get the matching policy for unprefixed element names in axis steps. This is a Saxon extension.
   * The value can be any of {@link UnprefixedElementMatchingPolicy#DEFAULT_NAMESPACE} (the default),
   * which uses the value of {@link #getDefaultElementNamespace()}, or {@link UnprefixedElementMatchingPolicy#DEFAULT_NAMESPACE_OR_NONE},
   * which matches both the namespace given in {@link #getDefaultElementNamespace()} and the null namespace,
   * or {@link UnprefixedElementMatchingPolicy#ANY_NAMESPACE}, which matches any namespace (that is, it
   * matches by local name only).
   */
  override def getUnprefixedElementMatchingPolicy = element.getCompilation.getCompilerInfo.getUnprefixedElementMatchingPolicy
}