////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.event.SequenceReceiver
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.Item
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.om.NodeName
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import java.io.PrintStream

/**
 * A filter that can be inserted into a Receiver pipeline to count the events that pass through.
 * This class is not normally used in Saxon, but is available for diagnostics when needed. Note
 * that the counters are only maintained if {@link Instrumentation#ACTIVE} is set to true. The counters
 * can be displayed by calling {@link Instrumentation#report()}.
 */
object CountingFilter {
  private var nextid = 0
}

class CountingFilter extends ProxyReceiver {
  private var id = 0

  /**
   * Create a TracingFilter and allocate a unique Id.
   *
   * @param nextReceiver the underlying receiver to which the events will be sent
   */
  def this(nextReceiver: Receiver) {
    this()
    this.setPipelineConfiguration(nextReceiver.getPipelineConfiguration)
    setUnderlyingReceiver(nextReceiver)
    setPipelineConfiguration(nextReceiver.getPipelineConfiguration)
    id = {
      CountingFilter.nextid += 1; CountingFilter.nextid - 1
    }
  }

  /**
   * Create a TracingFilter, allocate a unique Id, and supply the destination for diagnostic
   * trace messages
   *
   * @param nextReceiver     the underlying receiver to which the events will be sent
   * @param diagnosticOutput the destination for diagnostic trace messages
   */
  def this(nextReceiver: Receiver, diagnosticOutput: PrintStream) {
    this()
    this.setPipelineConfiguration(nextReceiver.getPipelineConfiguration)
    setUnderlyingReceiver(nextReceiver)
    setPipelineConfiguration(nextReceiver.getPipelineConfiguration)
    id = {
      CountingFilter.nextid += 1; CountingFilter.nextid - 1
    }
  }

  /**
   * Get the unique id that was allocated to this TracingFilter
   *
   * @return the unique id (which is included in all diagnostic messages)
   */
  def getId = id

  /**
   * Increment a named counter
   */
  private def count(counter: String) = Instrumentation.count("Filter " + id + " " + counter)

  /**
   * Append an arbitrary item (node or atomic value) to the output
   *
   * @param item           the item to be appended
   * @param locationId     the location of the calling instruction, for diagnostics
   * @param copyNamespaces if the item is an element node, this indicates whether its namespaces
   *                       need to be copied. Values are { @link ReceiverOption#ALL_NAMESPACES}; the default (0) means
   */
  @throws[XPathException]
  override def append(item: Item, locationId: Location, copyNamespaces: Int) = {
    count("append")
    if (nextReceiver.isInstanceOf[SequenceReceiver]) nextReceiver.asInstanceOf[SequenceReceiver].append(item, locationId, copyNamespaces)
    else super.append(item, locationId, copyNamespaces)
  }

  /**
   * Character data
   */
  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = {
    count("characters")
    nextReceiver.characters(chars, locationId, properties)
  }

  /**
   * End of document
   */
  @throws[XPathException]
  override def close() = {
    count("close")
    nextReceiver.close()
  }

  /**
   * Output a comment
   */
  @throws[XPathException]
  override def comment(chars: CharSequence, locationId: Location, properties: Int) = {
    count("comment")
    nextReceiver.comment(chars, locationId, properties)
  }

  /**
   * Notify the end of a document node
   */
  @throws[XPathException]
  override def endDocument() = {
    count("endDocument")
    nextReceiver.endDocument()
  }

  /**
   * End of element
   */
  @throws[XPathException]
  override def endElement() = {
    count("endElement")
    nextReceiver.endElement()
  }

  /**
   * Start of event stream
   */
  @throws[XPathException]
  override def open() = {
    count("open")
    nextReceiver.open()
  }

  /**
   * Processing Instruction
   */
  @throws[XPathException]
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = {
    count("processingInstruction")
    nextReceiver.processingInstruction(target, data, locationId, properties)
  }

  /**
   * Start of a document node.
   *
   * @param properties
   */
  @throws[XPathException]
  override def startDocument(properties: Int) = {
    count("startDocument")
    nextReceiver.startDocument(properties)
  }

  /**
   * Notify the start of an element
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    count("startElement")
    nextReceiver.startElement(elemName, `type`, attributes, namespaces, location, properties)
  }
}