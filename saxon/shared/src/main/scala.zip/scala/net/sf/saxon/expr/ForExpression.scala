////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.event.Outputter
import net.sf.saxon.expr.flwor.OuterForExpression
import net.sf.saxon.expr.instruct.Choose
import net.sf.saxon.expr.parser._
import net.sf.saxon.lib.Feature
import net.sf.saxon.model._
import net.sf.saxon.om.Item
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.IntegerValue
import net.sf.saxon.value.SequenceType
import java.util

/**
 * A ForExpression maps an expression over a sequence.
 * We use a ForExpression in preference to a FLWORExpression to handle simple cases
 * (roughly, the XPath subset). In 9.6, we no longer convert a FLWORExpression to a ForExpression
 * if there is a position variable, which simplifies the cases this class has to handle.
 */
object ForExpression {

  /**
   * The MappingAction represents the action to be taken for each item in the
   * source sequence. It acts as the MappingFunction for the mapping iterator.
   */
  class MappingAction(var context: XPathContext, var slotNumber: Int, var action: Expression) extends MappingFunction with ItemMappingFunction {
    /*@Nullable*/ @throws[XPathException]
    override def map(item: Item) = {
      context.setLocalVariable(slotNumber, item)
      action.iterate(context)
    }

    @throws[XPathException]
    override def mapItem(item: Item) = {
      context.setLocalVariable(slotNumber, item)
      action.evaluateItem(context)
    }
  }

}

class ForExpression()

/**
 * Create a "for" expression (for $x at $p in SEQUENCE return ACTION)
 */
  extends Assignation {
  private var actionCardinality = StaticProperty.ALLOWS_MANY

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "for"

  /**
   * Type-check the expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = { // The order of events is critical here. First we ensure that the type of the
    // sequence expression is established. This is used to establish the type of the variable,
    // which in turn is required when type-checking the action part.
    getSequenceOp.typeCheck(visitor, contextInfo)
    if (Literal.isEmptySequence(getSequence) && !this.isInstanceOf[OuterForExpression]) return getSequence
    if (requiredType != null) { // if declaration is null, we've already done the type checking in a previous pass
      val decl = requiredType
      val sequenceType = SequenceType.makeSequenceType(decl.getPrimaryType, StaticProperty.ALLOWS_ZERO_OR_MORE)
      val role = new RoleDiagnostic(RoleDiagnostic.VARIABLE, variableName.getDisplayName, 0)
      setSequence(TypeChecker.strictTypeCheck(getSequence, sequenceType, role, visitor.getStaticContext))
      val actualItemType = getSequence.getItemType
      refineTypeInformation(actualItemType, getRangeVariableCardinality, null, getSequence.getSpecialProperties, this)
    }
    if (Literal.isEmptySequence(getAction)) return getAction
    getActionOp.typeCheck(visitor, contextInfo)
    actionCardinality = getAction.getCardinality
    this
  }

  /**
   * Get the cardinality of the range variable
   *
   * @return the cardinality of the range variable (StaticProperty.EXACTLY_ONE). Can be overridden
   *         in a subclass
   */
  protected def getRangeVariableCardinality = StaticProperty.EXACTLY_ONE

  /**
   * Optimize the expression
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val opt = visitor.obtainOptimizer
    val debug = config.getBooleanProperty(Feature.TRACE_OPTIMIZER_DECISIONS)
    // Try to promote any WHERE clause appearing immediately within the FOR expression
    if (Choose.isSingleBranchChoice(getAction)) getActionOp.optimize(visitor, contextItemType)
    val p = promoteWhereClause
    if (p != null) {
      if (debug) opt.trace("Promoted where clause in for $" + getVariableName, p)
      return p.optimize(visitor, contextItemType)
    }
    val seq0 = getSequence
    getSequenceOp.optimize(visitor, contextItemType)
    if (seq0 ne getSequence) { // if it changed, re-optimize
      return optimize(visitor, contextItemType)
    }
    if (Literal.isEmptySequence(getSequence) && !this.isInstanceOf[OuterForExpression]) return getSequence
    val act0 = getAction
    getActionOp.optimize(visitor, contextItemType)
    if (act0 ne getAction) { // it's now worth re-attempting the "where" clause optimizations
      return optimize(visitor, contextItemType)
    }
    if (Literal.isEmptySequence(getAction)) return getAction
    // Simplify an expression of the form "for $b in a/b/c return $b/d".
    // (XQuery users seem to write these a lot!)
    if (getSequence.isInstanceOf[SlashExpression] && getAction.isInstanceOf[SlashExpression]) {
      val path2 = getAction.asInstanceOf[SlashExpression]
      val start2 = path2.getSelectExpression
      val step2 = path2.getActionExpression
      if (start2.isInstanceOf[VariableReference] && (start2.asInstanceOf[VariableReference].getBinding eq this) && ExpressionTool.getReferenceCount(getAction, this, false) == 1 && ((step2.getDependencies & (StaticProperty.DEPENDS_ON_POSITION | StaticProperty.DEPENDS_ON_LAST)) eq 0)) {
        var newPath = new SlashExpression(getSequence, path2.getActionExpression)
        ExpressionTool.copyLocationInfo(this, newPath)
        newPath = newPath.simplify.typeCheck(visitor, contextItemType)
        if (newPath.isInstanceOf[SlashExpression]) { // if not, it has been wrapped in a DocumentSorter or Reverser, which makes it ineligible.
          // see test qxmp299, where this condition isn't satisfied
          if (debug) opt.trace("Collapsed return clause of for $" + getVariableName + " into path expression", newPath)
          return newPath.optimize(visitor, contextItemType)
        }
      }
    }
    // Simplify an expression of the form "for $x in EXPR return $x". These sometimes
    // arise as a result of previous optimization steps.
    if (getAction.isInstanceOf[VariableReference] && (getAction.asInstanceOf[VariableReference].getBinding eq this)) {
      if (debug) opt.trace("Collapsed redundant for expression $" + getVariableName, getSequence)
      return getSequence
    }
    // If the cardinality of the sequence is exactly one, rewrite as a LET expression
    if (getSequence.getCardinality == StaticProperty.EXACTLY_ONE) {
      val let = new LetExpression
      let.setVariableQName(variableName)
      let.setRequiredType(SequenceType.makeSequenceType(getSequence.getItemType, StaticProperty.EXACTLY_ONE))
      let.setSequence(getSequence)
      let.setAction(getAction)
      let.setSlotNumber(slotNumber)
      let.setRetainedStaticContextLocally(getRetainedStaticContext)
      ExpressionTool.rebindVariableReferences(getAction, this, let)
      return let.typeCheck(visitor, contextItemType).optimize(visitor, contextItemType)
    }
    this
  }

  /**
   * Replace this expression by a simpler expression that delivers the results without regard
   * to order.
   *
   * @param retainAllNodes set to true if the result must contain exactly the same nodes as the
   *                       original; set to false if the result can eliminate (or introduce) duplicates.
   * @param forStreaming   set to true if optimizing for streaming
   */
  @throws[XPathException]
  override def unordered(retainAllNodes: Boolean, forStreaming: Boolean) = {
    setSequence(getSequence.unordered(retainAllNodes, forStreaming))
    setAction(getAction.unordered(retainAllNodes, forStreaming))
    this
  }

  /**
   * For an expression that returns an integer or a sequence of integers, get
   * a lower and upper bound on the values of the integers that may be returned, from
   * static analysis. The default implementation returns null, meaning "unknown" or
   * "not applicable". Other implementations return an array of two IntegerValue objects,
   * representing the lower and upper bounds respectively. The values
   * UNBOUNDED_LOWER and UNBOUNDED_UPPER are used by convention to indicate that
   * the value may be arbitrarily large. The values MAX_STRING_LENGTH and MAX_SEQUENCE_LENGTH
   * are used to indicate values limited by the size of a string or the size of a sequence.
   *
   * @return the lower and upper bounds of integer values in the result, or null to indicate
   *         unknown or not applicable.
   */
  override def getIntegerBounds = getAction.getIntegerBounds

  /**
   * Promote a WHERE clause whose condition doesn't depend on the variable being bound.
   * This rewrites an expression of the form
   * <p>let $i := SEQ return if (C) then R else ()</p>
   * <p>to the form:</p>
   * <p>if (C) then (let $i := SEQ return R) else ()</p>
   *
   * @return an expression in which terms from the WHERE clause that can be extracted have been extracted
   */
  private def promoteWhereClause: Expression = {
    if (Choose.isSingleBranchChoice(getAction)) {
      val condition = getAction.asInstanceOf[Choose].getCondition(0)
      val bindingList = Array[Binding](this)
      val list = new util.ArrayList[Expression](5)
      var promotedCondition = null
      BooleanExpression.listAndComponents(condition, list)
      for (i <- list.size - 1 to 0 by -1) {
        val term = list.get(i)
        if (!ExpressionTool.dependsOnVariable(term, bindingList)) {
          if (promotedCondition == null) promotedCondition = term
          else promotedCondition = new AndExpression(term, promotedCondition)
          list.remove(i)
        }
      }
      if (promotedCondition != null) if (list.isEmpty) { // the whole if() condition has been promoted
        val oldThen = getAction.asInstanceOf[Choose].getAction(0)
        setAction(oldThen)
        return Choose.makeConditional(condition, this)
      }
      else { // one or more terms of the if() condition have been promoted
        var retainedCondition = list.get(0)
        for (i <- 1 until list.size) {
          retainedCondition = new AndExpression(retainedCondition, list.get(i))
        }
        getAction.asInstanceOf[Choose].setCondition(0, retainedCondition)
        val newIf = Choose.makeConditional(promotedCondition, this, Literal.makeEmptySequence)
        ExpressionTool.copyLocationInfo(this, newIf)
        return newIf
      }
    }
    null
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @param rebindings variables that need to be re-bound
   * @return the copy of the original expression
   */
  override def copy(rebindings: RebindingMap) = {
    val forExp = new ForExpression
    ExpressionTool.copyLocationInfo(this, forExp)
    forExp.setRequiredType(requiredType)
    forExp.setVariableQName(variableName)
    forExp.setSequence(getSequence.copy(rebindings))
    rebindings.put(this, forExp)
    val newAction = getAction.copy(rebindings)
    forExp.setAction(newAction)
    forExp.variableName = variableName
    forExp.slotNumber = slotNumber
    forExp
  }

  /**
   * Mark tail function calls: only possible if the for expression iterates zero or one times.
   * (This arises in XSLT/XPath, which does not have a LET expression, so FOR gets used instead)
   */
  override def markTailFunctionCalls(qName: StructuredQName, arity: Int) = if (!Cardinality.allowsMany(getSequence.getCardinality)) ExpressionTool.markTailFunctionCalls(getAction, qName, arity)
  else UserFunctionCall.NOT_TAIL_CALL

  /**
   * Determine whether this is a vacuous expression as defined in the XQuery update specification
   *
   * @return true if this expression is vacuous
   */
  override def isVacuousExpression = getAction.isVacuousExpression

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided. This implementation provides both iterate() and
   * process() methods natively.
   */
  override def getImplementationMethod = ITERATE_METHOD | PROCESS_METHOD

  /**
   * Check that any elements and attributes constructed or returned by this expression are acceptable
   * in the content model of a given complex type. It's always OK to say yes, since the check will be
   * repeated at run-time. The process of checking element and attribute constructors against the content
   * model of a complex type also registers the type of content expected of those constructors, so the
   * static validation can continue recursively.
   */
  @throws[XPathException]
  override def checkPermittedContents(parentType: SchemaType, whole: Boolean) = getAction.checkPermittedContents(parentType, false)

  /**
   * Iterate over the sequence of values
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = { // First create an iteration of the base sequence.
    // Then create a MappingIterator which applies a mapping function to each
    // item in the base sequence. The mapping function is essentially the "return"
    // expression, wrapped in a MappingAction object that is responsible also for
    // setting the range variable at each step.
    val base = getSequence.iterate(context)
    val map = new ForExpression.MappingAction(context, getLocalSlotNumber, getAction)
    actionCardinality match {
      case StaticProperty.EXACTLY_ONE =>
        new ItemMappingIterator(base, map, true)
      case StaticProperty.ALLOWS_ZERO_OR_ONE =>
        new ItemMappingIterator(base, map, false)
      case _ =>
        new MappingIterator(base, map)
    }
  }

  /**
   * Process this expression as an instruction, writing results to the current
   * outputter
   */
  @throws[XPathException]
  override def process(output: Outputter, context: XPathContext) = {
    val slot = getLocalSlotNumber
    getSequence.iterate(context).forEachOrFail((item: Item) => {
      def foo(item: Item) = {
        context.setLocalVariable(slot, item)
        getAction.process(output, context)
      }

      foo(item)
    })
  }

  /**
   * Evaluate an updating expression, adding the results to a Pending Update List.
   * The default implementation of this method, which is used for non-updating expressions,
   * throws an UnsupportedOperationException
   *
   * @param context the XPath dynamic evaluation context
   * @param pul     the pending update list to which the results should be written
   */
  @throws[XPathException]
  override def evaluatePendingUpdates(context: XPathContext, pul: PendingUpdateList) = {
    val slot = getLocalSlotNumber
    getSequence.iterate(context).forEachOrFail((item: Item) => {
      def foo(item: Item) = {
        context.setLocalVariable(slot, item)
        getAction.evaluatePendingUpdates(context, pul)
      }

      foo(item)
    })
  }

  /**
   * Determine the data type of the items returned by the expression, if possible
   *
   * @return one of the values Type.STRING, Type.BOOLEAN, Type.NUMBER, Type.NODE,
   *         or Type.ITEM (meaning not known in advance)
   */
  override def getItemType = getAction.getItemType

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @param contextItemType the static type of the context item
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   */
  override def getStaticUType(contextItemType: UType) = getAction.getStaticUType(contextItemType)

  /**
   * Determine the static cardinality of the expression
   */
  override def computeCardinality = {
    val c1 = getSequence.getCardinality
    val c2 = getAction.getCardinality
    Cardinality.multiply(c1, c2)
  }

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   *
   * @return a representation of the expression as a string
   */
  override def toString = "for $" + getVariableEQName + " in " + (if (getSequence == null) "(...)"
  else getSequence.toString) + " return " + (if (getAction == null) "(...)"
  else ExpressionTool.parenthesize(getAction))

  override def toShortString = "for $" + getVariableQName.getDisplayName + " in " + (if (getSequence == null) "(...)"
  else getSequence.toShortString) + " return " + (if (getAction == null) "(...)"
  else getAction.toShortString)

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    out.startElement("for", this)
    explainSpecializedAttributes(out)
    out.emitAttribute("var", getVariableQName)
    val varType = getSequence.getItemType
    if (varType ne AnyItemType.getInstance) out.emitAttribute("as", AlphaCode.fromItemType(varType))
    out.emitAttribute("slot", "" + getLocalSlotNumber)
    out.setChildRole("in")
    getSequence.`export`(out)
    out.setChildRole("return")
    getAction.`export`(out)
    out.endElement
  }

  protected def explainSpecializedAttributes(out: ExpressionPresenter) = {
    // no action
  }

  override def getStreamerName = "ForExpression"
}