package net.sf.saxon.om

import net.sf.saxon.trans.XPathException
import java.util

/**
 * Class IteratorWrapper - provides an an SequenceIterator over a Java Iterator.
 */
class IteratorWrapper(var iterator: Iterator[_ <: Item])

/**
 * Create a IteratorWrapper backed by an iterator
 *
 * @param iterator the iterator that delivers the items in the sequence
 */
  extends SequenceIterator {
  /**
   * Get the next item in the Iterator
   *
   * @return the next item in the iterator, or null if there are no more items. Once a call
   *         on next() has returned null, no further calls should be made.
   */
  @throws[XPathException]
  override def next = if (iterator.hasNext) iterator.next
  else null
}