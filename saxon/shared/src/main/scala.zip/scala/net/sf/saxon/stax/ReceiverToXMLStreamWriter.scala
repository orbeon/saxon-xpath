////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.stax

import javax.xml.stream.{XMLStreamException, XMLStreamWriter}
import net.sf.saxon.event.{PipelineConfiguration, Receiver}
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.{AttributeMap, NamespaceMap, NodeName}
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException

/**
 * ReceiverToXMLStreamWriter is a Receiver writes XML by using the XMLStreamWriter
 */
class ReceiverToXMLStreamWriter(var writer: XMLStreamWriter) extends Receiver {
  protected var pipe = null
  protected var config = null
  protected var systemId = null
  protected var baseURI = null

  /**
   * Get the XMLStreamWriter to which this Receiver is writing events
   *
   * @return the destination of this ReceiverToXMLStreamWriter
   */
  def getXMLStreamWriter = writer

  def setPipelineConfiguration(pipe: PipelineConfiguration) = {
    this.pipe = pipe
    config = pipe.getConfiguration
  }

  override def getPipelineConfiguration = pipe

  override def setSystemId(systemId: String) = this.systemId = systemId

  override def getSystemId = systemId

  @throws[XPathException]
  override def open() = {
  }

  @throws[XPathException]
  override def startDocument(properties: Int) = try writer.writeStartDocument()
  catch {
    case e: XMLStreamException =>
      throw new XPathException(e)
  }

  @throws[XPathException]
  override def endDocument() = try writer.writeEndDocument()
  catch {
    case e: XMLStreamException =>
      throw new XPathException(e)
  }

  @throws[XPathException]
  override def setUnparsedEntity(name: String, systemID: String, publicID: String) = {
  }

  @throws[XPathException]
  def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    val local = elemName.getLocalPart
    val uri = elemName.getURI
    val prefix = elemName.getPrefix
    try {
      if (prefix == "" && uri == "") writer.writeStartElement(local)
      else if (prefix == "") writer.writeStartElement(prefix, local, uri)
      else writer.writeStartElement(prefix, local, uri)
      for (ns <- namespaces) {
        writer.writeNamespace(ns.getPrefix, ns.getURI)
      }
      for (att <- attributes) {
        val attName = att.getNodeName
        val attLocal = attName.getLocalPart
        val attUri = attName.getURI
        val attPrefix = attName.getPrefix
        val value = att.getValue
        if (attPrefix == "" && attUri == "") writer.writeAttribute(attLocal, value)
        else if (attPrefix == "" & !(attUri == "")) writer.writeAttribute(uri, local, value)
        else writer.writeAttribute(prefix, uri, local, value)
      }
    } catch {
      case e: XMLStreamException =>
        throw new XPathException(e)
    }
  }

  @throws[XPathException]
  override def endElement() = try writer.writeEndElement()
  catch {
    case e: XMLStreamException =>
      throw new XPathException(e)
  }

  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = try writer.writeCharacters(chars.toString)
  catch {
    case e: XMLStreamException =>
      throw new XPathException(e)
  }

  @throws[XPathException]
  override def processingInstruction(name: String, data: CharSequence, locationId: Location, properties: Int) = try writer.writeProcessingInstruction(name, data.toString)
  catch {
    case e: XMLStreamException =>
      throw new XPathException(e)
  }

  @throws[XPathException]
  override def comment(content: CharSequence, locationId: Location, properties: Int) = try writer.writeComment(content.toString)
  catch {
    case e: XMLStreamException =>
      throw new XPathException(e)
  }

  @throws[XPathException]
  override def close() = try writer.close()
  catch {
    case e: XMLStreamException =>
      throw new XPathException(e)
  }

  override def usesTypeAnnotations = false
}