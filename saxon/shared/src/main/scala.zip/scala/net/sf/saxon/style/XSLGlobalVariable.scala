////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.instruct.Actor
import net.sf.saxon.expr.instruct.GlobalParam
import net.sf.saxon.expr.instruct.GlobalVariable
import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.Optimizer
import net.sf.saxon.expr.parser.RetainedStaticContext
import net.sf.saxon.model.Affinity
import net.sf.saxon.model.AnyItemType
import net.sf.saxon.model.Type
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.StandardNames
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.SymbolicName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import java.util

/**
 * Handler for xsl:variable elements appearing as a child of xsl:stylesheet.
 * <p>The xsl:variable element has mandatory attribute {@code name} and
 * optional attribute {@code select} (inter alia)</p>
 */
class XSLGlobalVariable() extends StyleElement with StylesheetComponent {
  sourceBinding.setProperty(SourceBinding.BindingProperty.GLOBAL, true)
  private var slotManager = null // used to manage local variables declared inside this global variable
  protected var sourceBinding = new SourceBinding(this)
  protected var compiledVariable = null

  /**
   * Get the source binding object that holds information about the declared variable.
   *
   * @return the source binding
   */
  def getSourceBinding = sourceBinding

  def getVariableQName = sourceBinding.getVariableQName

  override def getObjectName = sourceBinding.getVariableQName

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  /**
   * Test whether this is a global variable or parameter
   *
   * @return true if this is global
   */
  def isGlobal = {
    isTopLevel
    // might be called before the "global" field is initialized
  }

  /**
   * Hook to allow additional validation of a parent element immediately after its
   * children have been validated.
   */
  @throws[XPathException]
  override def postValidate() = sourceBinding.postValidate()

  def getCompiledVariable = compiledVariable

  protected def getPermittedAttributes = util.EnumSet.of(SourceBinding.BindingProperty.ASSIGNABLE, SourceBinding.BindingProperty.SELECT, SourceBinding.BindingProperty.AS, SourceBinding.BindingProperty.STATIC, SourceBinding.BindingProperty.VISIBILITY)

  private var state = 0
  protected var redundant = false

  /**
   * Get the corresponding Procedure object that results from the compilation of this
   * StylesheetProcedure
   */
  @throws[XPathException]
  override def getActor = {
    var gv = getCompiledVariable
    if (gv == null) {
      gv = if (this.isInstanceOf[XSLGlobalParam]) new GlobalParam
      else new GlobalVariable
      gv.setPackageData(getCompilation.getPackageData)
      gv.obtainDeclaringComponent(this)
      gv.setRequiredType(sourceBinding.getDeclaredType)
      gv.setDeclaredVisibility(getDeclaredVisibility)
      gv.setVariableQName(sourceBinding.getVariableQName)
      gv.setSystemId(getSystemId)
      gv.setLineNumber(getLineNumber)
      val rsc = makeRetainedStaticContext
      gv.setRetainedStaticContext(rsc)
      if (gv.getBody != null) gv.getBody.setRetainedStaticContext(rsc)
      compiledVariable = gv
    }
    gv
  }

  override def getSymbolicName = new SymbolicName(StandardNames.XSL_VARIABLE, getObjectName)

  override def checkCompatibility(component: Component) = {
    var st1 = getSourceBinding.getDeclaredType
    if (st1 == null) st1 = SequenceType.ANY_SEQUENCE
    val other = component.getActor.asInstanceOf[GlobalVariable]
    val th = component.getDeclaringPackage.getConfiguration.getTypeHierarchy
    val relation = th.sequenceTypeRelationship(st1, other.getRequiredType)
    if (relation ne Affinity.SAME_TYPE) compileError("The declared type of the overriding variable $" + getVariableQName.getDisplayName + " is different from that of the overridden variable", "XTSE3070")
  }

  /**
   * Ask whether this element contains a binding for a variable with a given name; and if it does,
   * return the source binding information
   *
   * @param name the variable name
   * @return the binding information if this element binds a variable of this name; otherwise null
   */
  override def getBindingInformation(name: StructuredQName) = if (name == sourceBinding.getVariableQName) sourceBinding
  else null

  override def prepareAttributes(): Unit = {
    if (state == 2) return
    if (state == 1) compileError("Circular reference to variable", "XTDE0640")
    state = 1
    //System.err.println("Prepare attributes of $" + getVariableName());
    sourceBinding.prepareAttributes(getPermittedAttributes)
    state = 2
  }

  @throws[XPathException]
  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = top.indexVariableDeclaration(decl)

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    slotManager = getConfiguration.makeSlotManager
    sourceBinding.validate()
  }

  /**
   * Ask whether the global variable is declared with assignable="yes"
   *
   * @return true if assignabl="yes" was specified
   */
  def isAssignable = sourceBinding.hasProperty(SourceBinding.BindingProperty.ASSIGNABLE)

  /**
   * Determine whether this node is a declaration.
   *
   * @return true - a global variable is a declaration
   */
  override def isDeclaration = true

  /**
   * Determine whether this node is an instruction.
   *
   * @return false - a global variable is not an instruction
   */
  override def isInstruction = false

  /**
   * Get the static type of the variable. This is the declared type, unless the value
   * is statically known and constant, in which case it is the actual type of the value.
   *
   * @return the declared or inferred static type of the variable
   */
  def getRequiredType = sourceBinding.getInferredType(true)

  @throws[XPathException]
  override def fixupReferences() = {
    sourceBinding.fixupReferences(compiledVariable)
    super.fixupReferences
  }

  /**
   * Compile.
   * This method ensures space is available for local variables declared within
   * this global variable
   */
  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = { // Commented out: Can't eliminate unused variables at this stage because they might be xsl:expose'd as public
    //        boolean unused = sourceBinding.getReferences().isEmpty() && !isAssignable() &&
    //                getVisibility() == Visibility.PRIVATE;
    //        if (unused && !compilation.getCompilerInfo().isCompileWithTracing()) {
    //            redundant = true;
    //            // Remove the global variable from the package (otherwise a failure can occur
    //            // when pre-evaluating global variables)
    //            compilation.getPrincipalStylesheetModule().removeGlobalVariable(decl);
    //        }
    if (!redundant) {
      sourceBinding.handleSequenceConstructor(compilation, decl)
      var inst = getCompiledVariable
      if (inst == null) {
        inst = new GlobalVariable
        inst.setPackageData(getCompilation.getPackageData)
        inst.obtainDeclaringComponent(this)
        inst.setVariableQName(sourceBinding.getVariableQName)
      }
      if (sourceBinding.isStatic) {
        inst.setStatic(true)
        val value = compilation.getStaticVariable(sourceBinding.getVariableQName)
        if (value == null) throw new AssertionError
        val select = Literal.makeLiteral(value)
        select.setRetainedStaticContext(makeRetainedStaticContext)
        inst.setBody(select)
      }
      else {
        val select = sourceBinding.getSelectExpression
        inst.setBody(select)
        if (compilation.getCompilerInfo.getCodeInjector != null) compilation.getCompilerInfo.getCodeInjector.process(inst)
      }
      inst.setRetainedStaticContext(makeRetainedStaticContext)
      initializeBinding(inst)
      inst.setAssignable(isAssignable)
      inst.setRequiredType(getRequiredType)
      sourceBinding.fixupBinding(inst)
      compiledVariable = inst
      val overridden = getOverriddenComponent
      if (overridden != null) checkCompatibility(overridden)
    }
  }

  /**
   * Initialize - common code called from the compile() method of all subclasses
   *
   * @param var the representation of the variable declaration in the compiled executable
   */
  protected def initializeBinding(`var`: GlobalVariable) = {
    val select = `var`.getBody
    var exp2 = select
    if (exp2 != null) {
      try {
        val visitor = makeExpressionVisitor
        exp2 = select.simplify.typeCheck(visitor, getConfiguration.makeContextItemStaticInfo(Type.ITEM_TYPE, true))
      } catch {
        case err: XPathException =>
          compileError(err)
      }
      // Add trace wrapper code if required
      exp2 = makeTraceInstruction(this, exp2)
      allocateLocalSlots(exp2)
    }
    if (slotManager != null && slotManager.getNumberOfVariables > 0) `var`.setContainsLocals(slotManager)
    //StylesheetPackage pack = getCompilation().getStylesheetPackage();
    //pack.registerGlobalVariable(gvar);
    if (exp2 ne select) `var`.setBody(exp2)
  }

  /**
   * Get the SlotManager associated with this stylesheet construct. The SlotManager contains the
   * information needed to manage the local stack frames used by run-time instances of the code.
   *
   * @return the associated SlotManager object
   */
  override def getSlotManager = slotManager

  /**
   * Optimize the stylesheet construct
   *
   * @param declaration the declaration of this variable
   */
  @throws[XPathException]
  override def optimize(declaration: ComponentDeclaration) = if (!redundant && compiledVariable.getBody != null) {
    var exp2 = compiledVariable.getBody
    val visitor = makeExpressionVisitor
    exp2 = ExpressionTool.optimizeComponentBody(exp2, getCompilation, visitor, getConfiguration.makeContextItemStaticInfo(AnyItemType.getInstance, true), false)
    allocateLocalSlots(exp2)
    if (slotManager != null && slotManager.getNumberOfVariables > 0) compiledVariable.setContainsLocals(slotManager)
    if (exp2 ne compiledVariable.getBody) compiledVariable.setBody(exp2)
  }

  /**
   * Mark this global variable as redundant, typically because it is overridden by another global
   * variable of the same name, or because there are no references to it
   *
   * @param redundant true if this variable is redundant, otherwise false
   */
  def setRedundant(redundant: Boolean) = this.redundant = redundant

  /**
   * Generate byte code if appropriate
   *
   * @param opt the optimizer
   *
   */
  override def generateByteCode(opt: Optimizer) = {
  }
}