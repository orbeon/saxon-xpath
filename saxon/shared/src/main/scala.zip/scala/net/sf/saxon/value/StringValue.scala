////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.sort.AtomicMatchKey
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.regex.BMPString
import net.sf.saxon.regex.EmptyString
import net.sf.saxon.regex.LatinString
import net.sf.saxon.regex.UnicodeString
import net.sf.saxon.tree.iter.AtomicIterator
import net.sf.saxon.tree.util.CharSequenceConsumer
import net.sf.saxon.tree.util.FastStringBuffer

/**
 * An atomic value of type xs:string. This class is also used for types derived from xs:string.
 * Subclasses of StringValue are used for xs:untypedAtomic and xs:anyURI values.
 */
object StringValue {
  val EMPTY_STRING = new StringValue(EmptyString.THE_INSTANCE)
  val SINGLE_SPACE = new StringValue(LatinString.SINGLE_SPACE)
  val TRUE = new StringValue(new LatinString("true"))
  val FALSE = new StringValue(new LatinString("false"))

  /**
   * Factory method. Unlike the constructor, this avoids creating a new StringValue in the case
   * of a zero-length string (and potentially other strings, in future)
   *
   * @param value the String value. Null is taken as equivalent to "".
   * @return the corresponding StringValue
   */
  /*@NotNull*/ def makeStringValue(/*@Nullable*/ value: CharSequence) = if (value == null || value.length == 0) StringValue.EMPTY_STRING
  else new StringValue(value)

  /**
   * Utility method to test whether a CharSequence is empty
   *
   * @param string the input CharSequence
   * @return true if the CharSequence is empty
   */
  def isEmpty(string: CharSequence) = if (string.isInstanceOf[String]) string.asInstanceOf[String].isEmpty
  else if (string.isInstanceOf[UnicodeString]) string.asInstanceOf[UnicodeString].uLength == 0
  else string.length == 0

  /**
   * Get the length of a string, as defined in XPath. This is not the same as the Java length,
   * as a Unicode surrogate pair counts as a single character.
   *
   * @param s The string whose length is required
   * @return the length of the string in Unicode code points
   */
  def getStringLength(s: CharSequence): Int = {
    if (s.isInstanceOf[UnicodeString]) return s.asInstanceOf[UnicodeString].uLength
    var n = 0
    for (i <- 0 until s.length) {
      val c = s.charAt(i).toInt
      if (c < 55296 || c > 56319) n += 1 // don't count high surrogates, i.e. D800 to DBFF
    }
    n
  }

  /**
   * Expand a string containing surrogate pairs into an array of 32-bit characters
   *
   * @param s the string to be expanded
   * @return an array of integers representing the Unicode code points
   */
  def expand(s: CharSequence) = {
    val array = new Array[Int](getStringLength(s))
    var o = 0
    var i = 0
    while ( {
      i < s.length
    }) {
      var charval = 0
      val c = s.charAt(i)
      if (c >= 55296 && c <= 56319) { // we'll trust the data to be sound
        charval = ((c - 55296) * 1024) + (s.charAt(i + 1).toInt - 56320) + 65536
        i += 1
      }
      else charval = c
      array({
        o += 1; o - 1
      }) = charval
      i += 1
    }
    array
  }

  /**
   * Contract an array of integers containing Unicode codepoints into a Java string
   *
   * @param codes an array of integers representing the Unicode code points
   * @param used  the number of items in the array that are actually used
   * @return the constructed string
   */
  def contract(codes: Array[Int], used: Int) = {
    val sb = new FastStringBuffer(codes.length)
    for (i <- 0 until used) {
      sb.appendWideChar(codes(i))
    }
    sb
  }

  /**
   * Produce a diagnostic representation of the contents of the string
   *
   * @param s the string
   * @return a string in which non-Ascii-printable characters are replaced by \ uXXXX escapes
   */
  def diagnosticDisplay(s: String) = {
    val fsb = new FastStringBuffer(s.length)
    var i = 0
    val len = s.length
    while ( {
      i < len
    }) {
      val c = s.charAt(i)
      if (c >= 0x20 && c <= 0x7e) fsb.cat(c)
      else {
        fsb.append("\\u")
        var shift = 12
        while ( {
          shift >= 0
        }) {
          fsb.cat("0123456789ABCDEF".charAt((c >> shift) & 0xF))
          shift -= 4
        }
      }
      i += 1
    }
    fsb.toString
  }

  /**
   * CharacterIterator is used to iterate over the characters in a string,
   * returning them as integers representing the Unicode code-point.
   */
  final class CharacterIterator(var value: CharSequence)

  /**
   * Create an iterator over a string
   */
    extends AtomicIterator[Int64Value] {
    private[value] var inpos = 0 // 0-based index of the current Java char
    override def next = if (inpos < value.length) {
      val c = value.charAt({
        inpos += 1; inpos - 1
      })
      var current = 0
      if (c >= 55296 && c <= 56319) try current = ((c - 55296) * 1024) + (value.charAt({
        inpos += 1; inpos - 1
      }).toInt - 56320) + 65536
      catch {
        case e: StringIndexOutOfBoundsException =>
          System.err.println("Invalid surrogate at end of string")
          System.err.println(diagnosticDisplay(value.toString))
          e.printStackTrace()
          throw e
      }
      else current = c
      new Int64Value(current)
    }
    else null
  }

  final class UnicodeCharacterIterator(var uValue: UnicodeString) extends AtomicIterator[Int64Value] {
    private[value] var inpos = 0

    override def next = if (inpos < uValue.uLength) new Int64Value(uValue.uCharAt({
      inpos += 1; inpos - 1
    }))
    else null
  }

  final class Builder extends CharSequenceConsumer {
    private[value] val buffer = new FastStringBuffer(256)

    override def cat(chars: CharSequence) = buffer.cat(chars)

    override def cat(c: Char) = buffer.cat(c)

    def getStringValue = new StringValue(buffer.condense)
  }

}

class StringValue protected()

/**
 * Protected constructor for use by subtypes
 */
  extends AtomicValue {
  uValue = ""
  typeLabel = BuiltInAtomicType.STRING
  protected var value = null // may be zero-length, will never be null
  /**
   * Constructor. Note that although a StringValue may wrap any kind of CharSequence
   * (usually a String, but it can also be, for example, a StringBuffer), the caller
   * is responsible for ensuring that the value is immutable.
   *
   * @param value the String value. Null is taken as equivalent to "".
   */
  def this(value: CharSequence) {
    this()
    this.value = if (value == null) ""
    else value
    typeLabel = BuiltInAtomicType.STRING
  }

  /**
   * Constructor. Note that although a StringValue may wrap any kind of CharSequence
   * (usually a String, but it can also be, for example, a StringBuffer), the caller
   * is responsible for ensuring that the value is immutable.
   *
   * @param value     the String value.
   * @param typeLabel the type of the value to be created. The caller must ensure that this is
   *                  a type derived from string and that the string is valid against this type.
   */
  def this(value: CharSequence, typeLabel: AtomicType) {
    this()
    this.value = value
    this.typeLabel = typeLabel
  }

  /**
   * Assert that the string is known to contain no surrogate pairs
   */
  def setContainsNoSurrogates() = if (!(value.isInstanceOf[BMPString] || value.isInstanceOf[LatinString] || value.isInstanceOf[EmptyString])) value = new BMPString(value)

  /**
   * Create a copy of this atomic value, with a different type label
   *
   * @param typeLabel the type label of the new copy. The caller is responsible for checking that
   *                  the value actually conforms to this type.
   */
  override def copyAsSubType(typeLabel: AtomicType) = {
    val v = new StringValue(value)
    v.typeLabel = typeLabel
    v
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.STRING

  /**
   * Get the string value as a CharSequence
   */
  override final def getPrimitiveStringValue = value

  /**
   * Set the value of the item as a CharSequence.
   * <p><b>For system use only. In principle, a StringValue is immutable. However, in special circumstances,
   * if it is newly constructed, the content can be changed to reflect the effect of the whiteSpace facet.</b></p>
   *
   * @param value the value of the string
   */
  final def setStringValueCS(value: CharSequence) = this.value = value

  /**
   * Get the length of this string, as defined in XPath. This is not the same as the Java length,
   * as a Unicode surrogate pair counts as a single character
   *
   * @return the length of the string in Unicode code points
   */
  def getStringLength = {
    if (!value.isInstanceOf[UnicodeString]) makeUnicodeString()
    value.asInstanceOf[UnicodeString].uLength
  }

  /**
   * Get an upper bound on the length of the string in Unicode codepoints.
   *
   * @return a value N such that getStringLength &lt;= N. In practice, if the string is held
   *         as UTF16 codepoints this will be the length in UTF16 codepoints; if it is held in Unicode
   *         codepoints, it will be the length in Unicode codepoints
   */
  def getStringLengthUpperBound = if (value.isInstanceOf[UnicodeString]) value.asInstanceOf[UnicodeString].uLength
  else value.length

  /**
   * Get a UnicodeString value representing the same characters as this string. This is a memo-function;
   * the value is computed the first time it is needed, and is cached for subsequent reuse
   *
   * @return the corresponding UnicodeString
   */
  def getUnicodeString = {
    if (!value.isInstanceOf[UnicodeString]) makeUnicodeString()
    value.asInstanceOf[UnicodeString]
  }

  /**
   * Construct a Unicode representation of this string in which each character occupies a fixed amount of space,
   * allowing direct addressing and counting of Unicode characters
   */
  private def makeUnicodeString() = value = UnicodeString.makeUnicodeString(value)

  /**
   * Determine whether the string is a zero-length string. This may
   * be more efficient than testing whether the length is equal to zero
   *
   * @return true if the string is zero length
   */
  def isZeroLength = value.length == 0

  /**
   * Determine whether the string contains surrogate pairs
   *
   * @return true if the string contains any non-BMP characters
   */
  def containsSurrogatePairs = UnicodeString.containsSurrogatePairs(value)

  /**
   * Ask whether the string is known to contain no surrogate pairs.
   *
   * @return true if it is known to contain no surrogates, false if the answer is not known
   */
  def isKnownToContainNoSurrogates = value.isInstanceOf[BMPString] || value.isInstanceOf[LatinString] || value.isInstanceOf[EmptyString]

  /**
   * Iterate over a string, returning a sequence of integers representing the Unicode code-point values
   *
   * @return an iterator over the characters (Unicode code points) in the string
   */
  def iterateCharacters = if (value.isInstanceOf[UnicodeString]) new StringValue.UnicodeCharacterIterator(value.asInstanceOf[UnicodeString])
  else new StringValue.CharacterIterator(value)

  /**
   * Get an object value that implements the XPath equality and ordering comparison semantics for this value.
   * If the ordered parameter is set to true, the result will be a Comparable and will support a compareTo()
   * method with the semantics of the XPath lt/gt operator, provided that the other operand is also obtained
   * using the getXPathComparable() method. In all cases the result will support equals() and hashCode() methods
   * that support the semantics of the XPath eq operator, again provided that the other operand is also obtained
   * using the getXPathComparable() method. A context argument is supplied for use in cases where the comparison
   * semantics are context-sensitive, for example where they depend on the implicit timezone or the default
   * collation.
   *
   * @param ordered          true if an ordered comparison is required. In this case the result is null if the
   *                         type is unordered; in other cases the returned value will be a Comparable.
   * @param collator         Collation to be used for comparing strings
   * @param implicitTimezone the XPath dynamic evaluation context, used in cases where the comparison is context
   *                         sensitive
   * @return an Object whose equals() and hashCode() methods implement the XPath comparison semantics
   *         with respect to this atomic value. If ordered is specified, the result will either be null if
   *         no ordering is defined, or will be a Comparable
   */
  override def getXPathComparable(ordered: Boolean, collator: StringCollator, implicitTimezone: Int) = collator.getCollationKey(value)

  /**
   * Determine if two AtomicValues are equal, according to XPath rules. (This method
   * is not used for string comparisons, which are always under the control of a collation.
   * If we get here, it's because there's a type error in the comparison.)
   *
   * @throws ClassCastException always
   */
  override def equals(other: Any) = throw new ClassCastException("equals on StringValue is not allowed")

  override def hashCode = value.hashCode

  /**
   * Test whether this StringValue is equal to another under the rules of the codepoint collation
   *
   * @param other the value to be compared with this value
   * @return true if the strings are equal on a codepoint-by-codepoint basis
   */
  def codepointEquals(other: StringValue) = if (value.isInstanceOf[String]) value.asInstanceOf[String].contentEquals(other.value)
  else if (other.value.isInstanceOf[String]) other.value.asInstanceOf[String].contentEquals(value)
  else if (value.isInstanceOf[UnicodeString]) {
    if (!other.value.isInstanceOf[UnicodeString]) other.makeUnicodeString()
    value == other.value
  }
  else { // Avoid conversion to String unless the lengths are equal
    value.length == other.value.length && value.toString == other.value.toString
  }

  /**
   * Get the effective boolean value of a string
   *
   * @return true if the string has length greater than zero
   */
  override def effectiveBooleanValue = !isZeroLength

  override def toString = "\"" + value + '\"'

  override def toShortString = {
    var s = value.toString
    if (s.length > 40) s = s.substring(0, 35) + "..."
    "\"" + s + '\"'
  }

  /**
   * Get a Comparable value that implements the XML Schema comparison semantics for this value.
   * Returns null if the value is not comparable according to XML Schema rules. This implementation
   * returns the underlying Java string, which works because strings will only be compared for
   * equality, not for ordering, and the equality rules for strings in XML schema are the same as in Java.
   */
  override def getSchemaComparable = getStringValue

  /**
   * Determine whether two atomic values are identical, as determined by XML Schema rules. This is a stronger
   * test than equality (even schema-equality); for example two dateTime values are not identical unless
   * they are in the same timezone.
   * <p>Note that even this check ignores the type annotation of the value. The integer 3 and the short 3
   * are considered identical, even though they are not fully interchangeable. "Identical" means the
   * same point in the value space, regardless of type annotation.</p>
   * <p>NaN is identical to itself.</p>
   *
   * @param v the other value to be compared with this one
   * @return true if the two values are identical, false otherwise.
   */
  override def isIdentical(v: AtomicValue) = v.isInstanceOf[StringValue] && (this.isInstanceOf[AnyURIValue] == v.isInstanceOf[AnyURIValue]) && (this.isInstanceOf[UntypedAtomicValue] == v.isInstanceOf[UntypedAtomicValue]) && codepointEquals(v.asInstanceOf[StringValue])
}