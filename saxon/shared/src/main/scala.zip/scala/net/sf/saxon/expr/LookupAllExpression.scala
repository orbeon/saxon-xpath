////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.ma.arrays.ArrayItem
import net.sf.saxon.ma.arrays.ArrayItemType
import net.sf.saxon.ma.arrays.SquareArrayConstructor
import net.sf.saxon.ma.map.KeyValuePair
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.ma.map.MapType
import net.sf.saxon.ma.map.TupleType
import net.sf.saxon.model._
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.Item
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import java.util

/**
 * A lookup expression is an expression of the form A?*, where A must be a map or an array
 */
class LookupAllExpression(val base: Expression)

/**
 * Constructor
 *
 * @param base The left hand operand (which must always select a sequence of maps or arrays).
 */
  extends UnaryExpression(base) {
  override protected def getOperandRole = OperandRole.INSPECT

  /**
   * Determine the data type of the items returned by this expression
   *
   * @return the type of the step
   */
  /*@NotNull*/ override final def getItemType = {
    val base = getBaseExpression.getItemType
    if (base.isInstanceOf[MapType]) base.asInstanceOf[MapType].getValueType.getPrimaryType
    else if (base.isInstanceOf[ArrayItemType]) base.asInstanceOf[ArrayItemType].getMemberType.getPrimaryType
    else AnyItemType.getInstance
  }

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType The type of the context item (not used)
   */
  override def getStaticUType(contextItemType: UType) = getItemType.getUType

  /**
   * Type-check the expression
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    // Check the first operand
    getOperand.typeCheck(visitor, contextInfo)
    val containerType = getBaseExpression.getItemType
    val isArrayLookup = containerType.isInstanceOf[ArrayItemType]
    val isMapLookup = containerType.isInstanceOf[MapType] || containerType.isInstanceOf[TupleType]
    if (!isArrayLookup && !isMapLookup) if ((th.relationship(containerType, MapType.ANY_MAP_TYPE) eq Affinity.DISJOINT) && (th.relationship(containerType, ArrayItemType.getInstance) eq Affinity.DISJOINT)) {
      val err = new XPathException("The left-hand operand of '?' must be a map or an array; the supplied expression is of type " + containerType, "XPTY0004")
      err.setLocation(getLocation)
      err.setIsTypeError(true)
      err.setFailingExpression(this)
      throw err
    }
    if (getBaseExpression.isInstanceOf[Literal]) return new Literal(iterate(visitor.makeDynamicContext).materialize)
    this
  }

  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    getOperand.optimize(visitor, contextItemType)
    if (getBaseExpression.isInstanceOf[Literal]) return new Literal(iterate(visitor.makeDynamicContext).materialize)
    // See W3C bug 30228. In the interests of keeping certain tests streamable, we do a rewrite of [A,B,C]?*
    // to (A, B, C).
    if (getBaseExpression.isInstanceOf[SquareArrayConstructor]) {
      val children = new util.ArrayList[Expression]
      import scala.collection.JavaConversions._
      for (o <- getBaseExpression.operands) {
        children.add(o.getChildExpression.copy(new RebindingMap))
      }
      val childExpressions = children.toArray(new Array[Expression](0))
      val block = new Block(childExpressions)
      ExpressionTool.copyLocationInfo(this, block)
      return block
    }
    this
  }

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   *
   * @return a rough estimate of the cost of evaluation
   */
  override def getCost = getBaseExpression.getCost + 1

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be re-bound.
   */
  override def copy(rebindings: RebindingMap) = new LookupAllExpression(getBaseExpression.copy(rebindings))

  /**
   * Determine the static cardinality of the expression
   */
  override def computeCardinality = StaticProperty.ALLOWS_ZERO_OR_MORE

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any): Boolean = {
    if (!other.isInstanceOf[LookupAllExpression]) return false
    val p = other.asInstanceOf[LookupAllExpression]
    getBaseExpression.isEqual(p.getBaseExpression)
  }

  /**
   * get HashCode for comparing two expressions
   */
  override def computeHashCode = "LookupAll".hashCode ^ getBaseExpression.hashCode

  /**
   * Iterate the lookup-expression in a given context
   *
   * @param context the evaluation context
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = new SequenceIterator() {
    final private[expr] val level0 = getBaseExpression.iterate(context)
    private[expr
    ]
    var level1 = null // delivers GroundedValue in the case of an array, or KeyValuePair in the case of a map
    private[expr] var level2 = null

    @throws[XPathException]
    override def next: Item = if (level2 == null) if (level1 == null) {
      val base = level0.next
      if (base == null) return null
      else if (base.isInstanceOf[ArrayItem]) {
        level1 = base.asInstanceOf[ArrayItem].members.iterator
        return next
      }
      else if (base.isInstanceOf[MapItem]) {
        level1 = base.asInstanceOf[MapItem].keyValuePairs.iterator
        return next
      }
      else {
        LookupExpression.mustBeArrayOrMap(thisLookupAllExpression, base)
        return null
      }
    }
    else {
      if (level1.hasNext) {
        val nextEntry = level1.next
        if (nextEntry.isInstanceOf[KeyValuePair]) {
          val value = nextEntry.asInstanceOf[KeyValuePair].value
          level2 = value.iterate
        }
        else if (nextEntry.isInstanceOf[GroundedValue]) level2 = nextEntry.asInstanceOf[GroundedValue].iterate
        else throw new IllegalStateException
      }
      else level1 = null
      return next
    }
    else {
      val next = level2.next
      if (next == null) {
        level2 = null
        return next
      }
      else return next
    }

    override

    def close() = {
      if (level0 != null) level0.close()
      if (level2 != null) level2.close()
    }
  }

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("lookupAll", this)
    getBaseExpression.`export`(destination)
    destination.endElement
  }

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   *
   * @return a representation of the expression as a string
   */
  override def toString = ExpressionTool.parenthesize(getBaseExpression) + "?*"

  override def toShortString = getBaseExpression.toShortString + "?*"
}