////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.Controller
import net.sf.saxon.expr.ContextOriginator
import net.sf.saxon.expr.UserFunctionCall
import net.sf.saxon.expr.XPathContext
import net.sf.saxon.expr.XPathContextMajor
import net.sf.saxon.expr.instruct.ApplyTemplates
import net.sf.saxon.expr.instruct.CallTemplate
import net.sf.saxon.expr.instruct.GlobalVariable
import net.sf.saxon.expr.instruct.UserFunction
import net.sf.saxon.trans.rules.BuiltInRuleSet
import java.util

/**
 * This class provides a representation of the current runtime call stack, as represented by the stack
 * of XPathContext objects.
 */
object ContextStackIterator {
  private def getMajorCaller(context: XPathContext) = {
    var caller = context.getCaller
    while ( {
      !(caller == null || caller.isInstanceOf[XPathContextMajor])
    }) caller = caller.getCaller
    caller.asInstanceOf[XPathContextMajor]
  }
}

class ContextStackIterator(val context: XPathContext)

/**
 * Create an iterator over the stack of XPath dynamic context objects, starting with the top-most
 * stackframe and working down. The objects returned by this iterator will be of class {@link ContextStackFrame}.
 * Note that only "major" context objects are considered - those that have a stack frame of their own.
 *
 * @param context the current context
 */
  extends util.Iterator[ContextStackFrame] {
  if (!evaluationContext.isInstanceOf[XPathContextMajor]) evaluationContext = ContextStackIterator.getMajorCaller(evaluationContext)
  emitter = evaluationContext.asInstanceOf[XPathContextMajor]
  private var next = null

  /**
   * Returns <tt>true</tt> if the iteration has more elements. (In other
   * words, returns <tt>true</tt> if <tt>next</tt> would return an element
   * rather than throwing an exception.)
   *
   * @return <tt>true</tt> if the iterator has more elements.
   */
  override def hasNext = next != null

  /**
   * Returns the next element in the iteration.  Calling this method
   * repeatedly until the {@link #hasNext()} method returns false will
   * return each element in the underlying collection exactly once.
   *
   * @return the next element in the iteration, which will always be an instance
   *         of { @link ContextStackFrame}
   * @throws java.util.NoSuchElementException
   * iteration has no more elements.
   */
  /*@Nullable*/ override def next: ContextStackFrame = {
    val context = next
    if (context == null) return null
    val origin = context.getOrigin
    if (origin.isInstanceOf[Controller]) {
      next = ContextStackIterator.getMajorCaller(context)
      new ContextStackFrame.CallingApplication
    }
    else if (origin.isInstanceOf[BuiltInRuleSet]) {
      next = ContextStackIterator.getMajorCaller(context)
      new ContextStackFrame.BuiltInTemplateRule(context)
    }
    else if (origin.isInstanceOf[UserFunction]) {
      val sf = new ContextStackFrame.FunctionCall
      val ufc = origin.asInstanceOf[UserFunction]
      sf.setLocation(ufc.getLocation)
      sf.setFunctionName(ufc.getFunctionName)
      sf.setContextItem(context.getContextItem)
      sf.setContext(context)
      next = ContextStackIterator.getMajorCaller(context)
      sf
    }
    else if (origin.isInstanceOf[UserFunctionCall]) { // No longer used? Bug 3671
      val sf = new ContextStackFrame.FunctionCall
      val ufc = origin.asInstanceOf[UserFunctionCall]
      sf.setLocation(ufc.getLocation)
      sf.setFunctionName(ufc.getFunctionName)
      sf.setContextItem(context.getContextItem)
      sf.setContext(context)
      next = ContextStackIterator.getMajorCaller(context)
      sf
    }
    else if (origin.isInstanceOf[ApplyTemplates]) {
      val sf = new ContextStackFrame.ApplyTemplates
      val loc = origin.asInstanceOf[ApplyTemplates]
      sf.setLocation(loc.getLocation)
      sf.setContextItem(context.getContextItem)
      sf.setContext(context)
      next = ContextStackIterator.getMajorCaller(context)
      sf
    }
    else if (origin.isInstanceOf[CallTemplate]) {
      val sf = new ContextStackFrame.CallTemplate
      val loc = origin.asInstanceOf[CallTemplate]
      sf.setLocation(loc.getLocation)
      sf.setTemplateName(loc.getObjectName)
      sf.setContextItem(context.getContextItem)
      sf.setContext(context)
      next = ContextStackIterator.getMajorCaller(context)
      sf
    }
    else if (origin.isInstanceOf[GlobalVariable]) {
      val sf = new ContextStackFrame.VariableEvaluation
      val `var` = origin.asInstanceOf[GlobalVariable]
      sf.setLocation(`var`.getLocation)
      sf.setContextItem(context.getContextItem)
      sf.setVariableName(`var`.getVariableQName)
      sf.setComponent(`var`)
      sf.setContext(context)
      next = ContextStackIterator.getMajorCaller(context)
      sf
    }
    else { //other context changes are not considered significant enough to report
      //out.println("    In unidentified location " + construct);
      next = ContextStackIterator.getMajorCaller(context)
      val csf = next
      if (csf == null) { // we can't return null, because hasNext() returned true...
        new ContextStackFrame.CallingApplication
      }
      else csf
    }
  }

  /**
   * Removes from the underlying collection the last element returned by the
   * iterator (optional operation).
   *
   * @throws UnsupportedOperationException as the <tt>remove</tt>
   *                                       operation is not supported by this Iterator.
   */
  override def remove() = throw new UnsupportedOperationException
}