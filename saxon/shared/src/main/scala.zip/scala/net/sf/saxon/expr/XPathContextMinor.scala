////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.Controller
import net.sf.saxon.expr.instruct.ParameterSet
import net.sf.saxon.expr.sort.GroupIterator
import net.sf.saxon.lib.ErrorReporter
import net.sf.saxon.om._
import net.sf.saxon.regex.RegexIterator
import net.sf.saxon.trace.ContextStackIterator
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.rules.Rule
import net.sf.saxon.tree.iter.LookaheadIterator
import net.sf.saxon.value.DateTimeValue
import javax.xml.transform.URIResolver
import java.util
import java.util.function.Function

/**
 * This class represents a minor change in the dynamic context in which an XPath expression is evaluated:
 * a "major context" object allows all aspects of the dynamic context to change, whereas
 * a "minor context" only allows changes to the focus and the destination for push output.
 */
object XPathContextMinor {

  /**
   * Container for cached value of the last() function.
   * This is shared between all context objects that share the same current iterator.
   * Introduced in 9.2 to handle the case where a new context is introduced when the current
   * outputter changes, without changing the current iterator: in this case the cached value
   * was being lost because each call on last() used a different context object.
   */
  protected class LastValue(val count: Int) {
    value = count
    var value = 0
  }

}

class XPathContextMinor protected()

/**
 * Private Constructor
 */
  extends XPathContext {
  private[expr] var controller = null
  private[expr] var currentIterator = null
  /*@Nullable*/ private[expr] var last = null
  private[expr] var caller = null
  protected var stackFrame = null
  protected var currentDestination = ""
  protected var temporaryOutputState = 0

  /**
   * Construct a new context as a copy of another. The new context is effectively added
   * to the top of a stack, and contains a pointer to the previous context
   */
  override def newContext = XPathContextMajor.newContext(this)

  override def newMinorContext = {
    val c = new XPathContextMinor
    //System.err.println("NEW MINOR CONTEXT " + c);
    c.controller = controller
    c.caller = this
    c.currentIterator = currentIterator
    c.last = last
    c.stackFrame = stackFrame
    c.currentDestination = currentDestination
    c.temporaryOutputState = temporaryOutputState
    c
  }

  /**
   * Set the calling XPathContext
   */
  override def setCaller(caller: XPathContext) = this.caller = caller

  /**
   * Construct a new context without copying (used for the context in a function call)
   */
  override def newCleanContext = {
    val c = new XPathContextMajor(getController)
    c.setCaller(this)
    c
  }

  /**
   * Get the local parameters for the current template call.
   *
   * @return the supplied parameters
   */
  override def getLocalParameters = getCaller.getLocalParameters

  /**
   * Get the tunnel parameters for the current template call.
   *
   * @return the supplied tunnel parameters
   */
  override def getTunnelParameters = getCaller.getTunnelParameters

  /**
   * Get the Controller. May return null when running outside XSLT or XQuery
   */
  override final def getController = controller

  /**
   * Get the Configuration
   */
  override final def getConfiguration = controller.getConfiguration

  /**
   * Get the Name Pool
   */
  override final def getNamePool = controller.getConfiguration.getNamePool

  /**
   * Get the calling XPathContext (the next one down the stack). This will be null if unknown, or
   * if the bottom of the stack has been reached.
   */
  override final def getCaller = caller

  /**
   * Set a new sequence iterator.
   */
  override def setCurrentIterator(iter: FocusIterator) = {
    currentIterator = iter
    last = new XPathContextMinor.LastValue(-1)
  }

  /**
   * Create, set, and return a focus tracking iterator that wraps a supplied sequence iterator.
   *
   * @param iter the current iterator. The context item, position, and size are determined by reference
   *             to the current iterator.
   */
  override def trackFocus(iter: SequenceIterator) = {
    val factory = controller.getFocusTrackerFactory(false)
    //noinspection unchecked
    val fit = factory.apply(iter)
    setCurrentIterator(fit)
    fit
  }

  /**
   * Create, set, and return a focus tracking iterator that wraps a supplied sequence iterator,
   * suitable for use in a multithreaded xsl:for-each iteration
   *
   * @param iter the current iterator. The context item, position, and size are determined by reference
   *             to the current iterator.
   */
  def trackFocusMultithreaded(iter: SequenceIterator) = {
    val factory = controller.getFocusTrackerFactory(true)
    val fit = factory.apply(iter)
    setCurrentIterator(fit)
    fit
  }

  /**
   * Get the current iterator.
   * This encapsulates the context item, context position, and context size.
   *
   * @return the current iterator, or null if there is no current iterator
   *         (which means the context item, position, and size are undefined).
   */
  override final def getCurrentIterator = currentIterator

  /**
   * Get the context item
   *
   * @return the context item, or null if the context item is undefined
   */
  override final def getContextItem: Item = {
    if (currentIterator == null) return null
    currentIterator.current
  }

  /**
   * Get the context size (the position of the last item in the current node list)
   *
   * @return the context size
   * @throws XPathException if the context position is undefined
   */
  @throws[XPathException]
  override final def getLast: Int = {
    if (currentIterator == null) {
      val e = new XPathException("The context item is absent, so last() is undefined")
      e.setXPathContext(this)
      e.setErrorCode("XPDY0002")
      throw e
    }
    if (last.value >= 0) return last.value
    currentIterator.getLength
  }

  /**
   * Determine whether the context position is the same as the context size
   * that is, whether position()=last()
   */
  @throws[XPathException]
  override final def isAtLast: Boolean = {
    if (currentIterator.getProperties.contains(SequenceIterator.Property.LOOKAHEAD)) return !(currentIterator.asInstanceOf[LookaheadIterator]).hasNext
    currentIterator.position == getLast
  }

  /**
   * Get the URI resolver. This gets the local URIResolver set in the XPathContext if there
   * is one; if not, it gets the URIResolver from the Controller (which itself defaults to the
   * one set in the Configuration).
   *
   * @return the user-supplied URI resolver if there is one, or null otherwise.
   * @since 9.6
   */
  override def getURIResolver = caller.getURIResolver

  /**
   * Get the error reporter. If no ErrorReporter
   * has been set locally, the ErrorReporter in the Controller is returned; this in turn defaults
   * to the ErrorReporter set in the Configuration.
   *
   * @return the ErrorReporter in use.
   * @since 9.6. Changed in 10.0 to use ErrorReporter rather than ErrorListener
   */
  override def getErrorReporter = caller.getErrorReporter

  /**
   * Get the current exception (in saxon:catch)
   *
   * @return the current exception, or null if there is none defined
   */
  override def getCurrentException = caller.getCurrentException

  /**
   * Get the thread manager used to process asynchronous xsl:result-document threads.
   *
   * @return the current thread manager; or null if multithreading is not supported
   */
  override def getThreadManager = caller.getThreadManager

  /**
   * Get the current component
   */
  override def getCurrentComponent = caller.getCurrentComponent

  /**
   * Get a reference to the local stack frame for variables. Note that it's
   * the caller's job to make a local copy of this. This is used for creating
   * a Closure containing a retained copy of the variables for delayed evaluation.
   *
   * @return array of variables.
   */
  override def getStackFrame = stackFrame

  def makeStackFrameMutable() = if (stackFrame eq StackFrame.EMPTY) stackFrame = new StackFrame(null, SequenceTool.makeSequenceArray(0))

  /**
   * Get the value of a local variable, identified by its slot number
   */
  override final def evaluateLocalVariable(slotnumber: Int) = stackFrame.slots(slotnumber)

  /**
   * Set the value of a local variable, identified by its slot number
   */
  @throws[XPathException]
  override final def setLocalVariable(slotNumber: Int, value: Sequence) = { // The following code is deep defence against attempting to store a non-memo Closure in a variable.
    // This should not happen, and if it does, it means that the evaluation mode has been miscalculated.
    // But if it does happen, we recover by wrapping the Closure in a MemoSequence which remembers the
    // value as it is calculated.
    value = value.makeRepeatable
    try stackFrame.slots(slotNumber) = value
    catch {
      case e: ArrayIndexOutOfBoundsException =>
        if (slotNumber == -999) throw new AssertionError("Internal error: Cannot set local variable: no slot allocated")
        else throw new AssertionError("Internal error: Cannot set local variable (slot " + slotNumber + " of " + getStackFrame.getStackFrameValues.length + ")")
    }
  }

  @throws[XPathException]
  override def waitForChildThreads() = getCaller.waitForChildThreads()

  /**
   * Set the XSLT output state to "temporary" or "final"
   *
   * @param temporary set non-zero to set temporary output state; zero to set final output state. The integer
   *                  gives clues as to the reason temporary output state is being set, e.g. StandardNames.XSL_VARIABLE
   *                  indicates we are evaluating a variable.
   *
   */
  override def setTemporaryOutputState(temporary: Int) = temporaryOutputState = temporary

  /**
   * Ask whether the XSLT output state is "temporary" or "final"
   *
   * @return non-zero if in temporary output state (integer identifies the reason); zero if in final output state
   */
  override def getTemporaryOutputState = temporaryOutputState

  /**
   * Set the current output URI
   *
   * @param uri the current output URI, or null if in temporary output state
   */
  override def setCurrentOutputUri(uri: String) = currentDestination = uri

  /**
   * Get the current output URI
   *
   * @return the current output URI, or null if in temporary output state
   */
  override def getCurrentOutputUri = currentDestination

  /**
   * Use local parameter. This is called when a local xsl:param element is processed.
   * If a parameter of the relevant name was supplied, it is bound to the xsl:param element.
   * Otherwise the method returns false, so the xsl:param default will be evaluated
   *
   * @param parameterId Globally-unique parameter identifier
   * @param slotNumber  Slot number of the parameter within the stack frame of the called template
   * @param isTunnel    True if a tunnel parameter is required, else false  @return ParameterSet.NOT_SUPPLIED, ParameterSet.SUPPLIED, or ParameterSet.SUPPLIED_AND_CHECKED
   */
  @throws[XPathException]
  override def useLocalParameter(parameterId: StructuredQName, slotNumber: Int, isTunnel: Boolean) = getCaller.useLocalParameter(parameterId, slotNumber, isTunnel)

  /**
   * Get the current mode.
   *
   * @return the current mode
   */
  override def getCurrentMode = getCaller.getCurrentMode

  /**
   * Get the current template. This is used to support xsl:apply-imports
   *
   * @return the current template
   */
  override def getCurrentTemplateRule = { // In a minor context, the current template rule is always null. This is a consequence
    // of the way they are used.
    null
    //return getCaller().getCurrentTemplateRule();
  }

  /**
   * Get the current group iterator. This supports the current-group() and
   * current-grouping-key() functions in XSLT 2.0
   *
   * @return the current grouped collection
   */
  override def getCurrentGroupIterator = getCaller.getCurrentGroupIterator

  /**
   * Get the current merge group iterator. This supports the current-merge-group() and
   * current-merge-key() functions in XSLT 3.0
   *
   * @return the current grouped collection
   */
  override def getCurrentMergeGroupIterator = getCaller.getCurrentMergeGroupIterator

  /**
   * Get the current regex iterator. This supports the functionality of the regex-group()
   * function in XSLT 2.0.
   *
   * @return the current regular expressions iterator
   */
  override def getCurrentRegexIterator = getCaller.getCurrentRegexIterator

  /**
   * Get the current date and time for this query or transformation.
   * All calls during one transformation return the same answer.
   *
   * @return Get the current date and time. This will deliver the same value
   *         for repeated calls within the same transformation
   */
  override def getCurrentDateTime = controller.getCurrentDateTime

  /**
   * Get the implicit timezone, as a positive or negative offset from UTC in minutes.
   * The range is -14hours to +14hours
   *
   * @return the implicit timezone as an offset from UTC in minutes
   */
  override final def getImplicitTimezone = controller.getImplicitTimezone

  /**
   * Get the context stack. This method returns an iterator whose items are instances of
   * {@link net.sf.saxon.trace.ContextStackFrame}, starting with the top-most stackframe and
   * ending at the point the query or transformation was invoked by a calling application.
   *
   * @return an iterator over a copy of the run-time call stack
   */
  override def iterateStackFrames = new ContextStackIterator(this)

  override def getTargetComponent(bindingSlot: Int) = getCaller.getTargetComponent(bindingSlot)
}