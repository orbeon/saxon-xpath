////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.expr.accum.AccumulatorRegistry
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.SaxonErrorCode
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XmlProcessingIncident
import net.sf.saxon.tree.linked.ElementImpl
import net.sf.saxon.tree.linked.NodeFactory
import net.sf.saxon.tree.linked.NodeImpl
import net.sf.saxon.tree.linked.TextImpl
import javax.xml.transform.TransformerFactoryConfigurationError

/**
 * Class StyleNodeFactory. <br>
 * A Factory for nodes in the stylesheet tree. <br>
 * Currently only allows Element nodes to be user-constructed.
 *
 * @author Michael H. Kay
 */
class StyleNodeFactory(var config: Configuration, var compilation: Compilation)

/**
 * Create the node factory for representing an XSLT stylesheet as a tree structure
 *
 * @param config      the Saxon configuration
 * @param compilation the compilation episode (compiling one package)
 */
  extends NodeFactory {
  namePool = configuration.getNamePool
  protected var namePool = null
  private var topLevelModule = false

  /**
   * Say that this is the top-level module of a package
   *
   * @param topLevelModule true if this stylesheet module is the top level of a package; false
   *                       if it is included or imported
   */
  def setTopLevelModule(topLevelModule: Boolean) = this.topLevelModule = topLevelModule

  /**
   * Ask whether this is the top-level module of a package
   *
   * @return true if this stylesheet module is the top level of a package; false
   *         if it is included or imported
   */
  def isTopLevelModule = topLevelModule

  def getCompilation = compilation

  def getConfiguration = config

  /**
   * Create an Element node. Note, if there is an error detected while constructing
   * the Element, we add the element anyway, and return success, but flag the element
   * with a validation error. This allows us to report more than
   * one error from a single compilation.
   */
  override def makeElementNode(parent: NodeInfo, elemName: NodeName, elemType: SchemaType, isNilled: Boolean, attlist: AttributeMap, namespaces: NamespaceMap, pipe: PipelineConfiguration, location: Location, sequence: Int): ElementImpl = {
    val f = elemName.obtainFingerprint(pipe.getConfiguration.getNamePool)
    val toplevel = parent.isInstanceOf[XSLModuleRoot]
    var baseURI = null
    var lineNumber = -1
    var columnNumber = -1
    baseURI = location.getSystemId
    lineNumber = location.getLineNumber
    columnNumber = location.getColumnNumber
    if (parent.isInstanceOf[DataElement]) {
      val d = new DataElement
      d.setNamespaceMap(namespaces)
      d.initialise(elemName, elemType, attlist, parent, sequence)
      d.setLocation(baseURI, lineNumber, columnNumber)
      return d
    }
    // Try first to make an XSLT element
    var e = makeXSLElement(f, parent.asInstanceOf[NodeImpl])
    if ((e.isInstanceOf[XSLStylesheet] || e.isInstanceOf[XSLPackage]) && parent.getNodeKind != Type.DOCUMENT) {
      e = new AbsentExtensionElement
      val reason = new XmlProcessingIncident(elemName.getDisplayName + " can only appear at the outermost level", "XTSE0010")
      e.setValidationError(reason, StyleElement.OnFailure.REPORT_ALWAYS)
    }
    if (e != null) { // recognized as an XSLT element
      e.setCompilation(compilation)
      e.setNamespaceMap(namespaces)
      e.initialise(elemName, elemType, attlist, parent, sequence)
      e.setLocation(baseURI, lineNumber, columnNumber)
      e.processExtensionElementAttribute("")
      e.processExcludedNamespaces("")
      e.processVersionAttribute("")
      e.processDefaultXPathNamespaceAttribute("")
      e.processExpandTextAttribute("")
      e.processDefaultValidationAttribute("")
      //            if (e.isInstruction() && e.getEffectiveVersion() == 10 &&
      //                    !config.isLicensedFeature(Configuration.LicenseFeature.PROFESSIONAL_EDITION)) {
      //                e.setValidationError(
      //                        new XPathException("XSLT 1.0 compatibility mode is not available in this configuration", "XTDE0160"),
      //                        StyleElement.REPORT_IF_INSTANTIATED
      //                );
      //            }
      if (toplevel && !e.isDeclaration && e.forwardsCompatibleModeIsEnabled) {
        val d = new DataElement
        d.setNamespaceMap(namespaces)
        d.initialise(elemName, elemType, attlist, parent, sequence)
        d.setLocation(baseURI, lineNumber, columnNumber)
        return d
      }
      if (parent.isInstanceOf[AbsentExtensionElement] && parent.asInstanceOf[AbsentExtensionElement].forwardsCompatibleModeIsEnabled && parent.getURI == NamespaceConstant.XSLT && !e.isInstanceOf[XSLFallback]) { // Parent is an unknown XSLT element in forwards-compatibility mode; siblings of xsl:fallback are ignored
        val temp = new AbsentExtensionElement
        temp.initialise(elemName, elemType, attlist, parent, sequence)
        temp.setLocation(baseURI, lineNumber, columnNumber)
        temp.setCompilation(compilation)
        temp.setIgnoreInstruction()
        return temp
      }
      return e
    }
    val uri = elemName.getURI
    if (toplevel && !(uri == NamespaceConstant.XSLT)) {
      val d = new DataElement
      d.setNamespaceMap(namespaces)
      d.initialise(elemName, elemType, attlist, parent, sequence)
      d.setLocation(baseURI, lineNumber, columnNumber)
      d
    }
    else { // not recognized as an XSLT element, not top-level
      val localname = elemName.getLocalPart
      var temp = null
      // Detect a misspelt XSLT element, or a 3.0 element used in a 2.0 stylesheet
      if (uri == NamespaceConstant.XSLT) if (parent.isInstanceOf[XSLStylesheet]) if (parent.asInstanceOf[XSLStylesheet].getEffectiveVersion <= 20) {
        temp = new AbsentExtensionElement
        temp.setCompilation(compilation)
        temp.setValidationError(new XmlProcessingIncident("Unknown top-level XSLT declaration"), StyleElement.OnFailure.REPORT_UNLESS_FORWARDS_COMPATIBLE)
      }
      else {
        temp = new AbsentExtensionElement
        temp.initialise(elemName, elemType, attlist, parent, sequence)
        temp.setLocation(baseURI, lineNumber, columnNumber)
        temp.setCompilation(compilation)
        temp.processStandardAttributes("")
        if (temp.getEffectiveVersion > 20) temp.setValidationError(new XmlProcessingIncident("Unknown XSLT instruction"), StyleElement.OnFailure.REPORT_STATICALLY_UNLESS_FALLBACK_AVAILABLE)
        else temp.setValidationError(new XmlProcessingIncident("Unknown XSLT instruction"), StyleElement.OnFailure.REPORT_IF_INSTANTIATED)
      }
      // Detect an unrecognized element in the Saxon namespace
      if (uri == NamespaceConstant.SAXON) {
        var message = elemName.getDisplayName + " is not recognized as a Saxon instruction"
        if (config.getEditionCode == "HE") message += ". Saxon extensions require Saxon-PE or higher"
        else if (!config.isLicensedFeature(Configuration.LicenseFeature.PROFESSIONAL_EDITION)) message += ". No Saxon-PE or -EE license was found"
        val err = new XmlProcessingIncident(message, SaxonErrorCode.SXWN9008, location.saveLocation).asWarning
        pipe.getErrorReporter.report(err)
      }
      val assumedClass = classOf[LiteralResultElement]
      // We can't work out the final class of the node until we've examined its attributes
      // such as version and extension-element-prefixes; but we can have a good guess, and
      // change it later if need be.
      if (temp == null) temp = new LiteralResultElement
      temp.setNamespaceMap(namespaces)
      temp.setCompilation(compilation)
      temp.initialise(elemName, elemType, attlist, parent, sequence)
      temp.setLocation(baseURI, lineNumber, columnNumber)
      temp.processStandardAttributes(NamespaceConstant.XSLT)
      // Now we work out what class of element we really wanted, and change it if necessary
      var reason = null
      var actualClass = null
      if (uri == NamespaceConstant.XSLT) {
        reason = new XmlProcessingIncident("Unknown XSLT element: " + Err.wrap(localname, Err.ELEMENT), "XTSE0010")
        actualClass = classOf[AbsentExtensionElement]
        temp.setValidationError(reason, StyleElement.OnFailure.REPORT_STATICALLY_UNLESS_FALLBACK_AVAILABLE)
      }
      else if (temp.isExtensionNamespace(uri) && !toplevel) { // if we can't instantiate an extension element, we don't give up
        // immediately, because there might be an xsl:fallback defined. We
        // create a surrogate element called AbsentExtensionElement, and
        // save the reason for failure just in case there is no xsl:fallback
        actualClass = classOf[AbsentExtensionElement]
        if (NamespaceConstant.isReserved(uri)) {
          reason = new XmlProcessingIncident("Cannot use a reserved namespace for extension instructions", "XTSE0800")
          temp.setValidationError(reason, StyleElement.OnFailure.REPORT_ALWAYS)
        }
        else {
          reason = new XmlProcessingIncident("Unknown extension instruction " + Err.wrap(elemName.getDisplayName, Err.ELEMENT), "XTDE1450")
          temp.setValidationError(reason, StyleElement.OnFailure.REPORT_DYNAMICALLY_UNLESS_FALLBACK_AVAILABLE)
        }
      }
      else actualClass = classOf[LiteralResultElement]
      var node = null
      if (actualClass == assumedClass) node = temp // the original element will do the job
      else {
        try node = actualClass.newInstance.asInstanceOf[StyleElement]
        catch {
          case err1: InstantiationException =>
            throw new TransformerFactoryConfigurationError(err1, "Failed to create instance of " + actualClass.getName)
          case err2: IllegalAccessException =>
            throw new TransformerFactoryConfigurationError(err2, "Failed to access class " + actualClass.getName)
        }
        node.substituteFor(temp) // replace temporary node with the new one
      }
      node
    }
  }

  /**
   * Make an XSL element node
   *
   * @param f      the fingerprint of the node name
   * @param parent the parent node
   * @return the constructed element node
   */
  /*@Nullable*/ protected def makeXSLElement(f: Int, parent: NodeImpl) = f match {
    case StandardNames.XSL_ACCEPT =>
      new XSLAccept
    case StandardNames.XSL_ACCUMULATOR =>
      new XSLAccumulator
    case StandardNames.XSL_ACCUMULATOR_RULE =>
      new XSLAccumulatorRule
    case StandardNames.XSL_ANALYZE_STRING =>
      new XSLAnalyzeString
    case StandardNames.XSL_APPLY_IMPORTS =>
      new XSLApplyImports
    case StandardNames.XSL_APPLY_TEMPLATES =>
      new XSLApplyTemplates
    case StandardNames.XSL_ASSERT =>
      new XSLAssert
    case StandardNames.XSL_ATTRIBUTE =>
      new XSLAttribute
    case StandardNames.XSL_ATTRIBUTE_SET =>
      new XSLAttributeSet
    case StandardNames.XSL_BREAK =>
      new XSLBreak
    case StandardNames.XSL_CALL_TEMPLATE =>
      new XSLCallTemplate
    case StandardNames.XSL_CATCH =>
      new XSLCatch
    case StandardNames.XSL_CONTEXT_ITEM =>
      new XSLContextItem
    case StandardNames.XSL_CHARACTER_MAP =>
      new XSLCharacterMap
    case StandardNames.XSL_CHOOSE =>
      new XSLChoose
    case StandardNames.XSL_COMMENT =>
      new XSLComment
    case StandardNames.XSL_COPY =>
      new XSLCopy
    case StandardNames.XSL_COPY_OF =>
      new XSLCopyOf
    case StandardNames.XSL_DECIMAL_FORMAT =>
      new XSLDecimalFormat
    case StandardNames.XSL_DOCUMENT =>
      new XSLDocument
    case StandardNames.XSL_ELEMENT =>
      new XSLElement
    case StandardNames.XSL_EVALUATE =>
      new XSLEvaluate
    case StandardNames.XSL_EXPOSE =>
      new XSLExpose
    case StandardNames.XSL_FALLBACK =>
      new XSLFallback
    case StandardNames.XSL_FOR_EACH =>
      new XSLForEach
    case StandardNames.XSL_FOR_EACH_GROUP =>
      new XSLForEachGroup
    case StandardNames.XSL_FORK =>
      new XSLFork
    case StandardNames.XSL_FUNCTION =>
      new XSLFunction
    case StandardNames.XSL_GLOBAL_CONTEXT_ITEM =>
      new XSLGlobalContextItem
    case StandardNames.XSL_IF =>
      new XSLIf
    case StandardNames.XSL_IMPORT =>
      new XSLImport
    case StandardNames.XSL_IMPORT_SCHEMA =>
      new XSLImportSchema
    case StandardNames.XSL_INCLUDE =>
      new XSLInclude
    case StandardNames.XSL_ITERATE =>
      new XSLIterate
    case StandardNames.XSL_KEY =>
      new XSLKey
    case StandardNames.XSL_MAP =>
      new XSLMap
    case StandardNames.XSL_MAP_ENTRY =>
      new XSLMapEntry
    case StandardNames.XSL_MATCHING_SUBSTRING =>
      new XSLMatchingSubstring
    case StandardNames.XSL_MERGE =>
      new XSLMerge
    case StandardNames.XSL_MERGE_ACTION =>
      new XSLMergeAction
    case StandardNames.XSL_MERGE_KEY =>
      new XSLMergeKey
    case StandardNames.XSL_MERGE_SOURCE =>
      new XSLMergeSource
    case StandardNames.XSL_MESSAGE =>
      new XSLMessage
    case StandardNames.XSL_MODE =>
      new XSLMode
    case StandardNames.XSL_NEXT_ITERATION =>
      new XSLNextIteration
    case StandardNames.XSL_NEXT_MATCH =>
      new XSLNextMatch
    case StandardNames.XSL_NON_MATCHING_SUBSTRING =>
      new XSLMatchingSubstring //sic
    case StandardNames.XSL_NUMBER =>
      new XSLNumber
    case StandardNames.XSL_NAMESPACE =>
      new XSLNamespace
    case StandardNames.XSL_NAMESPACE_ALIAS =>
      new XSLNamespaceAlias
    case StandardNames.XSL_ON_COMPLETION =>
      new XSLOnCompletion
    case StandardNames.XSL_ON_EMPTY =>
      new XSLOnEmpty
    case StandardNames.XSL_ON_NON_EMPTY =>
      new XSLOnNonEmpty
    case StandardNames.XSL_OTHERWISE =>
      new XSLOtherwise
    case StandardNames.XSL_OUTPUT =>
      new XSLOutput
    case StandardNames.XSL_OUTPUT_CHARACTER =>
      new XSLOutputCharacter
    case StandardNames.XSL_OVERRIDE =>
      new XSLOverride
    case StandardNames.XSL_PACKAGE =>
      new XSLPackage
    case StandardNames.XSL_PARAM =>
      if (parent.isInstanceOf[XSLModuleRoot] || parent.isInstanceOf[XSLOverride]) new XSLGlobalParam
      else new XSLLocalParam
    case StandardNames.XSL_PERFORM_SORT =>
      new XSLPerformSort
    case StandardNames.XSL_PRESERVE_SPACE =>
      new XSLPreserveSpace
    case StandardNames.XSL_PROCESSING_INSTRUCTION =>
      new XSLProcessingInstruction
    case StandardNames.XSL_RESULT_DOCUMENT =>
      compilation.setCreatesSecondaryResultDocuments(true)
      new XSLResultDocument
    case StandardNames.XSL_SEQUENCE =>
      new XSLSequence
    case StandardNames.XSL_SORT =>
      new XSLSort
    case StandardNames.XSL_SOURCE_DOCUMENT =>
      new XSLSourceDocument
    case StandardNames.XSL_STRIP_SPACE =>
      new XSLPreserveSpace
    case StandardNames.XSL_STYLESHEET =>
      if (topLevelModule) new XSLPackage
      else new XSLStylesheet
    case StandardNames.XSL_TEMPLATE =>
      new XSLTemplate
    case StandardNames.XSL_TEXT =>
      new XSLText
    case StandardNames.XSL_TRANSFORM =>
      if (topLevelModule) new XSLPackage
      else new XSLStylesheet
    case StandardNames.XSL_TRY =>
      new XSLTry
    case StandardNames.XSL_USE_PACKAGE =>
      new XSLUsePackage
    case StandardNames.XSL_VALUE_OF =>
      new XSLValueOf
    case StandardNames.XSL_VARIABLE =>
      if (parent.isInstanceOf[XSLModuleRoot] || parent.isInstanceOf[XSLOverride]) new XSLGlobalVariable
      else new XSLLocalVariable
    case StandardNames.XSL_WITH_PARAM =>
      new XSLWithParam
    case StandardNames.XSL_WHEN =>
      new XSLWhen
    case StandardNames.XSL_WHERE_POPULATED =>
      new XSLWherePopulated
    case _ =>
      null
  }

  /**
   * Make a text node
   *
   * @param parent  the parent element
   * @param content the content of the text node
   * @return the constructed text node
   */
  override def makeTextNode(parent: NodeInfo, content: CharSequence) = if (parent.isInstanceOf[StyleElement] && parent.asInstanceOf[StyleElement].isExpandingText) new TextValueTemplateNode(content.toString)
  else new TextImpl(content.toString)

  /**
   * Method to support the element-available() function
   *
   * @param uri              the namespace URI
   * @param localName        the local Name
   * @param instructionsOnly true if only instruction elements qualify
   * @return true if an extension element of this name is recognized
   */
  def isElementAvailable(uri: String, localName: String, instructionsOnly: Boolean): Boolean = {
    val fingerprint = namePool.getFingerprint(uri, localName)
    if (uri == NamespaceConstant.XSLT) {
      if (fingerprint == -1) return false // all names are pre-registered
      val e = makeXSLElement(fingerprint, null)
      if (e != null) return !instructionsOnly || e.isInstruction
    }
    false
  }

  def makeAccumulatorManager = new AccumulatorRegistry

  /**
   * Create a stylesheet package
   *
   * @param node the XSLPackage element
   * @return a new stylesheet package
   */
  @throws[XPathException]
  def newPrincipalModule(node: XSLPackage) = new PrincipalStylesheetModule(node)
}