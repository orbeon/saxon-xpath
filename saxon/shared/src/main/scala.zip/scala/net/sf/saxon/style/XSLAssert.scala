////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.Choose
import net.sf.saxon.expr.instruct.Message
import net.sf.saxon.functions.SystemFunction
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.XPathException

/**
 * An xsl:assert element in an XSLT 3.0 stylesheet.
 */
final class XSLAssert extends StyleElement {
  private var test = null
  private var select = null
  private var errorCode = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var testAtt = null
    var selectAtt = null
    var errorCodeAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "test" =>
          testAtt = value
          test = makeExpression(testAtt, att)
        case "select" =>
          selectAtt = value
          select = makeExpression(selectAtt, att)
        case "error-code" =>
          errorCodeAtt = value
          errorCode = makeAttributeValueTemplate(errorCodeAtt, att)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (testAtt == null) reportAbsence("test")
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    select = typeCheck("select", select)
    test = typeCheck("test", test)
    if (errorCode == null) errorCode = new StringLiteral("Q{http://www.w3.org/2005/xqt-errors}XTMM9001")
    else errorCode = typeCheck("error-code", errorCode)
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = if (exec.getCompilerInfo.isAssertionsEnabled) {
    val b = compileSequenceConstructor(exec, decl, true)
    if (b != null) if (select == null) select = b
    else {
      select = Block.makeBlock(select, b)
      select.setLocation(allocateLocation)
    }
    if (select == null) select = new StringLiteral("xsl:message (no content)")
    if (errorCode.isInstanceOf[StringLiteral]) { // resolve any QName prefix now
      val code = errorCode.asInstanceOf[StringLiteral].getStringValue
      if (code.contains(":") && !code.startsWith("Q{")) {
        val name = makeQName(code, null, "error-code")
        errorCode = new StringLiteral(name.getEQName)
      }
    }
    val msg = new Message(select, new StringLiteral("yes"), errorCode)
    msg.setIsAssert(true)
    if (!errorCode.isInstanceOf[StringLiteral]) { // evaluation of the error code may need the namespace context
      msg.setRetainedStaticContext(makeRetainedStaticContext)
    }
    val condition = SystemFunction.makeCall("not", test.getRetainedStaticContext, test)
    new Choose(Array[Expression](condition), Array[Expression](msg))
  }
  else { // assertions are disabled (the default)
    Literal.makeEmptySequence
  }
}