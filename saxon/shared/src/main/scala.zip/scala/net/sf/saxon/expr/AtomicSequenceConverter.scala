////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser._
import net.sf.saxon.lib.ConversionRules
import net.sf.saxon.model._
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.Item
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.StringValue

/**
 * An AtomicSequenceConverter is an expression that performs a cast (or other supplied conversion)
 * on each member of a supplied sequence
 */
object AtomicSequenceConverter {
  var TO_STRING_MAPPER = new AtomicSequenceConverter.ToStringMappingFunction

  /**
   * Mapping function wrapped around a converter
   */
  class AtomicSequenceMappingFunction extends ItemMappingFunction {
    private var converter = null
    private var errorCode = null

    def setConverter(converter: Converter) = this.converter = converter

    def setErrorCode(code: String) = this.errorCode = code

    @throws[XPathException]
    override def mapItem(item: Item) = {
      val result = converter.convert(item.asInstanceOf[AtomicValue])
      if (errorCode != null && result.isInstanceOf[ValidationFailure]) result.asInstanceOf[ValidationFailure].setErrorCode(errorCode)
      result.asAtomic
    }
  }

  /**
   * Mapping function that converts every item in a sequence to a string
   */
  class ToStringMappingFunction extends ItemMappingFunction {
    override def mapItem(item: Item) = StringValue.makeStringValue(item.getStringValueCS)
  }

}

class AtomicSequenceConverter(val sequence: Expression, var requiredItemType: PlainType)

/**
 * Constructor
 *
 * @param sequence         this must be a sequence of atomic values. This is not checked; a ClassCastException
 *                         will occur if the precondition is not satisfied.
 * @param requiredItemType the item type to which all items in the sequence should be converted,
 */
  extends UnaryExpression(sequence) {
  protected var converter = null
  private var roleDiagnostic = null // may be null
  def allocateConverterStatically(config: Configuration, allowNull: Boolean) = converter = allocateConverter(config, allowNull, getBaseExpression.getItemType)

  def allocateConverter(config: Configuration, allowNull: Boolean) = allocateConverter(config, allowNull, getBaseExpression.getItemType)

  protected def getConverterDynamically(context: XPathContext): Converter = {
    if (converter != null) return converter
    allocateConverter(context.getConfiguration, false)
  }

  def allocateConverter(config: Configuration, allowNull: Boolean, sourceType: ItemType) = {
    val rules = config.getConversionRules
    var converter = null
    if (sourceType.isInstanceOf[ErrorType]) converter = StringConverter.IdentityConverter.INSTANCE
    else if (!sourceType.isInstanceOf[AtomicType]) converter = null
    else if (requiredItemType.isInstanceOf[AtomicType]) converter = rules.getConverter(sourceType.asInstanceOf[AtomicType], requiredItemType.asInstanceOf[AtomicType])
    else if (requiredItemType.asInstanceOf[SimpleType].isUnionType) converter = new StringConverter.StringToUnionConverter(requiredItemType, rules)
    if (converter == null && !allowNull) { // source type not known statically; create a converter that decides at run-time
      converter = new Converter(rules) {
        /*@NotNull*/ override def convert(input: AtomicValue) = {
          val converter = rules.getConverter(input.getPrimitiveType, requiredItemType.asInstanceOf[AtomicType])
          if (converter == null) new ValidationFailure("Cannot convert value from " + input.getPrimitiveType + " to " + requiredItemType)
          else converter.convert(input)
        }
      }
    }
    converter
  }

  override protected def getOperandRole = OperandRole.ATOMIC_SEQUENCE

  /**
   * Get the required item type (the target type of the conversion
   *
   * @return the required item type
   */
  def getRequiredItemType = requiredItemType

  /**
   * Get the converter used to convert the items in the sequence
   *
   * @return the converter. Note that a converter is always allocated during the typeCheck() phase,
   *         even if the source type is not known.
   */
  def getConverter = converter

  def setConverter(converter: Converter) = this.converter = converter

  /**
   * Set a RoleDiagnostic, used to give more precise error information if the conversion
   * fails
   *
   * @param role the RoleDiagnostic, which gives more precise error information
   */
  def setRoleDiagnostic(role: RoleDiagnostic) = { // TODO: pragmatic kludge in the run-up to 9.9. If the role says error=XPTY0004, ignore it, because
    // in XQuery the cast failure should be FORG0001. We only use the error code in XSLT paths where it
    // might be something like XTTE0780
    if (role != null && !("XPTY0004" == role.getErrorCode)) this.roleDiagnostic = role
  }

  /**
   * Get the RoleDiagnostic, used to give more precise error information if the conversion
   * fails
   *
   * @return the RoleDiagnostic, or null if none has been set
   */
  def getRoleDiagnostic = this.roleDiagnostic

  /**
   * Simplify an expression
   *
   */
  @throws[XPathException]
  override def simplify: Expression = {
    val operand = getBaseExpression.simplify
    setBaseExpression(operand)
    if (operand.isInstanceOf[Literal] && requiredItemType.isInstanceOf[AtomicType]) {
      if (Literal.isEmptySequence(operand)) return operand
      val config = getConfiguration
      allocateConverterStatically(config, true)
      if (converter != null) {
        val `val` = iterate(new EarlyEvaluationContext(config)).materialize
        return Literal.makeLiteral(`val`, operand)
      }
    }
    this
  }

  /**
   * Type-check the expression
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = {
    typeCheckChildren(visitor, contextInfo)
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    val operand = getBaseExpression
    if (th.isSubType(operand.getItemType, requiredItemType)) operand
    else {
      if (converter == null) allocateConverterStatically(config, true)
      this
    }
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val e = super.optimize(visitor, contextInfo)
    if (e ne this) return e
    if (getBaseExpression.isInstanceOf[UntypedSequenceConverter]) {
      val asc = getBaseExpression.asInstanceOf[UntypedSequenceConverter]
      val ascType = asc.getItemType
      if (ascType eq requiredItemType) return getBaseExpression
      else if (((requiredItemType eq BuiltInAtomicType.STRING) || (requiredItemType eq BuiltInAtomicType.UNTYPED_ATOMIC)) && ((ascType eq BuiltInAtomicType.STRING) || (ascType eq BuiltInAtomicType.UNTYPED_ATOMIC))) {
        val old = getBaseExpression.asInstanceOf[UntypedSequenceConverter]
        val asc2 = new UntypedSequenceConverter(old.getBaseExpression, requiredItemType)
        return asc2.typeCheck(visitor, contextInfo).optimize(visitor, contextInfo)
      }
    }
    else if (getBaseExpression.isInstanceOf[AtomicSequenceConverter]) {
      val asc = getBaseExpression.asInstanceOf[AtomicSequenceConverter]
      val ascType = asc.getItemType
      if (ascType eq requiredItemType) return getBaseExpression
      else if (((requiredItemType eq BuiltInAtomicType.STRING) || (requiredItemType eq BuiltInAtomicType.UNTYPED_ATOMIC)) && ((ascType eq BuiltInAtomicType.STRING) || (ascType eq BuiltInAtomicType.UNTYPED_ATOMIC))) {
        val old = getBaseExpression.asInstanceOf[AtomicSequenceConverter]
        val asc2 = new AtomicSequenceConverter(old.getBaseExpression, requiredItemType)
        return asc2.typeCheck(visitor, contextInfo).optimize(visitor, contextInfo)
      }
    }
    this
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Determine the special properties of this expression
   *
   * @return { @link StaticProperty#NO_NODES_NEWLY_CREATED}.
   */
  override def computeSpecialProperties = {
    var p = super.computeSpecialProperties | StaticProperty.NO_NODES_NEWLY_CREATED
    if (requiredItemType eq BuiltInAtomicType.UNTYPED_ATOMIC) p &= ~StaticProperty.NOT_UNTYPED_ATOMIC
    else p |= StaticProperty.NOT_UNTYPED_ATOMIC
    p
  }

  override def getStreamerName = "AtomicSequenceConverter"

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be re-bound
   */
  override def copy(rebindings: RebindingMap) = {
    val atomicConverter = new AtomicSequenceConverter(getBaseExpression.copy(rebindings), requiredItemType)
    ExpressionTool.copyLocationInfo(this, atomicConverter)
    atomicConverter.setConverter(converter)
    atomicConverter.setRoleDiagnostic(getRoleDiagnostic)
    atomicConverter
  }

  /**
   * Iterate over the sequence of values
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = {
    val base = getBaseExpression.iterate(context)
    val conv = getConverterDynamically(context)
    if (conv eq Converter.ToStringConverter.INSTANCE) new ItemMappingIterator(base, AtomicSequenceConverter.TO_STRING_MAPPER, true)
    else {
      val mapper = new AtomicSequenceConverter.AtomicSequenceMappingFunction
      mapper.setConverter(conv)
      if (roleDiagnostic != null) mapper.setErrorCode(roleDiagnostic.getErrorCode)
      new ItemMappingIterator(base, mapper, true)
    }
  }

  /**
   * Evaluate as an Item. This should only be called if the AtomicSequenceConverter has cardinality zero-or-one
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext): AtomicValue = {
    val conv = getConverterDynamically(context)
    val item = getBaseExpression.evaluateItem(context).asInstanceOf[AtomicValue]
    if (item == null) return null
    val result = conv.convert(item)
    if (roleDiagnostic != null && result.isInstanceOf[ValidationFailure]) { // TODO: use more of the information in the roleDiagnostic to form the error message
      result.asInstanceOf[ValidationFailure].setErrorCode(roleDiagnostic.getErrorCode)
    }
    result.asAtomic
  }

  /**
   * Determine the data type of the items returned by the expression, if possible
   *
   * @return a value such as Type.STRING, Type.BOOLEAN, Type.NUMBER, Type.NODE,
   *         or Type.ITEM (meaning not known in advance)
   */
  override def getItemType = requiredItemType

  /**
   * Determine the static cardinality of the expression
   */
  override def computeCardinality = getBaseExpression.getCardinality

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any) = super.equals(other) && requiredItemType == other.asInstanceOf[AtomicSequenceConverter].requiredItemType

  /**
   * get HashCode for comparing two expressions. Note that this hashcode gives the same
   * result for (A op B) and for (B op A), whether or not the operator is commutative.
   */
  override def computeHashCode = super.computeHashCode ^ requiredItemType.hashCode

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "convert"

  override protected def displayOperator(config: Configuration) = "convert"

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("convert", this)
    destination.emitAttribute("from", AlphaCode.fromItemType(getBaseExpression.getItemType))
    destination.emitAttribute("to", AlphaCode.fromItemType(requiredItemType))
    if (converter.isInstanceOf[Converter.PromoterToDouble] || converter.isInstanceOf[Converter.PromoterToFloat]) destination.emitAttribute("flags", "p")
    if (getRoleDiagnostic != null) destination.emitAttribute("diag", getRoleDiagnostic.save)
    getBaseExpression.`export`(destination)
    destination.endElement
  }
}