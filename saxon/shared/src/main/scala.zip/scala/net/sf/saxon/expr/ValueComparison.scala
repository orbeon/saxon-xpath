////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser._
import net.sf.saxon.expr.sort._
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model._
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.BooleanValue
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.SequenceType

/**
 * ValueComparison: a boolean expression that compares two atomic values
 * for equals, not-equals, greater-than or less-than. Implements the operators
 * eq, ne, lt, le, gt, ge
 */
object ValueComparison {
  /**
   * Compare two atomic values, using a specified operator and collation
   *
   * @param v0 the first operand
   * @param op the operator, as defined by constants such as { @link net.sf.saxon.expr.parser.Token#FEQ} or
   *                                                                 { @link net.sf.saxon.expr.parser.Token#FLT}
   * @param v1         the second operand
   * @param comparer   used to compare values. If the comparer is context-sensitive then the context must
   *                   already have been bound using comparer.provideContext().
   * @param checkTypes set to true if it is necessary to check that the types of the arguments are comparable
   * @return the result of the comparison: -1 for LT, 0 for EQ, +1 for GT
   * @throws XPathException if the values are not comparable
   */
    @throws[XPathException]
    def compare(v0: AtomicValue, op: Int, v1: AtomicValue, comparer: AtomicComparer, checkTypes: Boolean): Boolean = {
      if (checkTypes && !Type.isGuaranteedComparable(v0.getPrimitiveType, v1.getPrimitiveType, Token.isOrderedOperator(op))) {
        val e2 = new XPathException("Cannot compare " + Type.displayTypeName(v0) + " to " + Type.displayTypeName(v1))
        e2.setErrorCode("XPTY0004")
        e2.setIsTypeError(true)
        throw e2
      }
      if (v0.isNaN || v1.isNaN) return op == Token.FNE
      try op match {
        case Token.FEQ =>
          comparer.comparesEqual(v0, v1)
        case Token.FNE =>
          !comparer.comparesEqual(v0, v1)
        case Token.FGT =>
          comparer.compareAtomicValues(v0, v1) > 0
        case Token.FLT =>
          comparer.compareAtomicValues(v0, v1) < 0
        case Token.FGE =>
          comparer.compareAtomicValues(v0, v1) >= 0
        case Token.FLE =>
          comparer.compareAtomicValues(v0, v1) <= 0
        case _ =>
          throw new UnsupportedOperationException("Unknown operator " + op)
      }
      catch {
        case err: ComparisonException =>
          throw err.getCause
        case err: ClassCastException =>
          err.printStackTrace()
          val e2 = new XPathException("Cannot compare " + Type.displayTypeName(v0) + " to " + Type.displayTypeName(v1))
          e2.setErrorCode("XPTY0004")
          e2.setIsTypeError(true)
          throw e2
      }
    }
}

final class ValueComparison(val p1: Expression, val op: Int, val p2: Expression)

/**
 * Create a comparison expression identifying the two operands and the operator
 *
 * @param p1 the left-hand operand
 * @param op the operator, as a token returned by the Tokenizer (e.g. Token.LT)
 * @param p2 the right-hand operand
 */
  extends BinaryExpression(p1, op, p2) with ComparisonExpression with Negatable {
  private var comparer = null
  /*@Nullable*/ private var resultWhenEmpty = null
  private var needsRuntimeCheck = false

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "ValueComparison"

  /**
   * Set the AtomicComparer used to compare atomic values
   *
   * @param comparer the AtomicComparer
   */
  def setAtomicComparer(comparer: AtomicComparer) = this.comparer = comparer

  /**
   * Get the AtomicComparer used to compare atomic values. This encapsulates any collation that is used.
   * Note that the comparer is always known at compile time.
   */
  override def getAtomicComparer = comparer

  /**
   * Get the primitive (singleton) operator used: one of Token.FEQ, Token.FNE, Token.FLT, Token.FGT,
   * Token.FLE, Token.FGE
   */
  override def getSingletonOperator = operator

  /**
   * Determine whether untyped atomic values should be converted to the type of the other operand
   *
   * @return true if untyped values should be converted to the type of the other operand, false if they
   *         should be converted to strings.
   */
  override def convertsUntypedToOther = comparer.isInstanceOf[UntypedNumericComparer]

  /**
   * Set the result to be returned if one of the operands is an empty sequence
   *
   * @param value the result to be returned if an operand is empty. Supply null to mean the empty sequence.
   */
  def setResultWhenEmpty(value: BooleanValue) = resultWhenEmpty = value

  /**
   * Get the result to be returned if one of the operands is an empty sequence
   *
   * @return BooleanValue.TRUE, BooleanValue.FALSE, or null (meaning the empty sequence)
   */
  def getResultWhenEmpty = resultWhenEmpty

  /**
   * Determine whether a run-time check is needed to check that the types of the arguments
   * are comparable
   *
   * @return true if a run-time check is needed
   */
  def needsRuntimeComparabilityCheck = needsRuntimeCheck

  /**
   * Type-check the expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    resetLocalStaticProperties()
    getLhs.typeCheck(visitor, contextInfo)
    getRhs.typeCheck(visitor, contextInfo)
    val config = visitor.getConfiguration
    val env = visitor.getStaticContext
    if (Literal.isEmptySequence(getLhsExpression)) return if (resultWhenEmpty == null) getLhsExpression
    else Literal.makeLiteral(resultWhenEmpty, this)
    if (Literal.isEmptySequence(getRhsExpression)) return if (resultWhenEmpty == null) getRhsExpression
    else Literal.makeLiteral(resultWhenEmpty, this)
    if (comparer.isInstanceOf[UntypedNumericComparer]) return this // we've already done all that needs to be done
    val optionalAtomic = SequenceType.OPTIONAL_ATOMIC
    val tc = config.getTypeChecker(false)
    val role0 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 0)
    setLhsExpression(tc.staticTypeCheck(getLhsExpression, optionalAtomic, role0, visitor))
    val role1 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 1)
    setRhsExpression(tc.staticTypeCheck(getRhsExpression, optionalAtomic, role1, visitor))
    val t0 = getLhsExpression.getItemType.getAtomizedItemType
    val t1 = getRhsExpression.getItemType.getAtomizedItemType
    if (t0.getUType.union(t1.getUType).overlaps(UType.EXTENSION)) {
      val err = new XPathException("Cannot perform comparisons involving external objects")
      err.setIsTypeError(true)
      err.setErrorCode("XPTY0004")
      err.setLocation(getLocation)
      throw err
    }
    var p0 = t0.getPrimitiveItemType.asInstanceOf[BuiltInAtomicType]
    if (p0 == BuiltInAtomicType.UNTYPED_ATOMIC) p0 = BuiltInAtomicType.STRING
    var p1 = t1.getPrimitiveItemType.asInstanceOf[BuiltInAtomicType]
    if (p1 == BuiltInAtomicType.UNTYPED_ATOMIC) p1 = BuiltInAtomicType.STRING
    needsRuntimeCheck = p0 == BuiltInAtomicType.ANY_ATOMIC || p1 == BuiltInAtomicType.ANY_ATOMIC
    if (!needsRuntimeCheck && !Type.isPossiblyComparable(p0, p1, Token.isOrderedOperator(operator))) {
      val opt0 = Cardinality.allowsZero(getLhsExpression.getCardinality)
      val opt1 = Cardinality.allowsZero(getRhsExpression.getCardinality)
      if (opt0 || opt1) { // This is a comparison such as (xs:integer? eq xs:date?). This is almost
        // certainly an error, but we need to let it through because it will work if
        // one of the operands is an empty sequence.
        var which = null
        if (opt0) which = "the first operand is"
        if (opt1) which = "the second operand is"
        if (opt0 && opt1) which = "one or both operands are"
        visitor.getStaticContext.issueWarning("Comparison of " + t0.toString + (if (opt0) "?"
        else "") + " to " + t1.toString + (if (opt1) "?"
        else "") + " will fail unless " + which + " empty", getLocation)
        needsRuntimeCheck = true
      }
      else {
        val message = "In {" + toShortString + "}: cannot compare " + t0.toString + " to " + t1.toString
        val err = new XPathException(message)
        err.setIsTypeError(true)
        err.setErrorCode("XPTY0004")
        err.setLocation(getLocation)
        throw err
      }
    }
    if (!(operator == Token.FEQ || operator == Token.FNE)) {
      mustBeOrdered(t0, p0)
      mustBeOrdered(t1, p1)
    }
    if (comparer == null) { // In XSLT, only do this the first time through, otherwise the default-collation attribute may be missed
      val defaultCollationName = env.getDefaultCollationName
      var comp = config.getCollation(defaultCollationName)
      if (comp == null) comp = CodepointCollator.getInstance
      comparer = GenericAtomicComparer.makeAtomicComparer(p0, p1, comp, env.getConfiguration.getConversionContext)
    }
    this
  }

  @throws[XPathException]
  private def mustBeOrdered(t1: PlainType, p1: BuiltInAtomicType) = if (!p1.isOrdered(true)) {
    val err = new XPathException("Type " + t1.toString + " is not an ordered type")
    err.setErrorCode("XPTY0004")
    err.setIsTypeError(true)
    err.setLocation(getLocation)
    throw err
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor     an expression visitor
   * @param contextInfo the static type of "." at the point where this expression is invoked.
   *                    The parameter is set to null if it is known statically that the context item will be undefined.
   *                    If the type of the context item is not known statically, the argument is set to
   *                    { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = {
    getLhs.optimize(visitor, contextInfo)
    getRhs.optimize(visitor, contextInfo)
    visitor.obtainOptimizer.optimizeValueComparison(this, visitor, contextInfo)
  }

  /**
   * Check whether this specific instance of the expression is negatable
   *
   * @return true if it is
   * @param th the type hierarchy
   */
  override def isNegatable(th: TypeHierarchy) = { // Expression is not negatable if it might involve NaN
    isNeverNaN(getLhsExpression, th) && isNeverNaN(getRhsExpression, th)
  }

  private def isNeverNaN(exp: Expression, th: TypeHierarchy) = (th.relationship(exp.getItemType, BuiltInAtomicType.DOUBLE) eq Affinity.DISJOINT) && (th.relationship(exp.getItemType, BuiltInAtomicType.FLOAT) eq Affinity.DISJOINT)

  /**
   * Return the negation of this value comparison: that is, a value comparison that returns true()
   * if and only if the original returns false(). The result must be the same as not(this) even in the
   * case where one of the operands is ().
   *
   * @return the inverted comparison
   */
  override def negate = {
    val vc = new ValueComparison(getLhsExpression, Token.negate(operator), getRhsExpression)
    vc.comparer = comparer
    if (resultWhenEmpty == null || (resultWhenEmpty eq BooleanValue.FALSE)) vc.resultWhenEmpty = BooleanValue.TRUE
    else vc.resultWhenEmpty = BooleanValue.FALSE
    ExpressionTool.copyLocationInfo(this, vc)
    vc
  }

  override def equals(other: Any) = other.isInstanceOf[ValueComparison] && super.equals(other) && comparer == other.asInstanceOf[ValueComparison].comparer

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be re-bound
   */
  override def copy(rebindings: RebindingMap) = {
    val vc = new ValueComparison(getLhsExpression.copy(rebindings), operator, getRhsExpression.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, vc)
    vc.comparer = comparer
    vc.resultWhenEmpty = resultWhenEmpty
    vc.needsRuntimeCheck = needsRuntimeCheck
    vc
  }

  /**
   * Evaluate the effective boolean value of the expression
   *
   * @param context the given context for evaluation
   * @return a boolean representing the result of the comparison of the two operands
   */
  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext): Boolean = try {
    val v0 = getLhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
    if (v0 == null) return resultWhenEmpty eq BooleanValue.TRUE // normally false
    val v1 = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
    if (v1 == null) return resultWhenEmpty eq BooleanValue.TRUE
    ValueComparison.compare(v0, operator, v1, comparer.provideContext(context), needsRuntimeCheck)
  } catch {
    case e: XPathException =>
      // re-throw the exception with location information added
      e.maybeSetLocation(getLocation)
      e.maybeSetContext(context)
      throw e
  }

  /**
   * Evaluate the expression in a given context
   *
   * @param context the given context for evaluation
   * @return a BooleanValue representing the result of the numeric comparison of the two operands,
   *         or null representing the empty sequence
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext): BooleanValue = try {
    val v0 = getLhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
    if (v0 == null) return resultWhenEmpty
    val v1 = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
    if (v1 == null) return resultWhenEmpty
    BooleanValue.get(ValueComparison.compare(v0, operator, v1, comparer.provideContext(context), needsRuntimeCheck))
  } catch {
    case e: XPathException =>
      e.maybeSetLocation(getLocation)
      e.maybeSetContext(context)
      throw e
  }

  /**
   * Determine the data type of the expression
   *
   * @return Type.BOOLEAN
   */
  override def getItemType = BuiltInAtomicType.BOOLEAN

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType the static type of the context item
   */
  override def getStaticUType(contextItemType: UType) = UType.BOOLEAN

  /**
   * Determine the static cardinality.
   */
  override def computeCardinality = if (resultWhenEmpty != null) StaticProperty.EXACTLY_ONE
  else super.computeCardinality

  override def tag = "vc"

  override protected def explainExtraAttributes(out: ExpressionPresenter) = {
    if (resultWhenEmpty != null) out.emitAttribute("onEmpty", if (resultWhenEmpty.getBooleanValue) "1"
    else "0")
    out.emitAttribute("comp", comparer.save)
  }
}