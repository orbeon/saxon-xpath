////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.sort.ItemOrderComparer
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trans.XPathException

/**
 * An enumeration representing a nodeset that is an intersection of two other NodeSets.
 * This implements the XPath 2.0 operator "intersect".
 */
class IntersectionEnumeration @throws[XPathException]
(var e1: SequenceIterator, var e2: SequenceIterator, var comparer: ItemOrderComparer)

/**
 * Form an enumeration of the intersection of the nodes in two nodesets
 *
 * @param p1       the first operand: must be in document order
 * @param p2       the second operand: must be in document order
 * @param comparer Comparer to be used for putting nodes in document order
 * @throws XPathException if an error occurs, for example reading from the input sequence
 */
  extends SequenceIterator { // move to the first node in each input nodeset
  nextNode1 = next(e1)
  nextNode2 = next(e2)
  /*@Nullable*/ private var nextNode1 = null
  private var nextNode2 = null

  /**
   * Get the next item from one of the input sequences,
   * checking that it is a node.
   *
   * @param iter the iterator from which the next item is to be taken
   * @return the next value returned by that iterator
   * @throws XPathException if a failure occurs reading from the input sequence
   */
  @throws[XPathException]
  private def next(iter: SequenceIterator) = {
    iter.next.asInstanceOf[NodeInfo]
    // rely on type-checking to prevent a ClassCastException
  }

  @throws[XPathException]
  override def next: NodeInfo = { // main merge loop: iterate whichever sequence has the lower value, returning when a pair
    // is found that match.
    if (nextNode1 == null || nextNode2 == null) return null
    while ( {
      nextNode1 != null && nextNode2 != null
    }) {
      val c = comparer.compare(nextNode1, nextNode2)
      if (c < 0) nextNode1 = next(e1)
      else if (c > 0) nextNode2 = next(e2)
      else { // keys are equal
        val current = nextNode2 // which is the same as nextNode1
        nextNode2 = next(e2)
        nextNode1 = next(e1)
        return current
      }
    }
    null
  }

  override def close() = {
    e1.close()
    e2.close()
  }
}