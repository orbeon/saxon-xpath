////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.FingerprintedQName
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.om.NodeName
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.tiny.CharSlice
import java.util._

/**
 * HTMLIndenter: This ProxyReceiver indents HTML elements, by adding whitespace
 * character data where appropriate.
 * The character data is never added when within an inline element.
 * The string used for indentation defaults to three spaces
 *
 * @author Michael Kay
 */
object HTMLIndenter {
  private val formattedTags = Array("pre", "script", "style", "textarea", "title", "xmp")
  private val inlineTags = Array("a", "abbr", "acronym", "applet", "area", "audio", "b", "basefont", "bdi", "bdo", "big", "br", "button", "canvas", "cite", "code", "data", "datalist", "del", "dfn", "em", "embed", "font", "i", "iframe", "img", "input", "ins", "kbd", "label", /*"link" -- excluded, see bug 3877,*/ "map", "mark", "math", "meter", "noscript", "object", "output", "picture", "progress", "q", "ruby", "s", "samp", "script", "select", "small", "span", "strike", "strong", "sub", "sup", "svg", "template", "textarea", "time", "tt", "u", "var", "video", "wbr")
  private val inlineTable = new util.HashSet[String](70)
  private val formattedTable = new util.HashSet[String](10)
  private val IS_INLINE = 1
  private val IS_FORMATTED = 2
  private val IS_SUPPRESSED = 4
  try Collections.addAll(inlineTable, inlineTags)
  Collections.addAll(formattedTable, formattedTags)
}

class HTMLIndenter(val next: Receiver, val method: String) extends ProxyReceiver(next) {
  protected var indentChars = Array('\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ')
  private val method = null
  private var level = 0
  private var sameLine = false
  private var inFormattedTag = false
  private var afterInline = false
  private var afterEndElement = false
  private var propertyStack = new Array[Int](20)
  private var suppressed = null

  /**
   * Set the properties for this indenter
   *
   * @param props the serialization properties
   */
  def setOutputProperties(props: Properties) = {
    val s = props.getProperty(SaxonOutputKeys.SUPPRESS_INDENTATION)
    if (s != null) {
      suppressed = new util.HashSet[String](8)
      val st = new StringTokenizer(s, " \t\r\n")
      while ( {
        st.hasMoreTokens
      }) {
        val eqName = st.nextToken
        suppressed.add(FingerprintedQName.fromEQName(eqName).getLocalPart.toLowerCase)
      }
    }
  }

  /**
   * Classify an element name as inline, formatted, or both or neither.
   * This method is overridden in the XHTML indenter
   *
   * @param name the element name
   * @return a bit-significant integer containing flags IS_INLINE and/or IS_FORMATTED
   */
  def classifyTag(name: NodeName) = {
    var r = 0
    if (HTMLIndenter.inlineTable.contains(name.getLocalPart.toLowerCase)) r |= HTMLIndenter.IS_INLINE
    if (HTMLIndenter.formattedTable.contains(name.getLocalPart.toLowerCase)) r |= HTMLIndenter.IS_FORMATTED
    if (suppressed != null && suppressed.contains(name.getLocalPart.toLowerCase)) r |= HTMLIndenter.IS_SUPPRESSED
    r
  }

  /**
   * Output element start tag
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    val withinSuppressed = if (level == 0) 0
    else propertyStack(level - 1) & HTMLIndenter.IS_SUPPRESSED
    val tagProps = classifyTag(elemName) | withinSuppressed
    if (level >= propertyStack.length) propertyStack = util.Arrays.copyOf(propertyStack, level * 2)
    propertyStack(level) = tagProps
    val inlineTag = (tagProps & HTMLIndenter.IS_INLINE) != 0
    if (!inlineTag && !inFormattedTag && !afterInline && /*!afterFormatted &&*/ withinSuppressed == 0 && level != 0) indent()
    nextReceiver.startElement(elemName, `type`, attributes, namespaces, location, properties)
    inFormattedTag = inFormattedTag || ((tagProps & HTMLIndenter.IS_FORMATTED) != 0)
    level += 1
    sameLine = true
    afterInline = false
    //afterFormatted = false;
    afterEndElement = false
  }

  /**
   * Output element end tag
   */
  @throws[XPathException]
  override def endElement() = {
    level -= 1
    val thisInline = (propertyStack(level) & HTMLIndenter.IS_INLINE) != 0
    val thisFormatted = (propertyStack(level) & HTMLIndenter.IS_FORMATTED) != 0
    val thisSuppressed = (propertyStack(level) & HTMLIndenter.IS_SUPPRESSED) != 0
    if (afterEndElement && !thisInline && !thisSuppressed && !afterInline && !sameLine && !inFormattedTag) {
      indent()
      afterInline = false
    }
    else {
      afterInline = thisInline
      //afterFormatted = thisFormatted;
    }
    nextReceiver.endElement()
    inFormattedTag = inFormattedTag && !thisFormatted
    sameLine = false
    afterEndElement = true
  }

  /**
   * Output character data
   */
  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = {
    if (inFormattedTag || ReceiverOption.contains(properties, ReceiverOption.USE_NULL_MARKERS) || ReceiverOption.contains(properties, ReceiverOption.DISABLE_ESCAPING)) { // don't split the text if in a tag such as <pre>, or if the text contains the result of
      // expanding a character map or was produced using disable-output-escaping
      nextReceiver.characters(chars, locationId, properties)
    }
    else { // otherwise try to split long lines into multiple lines
      var lastNL = 0
      for (i <- 0 until chars.length) {
        if (chars.charAt(i) == '\n' || (i - lastNL > getLineLength && chars.charAt(i) == ' ')) {
          sameLine = false
          nextReceiver.characters(chars.subSequence(lastNL, i), locationId, properties)
          indent()
          lastNL = i + 1
          while ( {
            lastNL < chars.length && chars.charAt(lastNL) == ' '
          }) lastNL += 1
        }
      }
      if (lastNL < chars.length) nextReceiver.characters(chars.subSequence(lastNL, chars.length), locationId, properties)
    }
    afterInline = false
    afterEndElement = false
  }

  /**
   * Output a processing instruction
   */
  @throws[XPathException]
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = {
    if (afterEndElement && level != 0 && (propertyStack(level - 1) & HTMLIndenter.IS_INLINE) == 0) indent()
    nextReceiver.processingInstruction(target, data, locationId, properties)
    afterEndElement = false
  }

  /**
   * Output a comment
   */
  @throws[XPathException]
  override def comment(chars: CharSequence, locationId: Location, properties: Int) = {
    if (afterEndElement && level != 0 && (propertyStack(level - 1) & HTMLIndenter.IS_INLINE) == 0) indent()
    nextReceiver.comment(chars, locationId, properties)
    afterEndElement = false
  }

  /**
   * Get the maximum length of lines, after which long lines will be word-wrapped
   *
   * @return the maximum line length
   */
  protected def getLineLength = 80

  /**
   * Output white space to reflect the current indentation level
   *
   * @throws net.sf.saxon.trans.XPathException if an error occurs downstream in the pipeline
   */
  @throws[XPathException]
  private def indent() = {
    val spaces = level * getIndentation
    if (spaces + 1 >= indentChars.length) {
      var increment = 5 * getIndentation
      if (spaces + 1 > indentChars.length + increment) increment += spaces + 1
      val c2 = new Array[Char](indentChars.length + increment)
      System.arraycopy(indentChars, 0, c2, 0, indentChars.length)
      util.Arrays.fill(c2, indentChars.length, c2.length, ' ')
      indentChars = c2
    }
    nextReceiver.characters(new CharSlice(indentChars, 0, spaces + 1), Loc.NONE, ReceiverOption.NONE)
    sameLine = false
  }

  /**
   * Get the number of spaces to be used for indentation
   *
   * @return the number of spaces to be added to the indentation for each level
   */
  protected def getIndentation = 3
}