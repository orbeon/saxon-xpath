////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.ValueOf
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.linked.TextImpl
import net.sf.saxon.value.StringValue
import net.sf.saxon.value.Whitespace
import java.util

/**
 * Handler for xsl:text elements in stylesheet. <BR>
 */
class XSLText extends XSLLeafNodeConstructor {
  private var disable = false
  private var value = null

  override def prepareAttributes() = {
    var disableAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      if (f == "disable-output-escaping") disableAtt = Whitespace.trim(value)
      else checkUnknownAttribute(attName)
    }
    if (disableAtt != null) disable = processBooleanAttribute("disable-output-escaping", disableAtt)
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration): Unit = {
    value = StringValue.EMPTY_STRING
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[StyleElement]) {
        child.asInstanceOf[StyleElement].compileError("xsl:text must not contain child elements", "XTSE0010")
        return
      }
      else {
        value = StringValue.makeStringValue(child.getStringValueCS)
        //continue;
      }
    }
    super.validate(decl)
  }

  /**
   * Get the error code to be returned when the element has a select attribute but is not empty.
   *
   * @return the error code defined for this condition, for this particular instruction
   */
  /*@Nullable*/ override protected def getErrorCodeForSelectPlusContent = null // not applicable
  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = if (isExpandingText) {
    val child = iterateAxis(AxisInfo.CHILD).next.asInstanceOf[TextImpl]
    if (child != null) {
      val contents = new util.ArrayList[Expression](10)
      compileContentValueTemplate(child, contents)
      val block = Block.makeBlock(contents)
      block.setLocation(allocateLocation)
      block
    }
    else new ValueOf(new StringLiteral(StringValue.EMPTY_STRING), disable, false)
  }
  else new ValueOf(Literal.makeLiteral(value), disable, false)
}