////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.ListIterator
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.EmptySequence
import java.util

/**
 * A value that is a sequence containing one or more items. The main use is in declarations of reflexive extension
 * functions, where declaring an argument of type &lt;ZeroOrMore&lt;IntegerValue&gt;&gt; triggers automatic type
 * checking in the same way as for a native XSLT/XQuery function declaring the type as xs:integer*.
 */
class ZeroOrMore[T <: Item] extends GroundedValue with Iterable[T] {
  private var content = null

  /**
   * Create a sequence containing zero or one items
   *
   * @param content The content of the sequence
   */
  def this(content: Array[T]) {
    this()
    this.content = util.Arrays.asList(content)
  }

  def this(content: util.List[T]) {
    this()
    this.content = content
  }

  def this(iter: SequenceIterator) {
    this()
    content = new util.ArrayList[T]
    iter.forEachOrFail((item: Item) => content.add(item.asInstanceOf[T]))
  }

  override def head = if (content.isEmpty) null
  else content.get(0)

  override def iterate = new ListIterator[T](content)

  override def iterator = content.iterator

  /**
   * Get the n'th item in the value, counting from 0
   *
   * @param n the index of the required item, with 0 representing the first item in the sequence
   * @return the n'th item if it exists, or null otherwise
   */
  override def itemAt(n: Int) = if (n >= 0 && n < content.size) content.get(n)
  else null

  /**
   * Get a subsequence of the value
   *
   * @param start  the index of the first item to be included in the result, counting from zero.
   *               A negative value is taken as zero. If the value is beyond the end of the sequence, an empty
   *               sequence is returned
   * @param length the number of items to be included in the result. Specify Integer.MAX_VALUE to
   *               get the subsequence up to the end of the base sequence. If the value is negative, an empty sequence
   *               is returned. If the value goes off the end of the sequence, the result returns items up to the end
   *               of the sequence
   * @return the required subsequence.
   */
  override def subsequence(start: Int, length: Int) = {
    if (start < 0) start = 0
    if (start + length > content.size) length = content.size - start
    new ZeroOrMore[T](content.subList(start, start + length))
  }

  /**
   * Get the size of the value (the number of items)
   *
   * @return the number of items in the sequence
   */
  override def getLength = content.size

  /**
   * Get the effective boolean value of this sequence
   *
   * @return the effective boolean value
   * @throws net.sf.saxon.trans.XPathException
   * if the sequence has no effective boolean value (for example a sequence of two integers)
   */
  @throws[XPathException]
  override def effectiveBooleanValue = ExpressionTool.effectiveBooleanValue(iterate)

  /**
   * Get the string value of this sequence. The string value of an item is the result of applying the string()
   * function. The string value of a sequence is the space-separated result of applying the string-join() function
   * using a single space as the separator
   *
   * @return the string value of the sequence.
   * @throws net.sf.saxon.trans.XPathException
   * if the sequence contains items that have no string value (for example, function items)
   */
  @throws[XPathException]
  override def getStringValue = SequenceTool.getStringValue(this)

  @throws[XPathException]
  override def getStringValueCS = SequenceTool.getStringValue(this)

  /**
   * Reduce the sequence to its simplest form. If the value is an empty sequence, the result will be
   * EmptySequence.getInstance(). If the value is a single atomic value, the result will be an instance
   * of {@link AtomicValue}. If the value is a single item of any other kind, the result will be an instance
   * of {@link One}. Otherwise, the result will typically be unchanged.
   *
   * @return the simplified sequence
   */
  override def reduce: GroundedValue = {
    if (content.isEmpty) return EmptySequence.getInstance
    else if (content.size == 1) {
      val first = content.get(0)
      if (first.isInstanceOf[AtomicValue]) return first
      else return new One[T](head)
    }
    this
  }
}