////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.event.Outputter
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.UserFunction
import net.sf.saxon.expr.parser._
import net.sf.saxon.model.AnyItemType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.UType
import net.sf.saxon.om._
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans._
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.EmptySequence
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace
import java.util

/**
 * This class represents a call to a user-defined function in the stylesheet or query.
 */
object UserFunctionCall {
  val NOT_TAIL_CALL = 0
  val FOREIGN_TAIL_CALL = 1
  val SELF_TAIL_CALL = 2
  private val UNHANDLED_DEPENDENCIES = StaticProperty.DEPENDS_ON_POSITION | StaticProperty.DEPENDS_ON_LAST | StaticProperty.DEPENDS_ON_XSLT_CONTEXT | StaticProperty.DEPENDS_ON_USER_FUNCTIONS
  private val depth = 0
}

class UserFunctionCall()

/**
 * Create a function call to a user-written function in a query or stylesheet
 */
  extends FunctionCall with UserFunctionResolvable with ComponentInvocation with ContextOriginator {
  private var staticType = null
  private var function = null
  private var bindingSlot = -1
  private var tailCall = UserFunctionCall.NOT_TAIL_CALL
  private var name = null

  def isBeingInlined = beingInlined

  def setBeingInlined(beingInlined: Boolean) = this.beingInlined = beingInlined

  private var beingInlined = false
  /*@Nullable*/ private var argumentEvaluators = null

  /**
   * Set the name of the function being called
   *
   * @param name the name of the function
   */
  final def setFunctionName(name: StructuredQName) = this.name = name

  /**
   * Set the static type
   *
   * @param type the static type of the result of the function call
   */
  def setStaticType(`type`: SequenceType) = staticType = `type`

  /**
   * Create the reference to the function to be called
   *
   * @param compiledFunction the function being called
   */
  override def setFunction(compiledFunction: UserFunction) = function = compiledFunction

  /**
   * Set the binding slot to be used. This is the offset within the binding vector of the containing
   * component where the actual target template is to be found. The target function is not held directly
   * in the UserFunctionCall expression itself because it can be overridden in a using package.
   *
   * @param slot the offset in the binding vector of the containing package where the target template
   *             can be found.
   */
  override def setBindingSlot(slot: Int) = this.bindingSlot = slot

  /**
   * Get the binding slot to be used. This is the offset within the binding vector of the containing
   * component where the actual target template is to be found.
   *
   * @return the offset in the binding vector of the containing package where the target template
   *         can be found.
   */
  override def getBindingSlot = bindingSlot

  /**
   * Get the function that is being called by this function call. This is the provisional
   * binding: the actual function might be an override of this one.
   *
   * @return the function being called
   */
  def getFunction = function

  override def getFixedTarget = {
    val v = function.getDeclaringComponent.getVisibility
    if ((v eq Visibility.PRIVATE) || (v eq Visibility.FINAL)) function.getDeclaringComponent
    else null
  }

  /**
   * Determine whether this is a tail call (not necessarily a recursive tail call)
   *
   * @return true if this function call is a tail call
   */
  def isTailCall = tailCall != UserFunctionCall.NOT_TAIL_CALL

  def isRecursiveTailCall = tailCall == UserFunctionCall.SELF_TAIL_CALL

  /**
   * Get the qualified of the function being called
   *
   * @return the qualified name
   */
  override final def getFunctionName = if (name == null) function.getFunctionName
  else name

  override def getSymbolicName = new SymbolicName.F(getFunctionName, getArity)

  def getTarget = function.getDeclaringComponent

  /**
   * Set the argument evaluation modes
   *
   * @param evalModes the argument evaluation modes to be used
   */
  def setArgumentEvaluationModes(evalModes: Array[EvaluationMode]) = {
    argumentEvaluators = new Array[Evaluator](evalModes.length)
    for (i <- 0 until evalModes.length) {
      argumentEvaluators(i) = evalModes(i).getEvaluator
    }
  }

  def allocateArgumentEvaluators() = {
    argumentEvaluators = new Array[Evaluator](getArity)
    var i = 0
    import scala.collection.JavaConversions._
    for (o <- operands) {
      val arg = o.getChildExpression
      val required = function.getArgumentType(i)
      val cardinality = required.getCardinality
      if (i == 0 && function.getDeclaredStreamability.isConsuming) argumentEvaluators(i) = Evaluator.STREAMING_ARGUMENT
      else if (function.getParameterDefinitions(i).isIndexedVariable) argumentEvaluators(i) = Evaluator.MAKE_INDEXED_VARIABLE
      else if (arg.isInstanceOf[Literal]) argumentEvaluators(i) = Evaluator.LITERAL
      else if (arg.isInstanceOf[VariableReference]) argumentEvaluators(i) = Evaluator.VARIABLE
      else if (cardinality == StaticProperty.EXACTLY_ONE) argumentEvaluators(i) = Evaluator.SINGLE_ITEM
      else if ((arg.getDependencies & UserFunctionCall.UNHANDLED_DEPENDENCIES) != 0) { // If the argument contains a call to a user-defined function, then it might be a recursive call.
        // It's better to evaluate it now, rather than waiting until we are on a new stack frame, as
        // that can blow the stack if done repeatedly. (See test func42)
        // If the argument contains calls to position(), last(), regex-group(), current-group(),
        // current-merge-group(), etc, then in general we can't save the values in a Closure
        // so we need to evaluate the argument eagerly. (Tests position-0103, merge-096).
        argumentEvaluators(i) = Evaluator.EAGER_SEQUENCE
      }
      else if (!Cardinality.allowsMany(arg.getCardinality) && arg.getCost < 20) { // the argument is cheap to evaluate and doesn't use much memory...
        argumentEvaluators(i) = Evaluator.EAGER_SEQUENCE
      }
      else if (cardinality == StaticProperty.ALLOWS_ZERO_OR_ONE) argumentEvaluators(i) = Evaluator.OPTIONAL_ITEM
      else if (arg.isInstanceOf[Block] && arg.asInstanceOf[Block].isCandidateForSharedAppend) { // If the expression is a Block, that is, it is appending a value to a sequence,
        // then we have the opportunity to use a shared list underpinning the old value and
        // the new. This takes precedence over lazy evaluation (it would be possible to do this
        // lazily, but more difficult). We currently do this for any Block that has a variable
        // reference as one of its subexpressions. The most common case is that the first argument is a reference
        // to an argument of recursive function, where the recursive function returns the result of
        // appending to the sequence.
        argumentEvaluators(i) = Evaluator.SHARED_APPEND
      }
      else argumentEvaluators(i) = Evaluator.MEMO_CLOSURE
      i += 1
    }
  }

  def getArgumentEvaluators = argumentEvaluators

  /**
   * Pre-evaluate a function at compile time. This version of the method suppresses
   * early evaluation by doing nothing.
   *
   * @param visitor an expression visitor
   */
  override def preEvaluate(visitor: ExpressionVisitor) = this

  /**
   * Determine the data type of the expression, if possible
   *
   * @return Type.ITEM (meaning not known in advance)
   */
  /*@NotNull*/ override def getItemType = if (staticType == null) { // the actual type is not known yet, so we return an approximation
    AnyItemType.getInstance
  }
  else staticType.getPrimaryType

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @param contextItemType the static type of the context item
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   */
  override def getStaticUType(contextItemType: UType): UType = {
    val f = getFunction
    if (f == null) { // Happens when called during parsing
      return UType.ANY
    }
    f.getResultType.getPrimaryType.getUType
  }

  override def getIntrinsicDependencies = StaticProperty.DEPENDS_ON_USER_FUNCTIONS

  /**
   * Determine whether this is an updating expression as defined in the XQuery update specification
   *
   * @return true if this is an updating expression
   */
  override def isUpdatingExpression = function.isUpdating

  /**
   * Compute the special properties of this expression. These properties are denoted by a bit-significant
   * integer, possible values are in class {@link net.sf.saxon.expr.StaticProperty}. The "special" properties are properties
   * other than cardinality and dependencies, and most of them relate to properties of node sequences, for
   * example whether the nodes are in document order.
   *
   * @return the special properties, as a bit-significant integer
   */
  override protected def computeSpecialProperties = { // Inherit the properties of the function being called if possible. But we have to prevent
    // looping when the function is recursive. For safety, we only consider the properties of the
    // function body if it contains no further function calls. Also, we can only do this safely if
    // the function is private or final
    if (function == null) super.computeSpecialProperties
    else if (function.getBody != null && ((function.getDeclaredVisibility eq Visibility.PRIVATE) || (function.getDeclaredVisibility eq Visibility.FINAL))) {
      var props = 0
      val calledFunctions = new util.ArrayList[UserFunction]
      ExpressionTool.gatherCalledFunctions(function.getBody, calledFunctions)
      if (calledFunctions.isEmpty) props = function.getBody.getSpecialProperties
      else props = super.computeSpecialProperties
      if (function.getDeterminism ne UserFunction.Determinism.PROACTIVE) props |= StaticProperty.NO_NODES_NEWLY_CREATED
      props
    }
    else super.computeSpecialProperties
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @param rebindings variable bindings that need to be changed
   * @return the copy of the original expression
   */
  override def copy(rebindings: RebindingMap) = {
    if (function == null) { // not bound yet, we have no way to register the new copy with the XSLFunction
      throw new UnsupportedOperationException("UserFunctionCall.copy()")
    }
    val ufc = new UserFunctionCall
    ufc.setFunction(function)
    ufc.setStaticType(staticType)
    val numArgs = getArity
    val a2 = new Array[Expression](numArgs)
    for (i <- 0 until numArgs) {
      a2(i) = getArg(i).copy(rebindings)
    }
    ufc.setArguments(a2)
    ExpressionTool.copyLocationInfo(this, ufc)
    ufc
  }

  /**
   * Determine the cardinality of the result
   */
  override def computeCardinality = if (staticType == null) StaticProperty.ALLOWS_ZERO_OR_MORE
  else staticType.getCardinality

  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val e = super.typeCheck(visitor, contextInfo)
    if (e ne this) return e
    if (function != null) {
      checkFunctionCall(function, visitor)
      if (staticType == null || (staticType eq SequenceType.ANY_SEQUENCE)) { // try to get a better type
        staticType = function.getResultType
      }
    }
    this
  }

  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    val e = super.optimize(visitor, contextItemType)
    if ((e eq this) && function != null) return visitor.obtainOptimizer.tryInlineFunctionCall(this, visitor, contextItemType)
    e
  }

  /**
   * Reset the static properties of the expression to -1, so that they have to be recomputed
   * next time they are used.
   */
  override def resetLocalStaticProperties() = {
    super.resetLocalStaticProperties()
    argumentEvaluators = null
  }

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   * <p>The default implementation of this method assumes that an expression does no navigation other than
   * the navigation done by evaluating its subexpressions, and that the subexpressions are evaluated in the
   * same context as the containing expression. The method must be overridden for any expression
   * where these assumptions do not hold. For example, implementations exist for AxisExpression, ParentExpression,
   * and RootExpression (because they perform navigation), and for the doc(), document(), and collection()
   * functions because they create a new navigation root. Implementations also exist for PathExpression and
   * FilterExpression because they have subexpressions that are evaluated in a different context from the
   * calling expression.</p>
   *
   * @param pathMap        the PathMap to which the expression should be added
   * @param pathMapNodeSet the PathMapNodeSet to which the paths embodied in this expression should be added
   * @return the pathMapNode representing the focus established by this expression, in the case where this
   *         expression is the first operand of a path expression or filter expression. For an expression that does
   *         navigation, it represents the end of the arc in the path map that describes the navigation route. For other
   *         expressions, it is the same as the input pathMapNode.
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = addExternalFunctionCallToPathMap(pathMap, pathMapNodeSet)

  /**
   * Mark tail-recursive calls on stylesheet functions. This marks the function call as tailRecursive if
   * if is a call to the containing function, and in this case it also returns "true" to the caller to indicate
   * that a tail call was found.
   */
  override def markTailFunctionCalls(qName: StructuredQName, arity: Int) = {
    tailCall = if (getFunctionName == qName && arity == getArity) UserFunctionCall.SELF_TAIL_CALL
    else UserFunctionCall.FOREIGN_TAIL_CALL
    tailCall
  }

  override def getImplementationMethod = if (Cardinality.allowsMany(getCardinality)) ITERATE_METHOD | PROCESS_METHOD
  else EVALUATE_METHOD

  /**
   * Call the function, returning the value as an item. This method will be used
   * only when the cardinality is zero or one. If the function is tail recursive,
   * it returns an Object representing the arguments to the next (recursive) call
   */
  @throws[XPathException]
  override def evaluateItem(c: XPathContext) = callFunction(c).head

  /**
   * Call the function, returning an iterator over the results. (But if the function is
   * tail recursive, it returns an iterator over the arguments of the recursive call)
   */
  @throws[XPathException]
  override def iterate(c: XPathContext) = callFunction(c).iterate

  /**
   * Evaluate an updating expression, adding the results to a Pending Update List.
   * The default implementation of this method, which is used for non-updating expressions,
   * throws an UnsupportedOperationException
   *
   * @param context the XPath dynamic evaluation context
   * @param pul     the pending update list to which the results should be written
   */
  @throws[XPathException]
  override def evaluatePendingUpdates(context: XPathContext, pul: PendingUpdateList) = {
    val actualArgs = evaluateArguments(context)
    val c2 = context.newCleanContext
    c2.setOrigin(this)
    function.callUpdating(actualArgs, c2, pul)
  }

  /**
   * This is the method that actually does the function call (in pull mode)
   *
   * @param context the dynamic context
   * @return the result of the function
   * @throws XPathException if dynamic errors occur
   */
  @throws[XPathException]
  private def callFunction(context: XPathContext): Sequence = {
    var targetFunction = null
    val actualArgs = evaluateArguments(context)
    var c2 = null
    if (isTailCall) {
      requestTailCall(context, actualArgs)
      return EmptySequence.getInstance
    }
    if (bindingSlot >= 0) {
      val target = getTargetComponent(context)
      if (target.isHiddenAbstractComponent) throw new XPathException("Cannot call an abstract function (" + name.getDisplayName + ") with no implementation", "XTDE3052")
      targetFunction = target.getActor.asInstanceOf[UserFunction]
      c2 = targetFunction.makeNewContext(context, this)
      c2.setCurrentComponent(target)
      c2.setOrigin(this)
    }
    else {
      targetFunction = function
      c2 = targetFunction.makeNewContext(context, this)
      c2.setOrigin(this)
    }
    try targetFunction.call(c2, actualArgs)
    catch {
      case e: UncheckedXPathException =>
        val xe = e.getXPathException
        xe.maybeSetLocation(getLocation)
        throw xe
      case err: StackOverflowError =>
        throw new XPathException.StackOverflow("Too many nested function calls. May be due to infinite recursion", SaxonErrorCode.SXLM0001, getLocation)
    }
  }

  @throws[XPathException]
  private def requestTailCall(context: XPathContext, actualArgs: Array[Sequence]) = if (bindingSlot >= 0) {
    val info = new TailCallLoop.TailCallComponent
    val target = getTargetComponent(context)
    info.component = target
    info.function = target.getActor.asInstanceOf[UserFunction]
    if (target.isHiddenAbstractComponent) throw new XPathException("Cannot call an abstract function (" + name.getDisplayName + ") with no implementation", "XTDE3052")
    context.asInstanceOf[XPathContextMajor].requestTailCall(info, actualArgs)
  }
  else {
    val info = new TailCallLoop.TailCallFunction
    info.function = function
    context.asInstanceOf[XPathContextMajor].requestTailCall(info, actualArgs)
  }

  /**
   * Process the function call in push mode
   *
   * @param output  the destination for the result
   * @param context the XPath dynamic context
   * @throws XPathException if a dynamic error occurs
   */
  @throws[XPathException]
  override def process(output: Outputter, context: XPathContext): Unit = {
    val actualArgs = evaluateArguments(context)
    if (isTailCall) {
      requestTailCall(context, actualArgs)
      return
    }
    if (bindingSlot >= 0) {
      val target = getTargetComponent(context)
      val targetFunction = target.getActor.asInstanceOf[UserFunction]
      if (target.getVisibility eq Visibility.ABSTRACT) throw new XPathException("Cannot call a function defined with visibility=abstract", "XTDE3052")
      val c2 = targetFunction.makeNewContext(context, this)
      c2.setCurrentComponent(target)
      c2.setOrigin(this)
      targetFunction.process(c2, actualArgs, output)
    }
    else {
      val c2 = function.makeNewContext(context, this)
      c2.setOrigin(this)
      function.process(c2, actualArgs, output)
    }
  }

  def getTargetComponent(context: XPathContext) = if (bindingSlot == -1) { // fallback for non-package code
    function.getDeclaringComponent
  }
  else context.getTargetComponent(bindingSlot)

  override def getTargetFunction(context: XPathContext) = getTargetComponent(context).getActor.asInstanceOf[UserFunction]

  @throws[XPathException]
  override def evaluateArguments(c: XPathContext) = evaluateArguments(c, false)

  @throws[XPathException]
  def evaluateArguments(c: XPathContext, streamed: Boolean) = {
    val numArgs = getArity
    val actualArgs = SequenceTool.makeSequenceArray(numArgs)
    this synchronized {
      if (argumentEvaluators == null) { // should have been done at compile time
        allocateArgumentEvaluators()
      }
    }
    for (i <- 0 until numArgs) {
      var eval = argumentEvaluators(i)
      if ((eval eq Evaluator.STREAMING_ARGUMENT) && !streamed) eval = Evaluator.EAGER_SEQUENCE
      actualArgs(i) = eval.evaluate(getArg(i), c)
      if (actualArgs(i) == null) actualArgs(i) = EmptySequence.getInstance
    }
    actualArgs
  }

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    out.startElement("ufCall", this)
    if (getFunctionName != null) {
      out.emitAttribute("name", getFunctionName)
      out.emitAttribute("tailCall", if (tailCall == UserFunctionCall.NOT_TAIL_CALL) "false"
      else if (tailCall == UserFunctionCall.SELF_TAIL_CALL) "self"
      else "foreign")
    }
    out.emitAttribute("bSlot", "" + getBindingSlot)
    if (argumentEvaluators != null && getArity > 0) {
      val fsb = new FastStringBuffer(FastStringBuffer.C64)
      for (e <- argumentEvaluators) {
        fsb.append(e.getEvaluationMode.getCode + " ")
      }
      out.emitAttribute("eval", Whitespace.trim(fsb))
    }
    import scala.collection.JavaConversions._
    for (o <- operands) {
      o.getChildExpression.`export`(out)
    }
    if (getFunctionName == null) {
      out.setChildRole("inline")
      function.getBody.`export`(out)
      out.endElement
    }
    out.endElement
  }

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "userFunctionCall"

  override def getProperty(name: String): Any = {
    if (name == "target") return function
    super.getProperty(name)
  }

  override def getObjectName = getFunctionName
}