////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.Configuration
import net.sf.saxon.Controller
import net.sf.saxon.expr.XPathContext
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.model.FunctionItemType
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.om.Function
import net.sf.saxon.om.Sequence
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.s9api.streams.Step
import net.sf.saxon.trans.XPathException
import java.util.stream.Stream

/**
 * The class XdmFunctionItem represents a function item
 */
object XdmFunctionItem {
  /**
   * Get a system function. This can be any function defined in XPath 3.1 functions and operators,
   * including functions in the math, map, and array namespaces. It can also be a Saxon extension
   * function, provided a licensed Processor is used.
   *
   * @return the requested function, or null if there is no such function. Note that some functions
   *         (those with particular context dependencies) may be unsuitable for dynamic calling.
   * @throws SaxonApiException if dynamic function calls are not permitted by this Saxon Configuration
   */
    @throws[SaxonApiException]
    def getSystemFunction(processor: Processor, name: QName, arity: Int) = try {
      val config = processor.getUnderlyingConfiguration
      val f = config.getSystemFunction(name.getStructuredQName, arity)
      if (f == null) null
      else new XdmFunctionItem(f)
    } catch {
      case e: XPathException =>
        throw new SaxonApiException(e)
    }
}

class XdmFunctionItem protected() extends XdmItem {
  def this(fi: Function) {
    this()
    setValue(fi)
  }

  /**
   * Get the name of the function
   *
   * @return the function name, as a QName, or null for an anonymous inline function item
   */
  def getName = {
    val fi = getUnderlyingValue.asInstanceOf[Function]
    val sq = fi.getFunctionName
    if (sq == null) null
    else new QName(sq)
  }

  /**
   * Get the arity of the function
   *
   * @return the arity of the function, that is, the number of arguments in the function's signature
   */
  def getArity = {
    val fi = getUnderlyingValue.asInstanceOf[Function]
    fi.getArity
  }

  /**
   * Determine whether the item is an atomic value
   *
   * @return false, the item is not an atomic value, it is a function item
   */
  override def isAtomicValue = false

  /**
   * Get an equivalent Java Function object representing this XdmFunction.
   * This is possible only for arity-1 functions.
   *
   * @return a Java Function. This takes an XdmValue
   *         as its argument, and returns the function result in the form of an XdmValue.
   *         The Function throws an unchecked exception if evaluation fails
   * @throws IllegalStateException if the arity of the function is not one (1).
   */
  def asFunction(processor: Processor) = if (getArity == 1) (arg: XdmValue) => {
    def foo(arg: XdmValue) =
      try return thisXdmFunctionItem.call(processor, arg)
      catch {
        case e: SaxonApiException =>
          throw new SaxonApiUncheckedException(e)
      }

    foo(arg)
  }.asInstanceOf[Function[XdmValue, XdmValue]]
  else throw new IllegalStateException("Function arity must be one")

  /**
   * Get an equivalent Step object representing this XdmFunction.
   * This is possible only for arity-1 functions.
   *
   * @return a Step. This takes an XdmItem
   *         as its argument, and returns the function result in the form of an XdmStream.
   *         The Function throws an unchecked exception if evaluation fails
   * @throws IllegalStateException if the arity of the function is not one (1).
   */
  def asStep(processor: Processor) = if (getArity == 1) new Step[XdmItem]() {
    override def apply(arg: XdmItem): Stream[_ <: XdmItem] = try return thisXdmFunctionItem.call(processor, arg).stream
    catch {
      case e: SaxonApiException =>
        throw new SaxonApiUncheckedException(e)
    }
  }
  else throw new IllegalStateException("Function arity must be one")

  /**
   * Call the function
   *
   * @param arguments the values to be supplied as arguments to the function. The "function
   *                  conversion rules" will be applied to convert the arguments to the required
   *                  type when necessary.
   * @param processor the s9api Processor
   * @return the result of calling the function
   */
  @throws[SaxonApiException]
  def call(processor: Processor, arguments: XdmValue*) = {
    if (arguments.length != getArity) throw new SaxonApiException("Supplied " + arguments.length + " arguments, required " + getArity)
    try {
      val fi = getUnderlyingValue.asInstanceOf[Function]
      val `type` = fi.getFunctionItemType
      val argVals = new Array[Sequence](arguments.length)
      val th = processor.getUnderlyingConfiguration.getTypeHierarchy
      for (i <- 0 until arguments.length) {
        val required = `type`.getArgumentTypes(i)
        var `val` = arguments(i).getUnderlyingValue
        if (!required.matches(`val`, th)) {
          val role = new RoleDiagnostic(RoleDiagnostic.FUNCTION, "", i)
          `val` = th.applyFunctionConversionRules(`val`, required, role, Loc.NONE)
        }
        argVals(i) = `val`
      }
      val config = processor.getUnderlyingConfiguration
      val controller = new Controller(config)
      var context = controller.newXPathContext
      context = fi.makeNewContext(context, controller)
      var result = fi.call(context, argVals)
      if (!fi.isTrustedResultType) {
        result = result.materialize
        val required = `type`.getResultType
        if (!required.matches(result, th)) {
          val role = new RoleDiagnostic(RoleDiagnostic.FUNCTION_RESULT, "", 0)
          result = th.applyFunctionConversionRules(result.materialize, required, role, Loc.NONE)
        }
      }
      val se = result.iterate.materialize
      XdmValue.wrap(se)
    } catch {
      case e: XPathException =>
        throw new SaxonApiException(e)
    }
  }
}