////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.event.Outputter
import net.sf.saxon.expr.instruct.UserFunction
import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.model.ItemType
import net.sf.saxon.om._
import net.sf.saxon.trans.XPathException

/**
 * A TailCallLoop wraps the body of a function that contains tail-recursive function calls. On completion
 * of the "real" body of the function it tests whether the function has executed a tail call, and if so,
 * iterates to evaluate the tail call.
 */
object TailCallLoop {

  trait TailCallInfo {}

  protected class TailCallComponent extends TailCallLoop.TailCallInfo {
    var component = null
    var function = null
  }

  protected class TailCallFunction extends TailCallLoop.TailCallInfo {
    var function = null
  }

}

final class TailCallLoop(var containingFunction: UserFunction, val body: Expression)

/**
 * Constructor - create a TailCallLoop
 *
 * @param function the function in which this tail call loop appears
 * @param body     the function body (before wrapping in the tail call loop)
 */
  extends UnaryExpression(body) {
  /**
   * Get the containing function
   *
   * @return the containing function
   */
  def getContainingFunction = containingFunction

  /**
   * Type-check the expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = {
    getOperand.typeCheck(visitor, contextInfo)
    this
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided. This implementation provides both iterate() and
   * process() methods natively.
   */
  override def getImplementationMethod = getBaseExpression.getImplementationMethod

  override protected def getOperandRole = OperandRole.SAME_FOCUS_ACTION

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings Variables whose binding needs to change
   */
  override def copy(rebindings: RebindingMap) = {
    throw new UnsupportedOperationException("TailCallLoop.copy()")
    /*TailCallLoop e2 = new TailCallLoop(containingFunction);
            e2.setBaseExpression(getBaseExpression().copy());
            return e2;*/
  }

  /**
   * Iterate over the sequence of values
   */
  @throws[XPathException]
  override def iterate(context: XPathContext): SequenceIterator = {
    val cm = context.asInstanceOf[XPathContextMajor]
    while ( {
      true
    }) {
      val iter = getBaseExpression.iterate(cm)
      val extent = iter.materialize
      val tail = cm.getTailCallInfo
      if (tail == null) return extent.iterate
      else {
        val target = establishTargetFunction(tail, cm)
        if (target ne containingFunction) return tailCallDifferentFunction(target, cm).iterate
        // otherwise, loop round to execute the tail call
      }
    }
  }

  /**
   * Evaluate as an Item.
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext): Item = {
    val cm = context.asInstanceOf[XPathContextMajor]
    while ( {
      true
    }) {
      val item = getBaseExpression.evaluateItem(context)
      val tail = cm.getTailCallInfo
      if (tail == null) return item
      else {
        val target = establishTargetFunction(tail, cm)
        if (target ne containingFunction) return tailCallDifferentFunction(target, cm).head
      }
    }
  }

  private def establishTargetFunction(tail: TailCallLoop.TailCallInfo, cm: XPathContextMajor) = if (tail.isInstanceOf[TailCallLoop.TailCallFunction]) tail.asInstanceOf[TailCallLoop.TailCallFunction].function
  else if (tail.isInstanceOf[TailCallLoop.TailCallComponent]) {
    val targetComponent = tail.asInstanceOf[TailCallLoop.TailCallComponent].component
    cm.setCurrentComponent(targetComponent)
    targetComponent.getActor.asInstanceOf[UserFunction]
  }
  else throw new AssertionError

  /**
   * Process the function body
   *
   * @param output  the destination for the result
   * @param context The dynamic context, giving access to the current node,
   */
  @throws[XPathException]
  override def process(output: Outputter, context: XPathContext): Unit = {
    val cm = context.asInstanceOf[XPathContextMajor]
    val operand = getBaseExpression
    while ( {
      true
    }) {
      operand.process(output, context)
      val tail = cm.getTailCallInfo
      if (tail == null) return
      else {
        val target = establishTargetFunction(tail, cm)
        if (target ne containingFunction) {
          SequenceTool.process(tailCallDifferentFunction(target, cm), output, operand.getLocation)
          return
        }
      }
    }
  }

  /**
   * Make a tail call on a different function. This reuses the context object and the stack frame array
   * where possible, but it does consume some Java stack space. It's still worth it, because we don't use
   * as much stack as we would if we didn't return down to the TailCallLoop level.
   *
   * @param userFunction the function to be called
   * @param cm           the dynamic context
   * @return the result of calling the other function
   * @throws XPathException if the called function fails
   */
  /*@Nullable*/ @throws[XPathException]
  private def tailCallDifferentFunction(userFunction: UserFunction, cm: XPathContextMajor) = {
    cm.resetStackFrameMap(userFunction.getStackFrameMap, userFunction.getArity)
    try userFunction.getEvaluator.evaluate(userFunction.getBody, cm)
    catch {
      case err: XPathException =>
        err.maybeSetLocation(getLocation)
        err.maybeSetContext(cm)
        throw err
    }
  }

  /**
   * Determine the data type of the items returned by the expression
   */
  override def getItemType = getBaseExpression.getItemType

  /**
   * Give a string representation of the expression name for use in diagnostics
   *
   * @return the expression name, as a string
   */
  override def getExpressionName = "tailCallLoop"
}