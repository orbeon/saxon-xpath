////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.om.NodeName
import net.sf.saxon.s9api.Location
import net.sf.saxon.serialize.codenorm.Normalizer
import net.sf.saxon.trans.UncheckedXPathException
import net.sf.saxon.trans.XPathException
import java.util

/**
 * This class performs URI escaping for the XHTML output method. The logic for performing escaping
 * is the same as the HTML output method, but the way in which attributes are identified for escaping
 * is different, because XHTML is case-sensitive.
 */
object XHTMLURIEscaper {
  /**
   * Table of attributes whose value is a URL
   */
    private val urlTable = new util.HashSet[String](70)
  private val attTable = new util.HashSet[String](20)

  private def setUrlAttribute(element: String, attribute: String) = {
    attTable.add(attribute)
    urlTable.add(element + "+" + attribute)
  }

  /**
   * Determine whether a given attribute is a URL attribute
   */
  private def isURLAttribute(elcode: NodeName, atcode: NodeName): Boolean = {
    if (!elcode.hasURI(NamespaceConstant.XHTML)) return false
    if (!atcode.hasURI("")) return false
    val attName = atcode.getLocalPart
    attTable.contains(attName) && urlTable.contains(elcode.getLocalPart + "+" + attName)
  }

  private def isAllAscii(/*@NotNull*/ value: CharSequence): Boolean = {
    for (i <- 0 until value.length) {
      if (value.charAt(i) > 127) return false
    }
    true
  }

  try setUrlAttribute("form", "action")
  setUrlAttribute("object", "archive")
  setUrlAttribute("body", "background")
  setUrlAttribute("q", "cite")
  setUrlAttribute("blockquote", "cite")
  setUrlAttribute("del", "cite")
  setUrlAttribute("ins", "cite")
  setUrlAttribute("object", "classid")
  setUrlAttribute("object", "codebase")
  setUrlAttribute("applet", "codebase")
  setUrlAttribute("object", "data")
  setUrlAttribute("button", "datasrc")
  setUrlAttribute("div", "datasrc")
  setUrlAttribute("input", "datasrc")
  setUrlAttribute("object", "datasrc")
  setUrlAttribute("select", "datasrc")
  setUrlAttribute("span", "datasrc")
  setUrlAttribute("table", "datasrc")
  setUrlAttribute("textarea", "datasrc")
  setUrlAttribute("script", "for")
  setUrlAttribute("a", "href")
  setUrlAttribute("a", "name") // see second note in section B.2.1 of HTML 4 specification
  setUrlAttribute("area", "href")
  setUrlAttribute("link", "href")
  setUrlAttribute("base", "href")
  setUrlAttribute("img", "longdesc")
  setUrlAttribute("frame", "longdesc")
  setUrlAttribute("iframe", "longdesc")
  setUrlAttribute("head", "profile")
  setUrlAttribute("script", "src")
  setUrlAttribute("input", "src")
  setUrlAttribute("frame", "src")
  setUrlAttribute("iframe", "src")
  setUrlAttribute("img", "src")
  setUrlAttribute("img", "usemap")
  setUrlAttribute("input", "usemap")
  setUrlAttribute("object", "usemap")
}

class XHTMLURIEscaper(val next: Receiver) extends HTMLURIEscaper(next) {
  /**
   * Notify the start of an element
   *
   * @param nameCode
   * @param type
   * @param attributes
   * @param namespaces
   * @param location
   * @param properties
   */
  @throws[XPathException]
  override def startElement(nameCode: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    currentElement = nameCode
    var atts2 = attributes
    if (escapeURIAttributes) try atts2 = attributes.apply((att: AttributeInfo) => {
      def foo(att: AttributeInfo) =
        if (!ReceiverOption.contains(att.getProperties, ReceiverOption.DISABLE_ESCAPING)) {
          val attName = att.getNodeName
          if (isUrlAttribute(nameCode, attName)) {
            val value = att.getValue
            try {
              val normalized = if (XHTMLURIEscaper.isAllAscii(value)) value
              else Normalizer.make(Normalizer.C, getConfiguration).normalize(value)
              new AttributeInfo(attName, att.getType, escapeURL(normalized, true, getConfiguration).toString, att.getLocation, att.getProperties | ReceiverOption.DISABLE_CHARACTER_MAPS)
            } catch {
              case e: XPathException =>
                throw new UncheckedXPathException(e)
            }
          }
          else att
        }
        else att

      foo(att)
    })
    catch {
      case e: UncheckedXPathException =>
        throw e.getXPathException
    }
    nextReceiver.startElement(nameCode, `type`, atts2, namespaces, location, properties)
  }
}