////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.pull

import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.event.SequenceReceiver
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.model.Type
import net.sf.saxon.om.NamespaceBinding
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.Orphan
import java.util

/**
 * PullPushTee is a pass-through filter class that links one PullProvider to another PullProvider
 * in a pipeline, copying all events that are read into a push pipeline, supplied in the form
 * of a Receiver.
 * <p>This class can be used to insert a schema validator into a pull pipeline, since Saxon's schema
 * validation is push-based. It could also be used to insert a serializer into the pipeline, allowing
 * the XML document being "pulled" to be displayed for diagnostic purposes.</p>
 */
class PullPushTee(/*@NotNull*/ val base: PullProvider, var branch: Receiver)

/**
 * Create a PullPushTee
 *
 * @param base   the PullProvider to which requests are to be passed
 * @param branch the Receiver to which all events are to be copied, as "push" events.
 *               This Receiver must already be open before use
 */
  extends PullFilter(base) {
  private[pull] var previousAtomic = false
  private val nsStack = new util.Stack[NamespaceMap]

  /**
   * Get the Receiver to which events are being tee'd.
   *
   * @return the Receiver
   */
  def getReceiver = branch

  /**
   * Get the next event. This implementation gets the next event from the underlying PullProvider,
   * copies it to the branch Receiver, and then returns the event to the caller.
   *
   * @return an integer code indicating the type of event. The code
   *         { @link net.sf.saxon.pull.PullProvider.Event#END_OF_INPUT} is returned at the end of the sequence.
   */
  @throws[XPathException]
  override def next = {
    currentEvent = super.next
    copyEvent(currentEvent)
    currentEvent
  }

  /**
   * Copy a pull event to a Receiver
   *
   * @param event the pull event to be copied
   */
  @throws[XPathException]
  private def copyEvent(event: PullProvider.Event) = {
    val in = getUnderlyingProvider
    var loc = in.getSourceLocator
    if (loc == null) loc = Loc.NONE
    val out = branch
    event match {
      case START_DOCUMENT =>
        out.startDocument(ReceiverOption.NONE)
      case START_ELEMENT =>
        val bindings = in.getNamespaceDeclarations
        var nsMap = if (nsStack.isEmpty) NamespaceMap.emptyMap
        else nsStack.peek
        for (binding <- bindings) {
          if (binding == null) break //todo: break is not supported
          nsMap = nsMap.put(binding.getPrefix, binding.getURI)
        }
        nsStack.push(nsMap)
        out.startElement(in.getNodeName, in.getSchemaType, in.getAttributes, nsMap, loc, ReceiverOption.NAMESPACE_OK)
      case TEXT =>
        out.characters(in.getStringValue, loc, ReceiverOption.WHOLE_TEXT_NODE)
      case COMMENT =>
        out.comment(in.getStringValue, loc, ReceiverOption.NONE)
      case PROCESSING_INSTRUCTION =>
        out.processingInstruction(in.getNodeName.getLocalPart, in.getStringValue, loc, ReceiverOption.NONE)
      case END_ELEMENT =>
        out.endElement()
        nsStack.pop
      case END_DOCUMENT =>
        val entities = in.getUnparsedEntities
        if (entities != null) {
          import scala.collection.JavaConversions._
          for (entity <- entities) {
            val ue = entity.asInstanceOf[UnparsedEntity]
            out.setUnparsedEntity(ue.getName, ue.getSystemId, ue.getPublicId)
          }
        }
        out.endDocument()
      case END_OF_INPUT =>
        in.close()
      case ATOMIC_VALUE =>
        if (out.isInstanceOf[SequenceReceiver]) out.append(super.getAtomicValue, loc, ReceiverOption.NONE)
        else {
          if (previousAtomic) out.characters(" ", loc, ReceiverOption.NONE)
          val chars = in.getStringValue
          out.characters(chars, loc, ReceiverOption.NONE)
        }
      case ATTRIBUTE =>
        if (out.isInstanceOf[SequenceReceiver]) {
          val o = new Orphan(in.getPipelineConfiguration.getConfiguration)
          o.setNodeName(getNodeName)
          o.setNodeKind(Type.ATTRIBUTE)
          o.setStringValue(getStringValue)
          out.append(o, loc, ReceiverOption.NONE)
        }
      case NAMESPACE =>
        if (out.isInstanceOf[SequenceReceiver]) {
          val o = new Orphan(in.getPipelineConfiguration.getConfiguration)
          o.setNodeName(getNodeName)
          o.setNodeKind(Type.NAMESPACE)
          o.setStringValue(getStringValue)
          out.append(o, loc, ReceiverOption.NONE)
        }
      case _ =>
        throw new UnsupportedOperationException("" + event)
    }
    previousAtomic = event eq Event.ATOMIC_VALUE
  }
}