////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.model.{PrimitiveUType, Type, UType}
import net.sf.saxon.trans.XPathException
import net.sf.saxon.z.IntHashMap

/**
 * An axis, that is a direction of navigation in the document structure.
 */
object AxisInfo {
  /**
   * Constant representing the ancestor axis
   */
    val ANCESTOR = 0
  /**
   * Constant representing the ancestor-or-self axis
   */
  val ANCESTOR_OR_SELF = 1
  /**
   * Constant representing the attribute axis
   */
  val ATTRIBUTE = 2
  /**
   * Constant representing the child axis
   */
  val CHILD = 3
  /**
   * Constant representing the descendant axis
   */
  val DESCENDANT = 4
  /**
   * Constant representing the descendant-or-self axis
   */
  val DESCENDANT_OR_SELF = 5
  /**
   * Constant representing the following axis
   */
  val FOLLOWING = 6
  /**
   * Constant representing the following-sibling axis
   */
  val FOLLOWING_SIBLING = 7
  /**
   * Constant representing the namespace axis
   */
  val NAMESPACE = 8
  /**
   * Constant representing the parent axis
   */
  val PARENT = 9
  /**
   * Constant representing the preceding axis
   */
  val PRECEDING = 10
  /**
   * Constant representing the preceding-sibling axis
   */
  val PRECEDING_SIBLING = 11
  /**
   * Constant representing the self axis
   */
  val SELF = 12
  /**
   * Constant representing the preceding-or-ancestor axis. This axis is used internally by the xsl:number implementation, it returns the union of the preceding axis and the ancestor axis.
   */
  val PRECEDING_OR_ANCESTOR = 13
  /**
   * Table indicating the principal node type of each axis
   */
  val principalNodeType = Array(Type.ELEMENT, // ANCESTOR
    Type.ELEMENT, // ANCESTOR_OR_SELF;
    Type.ATTRIBUTE, // ATTRIBUTE;
    Type.ELEMENT, // CHILD;
    Type.ELEMENT, // DESCENDANT;
    Type.ELEMENT, // DESCENDANT_OR_SELF;
    Type.ELEMENT, // FOLLOWING;
    Type.ELEMENT, // FOLLOWING_SIBLING;
    Type.NAMESPACE, // NAMESPACE;
    Type.ELEMENT, // PARENT;
    Type.ELEMENT, // PRECEDING;
    Type.ELEMENT, // PRECEDING_SIBLING;
    Type.ELEMENT, // SELF;
    Type.ELEMENT) // PRECEDING_OR_ANCESTOR;
  val principalNodeUType = Array(UType.ELEMENT, UType.ELEMENT, UType.ATTRIBUTE, UType.ELEMENT, UType.ELEMENT, UType.ELEMENT, UType.ELEMENT, UType.ELEMENT, UType.NAMESPACE, UType.ELEMENT, UType.ELEMENT, UType.ELEMENT, UType.ELEMENT, UType.ELEMENT)
  /**
   * Table indicating for each axis whether it is in forwards document order
   */
  val isForwards = Array(false, false, true, true, true, true, true, true, true, true, false, false, true, false)
  /**
   * Table indicating for each axis whether it is a peer axis. An axis is a peer
   * axis if no node on the axis is an ancestor of another node on the axis.
   */
  val isPeerAxis = Array(false, false, true, true, false, false, false, true, true, true, false, true, true, false)
  /**
   * Table indicating for each axis whether it is contained within the subtree
   * rooted at the origin node.
   */
  val isSubtreeAxis = Array(false, false, true, true, true, true, false, false, true, false, false, false, true, false)
  /**
   * Table giving the name of each axis as used in XPath, for example "ancestor-or-self"
   */
  val axisName = Array("ancestor", "ancestor-or-self", "attribute", "child", "descendant", "descendant-or-self", "following", "following-sibling", "namespace", "parent", "preceding", "preceding-sibling", "self", "preceding-or-ancestor")

  /**
   * Resolve an axis name into a symbolic constant representing the axis
   *
   * @param name the name of the axis
   * @return integer value representing the named axis
   * @throws XPathException if the axis name is not one of the defined axes
   */
  @throws[XPathException]
  def getAxisNumber(name: String) = name match {
    case "ancestor" =>
      ANCESTOR
    case "ancestor-or-self" =>
      ANCESTOR_OR_SELF
    case "attribute" =>
      ATTRIBUTE
    case "child" =>
      CHILD
    case "descendant" =>
      DESCENDANT
    case "descendant-or-self" =>
      DESCENDANT_OR_SELF
    case "following" =>
      FOLLOWING
    case "following-sibling" =>
      FOLLOWING_SIBLING
    case "namespace" =>
      NAMESPACE
    case "parent" =>
      PARENT
    case "preceding" =>
      PRECEDING
    case "preceding-sibling" =>
      PRECEDING_SIBLING
    case "self" =>
      SELF
    case "preceding-or-ancestor" =>
      PRECEDING_OR_ANCESTOR
    // preceding-or-ancestor cannot be used in an XPath expression
    case _ =>
      throw new XPathException("Unknown axis name: " + name)
  }

  /**
   * The following table indicates the combinations of axis and origin node-kind that always
   * return an empty result.
   */
  private val DOC = 1 << Type.DOCUMENT
  private val ELE = 1 << Type.ELEMENT
  private val ATT = 1 << Type.ATTRIBUTE
  private val TEX = 1 << Type.TEXT
  private val PIN = 1 << Type.PROCESSING_INSTRUCTION
  private val COM = 1 << Type.COMMENT
  private val NAM = 1 << Type.NAMESPACE
  private val voidAxisTable = Array(DOC, 0, DOC | ATT | TEX | PIN | COM | NAM, ATT | TEX | PIN | COM | NAM, ATT | TEX | PIN | COM | NAM, 0, DOC, DOC | ATT | NAM, DOC | ATT | TEX | PIN | COM | NAM, DOC, DOC, DOC | ATT | NAM, 0)

  /**
   * Ask whether a given axis can contain any nodes when starting at the specified node kind.
   * For example, the attribute axis when starting at an attribute node will always be empty
   *
   * @param axis the axis, for example { @link AxisInfo#ATTRIBUTE}
   * @param nodeKind the node kind of the origin node, for example { @link Type#ATTRIBUTE}
   * @return true if no nodes will ever appear on the specified axis when starting at the specified
   *         node kind.
   */
  def isAlwaysEmpty(axis: Int, nodeKind: Int) = (voidAxisTable(axis) & (1 << nodeKind)) != 0

  /**
   * The following table indicates the kinds of node found on each axis
   */
  private val nodeKindTable = Array(DOC | ELE, DOC | ELE | ATT | TEX | PIN | COM | NAM, ATT, ELE | TEX | PIN | COM, ELE | TEX | PIN | COM, DOC | ELE | ATT | TEX | PIN | COM | NAM, ELE | TEX | PIN | COM, ELE | TEX | PIN | COM, NAM, DOC | ELE, ELE | TEX | PIN | COM, ELE | TEX | PIN | COM, DOC | ELE | ATT | TEX | PIN | COM | NAM)

  /**
   * Determine whether a given kind of node can be found on a given axis. For example,
   * the attribute axis will never contain any element nodes.
   *
   * @param axis the axis, for example { @link AxisInfo#ATTRIBUTE}
   * @param nodeKind the node kind of the origin node, for example { @link Type#ELEMENT}
   * @return true if the given kind of node can appear on the specified axis
   */
  def containsNodeKind(axis: Int, nodeKind: Int) = nodeKind == Type.NODE || (nodeKindTable(axis) & (1 << nodeKind)) != 0

  /**
   * For each axis, determine the inverse axis, in the sense that if A is on axis X starting at B,
   * the B is on the axis inverseAxis[X] starting at A. This doesn't quite work for the PARENT axis,
   * which has no simple inverse: this table gives the inverse as CHILD
   */
  var inverseAxis = Array(DESCENDANT, //        ANCESTOR
    DESCENDANT_OR_SELF, //        ANCESTOR_OR_SELF;
    PARENT, //        ATTRIBUTE;
    PARENT, //        CHILD;
    ANCESTOR, //        DESCENDANT;
    ANCESTOR_OR_SELF, //        DESCENDANT_OR_SELF;
    PRECEDING, //        FOLLOWING;
    PRECEDING_SIBLING, //        FOLLOWING_SIBLING;
    PARENT, //        NAMESPACE;
    CHILD, //        PARENT;
    FOLLOWING, //        PRECEDING;
    FOLLOWING_SIBLING, //        PRECEDING_SIBLING;
    SELF //        SELF;
   )
  /**
   * Give the corresponding axis if the self node is excluded. (Doesn't really
   * work for the self axis itself).
   */
  var excludeSelfAxis = Array(ANCESTOR, ANCESTOR, ATTRIBUTE, CHILD, DESCENDANT, DESCENDANT, FOLLOWING, FOLLOWING_SIBLING, NAMESPACE, PARENT, PRECEDING, PRECEDING_SIBLING, SELF)
  private val axisTransitions = new IntHashMap[UType](50)

  private def e(origin: PrimitiveUType, axis: Int, target: UType) = axisTransitions.put(makeKey(origin, axis), target)

  private def makeKey(origin: PrimitiveUType, axis: Int) = origin.getBit << 16 | axis

  /**
   * Given a context item type and an axis, determine the kinds of nodes that can be returned
   *
   * @param origin the context item type, as a UType representing one or more node kinds
   * @param axis   identifies the axis
   * @return the set of possible node kinds in the result of the axis expression, as a UType
   */
  def getTargetUType(origin: UType, axis: Int) = {
    var resultType = UType.VOID
    val origins = origin.intersection(UType.ANY_NODE).decompose
    import scala.collection.JavaConversions._
    for (u <- origins) {
      val r = axisTransitions.get(makeKey(u, axis))
      if (r == null) System.err.println("Unknown transitions for primitive type " + u.toString + "::" + axis)
      resultType = resultType.union(r)
    }
    resultType
  }

  try // Declare as triples the relationships that can exist between nodes. The first argument is the type
    // of the origin node; the second is the axis; the third is the set of node kinds that can be found
    // using this axis, when starting from this origin.
    e(PrimitiveUType.DOCUMENT, ANCESTOR, UType.VOID)
  e(PrimitiveUType.DOCUMENT, ANCESTOR_OR_SELF, UType.DOCUMENT)
  e(PrimitiveUType.DOCUMENT, ATTRIBUTE, UType.VOID)
  e(PrimitiveUType.DOCUMENT, CHILD, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.DOCUMENT, DESCENDANT, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.DOCUMENT, DESCENDANT_OR_SELF, UType.DOCUMENT.union(UType.CHILD_NODE_KINDS))
  e(PrimitiveUType.DOCUMENT, FOLLOWING, UType.VOID)
  e(PrimitiveUType.DOCUMENT, FOLLOWING_SIBLING, UType.VOID)
  e(PrimitiveUType.DOCUMENT, NAMESPACE, UType.VOID)
  e(PrimitiveUType.DOCUMENT, PARENT, UType.VOID)
  e(PrimitiveUType.DOCUMENT, PRECEDING, UType.VOID)
  e(PrimitiveUType.DOCUMENT, PRECEDING_SIBLING, UType.VOID)
  e(PrimitiveUType.DOCUMENT, SELF, UType.DOCUMENT)
  e(PrimitiveUType.ELEMENT, ANCESTOR, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, ANCESTOR_OR_SELF, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, ATTRIBUTE, UType.ATTRIBUTE)
  e(PrimitiveUType.ELEMENT, CHILD, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, DESCENDANT, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, DESCENDANT_OR_SELF, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, FOLLOWING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, FOLLOWING_SIBLING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, NAMESPACE, UType.NAMESPACE)
  e(PrimitiveUType.ELEMENT, PARENT, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, PRECEDING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, PRECEDING_SIBLING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ELEMENT, SELF, UType.ELEMENT)
  e(PrimitiveUType.ATTRIBUTE, ANCESTOR, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.ATTRIBUTE, ANCESTOR_OR_SELF, UType.ATTRIBUTE.union(UType.PARENT_NODE_KINDS))
  e(PrimitiveUType.ATTRIBUTE, ATTRIBUTE, UType.VOID)
  e(PrimitiveUType.ATTRIBUTE, CHILD, UType.VOID)
  e(PrimitiveUType.ATTRIBUTE, DESCENDANT, UType.VOID)
  e(PrimitiveUType.ATTRIBUTE, DESCENDANT_OR_SELF, UType.ATTRIBUTE)
  e(PrimitiveUType.ATTRIBUTE, FOLLOWING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ATTRIBUTE, FOLLOWING_SIBLING, UType.VOID)
  e(PrimitiveUType.ATTRIBUTE, NAMESPACE, UType.VOID)
  e(PrimitiveUType.ATTRIBUTE, PARENT, UType.ELEMENT)
  e(PrimitiveUType.ATTRIBUTE, PRECEDING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.ATTRIBUTE, PRECEDING_SIBLING, UType.VOID)
  e(PrimitiveUType.ATTRIBUTE, SELF, UType.ATTRIBUTE)
  e(PrimitiveUType.TEXT, ANCESTOR, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.TEXT, ANCESTOR_OR_SELF, UType.TEXT.union(UType.PARENT_NODE_KINDS))
  e(PrimitiveUType.TEXT, ATTRIBUTE, UType.VOID)
  e(PrimitiveUType.TEXT, CHILD, UType.VOID)
  e(PrimitiveUType.TEXT, DESCENDANT, UType.VOID)
  e(PrimitiveUType.TEXT, DESCENDANT_OR_SELF, UType.TEXT)
  e(PrimitiveUType.TEXT, FOLLOWING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.TEXT, FOLLOWING_SIBLING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.TEXT, NAMESPACE, UType.VOID)
  e(PrimitiveUType.TEXT, PARENT, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.TEXT, PRECEDING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.TEXT, PRECEDING_SIBLING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.TEXT, SELF, UType.TEXT)
  e(PrimitiveUType.PI, ANCESTOR, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.PI, ANCESTOR_OR_SELF, UType.PI.union(UType.PARENT_NODE_KINDS))
  e(PrimitiveUType.PI, ATTRIBUTE, UType.VOID)
  e(PrimitiveUType.PI, CHILD, UType.VOID)
  e(PrimitiveUType.PI, DESCENDANT, UType.VOID)
  e(PrimitiveUType.PI, DESCENDANT_OR_SELF, UType.PI)
  e(PrimitiveUType.PI, FOLLOWING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.PI, FOLLOWING_SIBLING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.PI, NAMESPACE, UType.VOID)
  e(PrimitiveUType.PI, PARENT, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.PI, PRECEDING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.PI, PRECEDING_SIBLING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.PI, SELF, UType.PI)
  e(PrimitiveUType.COMMENT, ANCESTOR, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.COMMENT, ANCESTOR_OR_SELF, UType.COMMENT.union(UType.PARENT_NODE_KINDS))
  e(PrimitiveUType.COMMENT, ATTRIBUTE, UType.VOID)
  e(PrimitiveUType.COMMENT, CHILD, UType.VOID)
  e(PrimitiveUType.COMMENT, DESCENDANT, UType.VOID)
  e(PrimitiveUType.COMMENT, DESCENDANT_OR_SELF, UType.COMMENT)
  e(PrimitiveUType.COMMENT, FOLLOWING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.COMMENT, FOLLOWING_SIBLING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.COMMENT, NAMESPACE, UType.VOID)
  e(PrimitiveUType.COMMENT, PARENT, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.COMMENT, PRECEDING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.COMMENT, PRECEDING_SIBLING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.COMMENT, SELF, UType.COMMENT)
  e(PrimitiveUType.NAMESPACE, ANCESTOR, UType.PARENT_NODE_KINDS)
  e(PrimitiveUType.NAMESPACE, ANCESTOR_OR_SELF, UType.NAMESPACE.union(UType.PARENT_NODE_KINDS))
  e(PrimitiveUType.NAMESPACE, ATTRIBUTE, UType.VOID)
  e(PrimitiveUType.NAMESPACE, CHILD, UType.VOID)
  e(PrimitiveUType.NAMESPACE, DESCENDANT, UType.VOID)
  e(PrimitiveUType.NAMESPACE, DESCENDANT_OR_SELF, UType.NAMESPACE)
  e(PrimitiveUType.NAMESPACE, FOLLOWING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.NAMESPACE, FOLLOWING_SIBLING, UType.VOID)
  e(PrimitiveUType.NAMESPACE, NAMESPACE, UType.VOID)
  e(PrimitiveUType.NAMESPACE, PARENT, UType.ELEMENT)
  e(PrimitiveUType.NAMESPACE, PRECEDING, UType.CHILD_NODE_KINDS)
  e(PrimitiveUType.NAMESPACE, PRECEDING_SIBLING, UType.VOID)
  e(PrimitiveUType.NAMESPACE, SELF, UType.NAMESPACE)
}


/**
 * The class is never instantiated
 */
final class AxisInfo private(){
}

/*
    // a list for any future cut-and-pasting...
    ANCESTOR
    ANCESTOR_OR_SELF;
    ATTRIBUTE;
    CHILD;
    DESCENDANT;
    DESCENDANT_OR_SELF;
    FOLLOWING;
    FOLLOWING_SIBLING;
    NAMESPACE;
    PARENT;
    PRECEDING;
    PRECEDING_SIBLING;
    SELF;
*/