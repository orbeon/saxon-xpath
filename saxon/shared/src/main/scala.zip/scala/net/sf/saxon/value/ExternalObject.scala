////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.model.ItemType
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.om.Item

/**
 * An item that wraps an external (Java or .NET) object
 *
 * @param < T> the static class of the wrapped object
 */
trait ExternalObject[T] extends Item {
  /**
   * Get the wrapped object
   *
   * @return the wrapped object. This will never be null.
   */
    def getObject

  /**
   * Get the item type of the object
   *
   * @return the item type
   */
  def getItemType(th: TypeHierarchy)
}