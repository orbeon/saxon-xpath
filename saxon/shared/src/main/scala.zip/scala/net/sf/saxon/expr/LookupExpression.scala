////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser._
import net.sf.saxon.ma.arrays.ArrayFunctionSet
import net.sf.saxon.ma.arrays.ArrayItem
import net.sf.saxon.ma.arrays.ArrayItemType
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.ma.map.MapType
import net.sf.saxon.ma.map.TupleItemType
import net.sf.saxon.ma.map.TupleType
import net.sf.saxon.model._
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.Item
import net.sf.saxon.om.NameChecker
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.value._

/**
 * A lookup expression is an expression of the form A?B. Here A must be a sequence of maps or arrays.
 * In the general case B is an expression that computes a key/index into the map or array; the case where
 * B is constant needs to be handled efficiently. The class also implements the unary lookup expression
 * ?B, which is interpreted as .?B. It does not handle the case A?* - that is handled as a LookupAllExpression.
 */
object LookupExpression {
  @throws[XPathException]
  protected def mustBeArrayOrMap(exp: Expression, baseItem: Item) = {
    val exception = new XPathException("The items on the LHS of the '?' operator must be maps or arrays; but value (" + baseItem.toShortString + ") was supplied", "XPTY0004")
    exception.setIsTypeError(true)
    exception.setLocation(exp.getLocation)
    exception.setFailingExpression(exp)
    throw exception
  }
}

class LookupExpression(val start: Expression, val step: Expression)

/**
 * Constructor
 *
 * @param start The left hand operand (which must always select a sequence of maps or arrays).
 * @param step  The step to be followed from each map/array in the start expression to yield a new
 *              sequence
 */
  extends BinaryExpression(start, Token.QMARK, step) {
  private var isClassified = false
  protected var isArrayLookup = false
  protected var isMapLookup = false
  protected var isSingleContainer = false
  protected var isSingleEntry = false

  override protected def getOperandRole(arg: Int) = if (arg == 0) OperandRole.INSPECT
  else OperandRole.ABSORB

  override def getExpressionName = "lookupExp"

  /**
   * Determine the data type of the items returned by this expression
   *
   * @return the type of the expression, as far as this is known. Prior to type-checking,
   *         the method returns { @link AnyItemType}
   */
  /*@NotNull*/ override def getItemType: ItemType = {
    if (isClassified) if (isArrayLookup) {
      val arrayType = getLhsExpression.getItemType
      if (arrayType.isInstanceOf[ArrayItemType]) return arrayType.asInstanceOf[ArrayItemType].getMemberType.getPrimaryType
    }
    else if (isMapLookup) {
      val mapType = getLhsExpression.getItemType
      if (mapType.isInstanceOf[TupleItemType] && getRhsExpression.isInstanceOf[StringLiteral]) {
        val fieldName = getRhsExpression.asInstanceOf[StringLiteral].getStringValue
        val fieldType = mapType.asInstanceOf[TupleItemType].getFieldType(fieldName)
        if (fieldType == null) return if (mapType.asInstanceOf[TupleItemType].isExtensible) AnyItemType.getInstance
        else ErrorType.getInstance
        else return fieldType.getPrimaryType
      }
      else if (mapType.isInstanceOf[MapType]) return mapType.asInstanceOf[MapType].getValueType.getPrimaryType
    }
    AnyItemType.getInstance
  }

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @param contextItemType not used
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   */
  override def getStaticUType(contextItemType: UType) = getItemType.getUType

  /**
   * Type-check the expression
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    // Running typeCheck on the first operand can lose static type information if it's declared
    // with a tuple type. So check this first.
    val originalType = getLhsExpression.getItemType
    // Check the first operand
    getLhs.typeCheck(visitor, contextInfo)
    val containerType = getLhsExpression.getItemType
    isArrayLookup = containerType.isInstanceOf[ArrayItemType]
    val isTupleLookup = containerType.isInstanceOf[TupleType] || originalType.isInstanceOf[TupleType]
    isMapLookup = containerType.isInstanceOf[MapType] || isTupleLookup
    if (containerType.isInstanceOf[AnyExternalObjectType]) {
      config.checkLicensedFeature(Configuration.LicenseFeature.PROFESSIONAL_EDITION, "use of lookup expressions on external objects", -1)
      return config.makeObjectLookupExpression(getLhsExpression, getRhsExpression).typeCheck(visitor, contextInfo)
    }
    isSingleContainer = getLhsExpression.getCardinality == StaticProperty.EXACTLY_ONE
    if (!isArrayLookup && !isMapLookup) if ((th.relationship(containerType, MapType.ANY_MAP_TYPE) eq Affinity.DISJOINT) && (th.relationship(containerType, ArrayItemType.getInstance) eq Affinity.DISJOINT) && (th.relationship(containerType, AnyExternalObjectType.THE_INSTANCE) eq Affinity.DISJOINT)) {
      val err = new XPathException("The left-hand operand of '?' must be a map or an array; the supplied expression is of type " + containerType, "XPTY0004")
      err.setLocation(getLocation)
      err.setIsTypeError(true)
      err.setFailingExpression(this)
      throw err
    }
    // Now check the second operand
    getRhs.typeCheck(visitor, contextInfo)
    val role = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, "?", 1)
    val tc = config.getTypeChecker(false)
    var req = BuiltInAtomicType.ANY_ATOMIC.zeroOrMore
    if (isArrayLookup) req = BuiltInAtomicType.INTEGER.zeroOrMore
    setRhsExpression(tc.staticTypeCheck(getRhsExpression, req, role, visitor))
    isSingleEntry = getRhsExpression.getCardinality == StaticProperty.EXACTLY_ONE
    if (isTupleLookup && getRhsExpression.isInstanceOf[StringLiteral]) {
      val tt = (if (containerType.isInstanceOf[TupleType]) containerType
      else originalType).asInstanceOf[TupleType]
      if (!tt.isExtensible) {
        val fieldName = getRhsExpression.asInstanceOf[StringLiteral].getStringValue
        if (tt.getFieldType(fieldName) == null) {
          val err = new XPathException("Field " + fieldName + " is not defined in the tuple type", "XPTY0004")
          err.setIsTypeError(true)
          err.setLocation(getLocation)
          throw err
        }
      }
    }
    isClassified = true
    this
  }

  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = {
    getLhs.optimize(visitor, contextInfo)
    getRhs.optimize(visitor, contextInfo)
    this
  }

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   *
   * @return a rough estimate of the cost of evaluation
   */
  override def getCost = getLhsExpression.getCost * getRhsExpression.getCost

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @param rebindings a mutable list of (old binding, new binding) pairs
   *                   that is used to update the bindings held in any
   *                   local variable references that are copied.
   * @return the copy of the original expression
   */
  override def copy(rebindings: RebindingMap) = {
    val exp = new LookupExpression(getLhsExpression.copy(rebindings), getRhsExpression.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, exp)
    exp.isArrayLookup = isArrayLookup
    exp.isMapLookup = isMapLookup
    exp.isSingleEntry = isSingleEntry
    exp.isSingleContainer = isSingleContainer
    exp
  }

  /**
   * Determine the static cardinality of the expression
   */
  override def computeCardinality: Int = {
    if (isSingleContainer && isSingleEntry) if (isArrayLookup) {
      val arrayType = getLhsExpression.getItemType
      if (arrayType.isInstanceOf[ArrayItemType]) return arrayType.asInstanceOf[ArrayItemType].getMemberType.getCardinality
    }
    else if (isMapLookup) {
      val mapType = getLhsExpression.getItemType
      if (mapType.isInstanceOf[TupleItemType] && getRhsExpression.isInstanceOf[StringLiteral]) {
        val fieldName = getRhsExpression.asInstanceOf[StringLiteral].getStringValue
        val fieldType = mapType.asInstanceOf[TupleItemType].getFieldType(fieldName)
        if (fieldType == null) return if (mapType.asInstanceOf[TupleItemType].isExtensible) StaticProperty.ALLOWS_ZERO_OR_MORE
        else StaticProperty.ALLOWS_ZERO
        else return fieldType.getCardinality
      }
      else if (mapType.isInstanceOf[MapType]) return Cardinality.union((mapType.asInstanceOf[MapType]).getValueType.getCardinality, StaticProperty.ALLOWS_ZERO)
    }
    StaticProperty.ALLOWS_ZERO_OR_MORE
  }

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any): Boolean = {
    if (!other.isInstanceOf[LookupExpression]) return false
    val p = other.asInstanceOf[LookupExpression]
    getLhsExpression.isEqual(p.getLhsExpression) && getRhsExpression.isEqual(p.getRhsExpression)
  }

  /**
   * get HashCode for comparing two expressions
   */
  override def computeHashCode = "LookupExpression".hashCode ^ getLhsExpression.hashCode ^ getRhsExpression.hashCode

  /**
   * Iterate the lookup-expression in a given context
   *
   * @param context the evaluation context
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = {
    val config = context.getConfiguration
    if (isArrayLookup) if (isSingleContainer && isSingleEntry) {
      val array = getLhsExpression.evaluateItem(context).asInstanceOf[ArrayItem]
      val subscript = getRhsExpression.evaluateItem(context).asInstanceOf[IntegerValue]
      val index = ArrayFunctionSet.checkSubscript(subscript, array.arrayLength)
      array.get(index - 1).iterate
    }
    else if (isSingleEntry) {
      val baseIterator = getLhsExpression.iterate(context)
      val subscriptValue = getRhsExpression.evaluateItem(context).asInstanceOf[IntegerValue]
      val subscript = subscriptValue.asSubscript - 1
      new MappingIterator(baseIterator, (baseItem: Item) => {
        def foo(baseItem: Item) = {
          val array = baseItem.asInstanceOf[ArrayItem]
          if (subscript >= 0 && subscript < array.arrayLength) return array.get(subscript).iterate
          else { // reuse the diagnostic logic
            ArrayFunctionSet.checkSubscript(subscriptValue, array.arrayLength)
            null // shouldn't happen
          }
        }

        foo(baseItem)
      })
    }
    else {
      val baseIterator = getLhsExpression.iterate(context)
      val rhs = getRhsExpression.iterate(context).materialize
      new MappingIterator(baseIterator, (baseItem: Item) => new MappingIterator(rhs.iterate, (index: Item) => {
        def foo(index: Item) = {
          val array = baseItem.asInstanceOf[ArrayItem]
          val subscript = ArrayFunctionSet.checkSubscript(index.asInstanceOf[IntegerValue], array.arrayLength) - 1
          array.get(subscript).iterate
        }

        foo(index)
      }))
    }
    else if (isMapLookup) if (isSingleContainer && isSingleEntry) {
      val map = getLhsExpression.evaluateItem(context).asInstanceOf[MapItem]
      val key = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
      val value = map.get(key)
      if (value == null) EmptyIterator.emptyIterator
      else value.iterate
    }
    else if (isSingleEntry) {
      val baseIterator = getLhsExpression.iterate(context)
      val key = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
      new MappingIterator(baseIterator, (baseItem: Item) => {
        def foo(baseItem: Item) = {
          val value = baseItem.asInstanceOf[MapItem].get(key)
          if (value == null) EmptyIterator.emptyIterator
          else value.iterate
        }

        foo(baseItem)
      })
    }
    else {
      val baseIterator = getLhsExpression.iterate(context)
      val rhs = getRhsExpression.iterate(context).materialize
      new MappingIterator(baseIterator, (baseItem: Item) => new MappingIterator(rhs.iterate, (index: Item) => {
        def foo(index: Item) = {
          val value = baseItem.asInstanceOf[MapItem].get(index.asInstanceOf[AtomicValue])
          if (value == null) EmptyIterator.emptyIterator
          else value.iterate
        }

        foo(index)
      }))
    }
    else {
      val baseIterator = getLhsExpression.iterate(context)
      val rhs = getRhsExpression.iterate(context).materialize
      val mappingFunction = (baseItem: Item) => {
        def foo(baseItem: Item) =
          if (baseItem.isInstanceOf[ArrayItem]) {
            val arrayAccess = (index: Item) => {
              def foo(index: Item) =
                if (index.isInstanceOf[IntegerValue]) {
                  val member = baseItem.asInstanceOf[ArrayItem].get(index.asInstanceOf[IntegerValue].longValue.toInt - 1)
                  member.iterate
                }
                else {
                  val exception = new XPathException("An item on the LHS of the '?' operator is an array, but a value on the RHS of the operator (" + baseItem.toShortString + ") is not an integer", "XPTY0004")
                  exception.setIsTypeError(true)
                  exception.setLocation(getLocation)
                  exception.setFailingExpression(thisLookupExpression)
                  throw exception
                }

              foo(index)
            }
            val rhsIter = rhs.iterate
            new MappingIterator(rhsIter, arrayAccess)
          }
          else if (baseItem.isInstanceOf[MapItem]) {
            val rhsIter = rhs.iterate
            new MappingIterator(rhsIter, (key: Item) => {
              def foo(key: Item) = {
                val value = baseItem.asInstanceOf[MapItem].get(key.asInstanceOf[AtomicValue])
                if (value == null) EmptyIterator.emptyIterator
                else value.iterate
              }

              foo(key)
            })
          }
          else if (baseItem.isInstanceOf[ObjectValue[_]]) {
            if (!rhs.isInstanceOf[StringValue]) {
              val exception = new XPathException("An item on the LHS of the '?' operator is an external object, but a value on the RHS of the operator (" + baseItem.toShortString + ") is not a singleton string", "XPTY0004")
              exception.setIsTypeError(true)
              exception.setLocation(getLocation)
              exception.setFailingExpression(thisLookupExpression)
              throw exception
            }
            val key = rhs.getStringValue
            config.externalObjectAsMap(baseItem.asInstanceOf[ObjectValue[_]], key).get(rhs.asInstanceOf[StringValue]).iterate
          }
          else {
            LookupExpression.mustBeArrayOrMap(this, baseItem)
            null
          }

        foo(baseItem)
      }
      new MappingIterator(baseIterator, mappingFunction)
    }
  }

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("lookup", this)
    getLhsExpression.`export`(destination)
    getRhsExpression.`export`(destination)
    destination.endElement
  }

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   *
   * @return a representation of the expression as a string
   */
  override def toString = {
    var rhs = null
    if (getRhsExpression.isInstanceOf[Literal]) {
      val lit = getRhsExpression.asInstanceOf[Literal]
      if (lit.isInstanceOf[StringLiteral] && NameChecker.isValidNCName(lit.asInstanceOf[StringLiteral].getStringValue)) rhs = lit.asInstanceOf[StringLiteral].getStringValue
      else if (lit.getValue.isInstanceOf[Int64Value]) rhs = lit.getValue.toString
      else rhs = ExpressionTool.parenthesize(lit)
    }
    else rhs = ExpressionTool.parenthesize(getRhsExpression)
    ExpressionTool.parenthesize(getLhsExpression) + "?" + rhs
  }
}