////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Controller
import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.XPathContext
import net.sf.saxon.expr.XPathContextMajor
import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.expr.parser._
import net.sf.saxon.functions.DocumentFn
import net.sf.saxon.functions.ElementAvailable
import net.sf.saxon.functions.FunctionLibraryList
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XmlProcessingException
import net.sf.saxon.trans.packages.UsePack
import net.sf.saxon.tree.AttributeLocation
import net.sf.saxon.tree.linked.DocumentImpl
import net.sf.saxon.tree.linked.LinkedTreeBuilder
import net.sf.saxon.value._
import javax.xml.transform.Source
import javax.xml.transform.TransformerException
import javax.xml.transform.URIResolver
import java.io.File
import java.math.BigDecimal
import java.net.URI
import java.net.URISyntaxException
import java.util

/**
 * This is a filter inserted into the input pipeline for processing stylesheet modules, whose
 * task is to evaluate use-when expressions and discard those parts of the stylesheet module
 * for which the use-when attribute evaluates to false.
 *
 * <p>Originally, with XSLT 2.0, this class did use-when filtering and very little else.
 * In XSLT 3.0 its role has expanded: it evaluates shadow attributes and static variables,
 * and collects information about package dependencies.</p>
 */
object UseWhenFilter {

  /**
   * Define a URIResolver that disallows all URIs
   */
  private class URIPreventer extends URIResolver {
    /**
     * Called by the processor when it encounters
     * an xsl:include, xsl:import, or document() function.
     *
     * @param href An href attribute, which may be relative or absolute.
     * @param base The base URI against which the first argument will be made
     *             absolute if the absolute URI is required.
     * @return A Source object, or null if the href cannot be resolved,
     *         and the processor should try to resolve the URI itself.
     * @throws XPathException if an error occurs when trying to
     *                        resolve the URI.
     */
      /*@NotNull*/ @throws[XPathException]
      override def resolve(href: String, base: String) = throw new XPathException("No external documents are available within an [xsl]use-when expression")
  }

}

class UseWhenFilter(var compilation: Compilation, val next: Receiver, var precedence: NestedIntegerValue)

/**
 * Create a UseWhenFilter
 *
 * @param compilation the compilation episode
 * @param next        the next receiver in the pipeline
 * @param precedence  the import precedence expressed as a dotted-decimal integer, e.g. 1.4.6
 */
  extends ProxyReceiver(next) {
  assert(emitter.isInstanceOf[LinkedTreeBuilder]) // Currently always true; but the design
  // tries to avoid assuming it will always be true
  treeBuilder = emitter.asInstanceOf[LinkedTreeBuilder]
  private var depthOfHole = 0
  private var emptyStylesheetElement = false
  private val defaultNamespaceStack = new util.Stack[String]
  private val versionStack = new util.Stack[Integer]
  private val currentDateTime = DateTimeValue.getCurrentDateTime(null)
  private val systemIdStack = new util.Stack[String]
  private val baseUriStack = new util.Stack[URI]
  private var importCount = 0
  private var dropUnderscoredAttributes = false
  private var treeBuilder = null

  /**
   * Start of document
   */
  @throws[XPathException]
  override def open() = {
    nextReceiver.open()
    var sysId = getSystemId
    if (sysId == null) sysId = ""
    systemIdStack.push(sysId)
    try baseUriStack.push(new URI(sysId))
    catch {
      case e: URISyntaxException =>
        try baseUriStack.push(new File(sysId).toURI)
        catch {
          case ex: Exception =>

          //throw new XPathException("Invalid URI for stylesheet: " + getSystemId());
        }
    }
  }

  /**
   * Notify the start of an element.
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int): Unit = {
    val fp = elemName.obtainFingerprint(getNamePool)
    val inXsltNamespace = elemName.hasURI(NamespaceConstant.XSLT)
    val inSaxonNamespace = elemName.hasURI(NamespaceConstant.SAXON)
    val stdAttUri = if (inXsltNamespace) ""
    else NamespaceConstant.XSLT
    var xpathDefaultNamespaceAtt = null
    var versionAtt = null
    var xmlBaseAtt = null
    var useWhenAtt = null
    var staticAtt = null
    var hasShadowAttributes = false
    var includedDoc = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      attName.obtainFingerprint(getNamePool)
      val uri = attName.getURI
      if (uri == stdAttUri) {
        val local = attName.getLocalPart
        local match {
          case "xpath-default-namespace" =>
            xpathDefaultNamespaceAtt = att.getValue
          case "version" =>
            versionAtt = att.getValue
          case "use-when" =>
            useWhenAtt = att.getValue
          case "static" =>
            staticAtt = att.getValue
        }
        if (local.startsWith("_") && uri == "" && (inXsltNamespace || inSaxonNamespace)) hasShadowAttributes = true
      }
      else if (inSaxonNamespace || uri == NamespaceConstant.SAXON) if (attName.getLocalPart.startsWith("_")) hasShadowAttributes = true
      else if (uri == NamespaceConstant.XML) if (attName.getLocalPart == "base") xmlBaseAtt = att.getValue
    }
    defaultNamespaceStack.push(xpathDefaultNamespaceAtt)
    if (emptyStylesheetElement) {
      depthOfHole += 1
      return
    }
    if (depthOfHole == 0) {
      val baseUri = processBaseUri(location, xmlBaseAtt)
      var ignore = false
      var version = Integer.MIN_VALUE
      if (versionAtt != null && fp != StandardNames.XSL_OUTPUT) version = processVersionAttribute(versionAtt)
      if (version == Integer.MIN_VALUE) version = if (versionStack.isEmpty) 30
      else versionStack.peek
      versionStack.push(version)
      if (inXsltNamespace && defaultNamespaceStack.size == 2 && version > 30 && !ElementAvailable.isXslt30Element(fp)) { // top level unknown XSLT element is ignored in forwards-compatibility mode
        ignore = true
      }
      if (hasShadowAttributes && !ignore) {
        attributes = processShadowAttributes(elemName, attributes, namespaces, location, baseUri)
        val uw = attributes.getValue(stdAttUri, "use-when")
        if (uw != null) useWhenAtt = uw
      }
      if (!ignore) {
        if (useWhenAtt != null) {
          val attLoc = new AttributeLocation(elemName.getStructuredQName, new StructuredQName("", stdAttUri, "use-when"), location)
          val use = evaluateUseWhen(useWhenAtt, attLoc, baseUri.toString, namespaces)
          ignore = !use
        }
        if (ignore) if (fp == StandardNames.XSL_STYLESHEET || fp == StandardNames.XSL_TRANSFORM || fp == StandardNames.XSL_PACKAGE) emptyStylesheetElement = true
        else {
          depthOfHole = 1
          return
        }
      }
      if (inXsltNamespace) if (defaultNamespaceStack.size == 2) fp match {
        case StandardNames.XSL_VARIABLE =>
        case StandardNames.XSL_PARAM =>
          if (hasShadowAttributes) staticAtt = attributes.getValue("", "static")
          if (staticAtt != null) {
            val staticStr = Whitespace.trim(staticAtt)
            if (StyleElement.isYes(staticStr)) processStaticVariable(elemName, attributes, namespaces, location, baseUri, precedence)
          }
        case StandardNames.XSL_INCLUDE =>
        case StandardNames.XSL_IMPORT =>
          // We need to process the included/imported stylesheet now, because its static variables
          // can be used later in this module
          val href = attributes.getValue("", "href")
          includedDoc = processIncludeImport(elemName, location, baseUri, href, fp == StandardNames.XSL_IMPORT)
        case StandardNames.XSL_IMPORT_SCHEMA =>
          compilation.setSchemaAware(true) // bug 3105
        case StandardNames.XSL_USE_PACKAGE =>
          if (precedence.getDepth > 1) throw new XPathException("xsl:use-package cannot appear in an imported stylesheet", "XTSE3008")
          val name = attributes.getValue("", "name")
          val pversion = attributes.getValue("", "package-version")
          if (name != null) try {
            val use = new UsePack(name, pversion, location.saveLocation)
            compilation.registerPackageDependency(use)
          } catch {
            case err: XPathException =>

            // No action, error will be reported later.
          }
      }
      dropUnderscoredAttributes = inXsltNamespace
      nextReceiver.startElement(elemName, `type`, attributes, namespaces, location, properties)
      if (includedDoc != null) {
        val node = treeBuilder.getCurrentParentNode.asInstanceOf[XSLGeneralIncorporate]
        node.setTargetDocument(includedDoc)
      }
    }
    else depthOfHole += 1
  }

  @throws[XPathException]
  private def processIncludeImport(elemName: NodeName, location: Location, baseUri: URI, href: String, isImport: Boolean) = {
    if (href == null) throw new XPathException("Missing href attribute on " + elemName.getDisplayName, "XTSE0010")
    val resolver = compilation.getCompilerInfo.getURIResolver
    val baseUriStr = baseUri.toString
    val key = DocumentFn.computeDocumentKey(href, baseUriStr, compilation.getPackageData, resolver, false)
    val map = compilation.getStylesheetModules
    if (map.containsKey(key)) map.get(key).asInstanceOf[DocumentImpl]
    else {
      var source = null
      try source = resolver.resolve(href, baseUriStr)
      catch {
        case e: TransformerException =>
          throw XPathException.makeXPathException(e)
      }
      if (source == null) source = getConfiguration.getSystemURIResolver.resolve(href, baseUriStr)
      var newPrecedence = precedence
      if (isImport) newPrecedence = precedence.getStem.append(precedence.getLeaf - 1).append(2 * {
        importCount += 1; importCount
      })
      try {
        val includedDoc = StylesheetModule.loadStylesheetModule(source, false, compilation, newPrecedence)
        map.put(key, includedDoc)
        includedDoc
      } catch {
        case e: XPathException =>
          e.maybeSetLocation(location)
          e.maybeSetErrorCode("XTSE0165")
          if ("XTSE0180" == e.getErrorCodeLocalPart) if (isImport) e.setErrorCode("XTSE0210")
          if (!e.hasBeenReported) compilation.reportError(e)
          throw e
      }
    }
  }

  @throws[XPathException]
  private def processStaticVariable(elemName: NodeName, attributes: AttributeMap, nsResolver: NamespaceResolver, location: Location, baseUri: URI, precedence: NestedIntegerValue) = {
    val nameStr = attributes.getValue("", "name")
    val asStr = attributes.getValue("", "as")
    val requiredStr = Whitespace.trim(attributes.getValue("", "required"))
    val isRequired = StyleElement.isYes(requiredStr)
    val staticContext = new UseWhenStaticContext(compilation, nsResolver)
    staticContext.setBaseURI(baseUri.toString)
    staticContext.setContainingLocation(new AttributeLocation(elemName.getStructuredQName, new StructuredQName("", "", "as"), location))
    var requiredType = SequenceType.ANY_SEQUENCE
    var languageLevel = compilation.getConfiguration.getConfigurationProperty(Feature.XPATH_VERSION_FOR_XSLT)
    if (languageLevel == 30) languageLevel = 305 // XPath 3.0 + XSLT extensions
    if (asStr != null) {
      val parser = compilation.getConfiguration.newExpressionParser("XP", false, languageLevel)
      requiredType = parser.parseSequenceType(asStr, staticContext)
    }
    var varName = null
    try varName = StructuredQName.fromLexicalQName(nameStr, false, true, nsResolver)
    catch {
      case err: XPathException =>
        throw createXPathException("Invalid variable name:" + nameStr + ". " + err.getMessage, err.getErrorCodeLocalPart, location)
    }
    val isVariable = elemName.getLocalPart == "variable"
    val isParam = elemName.getLocalPart == "param"
    val isSupplied = isParam && compilation.getParameters.containsKey(varName)
    val attLoc = new AttributeLocation(elemName.getStructuredQName, new StructuredQName("", "", "select"), location)
    if (isParam) {
      if (isRequired && !isSupplied) {
        val selectStr = attributes.getValue("", "select")
        if (selectStr != null) throw createXPathException("Cannot supply a default value when required='yes'", "XTSE0010", attLoc)
        else throw createXPathException("No value was supplied for the required static parameter $" + varName.getDisplayName, "XTDE0050", location)
      }
      if (isSupplied) {
        val suppliedValue = compilation.getParameters.convertParameterValue(varName, requiredType, true, staticContext.makeEarlyEvaluationContext)
        compilation.declareStaticVariable(varName, suppliedValue.materialize, precedence, isParam)
      }
    }
    if (isVariable || !isSupplied) {
      val selectStr = attributes.getValue("", "select")
      var value = null
      if (selectStr == null) if (isVariable) throw createXPathException("The select attribute is required for a static global variable", "XTSE0010", location)
      else if (!Cardinality.allowsZero(requiredType.getCardinality)) throw createXPathException("The parameter is implicitly required because it does not accept an " + "empty sequence, but no value has been supplied", "XTDE0700", location)
      else {
        value = if (asStr == null) StringValue.EMPTY_STRING
        else EmptySequence.getInstance
        compilation.declareStaticVariable(varName, value, precedence, isParam)
      }
      else try {
        staticContext.setContainingLocation(attLoc)
        val seq = evaluateStatic(selectStr, location, staticContext)
        value = seq.materialize
      } catch {
        case e: XPathException =>
          throw createXPathException("Error in " + elemName.getLocalPart + " expression. " + e.getMessage, e.getErrorCodeLocalPart, attLoc)
      }
      val role = new RoleDiagnostic(RoleDiagnostic.VARIABLE, varName.getDisplayName, 0)
      role.setErrorCode("XTDE0050")
      val th = getConfiguration.getTypeHierarchy
      val seq = th.applyFunctionConversionRules(value, requiredType, role, attLoc)
      value = seq.materialize
      try compilation.declareStaticVariable(varName, value, precedence, isParam)
      catch {
        case e: XPathException =>
          throw createXPathException(e.getMessage, e.getErrorCodeLocalPart, attLoc)
      }
    }
  }

  @throws[XPathException]
  private def processShadowAttributes(elemName: NodeName, attributes: AttributeMap, nsResolver: NamespaceResolver, location: Location, baseUri: URI) = {
    val attMap = new util.HashMap[NodeName, AttributeInfo]
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      attMap.put(attName, att)
    }
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val local = attName.getLocalPart
      val uri = attName.getURI
      if (local.startsWith("_") && (uri.isEmpty || uri == NamespaceConstant.SAXON) && local.length >= 2) {
        val value = att.getValue
        val attLocation = new AttributeLocation(elemName.getStructuredQName, attName.getStructuredQName, location)
        val newValue = processShadowAttribute(value, baseUri.toString, nsResolver, attLocation)
        val plainName = local.substring(1)
        val newName = if (uri.isEmpty) new NoNamespaceName(plainName)
        else new FingerprintedQName(attName.getPrefix, NamespaceConstant.SAXON, plainName)
        // if a corresponding attribute exists with no underscore, overwrite it.
        // Drop the shadow attribute itself.
        val newAtt = new AttributeInfo(newName, att.getType, newValue, att.getLocation, ReceiverOption.NONE)
        attMap.put(newName, newAtt)
        attMap.remove(attName)
      }
    }
    var resultAtts = EmptyAttributeMap.getInstance
    import scala.collection.JavaConversions._
    for (att <- attMap.values) {
      resultAtts = resultAtts.put(new AttributeInfo(att.getNodeName, att.getType, att.getValue, att.getLocation, att.getProperties))
    }
    resultAtts
  }

  @throws[XPathException]
  private def processBaseUri(location: Location, xmlBaseAtt: String) = {
    var systemId = location.getSystemId
    if (systemId == null) systemId = getSystemId
    var baseUri = null
    if (systemId == null || systemId == systemIdStack.peek) baseUri = baseUriStack.peek
    else try baseUri = new URI(systemId)
    catch {
      case e: URISyntaxException =>
        throw new XPathException("Invalid URI for stylesheet entity: " + systemId)
    }
    if (xmlBaseAtt != null) try baseUri = baseUri.resolve(xmlBaseAtt)
    catch {
      case iae: IllegalArgumentException =>
        throw new XPathException("Invalid URI in xml:base attribute: " + xmlBaseAtt + ". " + iae.getMessage)
    }
    baseUriStack.push(baseUri)
    systemIdStack.push(systemId)
    baseUri
  }

  @throws[XPathException]
  private def processVersionAttribute(version: String) = if (version != null) {
    val cr = BigDecimalValue.makeDecimalValue(version, true)
    if (cr.isInstanceOf[ValidationFailure]) throw new XPathException("Invalid version number: " + version, "XTSE0110")
    val d = cr.asAtomic.asInstanceOf[BigDecimalValue]
    d.getDecimalValue.multiply(BigDecimal.TEN).intValue
  }
  else Integer.MIN_VALUE

  /**
   * Perform evaluation of the nested expressions within a shadow attribute
   *
   * @param expression the value of the shadow attribute as written
   * @param baseUri    the base URI of the containing element
   * @param loc        the location of the attribute, for diagnostics
   * @return the result of evaluating nested expressions in the value
   * @throws XPathException if the syntax is invalid, or if evaluation of nested expressions fails
   */
  @throws[XPathException]
  private def processShadowAttribute(expression: String, baseUri: String, nsResolver: NamespaceResolver, loc: AttributeLocation) = {
    val staticContext = new UseWhenStaticContext(compilation, nsResolver)
    staticContext.setBaseURI(baseUri)
    staticContext.setContainingLocation(loc)
    setNamespaceBindings(staticContext)
    var expr = AttributeValueTemplate.make(expression, staticContext)
    expr = typeCheck(expr, staticContext)
    val stackFrameMap = allocateSlots(expression, expr)
    val dynamicContext = makeDynamicContext(staticContext)
    dynamicContext.asInstanceOf[XPathContextMajor].openStackFrame(stackFrameMap)
    expr.evaluateAsString(dynamicContext).toString
  }

  private def createXPathException(message: String, errorCode: String, location: Location) = {
    val err = new XPathException(message)
    err.setErrorCode(errorCode)
    err.setIsStaticError(true)
    err.setLocator(location.saveLocation)
    getPipelineConfiguration.getErrorReporter.report(new XmlProcessingException(err))
    err.setHasBeenReported(true)
    err
  }

  /**
   * End of element
   */
  @throws[XPathException]
  override def endElement() = {
    defaultNamespaceStack.pop
    if (depthOfHole > 0) depthOfHole -= 1
    else {
      systemIdStack.pop
      baseUriStack.pop
      versionStack.pop
      nextReceiver.endElement()
    }
  }

  /**
   * Character data
   */
  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = if (depthOfHole == 0) nextReceiver.characters(chars, locationId, properties)

  /**
   * Processing Instruction
   */
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = {
    // these are ignored in a stylesheet
  }

  /**
   * Output a comment
   */
  @throws[XPathException]
  override def comment(chars: CharSequence, locationId: Location, properties: Int) = {
  }

  /**
   * Evaluate a use-when attribute
   *
   * @param expression the expression to be evaluated
   * @param location   identifies the location of the expression in case error need to be reported
   * @param baseUri    the base URI of the element containing the expression
   * @return the effective boolean value of the result of evaluating the expression
   * @throws XPathException if evaluation of the expression fails
   */
  @throws[XPathException]
  private def evaluateUseWhen(expression: String, location: AttributeLocation, baseUri: String, nsResolver: NamespaceResolver) = {
    val staticContext = new UseWhenStaticContext(compilation, nsResolver)
    staticContext.setBaseURI(baseUri)
    staticContext.setContainingLocation(location)
    setNamespaceBindings(staticContext)
    var expr = ExpressionTool.make(expression, staticContext, 0, Token.EOF, null)
    expr.setRetainedStaticContext(staticContext.makeRetainedStaticContext)
    expr = typeCheck(expr, staticContext)
    val stackFrameMap = allocateSlots(expression, expr)
    val dynamicContext = makeDynamicContext(staticContext)
    //dynamicContext.getController().getExecutable().setFunctionLibrary((FunctionLibraryList)staticContext.getFunctionLibrary());
    dynamicContext.asInstanceOf[XPathContextMajor].openStackFrame(stackFrameMap)
    expr.effectiveBooleanValue(dynamicContext)
  }

  private def allocateSlots(expression: String, expr: Expression) = {
    val stackFrameMap = getPipelineConfiguration.getConfiguration.makeSlotManager
    if (expression.indexOf('$') >= 0) ExpressionTool.allocateSlots(expr, stackFrameMap.getNumberOfVariables, stackFrameMap)
    stackFrameMap
  }

  private def setNamespaceBindings(staticContext: UseWhenStaticContext) = {
    staticContext.setDefaultElementNamespace(NamespaceConstant.NULL)
    for (i <- defaultNamespaceStack.size - 1 to 0 by -1) {
      val uri = defaultNamespaceStack.get(i)
      if (uri != null) {
        staticContext.setDefaultElementNamespace(uri)
        break //todo: break is not supported
      }
    }
  }

  @throws[XPathException]
  private def typeCheck(expr: Expression, staticContext: UseWhenStaticContext) = {
    val contextItemType = Type.ITEM_TYPE
    val cit = getConfiguration.makeContextItemStaticInfo(contextItemType, true)
    val visitor = ExpressionVisitor.make(staticContext)
    expr.typeCheck(visitor, cit)
  }

  @throws[XPathException]
  private def makeDynamicContext(staticContext: UseWhenStaticContext) = {
    val controller = new Controller(getConfiguration)
    controller.getExecutable.setFunctionLibrary(staticContext.getFunctionLibrary.asInstanceOf[FunctionLibraryList])
    if (staticContext.getXPathVersion < 30) controller.setURIResolver(new UseWhenFilter.URIPreventer)
    controller.setCurrentDateTime(currentDateTime)
    // this is to ensure that all use-when expressions in a module use the same date and time
    var dynamicContext = controller.newXPathContext
    dynamicContext = dynamicContext.newCleanContext
    dynamicContext
  }

  /**
   * Evaluate a static expression (to initialize a static variable)
   *
   * @param expression    the expression to be evaluated
   * @param locationId    identifies the location of the expression in case error need to be reported
   * @param staticContext the static context for evaluation of the expression
   * @return the effective boolean value of the result of evaluating the expression
   * @throws XPathException if evaluation of the expression fails
   */
  @throws[XPathException]
  def evaluateStatic(expression: String, locationId: Location, staticContext: UseWhenStaticContext) = {
    setNamespaceBindings(staticContext)
    var expr = ExpressionTool.make(expression, staticContext, 0, Token.EOF, null)
    expr = typeCheck(expr, staticContext)
    val stackFrameMap = getPipelineConfiguration.getConfiguration.makeSlotManager
    ExpressionTool.allocateSlots(expr, stackFrameMap.getNumberOfVariables, stackFrameMap)
    val dynamicContext = makeDynamicContext(staticContext)
    dynamicContext.asInstanceOf[XPathContextMajor].openStackFrame(stackFrameMap)
    expr.iterate(dynamicContext).materialize
  }
}