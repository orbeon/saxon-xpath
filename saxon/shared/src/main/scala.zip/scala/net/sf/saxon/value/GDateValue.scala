////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.functions.AccessorFn
import net.sf.saxon.model.ConversionResult
import net.sf.saxon.model.ValidationFailure
import net.sf.saxon.om.SequenceTool
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.NoDynamicContextException
import net.sf.saxon.trans.XPathException
import java.util._

/**
 * Abstract superclass for the primitive types containing date components: xs:date, xs:gYear,
 * xs:gYearMonth, xs:gMonth, xs:gMonthDay, xs:gDay
 */
object GDateValue {
  /**
   * Test whether a candidate date is actually a valid date in the proleptic Gregorian calendar
   */
    /*@NotNull*/ protected var daysPerMonth = Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
  protected val monthData = Array(306, 337, 0, 31, 61, 92, 122, 153, 184, 214, 245, 275)

  /**
   * Initialize the DateValue using a character string in the format yyyy-mm-dd and an optional time zone.
   * Input must have format [-]yyyy-mm-dd[([+|-]hh:mm | Z)]
   *
   * @param d             the "raw" DateValue to be populated
   * @param s             the supplied string value
   * @param allowYearZero true if (as in XSD 1.1) there is a year zero, false if (as in XSD 1.0) there is not
   * @return either the supplied GDateValue, with its data initialized; or a ValidationFailure
   */
  protected def setLexicalValue(d: GDateValue, s: CharSequence, allowYearZero: Boolean): ConversionResult = {
    d.hasNoYearZero = !allowYearZero
    val tok = new StringTokenizer(Whitespace.trimWhitespace(s).toString, "-:+TZ", true)
    try {
      if (!tok.hasMoreElements) return badDate("Too short", s)
      var part = tok.nextElement.asInstanceOf[String]
      var era = +1
      if ("+" == part) return badDate("Date must not start with '+' sign", s)
      else if ("-" == part) {
        era = -1
        if (!tok.hasMoreElements) return badDate("No year after '-'", s)
        part = tok.nextElement.asInstanceOf[String]
      }
      if (part.length < 4) return badDate("Year is less than four digits", s)
      if (part.length > 4 && part.charAt(0) == '0') return badDate("When year exceeds 4 digits, leading zeroes are not allowed", s)
      var value = DurationValue.simpleInteger(part)
      if (value < 0) if (value == -1) return badDate("Non-numeric year component", s)
      else return badDate("Year is outside the range that Saxon can handle", s, "FODT0001")
      d.year = value * era
      if (d.year == 0 && !allowYearZero) return badDate("Year zero is not allowed", s)
      if (era < 0 && !allowYearZero) d.year += 1 // if year zero not allowed, -0001 is the year before +0001, represented as 0 internally.
      if (!tok.hasMoreElements) return badDate("Too short", s)
      if (!("-" == tok.nextElement)) return badDate("Wrong delimiter after year", s)
      if (!tok.hasMoreElements) return badDate("Too short", s)
      part = tok.nextElement.asInstanceOf[String]
      if (part.length != 2) return badDate("Month must be two digits", s)
      value = DurationValue.simpleInteger(part)
      if (value < 0) return badDate("Non-numeric month component", s)
      d.month = value.toByte
      if (d.month < 1 || d.month > 12) return badDate("Month is out of range", s)
      if (!tok.hasMoreElements) return badDate("Too short", s)
      if (!("-" == tok.nextElement)) return badDate("Wrong delimiter after month", s)
      if (!tok.hasMoreElements) return badDate("Too short", s)
      part = tok.nextElement.asInstanceOf[String]
      if (part.length != 2) return badDate("Day must be two digits", s)
      value = DurationValue.simpleInteger(part)
      if (value < 0) return badDate("Non-numeric day component", s)
      d.day = value.toByte
      if (d.day < 1 || d.day > 31) return badDate("Day is out of range", s)
      var tzOffset = 0
      if (tok.hasMoreElements) {
        val delim = tok.nextElement.asInstanceOf[String]
        if ("T" == delim) return badDate("Value includes time", s)
        else if ("Z" == delim) {
          tzOffset = 0
          if (tok.hasMoreElements) return badDate("Continues after 'Z'", s)
          d.setTimezoneInMinutes(tzOffset)
        }
        else if (!(!("+" == delim) && !("-" == delim))) {
          if (!tok.hasMoreElements) return badDate("Missing timezone", s)
          part = tok.nextElement.asInstanceOf[String]
          value = DurationValue.simpleInteger(part)
          if (value < 0) return badDate("Non-numeric timezone hour component", s)
          val tzhour = value
          if (part.length != 2) return badDate("Timezone hour must be two digits", s)
          if (tzhour > 14) return badDate("Timezone hour is out of range", s)
          if (!tok.hasMoreElements) return badDate("No minutes in timezone", s)
          if (!(":" == tok.nextElement)) return badDate("Wrong delimiter after timezone hour", s)
          if (!tok.hasMoreElements) return badDate("No minutes in timezone", s)
          part = tok.nextElement.asInstanceOf[String]
          value = DurationValue.simpleInteger(part)
          if (value < 0) return badDate("Non-numeric timezone minute component", s)
          val tzminute = value
          if (part.length != 2) return badDate("Timezone minute must be two digits", s)
          if (tzminute > 59) return badDate("Timezone minute is out of range", s)
          if (tok.hasMoreElements) return badDate("Continues after timezone", s)
          tzOffset = tzhour * 60 + tzminute
          if ("-" == delim) tzOffset = -tzOffset
          d.setTimezoneInMinutes(tzOffset)
        }
        else return badDate("Timezone format is incorrect", s)
      }
      if (!isValidDate(d.year, d.month, d.day)) return badDate("Non-existent date", s)
    } catch {
      case err: NumberFormatException =>
        return badDate("Non-numeric component", s)
    }
    d
  }

  private def badDate(msg: String, value: CharSequence) = {
    val err = new ValidationFailure("Invalid date " + Err.wrap(value, Err.VALUE) + " (" + msg + ")")
    err.setErrorCode("FORG0001")
    err
  }

  private def badDate(msg: String, value: CharSequence, errorCode: String) = {
    val err = new ValidationFailure("Invalid date " + Err.wrap(value, Err.VALUE) + " (" + msg + ")")
    err.setErrorCode(errorCode)
    err
  }

  /**
   * Determine whether a given date is valid
   *
   * @param year  the year (permitting year zero)
   * @param month the month (1-12)
   * @param day   the day (1-31)
   * @return true if this is a valid date
   */
  def isValidDate(year: Int, month: Int, day: Int) = month > 0 && month <= 12 && day > 0 && day <= daysPerMonth(month - 1) || month == 2 && day == 29 && isLeapYear(year)

  /**
   * Test whether a year is a leap year
   *
   * @param year the year (permitting year zero)
   * @return true if the supplied year is a leap year
   */
  def isLeapYear(year: Int) = (year % 4 == 0) && !(year % 100 == 0 && !(year % 400 == 0))
}

abstract class GDateValue extends CalendarValue {
  protected var year = 0 // unlike the lexical representation, includes a year zero
  protected var month = 0
  protected var day = 0
  protected var hasNoYearZero = false

  /**
   * Get the year component of the date (in local form)
   *
   * @return the year component, as represented internally (allowing a year zero)
   */
  def getYear = year

  /**
   * Get the month component of the date (in local form)
   *
   * @return the month component (1-12)
   */
  def getMonth = month

  /**
   * Get the day component of the date (in local form)
   *
   * @return the day component (1-31)
   */
  def getDay = day

  override def getCalendar: GregorianCalendar = {
    val tz = if (hasTimezone) getTimezoneInMinutes * 60000
    else 0
    val zone = new SimpleTimeZone(tz, "LLL")
    val calendar = new GregorianCalendar(zone)
    calendar.setGregorianChange(new Date(Long.MIN_VALUE))
    if (tz < calendar.getMinimum(Calendar.ZONE_OFFSET) || tz > calendar.getMaximum(Calendar.ZONE_OFFSET)) return adjustTimezone(0).getCalendar
    calendar.clear()
    calendar.setLenient(false)
    var yr = year
    if (year <= 0) {
      yr = if (hasNoYearZero) 1 - year
      else 0 - year
      calendar.set(Calendar.ERA, GregorianCalendar.BC)
    }
    //noinspection MagicConstant
    calendar.set(yr, month - 1, day)
    calendar.set(Calendar.ZONE_OFFSET, tz)
    calendar.set(Calendar.DST_OFFSET, 0)
    calendar.getTime
    calendar
  }

  /**
   * Check that the value can be handled in Saxon-JS
   *
   * @throws XPathException if it can't be handled in Saxon-JS
   */
  @throws[XPathException]
  override def checkValidInJavascript() = if (year <= 0 || year > 9999) throw new XPathException("Year out of range for Saxon-JS", "FODT0001")

  /**
   * The equals() methods on atomic values is defined to follow the semantics of eq when applied
   * to two atomic values. When the other operand is not an atomic value, the result is undefined
   * (may be false, may be an exception). When the other operand is an atomic value that cannot be
   * compared with this one, the method returns false.
   * <p>The hashCode() method is consistent with equals().</p>
   * <p>This implementation performs a context-free comparison: it fails with ClassCastException
   * if one value has a timezone and the other does not.</p>
   *
   * @param o the other value
   * @return true if the other operand is an atomic value and the two values are equal as defined
   *         by the XPath eq operator
   * @throws ClassCastException if the values are not comparable
   */
  override def equals(o: Any) = if (o.isInstanceOf[GDateValue]) {
    val gdv = o.asInstanceOf[GDateValue]
    (getPrimitiveType eq gdv.getPrimitiveType) && toDateTime == gdv.toDateTime
  }
  else false

  override def hashCode = DateTimeValue.hashCode(year, month, day, 12.toByte, 0.toByte, 0.toByte, 0, getTimezoneInMinutes)

  /**
   * Compare this value to another value of the same type, using the supplied context object
   * to get the implicit timezone if required. This method implements the XPath comparison semantics.
   *
   * @param other            the value to be compared
   * @param implicitTimezone the implicit timezone to be used for a value with no timezone
   * @return -1 if this value is less, 0 if equal, +1 if greater
   */
  @throws[NoDynamicContextException]
  override def compareTo(other: CalendarValue, implicitTimezone: Int): Int = {
    if (getPrimitiveType ne other.getPrimitiveType) {
      throw new ClassCastException("Cannot compare dates of different types")
      // covers, for example, comparing a gYear to a gYearMonth
    }
    val v2 = other.asInstanceOf[GDateValue]
    if (getTimezoneInMinutes == other.getTimezoneInMinutes) { // both values are in the same timezone (explicitly or implicitly)
      if (year != v2.year) return IntegerValue.signum(year - v2.year)
      if (month != v2.month) return IntegerValue.signum(month - v2.month)
      if (day != v2.day) return IntegerValue.signum(day - v2.day)
      return 0
    }
    toDateTime.compareTo(other.toDateTime, implicitTimezone)
  }

  /**
   * Convert to DateTime.
   *
   * @return the starting instant of the GDateValue (with the same timezone)
   */
  override def toDateTime = new DateTimeValue(year, month, day, 0.toByte, 0.toByte, 0.toByte, 0, getTimezoneInMinutes, hasNoYearZero)

  override def getSchemaComparable = new GDateValue#GDateComparable

  /**
   * Get a component of the value. Returns null if the timezone component is
   * requested and is not present.
   *
   * @param component the required component
   */
  /*@Nullable*/ @throws[XPathException]
  override def getComponent(component: AccessorFn.Component) = component match {
    case YEAR_ALLOWING_ZERO =>
      Int64Value.makeIntegerValue(year)
    case YEAR =>
      Int64Value.makeIntegerValue(if (year > 0 || !hasNoYearZero) year
      else year - 1)
    case MONTH =>
      Int64Value.makeIntegerValue(month)
    case DAY =>
      Int64Value.makeIntegerValue(day)
    case TIMEZONE =>
      if (hasTimezone) DayTimeDurationValue.fromMilliseconds(60000L * getTimezoneInMinutes)
      else null
    case _ =>
      throw new IllegalArgumentException("Unknown component for date: " + component)
  }

  private class GDateComparable extends Comparable[_] {
    def asGDateValue = thisGDateValue

    override def compareTo(o: Any): Int = if (o.isInstanceOf[GDateValue#GDateComparable]) {
      if (asGDateValue.getPrimitiveType ne o.asInstanceOf[GDateValue#GDateComparable].asGDateValue.getPrimitiveType) return SequenceTool.INDETERMINATE_ORDERING
      val dt0 = thisGDateValue.toDateTime
      val dt1 = o.asInstanceOf[GDateValue#GDateComparable].asGDateValue.toDateTime
      dt0.getSchemaComparable.compareTo(dt1.getSchemaComparable)
    }
    else SequenceTool.INDETERMINATE_ORDERING

    override def equals(o: Any) = compareTo(o) == 0

    override def hashCode = thisGDateValue.toDateTime.getSchemaComparable.hashCode
  }

}