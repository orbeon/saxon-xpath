////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.instruct.Choose
import net.sf.saxon.expr.parser._
import net.sf.saxon.functions.SystemFunction
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.BooleanValue
import java.util

object AndExpression {
  /**
   * Generate an 'and' tree over a set of expressions
   *
   * @param exprs the expressions to be "and'ed" together
   * @return the root of the new expression tree
   */
    def distribute(exprs: util.Collection[Expression]) = {
      var result = null
      if (exprs != null) {
        var first = true
        import scala.collection.JavaConversions._
        for (e <- exprs) {
          if (first) {
            first = false
            result = e
          }
          else result = new AndExpression(result, e)
        }
      }
      result
    }
}

class AndExpression(val p1: Expression, val p2: Expression)

/**
 * Construct a boolean AND expression
 *
 * @param p1 the first operand
 * @param p2 the second operand
 */
  extends BooleanExpression(p1, Token.AND, p2) {
  override protected def preEvaluate = { // If the value can be determined from knowledge of one operand, precompute the result
    if (Literal.isConstantBoolean(getLhsExpression, false) || Literal.isConstantBoolean(getRhsExpression, false)) { // A and false() => false()
      // false() and B => false()
      Literal.makeLiteral(BooleanValue.FALSE, this)
    }
    else if (Literal.hasEffectiveBooleanValue(getLhsExpression, true)) { // true() and B => B
      forceToBoolean(getRhsExpression)
    }
    else if (Literal.hasEffectiveBooleanValue(getRhsExpression, true)) { // A and true() => A
      forceToBoolean(getLhsExpression)
    }
    else this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor     an expression visitor
   * @param contextInfo the static type of "." at the point where this expression is invoked.
   *                    The parameter is set to null if it is known statically that the context item will be undefined.
   *                    If the type of the context item is not known statically, the argument is set to
   *                    { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  /*@NotNull*/ @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val t = super.optimize(visitor, contextInfo)
    if (t ne this) return t
    // Rewrite (A and B) as (if (A) then B else false()). The benefit of this is that when B is a recursive
    // function call, it is treated as a tail call (test qxmp290). To avoid disrupting other optimizations
    // of "and" expressions (specifically, where clauses in FLWOR expressions), do this ONLY if B is a user
    // function call (we can't tell if it's recursive), and it's not in a loop.
    val th = visitor.getConfiguration.getTypeHierarchy
    if (getRhsExpression.isInstanceOf[UserFunctionCall] && th.isSubType(getRhsExpression.getItemType, BuiltInAtomicType.BOOLEAN) && !ExpressionTool.isLoopingSubexpression(this, null)) {
      val cond = Choose.makeConditional(getLhsExpression, getRhsExpression, Literal.makeLiteral(BooleanValue.FALSE, this))
      ExpressionTool.copyLocationInfo(this, cond)
      return cond
    }
    this
  }

  override def getCost = { // Assume the RHS will be evaluated 50% of the time
    getLhsExpression.getCost + getRhsExpression.getCost / 2
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be rebound
   */
  override def copy(rebindings: RebindingMap) = {
    val a2 = new AndExpression(getLhsExpression.copy(rebindings), getRhsExpression.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, a2)
    a2
  }

  /**
   * Return the negation of this boolean expression, that is, an expression that returns true
   * when this expression returns false, and vice versa
   *
   * @return the negation of this expression
   */
  override def negate = { // Apply de Morgan's laws
    // not(A and B) ==> not(A) or not(B)
    val not0 = SystemFunction.makeCall("not", getRetainedStaticContext, getLhsExpression)
    val not1 = SystemFunction.makeCall("not", getRetainedStaticContext, getRhsExpression)
    new OrExpression(not0, not1)
  }

  /**
   * Get the element name used to identify this expression in exported expression format
   *
   * @return the element name used to identify this expression
   */
  override protected def tag = "and"

  /**
   * Evaluate as a boolean.
   */
  @throws[XPathException]
  override def effectiveBooleanValue(c: XPathContext) = getLhsExpression.effectiveBooleanValue(c) && getRhsExpression.effectiveBooleanValue(c)
}