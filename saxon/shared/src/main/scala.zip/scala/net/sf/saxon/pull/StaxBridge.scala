////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.pull

import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Untyped
import net.sf.saxon.om._
import net.sf.saxon.trans.SaxonErrorCode
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XmlProcessingIncident
import net.sf.saxon.tree.tiny.CharSlice
import net.sf.saxon.tree.tiny.CompressedWhitespace
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.Whitespace
import javax.xml.namespace.QName
import javax.xml.stream._
import javax.xml.stream.events.EntityDeclaration
import java.io.InputStream
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.net.URI
import java.net.URISyntaxException
import java.util

/**
 * This class implements the Saxon PullProvider API on top of a standard StAX parser
 * (or any other StAX XMLStreamReader implementation)
 */
class StaxBridge()

/**
 * Create a new instance of the class
 */
  extends PullProvider {
  namespaceStack.push(NamespaceMap.emptyMap)
  private var reader = null
  private var attributes = null
  private var pipe = null
  private var namePool = null
  private val nameCache = new util.HashMap[String, NodeName]
  private val namespaceStack = new util.Stack[NamespaceMap]
  private var unparsedEntities = null
  private[pull] var currentEvent = Event.START_OF_INPUT
  private[pull] var depth = 0
  private[pull] var ignoreIgnorable = false

  /**
   * Supply an input stream containing XML to be parsed. A StAX parser is created using
   * the JAXP XMLInputFactory.
   *
   * @param systemId    The Base URI of the input document
   * @param inputStream the stream containing the XML to be parsed
   * @throws XPathException if an error occurs creating the StAX parser
   */
  @throws[XPathException]
  def setInputStream(systemId: String, inputStream: InputStream) = try {
    val factory = XMLInputFactory.newInstance
    //XMLInputFactory factory = new WstxInputFactory();
    factory.setXMLReporter(new StaxBridge#StaxErrorReporter)
    reader = factory.createXMLStreamReader(systemId, inputStream)
  } catch {
    case e: XMLStreamException =>
      throw new XPathException(e)
  }

  /**
   * Supply an XMLStreamReader: the events reported by this XMLStreamReader will be translated
   * into PullProvider events
   *
   * @param reader the supplier of XML events, typically an XML parser
   */
  def setXMLStreamReader(reader: XMLStreamReader) = this.reader = reader

  /**
   * Set configuration information. This must only be called before any events
   * have been read.
   */
  override def setPipelineConfiguration(pipe: PipelineConfiguration) = {
    this.pipe = new PipelineConfiguration(pipe)
    this.namePool = pipe.getConfiguration.getNamePool
    ignoreIgnorable = pipe.getConfiguration.getParseOptions.getSpaceStrippingRule ne NoElementsSpaceStrippingRule.getInstance
  }

  /**
   * Get configuration information.
   */
  override def getPipelineConfiguration = pipe

  /**
   * Get the XMLStreamReader used by this StaxBridge. This is available only after
   * setInputStream() or setXMLStreamReader() has been called
   *
   * @return the instance of XMLStreamReader allocated when setInputStream() was called,
   *         or the instance supplied directly to setXMLStreamReader()
   */
  def getXMLStreamReader = reader

  /**
   * Get the name pool
   *
   * @return the name pool
   */
  def getNamePool = pipe.getConfiguration.getNamePool

  /**
   * Get the next event
   *
   * @return an integer code indicating the type of event. The code
   *         { @link net.sf.saxon.pull.PullProvider.Event#END_OF_INPUT} is returned at the end of the sequence.
   */
  @throws[XPathException]
  override def next: PullProvider.Event = {
    if (currentEvent eq Event.START_OF_INPUT) { // StAX isn't reporting START_DOCUMENT so we supply it ourselves
      currentEvent = Event.START_DOCUMENT
      return currentEvent
    }
    if ((currentEvent eq Event.END_OF_INPUT) || (currentEvent eq Event.END_DOCUMENT)) {
      try reader.close()
      catch {
        case e: XMLStreamException =>
          throw new XPathException(e)
      }
      return Event.END_OF_INPUT
    }
    try if (reader.hasNext) {
      val event = reader.next
      //System.err.println("Read event " + event);
      currentEvent = translate(event)
      if (currentEvent eq Event.START_ELEMENT) {
        var nsMap = namespaceStack.peek
        val n = reader.getNamespaceCount
        for (i <- 0 until n) {
          val prefix = reader.getNamespacePrefix(i)
          val uri = reader.getNamespaceURI(i)
          nsMap = nsMap.bind(if (prefix == null) ""
          else prefix, if (uri == null) ""
          else uri)
        }
        namespaceStack.push(nsMap)
        val attCount = reader.getAttributeCount
        if (attCount == 0) attributes = EmptyAttributeMap.getInstance
        else {
          val attList = new util.ArrayList[AttributeInfo]
          val pool = getNamePool
          for (i <- 0 until attCount) {
            val name = reader.getAttributeName(i)
            val fName = new FingerprintedQName(name.getPrefix, name.getNamespaceURI, name.getLocalPart, pool)
            val value = reader.getAttributeValue(i)
            val att = new AttributeInfo(fName, BuiltInAtomicType.UNTYPED_ATOMIC, value, Loc.NONE, 0)
            attList.add(att)
          }
          attributes = AttributeMap.fromList(attList)
        }
      }
      else if (currentEvent eq Event.END_ELEMENT) namespaceStack.pop
    }
    else currentEvent = Event.END_OF_INPUT
    catch {
      case e: XMLStreamException =>
        var message = e.getMessage
        // Following code recognizes the messages produced by the Sun Zephyr parser
        if (message.startsWith("ParseError at")) {
          val c = message.indexOf("\nMessage: ")
          if (c > 0) message = message.substring(c + 10)
        }
        val err = new XPathException("Error reported by XML parser: " + message, e)
        err.setErrorCode(SaxonErrorCode.SXXP0003)
        err.setLocator(translateLocation(e.getLocation))
        throw err
    }
    currentEvent
  }

  @throws[XPathException]
  private def translate(event: Int) = { //System.err.println("EVENT " + event);
    event match {
      case XMLStreamConstants.ATTRIBUTE =>
        Event.ATTRIBUTE
      case XMLStreamConstants.CDATA =>
        Event.TEXT
      case XMLStreamConstants.CHARACTERS =>
        if (depth == 0 && reader.isWhiteSpace) {
          next
          //                    } else if (reader.isWhiteSpace()) {
          //                        return next();
        }
        else { //                        System.err.println("TEXT[" + new String(reader.getTextCharacters(), reader.getTextStart(), reader.getTextLength()) + "]");
          //                        System.err.println("  ARRAY length " + reader.getTextCharacters().length + "[" + new String(reader.getTextCharacters(), 0, reader.getTextStart() + reader.getTextLength()) + "]");
          //                        System.err.println("  START: " + reader.getTextStart() + " LENGTH " + reader.getTextLength());
          Event.TEXT
        }
      case XMLStreamConstants.COMMENT =>
        Event.COMMENT
      case XMLStreamConstants.DTD =>
        unparsedEntities = reader.getProperty("javax.xml.stream.entities").asInstanceOf[util.List[_]]
        next
      case XMLStreamConstants.END_DOCUMENT =>
        Event.END_DOCUMENT
      case XMLStreamConstants.END_ELEMENT =>
        depth -= 1
        Event.END_ELEMENT
      case XMLStreamConstants.ENTITY_DECLARATION =>
        next
      case XMLStreamConstants.ENTITY_REFERENCE =>
        next
      case XMLStreamConstants.NAMESPACE =>
        Event.NAMESPACE
      case XMLStreamConstants.NOTATION_DECLARATION =>
        next
      case XMLStreamConstants.PROCESSING_INSTRUCTION =>
        Event.PROCESSING_INSTRUCTION
      case XMLStreamConstants.SPACE =>
        if (depth == 0) next
        else if (ignoreIgnorable) { // (Brave attempt, but Woodstox doesn't seem to report ignorable whitespace)
          next
        }
        else Event.TEXT
      case XMLStreamConstants.START_DOCUMENT =>
        next // we supplied the START_DOCUMENT ourselves
      //return START_DOCUMENT;
      case XMLStreamConstants.START_ELEMENT =>
        depth += 1
        Event.START_ELEMENT
      case _ =>
        throw new IllegalStateException("Unknown StAX event " + event)
    }
  }

  /**
   * Get the event most recently returned by next(), or by other calls that change
   * the position, for example getStringValue() and skipToMatchingEnd(). This
   * method does not change the position of the PullProvider.
   *
   * @return the current event
   */
  override def current = currentEvent

  /**
   * Get the attributes associated with the current element. This method must
   * be called only after a START_ELEMENT event has been notified. The contents
   * of the returned AttributeMap are immutable.
   * <p>Attributes may be read before or after reading the namespaces of an element,
   * but must not be read after the first child node has been read, or after calling
   * one of the methods skipToEnd(), getStringValue(), or getTypedValue().</p>
   *
   * @return an AttributeCollection representing the attributes of the element
   *         that has just been notified.
   */
  override def getAttributes = attributes

  /**
   * Get the namespace declarations associated with the current element. This method must
   * be called only after a START_ELEMENT event has been notified. In the case of a top-level
   * START_ELEMENT event (that is, an element that either has no parent node, or whose parent
   * is not included in the sequence being read), the NamespaceDeclarations object returned
   * will contain a namespace declaration for each namespace that is in-scope for this element
   * node. In the case of a non-top-level element, the NamespaceDeclarations will contain
   * a set of namespace declarations and undeclarations, representing the differences between
   * this element and its parent.
   * <p>It is permissible for this method to return namespace declarations that are redundant.</p>
   * <p>The NamespaceDeclarations object is guaranteed to remain unchanged until the next START_ELEMENT
   * event, but may then be overwritten. The object should not be modified by the client.</p>
   * <p>Namespaces may be read before or after reading the attributes of an element,
   * but must not be read after the first child node has been read, or after calling
   * one of the methods skipToEnd(), getStringValue(), or getTypedValue().</p>
   */
  override def getNamespaceDeclarations = {
    val n = reader.getNamespaceCount
    if (n == 0) NamespaceBinding.EMPTY_ARRAY
    else {
      val bindings = new Array[NamespaceBinding](n)
      for (i <- 0 until n) {
        var prefix = reader.getNamespacePrefix(i)
        if (prefix == null) prefix = ""
        var uri = reader.getNamespaceURI(i)
        if (uri == null) uri = ""
        bindings(i) = new NamespaceBinding(prefix, uri)
      }
      bindings
    }
  }

  /**
   * Skip the current subtree. This method may be called only immediately after
   * a START_DOCUMENT or START_ELEMENT event. This call returns the matching
   * END_DOCUMENT or END_ELEMENT event; the next call on next() will return
   * the event following the END_DOCUMENT or END_ELEMENT.
   */
  @throws[XPathException]
  override def skipToMatchingEnd: PullProvider.Event = currentEvent match {
    case START_DOCUMENT =>
      currentEvent = Event.END_DOCUMENT
      currentEvent
    case START_ELEMENT =>
      try {
        var skipDepth = 0
        while ( {
          reader.hasNext
        }) {
          val event = reader.next
          if (event == XMLStreamConstants.START_ELEMENT) skipDepth += 1
          else if (event == XMLStreamConstants.END_ELEMENT) if ( {
            skipDepth -= 1; skipDepth + 1
          } == 0) {
            currentEvent = Event.END_ELEMENT
            return currentEvent
          }
        }
      } catch {
        case e: XMLStreamException =>
          throw new XPathException(e)
      }
      throw new IllegalStateException("Element start has no matching element end")
    case _ =>
      throw new IllegalStateException("Cannot call skipToMatchingEnd() except when at start of element or document")
  }

  /**
   * Close the event reader. This indicates that no further events are required.
   * It is not necessary to close an event reader after {@link net.sf.saxon.pull.PullProvider.Event#END_OF_INPUT} has
   * been reported, but it is recommended to close it if reading terminates
   * prematurely. Once an event reader has been closed, the effect of further
   * calls on next() is undefined.
   */
  override def close() = try reader.close()
  catch {
    case e: XMLStreamException =>

    //
  }

  /**
   * Get the NodeName identifying the name of the current node. This method
   * can be used after the {@link net.sf.saxon.pull.PullProvider.Event#START_ELEMENT}, {@link net.sf.saxon.pull.PullProvider.Event#PROCESSING_INSTRUCTION},
   * {@link net.sf.saxon.pull.PullProvider.Event#ATTRIBUTE}, or {@link net.sf.saxon.pull.PullProvider.Event#NAMESPACE} events. With some PullProvider implementations,
   * it can also be used after {@link net.sf.saxon.pull.PullProvider.Event#END_ELEMENT}, but this is not guaranteed.
   * If called at other times, the result is undefined and may result in an IllegalStateException.
   * If called when the current node is an unnamed namespace node (a node representing the default namespace)
   * the returned value is null.
   *
   * @return the NodeName. The NodeName can be used to obtain the prefix, local name,
   *         and namespace URI.
   */
  override def getNodeName = if ((currentEvent eq Event.START_ELEMENT) || (currentEvent eq Event.END_ELEMENT)) {
    val local = reader.getLocalName
    val uri = reader.getNamespaceURI
    // We keep a cache indexed by local name, on the assumption that most of the time, a given
    // local name will only ever be used with the same prefix and URI
    var cached = nameCache.get(local)
    if (cached != null && cached.hasURI(if (uri == null) ""
    else uri) && cached.getPrefix == reader.getPrefix) cached
    else {
      val fp = namePool.allocateFingerprint(uri, local)
      if (uri == null) cached = new NoNamespaceName(local, fp)
      else cached = new FingerprintedQName(reader.getPrefix, uri, local, fp)
      nameCache.put(local, cached)
      cached
    }
  }
  else if (currentEvent eq Event.PROCESSING_INSTRUCTION) {
    val local = reader.getPITarget
    new NoNamespaceName(local)
  }
  else throw new IllegalStateException

  /**
   * Get the string value of the current element, text node, processing-instruction,
   * or top-level attribute or namespace node, or atomic value.
   * <p>In other situations the result is undefined and may result in an IllegalStateException.</p>
   * <p>If the most recent event was a {@link net.sf.saxon.pull.PullProvider.Event#START_ELEMENT}, this method causes the content
   * of the element to be read. The current event on completion of this method will be the
   * corresponding {@link net.sf.saxon.pull.PullProvider.Event#END_ELEMENT}. The next call of next() will return the event following
   * the END_ELEMENT event.</p>
   *
   * @return the String Value of the node in question, defined according to the rules in the
   *         XPath data model.
   */
  @throws[XPathException]
  override def getStringValue: CharSequence = currentEvent match {
    case TEXT =>
      val cs = new CharSlice(reader.getTextCharacters, reader.getTextStart, reader.getTextLength)
      CompressedWhitespace.compress(cs)
    case COMMENT =>
      new CharSlice(reader.getTextCharacters, reader.getTextStart, reader.getTextLength)
    case PROCESSING_INSTRUCTION =>
      val s = reader.getPIData
      // The BEA parser includes the separator space in the value,
      // which isn't part of the XPath data model
      Whitespace.removeLeadingWhitespace(s)
    case START_ELEMENT =>
      var combinedText = null
      try {
        var depth = 0
        while ( {
          reader.hasNext
        }) {
          val event = reader.next
          if (event == XMLStreamConstants.CHARACTERS) {
            if (combinedText == null) combinedText = new FastStringBuffer(FastStringBuffer.C64)
            combinedText.append(reader.getTextCharacters, reader.getTextStart, reader.getTextLength)
          }
          else if (event == XMLStreamConstants.START_ELEMENT) depth += 1
          else if (event == XMLStreamConstants.END_ELEMENT) if ( {
            depth -= 1; depth + 1
          } == 0) {
            currentEvent = Event.END_ELEMENT
            if (combinedText != null) return combinedText.condense
            else return ""
          }
        }
      } catch {
        case e: XMLStreamException =>
          throw new XPathException(e)
      }
    case _ =>
      throw new IllegalStateException("getStringValue() called when current event is " + currentEvent)
  }

  /**
   * Get an atomic value. This call may be used only when the last event reported was
   * ATOMIC_VALUE. This indicates that the PullProvider is reading a sequence that contains
   * a free-standing atomic value; it is never used when reading the content of a node.
   */
  override def getAtomicValue = throw new IllegalStateException

  /**
   * Get the type annotation of the current attribute or element node, or atomic value.
   * The result of this method is undefined unless the most recent event was START_ELEMENT,
   * ATTRIBUTE, or ATOMIC_VALUE.
   *
   * @return the type annotation.
   */
  override def getSchemaType = if (currentEvent eq Event.START_ELEMENT) Untyped.getInstance
  else if (currentEvent eq Event.ATTRIBUTE) BuiltInAtomicType.UNTYPED_ATOMIC
  else null

  /**
   * Get the location of the current event.
   * For an event stream representing a real document, the location information
   * should identify the location in the lexical XML source. For a constructed document, it should
   * identify the location in the query or stylesheet that caused the node to be created.
   * A value of null can be returned if no location information is available.
   */
  override def getSourceLocator = translateLocation(reader.getLocation)

  /**
   * Translate a StAX Location object to a Saxon Locator
   *
   * @param location the StAX Location object
   * @return a Saxon/SAX SourceLocator object
   */
  private def translateLocation(location: Location) = if (location == null) Loc.NONE
  else new Loc(location.getSystemId, location.getLineNumber, location.getColumnNumber)

  /**
   * Get a list of unparsed entities.
   *
   * @return a list of unparsed entities, or null if the information is not available, or
   *         an empty list if there are no unparsed entities. Each item in the list will
   *         be an instance of { @link net.sf.saxon.pull.UnparsedEntity}
   */
  override def getUnparsedEntities: util.List[UnparsedEntity] = {
    if (unparsedEntities == null) return null
    val list = new util.ArrayList[UnparsedEntity](unparsedEntities.size)
    import scala.collection.JavaConversions._
    for (ent <- unparsedEntities) {
      var name = null
      var systemId = null
      var publicId = null
      var baseURI = null
      if (ent.isInstanceOf[EntityDeclaration]) { // This is what we would expect from the StAX API spec
        val ed = ent.asInstanceOf[EntityDeclaration]
        name = ed.getName
        systemId = ed.getSystemId
        publicId = ed.getPublicId
        baseURI = ed.getBaseURI
      }
      else if (ent.getClass.getName == "com.ctc.wstx.ent.UnparsedExtEntity") { // Woodstox 3.0.0 returns this: use introspection to get the data we need
        try {
          val woodstoxClass = ent.getClass
          val noArgClasses = new Array[Class[_]](0)
          val noArgs = new Array[AnyRef](0)
          var method = woodstoxClass.getMethod("getName", noArgClasses)
          name = method.invoke(ent, noArgs).asInstanceOf[String]
          method = woodstoxClass.getMethod("getSystemId", noArgClasses)
          systemId = method.invoke(ent, noArgs).asInstanceOf[String]
          method = woodstoxClass.getMethod("getPublicId", noArgClasses)
          publicId = method.invoke(ent, noArgs).asInstanceOf[String]
          method = woodstoxClass.getMethod("getBaseURI", noArgClasses)
          baseURI = method.invoke(ent, noArgs).asInstanceOf[String]
        } catch {
          case e@(_: NoSuchMethodException | _: IllegalAccessException | _: InvocationTargetException) =>
        }
      }
      if (name != null) {
        if (baseURI != null && systemId != null) try systemId = new URI(baseURI).resolve(systemId).toString
        catch {
          case err: URISyntaxException =>
        }
        val ue = new UnparsedEntity
        ue.setName(name)
        ue.setSystemId(systemId)
        ue.setPublicId(publicId)
        ue.setBaseURI(baseURI)
        list.add(ue)
      }
    }
    list
  }

  /**
   * Error reporting class for StAX parser errors
   */
  private class StaxErrorReporter extends XMLReporter {
    override def report(message: String, errorType: String, relatedInformation: Any, location: Location) = {
      val err = new XmlProcessingIncident("Error reported by XML parser: " + message + " (" + errorType + ')')
      err.setLocation(translateLocation(location))
      pipe.getErrorReporter.report(err)
    }
  }

}