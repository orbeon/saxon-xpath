////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.model.ErrorType
import net.sf.saxon.model.ItemType
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.value.SequenceType

/**
 * A SimpleStepExpression is a special case of a SlashExpression in which the
 * start expression selects a single item (or nothing), and the step expression is
 * a simple AxisExpression. This is designed to avoid the costs of creating a new
 * dynamic context for expressions (common in XQuery) such as
 * for $b in EXPR return $b/title
 */
object SimpleStepExpression {
  private val STEP_ROLE = new OperandRole(OperandRole.USES_NEW_FOCUS | OperandRole.HIGHER_ORDER, OperandUsage.TRANSMISSION, SequenceType.ANY_SEQUENCE)
}

final class SimpleStepExpression(val start: Expression, val step: Expression) extends SlashExpression(start, step) {
  if (!step.isInstanceOf[AxisExpression]) throw new IllegalArgumentException

  override protected def getOperandRole(arg: Int) = if (arg == 0) OperandRole.FOCUS_CONTROLLING_SELECT
  else SimpleStepExpression.STEP_ROLE

  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    getLhs.typeCheck(visitor, contextInfo)
    val selectType = getStart.getItemType
    if (selectType eq ErrorType.getInstance) return Literal.makeEmptySequence
    val cit = visitor.getConfiguration.makeContextItemStaticInfo(selectType, false)
    cit.setContextSettingExpression(getStart)
    getRhs.typeCheck(visitor, cit)
    if (!getStep.isInstanceOf[AxisExpression]) {
      if (Literal.isEmptySequence(getStep)) return getStep
      val se = new SlashExpression(getStart, getStep)
      ExpressionTool.copyLocationInfo(this, se)
      return se
    }
    if (getStart.isInstanceOf[ContextItemExpression] && AxisInfo.isForwards(getStep.asInstanceOf[AxisExpression].getAxis)) return getStep
    this
  }

  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo) = this

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings
   */
  override def copy(rebindings: RebindingMap) = {
    val exp = new SimpleStepExpression(getStart.copy(rebindings), getStep.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, exp)
    exp
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Evaluate the expression, returning an iterator over the result
   *
   * @param context the evaluation context
   */
  @throws[XPathException]
  override def iterate(context: XPathContext): SequenceIterator = {
    var origin = null
    try origin = getStart.evaluateItem(context).asInstanceOf[NodeInfo]
    catch {
      case e: XPathException =>
        if ("XPDY0002" == e.getErrorCodeLocalPart && !e.hasBeenReported) throw new XPathException("The context item for axis step " + toShortString + " is absent", "XPDY0002", getLocation)
        else throw e
    }
    if (origin == null) return EmptyIterator.getInstance
    getStep.asInstanceOf[AxisExpression].iterate(origin)
  }

  override def getExpressionName = "simpleStep"
}