////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon

import net.sf.saxon.expr.Component
import net.sf.saxon.expr.accum.Accumulator
import net.sf.saxon.expr.instruct._
import net.sf.saxon.functions.ExecutableFunctionLibrary
import net.sf.saxon.functions.FunctionLibrary
import net.sf.saxon.functions.FunctionLibraryList
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.OutputURIResolver
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.s9api.HostLanguage
import net.sf.saxon.serialize.SerializationProperties
import net.sf.saxon.style.Compilation
import net.sf.saxon.style.StylesheetPackage
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans._
import net.sf.saxon.trans.rules.RuleManager
import java.net.URI
import java.net.URISyntaxException
import java.util._

/**
 * This <b>PreparedStylesheet</b> class represents a Stylesheet that has been
 * prepared for execution (or "compiled").
 *
 * <p>Note that the PreparedStylesheet object does not contain a reference to the source stylesheet
 * tree (rooted at an XSLStyleSheet object). This allows the source tree to be garbage-collected
 * when it is no longer required.</p>
 *
 * <p>The PreparedStylesheet in XSLT 3.0 represents the set of all packages making up an executable
 * stylesheet.</p>
 */
class PreparedStylesheet(val compilation: Compilation)

/**
 * Constructor - deliberately protected
 *
 * @param compilation Compilation options
 */
  extends Executable(compilation.getConfiguration) {
  val compilerInfo = compilation.getCompilerInfo
  setHostLanguage(HostLanguage.XSLT)
  if (compilerInfo.isSchemaAware) {
    val localLic = compilation.getPackageData.getLocalLicenseId
    getConfiguration.checkLicensedFeature(Configuration.LicenseFeature.ENTERPRISE_XSLT, "schema-aware XSLT", localLic)
    schemaAware = true
  }
  defaultInitialMode = compilerInfo.getDefaultInitialMode
  defaultInitialTemplate = compilerInfo.getDefaultInitialTemplate
  messageReceiverClassName = compilerInfo.getMessageReceiverClassName
  outputURIResolver = compilerInfo.getOutputURIResolver
  compileTimeParams = compilation.getParameters
  private var nextStylesheetCache = null
  // definitions of template rules (XSLT only)
  private var ruleManager = null
  // index of named templates.
  private var namedTemplateTable = null
  // Table of components declared in this package or imported from used packages. Key is the symbolic identifier of the
  // component; value is the component itself. Hidden components are not included in this table because their names
  // need not be unique, and because they are not available for reference by name.
  private var componentIndex = null
  private var defaultInitialTemplate = null
  private var defaultInitialMode = null
  private var messageReceiverClassName = null
  private var outputURIResolver = null
  private var compileTimeParams = null

  /**
   * Make a Controller from this stylesheet object.
   *
   * @return the new Controller
   * @see net.sf.saxon.Controller
   */
  def newController = {
    val config = getConfiguration
    val c = new XsltController(config, this)
    c.setMessageReceiverClassName(messageReceiverClassName)
    c.setOutputURIResolver(outputURIResolver)
    if (defaultInitialMode != null) try c.setInitialMode(defaultInitialMode)
    catch {
      case e: XPathException =>

      // ignore the error if the default initial mode is not defined
    }
    c
  }

  /**
   * Get the parameters that were set at compile time. These will generally be static parameters,
   * but it is also permitted to set non-static parameters at compile time.
   *
   * @return the parameters that were set prior to XSLT compilation
   */
  def getCompileTimeParams = compileTimeParams

  /**
   * Check that all required parameters have been supplied. Also checks that the supplied
   * parameters dynamically do not conflict with parameters supplied statically. Used in XSLT only.
   *
   * @param params the set of parameters that have been supplied dynamically to the transformer
   *               (null represents an empty set).
   * @throws XPathException if there is a required parameter for which no value has been supplied
   */
  @throws[XPathException]
  override def checkSuppliedParameters(params: GlobalParameterSet) = {
    import scala.collection.JavaConversions._
    for (entry <- getGlobalParameters.entrySet) {
      if (entry.getValue.isRequiredParam) {
        val req = entry.getKey
        if (getCompileTimeParams.get(req) == null && (params == null || params.get(req) == null)) {
          val err = new XPathException("No value supplied for required parameter " + req.getDisplayName)
          err.setErrorCode(if (getHostLanguage eq HostLanguage.XQUERY) "XPDY0002"
          else "XTDE0050")
          throw err
        }
      }
    }
    import scala.collection.JavaConversions._
    for (name <- params.getKeys) {
      val decl = getGlobalParameter(name)
      if (decl != null && decl.isStatic) throw new XPathException("Parameter $" + name.getDisplayName + " cannot be supplied dynamically because it is declared as static")
      if (compileTimeParams.containsKey(name)) throw new XPathException("Parameter $" + name.getDisplayName + " cannot be supplied dynamically because a value was already supplied at compile time")
    }
    import scala.collection.JavaConversions._
    for (name <- compileTimeParams.getKeys) {
      params.put(name, compileTimeParams.get(name))
    }
  }

  override def getTopLevelPackage = super.getTopLevelPackage.asInstanceOf[StylesheetPackage]

  /**
   * Set the RuleManager that handles template rules
   *
   * @param rm the RuleManager containing details of all the template rules
   */
  def setRuleManager(rm: RuleManager) = ruleManager = rm

  /**
   * Get the RuleManager which handles template rules
   *
   * @return the RuleManager registered with setRuleManager
   */
  def getRuleManager = ruleManager

  /**
   * Register the named template with a given name
   *
   * @param templateName the name of a named XSLT template
   * @param template     the template
   */
  def putNamedTemplate(templateName: StructuredQName, template: NamedTemplate) = {
    if (namedTemplateTable == null) namedTemplateTable = new util.HashMap[StructuredQName, NamedTemplate](32)
    namedTemplateTable.put(templateName, template)
  }

  /**
   * Get the default initial template name
   *
   * @return the default initial template name
   */
  def getDefaultInitialTemplateName = defaultInitialTemplate

  /**
   * Register the index of components
   *
   * @param index the component index
   */
  def setComponentIndex(index: util.Map[SymbolicName, Component]) = componentIndex = index

  def getComponent(name: SymbolicName) = componentIndex.get(name)

  /**
   * Ask whether a mode is eligible for invoking from outside the stylesheet
   *
   * @param component the component
   * @return true if the component can be referenced from the calling application
   */
  def isEligibleInitialMode(component: Component.M): Boolean = {
    if (component == null) return false
    // Rules 1 and 4
    if ((component.getVisibility eq Visibility.PUBLIC) || (component.getVisibility eq Visibility.FINAL)) return true
    // Rule 2
    if (component.getActor.isUnnamedMode) return true
    // Rule 3
    val top = getTopLevelPackage
    if (component.getActor.getModeName == top.getDefaultMode) return true
    // Rule 5 (but see also bug 30405)
    if (!top.isDeclaredModes && !component.getActor.isEmpty() && ((component.getVisibilityProvenance eq VisibilityProvenance.DEFAULTED) || (component.getVisibility ne Visibility.PRIVATE))) return true
    false
  }

  /**
   * Explain the expression tree for named templates in a stylesheet
   *
   * @param presenter destination for the explanatory output
   * @throws XPathException if writing to the output fails
   */
  @throws[XPathException]
  def explainNamedTemplates(presenter: ExpressionPresenter) = {
    presenter.startElement("namedTemplates")
    if (namedTemplateTable != null) {
      import scala.collection.JavaConversions._
      for (t <- namedTemplateTable.values) {
        presenter.startElement("template")
        presenter.emitAttribute("name", t.getTemplateName.getDisplayName)
        presenter.emitAttribute("line", t.getLineNumber + "")
        presenter.emitAttribute("module", t.getSystemId)
        if (t.getBody != null) t.getBody.`export`(presenter)
        presenter.endElement
      }
    }
    presenter.endElement
  }

  /**
   * Get the properties for xsl:output, including character maps.  The object returned will
   * be a clone of the internal values, and thus it can be mutated
   * without affecting the value held in this {@code PreparedStylesheet}.
   * <p>This method gets the output properties for the unnamed output
   * format in the stylesheet.</p>
   *
   * @return An OutputProperties object reflecting the output properties defined
   *         for the default (unnamed) output format in the stylesheet. It may
   *         be mutated and supplied to the setOutputProperties() method of the
   *         Transformer, without affecting other transformations that use the
   *         same stylesheet.
   * @see javax.xml.transform.Transformer#setOutputProperties
   */
  def getDeclaredSerializationProperties = {
    val details = getPrimarySerializationProperties
    new SerializationProperties(new Properties(details.getProperties), getCharacterMapIndex)
  }

  /**
   * Get a "next in chain" stylesheet. This method is intended for internal use.
   *
   * @param href    the relative URI of the next-in-chain stylesheet
   * @param baseURI the baseURI against which this relativeURI is to be resolved
   * @return the cached stylesheet if present in the cache, or null if not
   */
  /*@Nullable*/ def getCachedStylesheet(href: String, baseURI: String) = {
    var abs = null
    try abs = new URI(baseURI).resolve(href)
    catch {
      case err: URISyntaxException =>

      //
    }
    var result = null
    if (abs != null && nextStylesheetCache != null) result = nextStylesheetCache.get(abs)
    result
  }

  /**
   * Save a "next in chain" stylesheet in compiled form, so that it can be reused repeatedly.
   * This method is intended for internal use.
   *
   * @param href    the relative URI of the stylesheet
   * @param baseURI the base URI against which the relative URI is resolved
   * @param pss     the prepared stylesheet object to be cached
   */
  def putCachedStylesheet(href: String, baseURI: String, pss: PreparedStylesheet) = {
    var abs = null
    try abs = new URI(baseURI).resolve(href)
    catch {
      case err: URISyntaxException =>
    }
    if (abs != null) {
      if (nextStylesheetCache == null) nextStylesheetCache = new util.HashMap[URI, PreparedStylesheet](4)
      nextStylesheetCache.put(abs, pss)
    }
  }

  /**
   * Produce an XML representation of the compiled and optimized stylesheet,
   * as a human-readable entity
   *
   * @param presenter defines the destination and format of the output
   * @throws XPathException if output fails
   */
  @throws[XPathException]
  def explain(presenter: ExpressionPresenter) = {
    presenter.startElement("stylesheet")
    presenter.namespace("fn", NamespaceConstant.FN)
    presenter.namespace("xs", NamespaceConstant.SCHEMA)
    explainGlobalVariables(presenter)
    ruleManager.explainTemplateRules(presenter)
    explainNamedTemplates(presenter)
    presenter.startElement("accumulators")
    import scala.collection.JavaConversions._
    for (acc <- getTopLevelPackage.getAccumulatorRegistry.getAllAccumulators) {
      acc.`export`(presenter)
    }
    presenter.endElement
    val libList = getFunctionLibrary
    val libraryList = libList.getLibraryList
    presenter.startElement("functions")
    import scala.collection.JavaConversions._
    for (lib <- libraryList) {
      if (lib.isInstanceOf[ExecutableFunctionLibrary]) {
        val f = lib.asInstanceOf[ExecutableFunctionLibrary].iterateFunctions
        while ( {
          f.hasNext
        }) {
          val func = f.next.asInstanceOf[UserFunction]
          func.`export`(presenter)
        }
      }
    }
    presenter.endElement
    presenter.endElement
    presenter.close
  }
}