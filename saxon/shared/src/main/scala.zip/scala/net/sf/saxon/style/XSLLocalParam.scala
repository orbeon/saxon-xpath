////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.SuppliedParameterReference
import net.sf.saxon.expr.instruct.LocalParam
import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.StandardNames
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace
import java.util

/**
 * An xsl:param element representing a local parameter (template or function parameter) in the stylesheet. <br>
 * The xsl:param element has mandatory attribute name and optional attributes
 * select, required, as, ...
 */
class XSLLocalParam extends XSLGeneralVariable {
  private val permittedAttributes = util.EnumSet.of(SourceBinding.BindingProperty.TUNNEL, SourceBinding.BindingProperty.REQUIRED, SourceBinding.BindingProperty.SELECT, SourceBinding.BindingProperty.AS)
  /*@Nullable*/ private[style] var conversion = null
  private var slotNumber = -9876 // initial value designed solely to show up when debugging
  private var compiledParam = null
  private var prepared = false

  /**
   * Ask whether this element contains a binding for a variable with a given name; and if it does,
   * return the source binding information
   *
   * @param name the variable name
   * @return the binding information if this element binds a variable of this name; otherwise null
   */
  override def getBindingInformation(name: StructuredQName) = if (name == sourceBinding.getVariableQName) sourceBinding
  else null

  /**
   * Get the slot number allocated to this variable (its position in the stackframe)
   *
   * @return the allocated slot number
   */
  def getSlotNumber = slotNumber

  override def prepareAttributes() = if (!prepared) {
    prepared = true
    sourceBinding.setProperty(SourceBinding.BindingProperty.PARAM, true)
    if (getParent.isInstanceOf[XSLFunction]) {
      permittedAttributes.remove(SourceBinding.BindingProperty.SELECT)
      sourceBinding.setProperty(SourceBinding.BindingProperty.DISALLOWS_CONTENT, true)
    }
    sourceBinding.prepareAttributes(permittedAttributes)
    if (sourceBinding.hasProperty(SourceBinding.BindingProperty.TUNNEL) && !getParent.isInstanceOf[XSLTemplate]) compileError("For attribute 'tunnel' within an " + getParent.getDisplayName + " parameter, the only permitted value is 'no'", "XTSE0020")
    if (getParent.isInstanceOf[XSLFunction] && getAttributeValue("", "required") != null) if (!sourceBinding.hasProperty(SourceBinding.BindingProperty.REQUIRED)) compileError("For attribute 'required' within an " + getParent.getDisplayName + " parameter, the only permitted value is 'yes'", "XTSE0020")
  }

  @throws[XPathException]
  def prepareTemplateSignatureAttributes() = if (!prepared) {
    sourceBinding.setProperty(SourceBinding.BindingProperty.PARAM, true)
    sourceBinding.prepareTemplateSignatureAttributes()
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    val name = sourceBinding.getVariableQName
    val parent = getParent
    if (!((parent.isInstanceOf[StyleElement]) && (parent.asInstanceOf[StyleElement]).mayContainParam)) compileError("xsl:param must be immediately within a template, function or stylesheet", "XTSE0010")
    if (hasChildNodes && getParent.isInstanceOf[XSLFunction]) compileError("Function parameters cannot have a default value", "XTSE0760")
    iterateAxis(AxisInfo.PRECEDING_SIBLING).forEachOrFail((node: Item) => {
      def foo(node: Item) = {
        if (node.isInstanceOf[XSLLocalParam]) if (name == node.asInstanceOf[XSLLocalParam].sourceBinding.getVariableQName) compileError("The name of the parameter is not unique", "XTSE0580")
        else if (node.isInstanceOf[StyleElement] && node.asInstanceOf[StyleElement].getFingerprint != StandardNames.XSL_CONTEXT_ITEM) compileError("xsl:param must not be preceded by other instructions", "XTSE0010")
        else { // it must be a text node; allow it if all whitespace
          if (!Whitespace.isWhite(node.getStringValueCS)) compileError("xsl:param must not be preceded by text", "XTSE0010")
        }
      }

      foo(node)
    })
    val p = getContainingSlotManager
    if (p == null) compileError("Local variable must be declared within a template or function", "XTSE0010")
    else slotNumber = p.allocateSlotNumber(name)
    if (sourceBinding.hasProperty(SourceBinding.BindingProperty.REQUIRED)) {
      if (sourceBinding.getSelectExpression != null) { // NB, we do this test before setting the default select attribute
        compileError("The select attribute must be omitted when required='yes'", "XTSE0010")
      }
      if (hasChildNodes) compileError("A parameter specifying required='yes' must have empty content", "XTSE0010")
    }
    super.validate(decl)
  }

  def isTunnelParam = sourceBinding.hasProperty(SourceBinding.BindingProperty.TUNNEL)

  def isRequiredParam = sourceBinding.hasProperty(SourceBinding.BindingProperty.REQUIRED)

  @throws[XPathException]
  override def fixupReferences() = {
    sourceBinding.fixupReferences(null)
    super.fixupReferences()
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = { //        if (!"iterate".equals(getParent().getLocalPart()) &&
    //                sourceBinding.getReferences().size() == 0 && !sourceBinding.hasProperty(SourceBinding.REQUIRED)) {
    //            return null;
    //        }
    if (getParent.isInstanceOf[XSLFunction]) { // Do nothing. We did everything necessary while compiling the XSLFunction element.
      null
    }
    else {
      val declaredType = getRequiredType
      val name = sourceBinding.getVariableQName
      val slot = getSlotNumber
      if (declaredType != null) {
        val pref = new SuppliedParameterReference(slot)
        pref.setRetainedStaticContext(makeRetainedStaticContext)
        pref.setLocation(allocateLocation)
        val role = new RoleDiagnostic(RoleDiagnostic.PARAM, name.getDisplayName, 0)
        //role.setSourceLocator(new ExpressionLocation(this));
        role.setErrorCode("XTTE0590")
        conversion = exec.getConfiguration.getTypeChecker(false).staticTypeCheck(pref, declaredType, role, makeExpressionVisitor)
      }
      sourceBinding.handleSequenceConstructor(exec, decl)
      val binding = new LocalParam
      binding.setSelectExpression(sourceBinding.getSelectExpression)
      binding.setConversion(conversion)
      binding.setVariableQName(name)
      binding.setSlotNumber(slot)
      binding.setRequiredType(getRequiredType)
      binding.setRequiredParam(sourceBinding.hasProperty(SourceBinding.BindingProperty.REQUIRED))
      binding.setImplicitlyRequiredParam(sourceBinding.hasProperty(SourceBinding.BindingProperty.IMPLICITLY_REQUIRED))
      binding.setTunnel(sourceBinding.hasProperty(SourceBinding.BindingProperty.TUNNEL))
      sourceBinding.fixupBinding(binding)
      compiledParam = binding
    }
  }

  def getCompiledParam = compiledParam

  /**
   * Get the static type of the parameter. This is the declared type, because we cannot know
   * the actual value in advance.
   */
  def getRequiredType = {
    val declaredType = sourceBinding.getDeclaredType
    if (declaredType != null) declaredType
    else SequenceType.ANY_SEQUENCE
  }
}