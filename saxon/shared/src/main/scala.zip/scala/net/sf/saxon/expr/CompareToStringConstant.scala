////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.expr.parser.Token
import net.sf.saxon.expr.sort.AtomicComparer
import net.sf.saxon.expr.sort.CodepointCollatingComparer
import net.sf.saxon.expr.sort.CodepointCollator
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException

/**
 * This class implements a comparison of a computed value to a string constant using one of the operators
 * eq, ne, lt, gt, le, ge. The semantics are identical to ValueComparison, with code-point collation,
 * but this is a fast path for an important common case.
 */
class CompareToStringConstant(val operand: Expression, val operator: Int, var comparand: String)

/**
 * Create the expression
 *
 * @param operand  the operand to be compared with an integer constant. This must
 *                 have a static type of NUMERIC, and a cardinality of EXACTLY ONE
 * @param operator the comparison operator,
 *                 one of { @link Token#FEQ}, { @link Token#FNE}, { @link Token#FGE},
 *                                { @link Token#FGT}, { @link Token#FLE}, { @link Token#FLT}
 * @param comparand the integer constant
 */
  extends CompareToConstant(operand) {
  this.operator = operator

  /**
   * Get the integer value on the rhs of the expression
   *
   * @return the integer constant
   */
  def getComparand = comparand

  /**
   * Get the effective right-hand-side expression (so that general logic for comparison expressions
   * can be used)
   *
   * @return a Literal representing the RHS expression
   */
  override def getRhsExpression = new StringLiteral(comparand)

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be re-bound
   */
  /*@NotNull*/ override def copy(rebindings: RebindingMap) = {
    val c2 = new CompareToStringConstant(getLhsExpression.copy(rebindings), operator, comparand)
    ExpressionTool.copyLocationInfo(this, c2)
    c2
  }

  /**
   * Is this expression the same as another expression?
   *
   * @param other the expression to be compared with this one
   * @return true if the two expressions are statically equivalent
   */
  override def equals(other: Any) = other.isInstanceOf[CompareToStringConstant] && other.asInstanceOf[CompareToStringConstant].getLhsExpression.isEqual(getLhsExpression) && other.asInstanceOf[CompareToStringConstant].comparand == comparand && other.asInstanceOf[CompareToStringConstant].operator == operator

  /**
   * Hashcode supporting equals()
   */
  override def computeHashCode = {
    val h = 0x884b12a0
    h + getLhsExpression.hashCode ^ comparand.hashCode
  }

  /**
   * Get the effective boolean value of the expression. This returns false if the value
   * is the empty sequence, a zero-length string, a number equal to zero, or the boolean
   * false. Otherwise it returns true.
   *
   * @param context The context in which the expression is to be evaluated
   * @return the effective boolean value
   * @throws XPathException
   * if any dynamic error occurs evaluating the
   * expression
   */
  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext) = {
    val s = getLhsExpression.evaluateAsString(context)
    val c = CodepointCollator.compareCS(s, comparand)
    interpretComparisonResult(c)
  }

  override def computeCardinality = StaticProperty.EXACTLY_ONE

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in export() output displaying the expression.
   */
  override def getExpressionName = "compareToString"

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("compareToString", this)
    destination.emitAttribute("op", Token.tokens(operator))
    destination.emitAttribute("val", comparand)
    getLhsExpression.`export`(destination)
    destination.endElement
  }

  /**
   * <p>The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form.</p>
   * <p>For subclasses of Expression that represent XPath expressions, the result should always be a string that
   * parses as an XPath 3.0 expression</p>
   *
   * @return a representation of the expression as a string
   */
  override def toString = ExpressionTool.parenthesize(getLhsExpression) + " " + Token.tokens(operator) + " \"" + comparand + "\""

  /**
   * Produce a short string identifying the expression for use in error messages
   *
   * @return a short string, sufficient to identify the expression
   */
  override def toShortString = getLhsExpression.toShortString + " " + Token.tokens(operator) + " \"" + comparand + "\""

  /**
   * Get the AtomicComparer used to compare atomic values. This encapsulates any collation that is used
   */
  override def getAtomicComparer = {
    CodepointCollatingComparer.getInstance
    // Note: this treats NaN=NaN as true, but it doesn't matter, because the rhs will never be NaN.
  }
}