////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.XPathException

/**
 * This class defines common behaviour across xsl:variable, xsl:param, and xsl:with-param
 */
abstract class XSLGeneralVariable extends StyleElement {
  protected var sourceBinding = new SourceBinding(this)

  /**
   * Get the source binding object that holds information about the declared variable.
   */
  def getSourceBinding = sourceBinding

  def getVariableQName = sourceBinding.getVariableQName

  override def getObjectName = sourceBinding.getVariableQName

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  /**
   * Test whether this is a global variable or parameter
   *
   * @return true if this is global
   */
  def isGlobal = {
    isTopLevel
    // might be called before the "global" field is initialized
  }

  /**
   * Check that the variable is not already declared, and allocate a slot number
   *
   * @param decl the declaration being validated. A single XSLVariableDeclaration object may represent
   *             multiple declarations if it appears in a stylesheet module that is included/imported more than once
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = sourceBinding.validate()

  /**
   * Hook to allow additional validation of a parent element immediately after its
   * children have been validated.
   */
  @throws[XPathException]
  override def postValidate() = sourceBinding.postValidate()
}