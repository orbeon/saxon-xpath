////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.LetExpression
import net.sf.saxon.expr.instruct._
import net.sf.saxon.expr.parser.CodeInjector
import net.sf.saxon.functions.Trace
import net.sf.saxon.lib.NamespaceConstant

/**
 * A Simple trace listener for XSLT that writes messages (by default) to System.err
 */
object XSLTTraceListener {
  def tagName(info: Traceable) = if (info.isInstanceOf[Expression]) {
    val expr = info.asInstanceOf[Expression]
    if (expr.isInstanceOf[FixedElement]) "LRE"
    else if (expr.isInstanceOf[FixedAttribute]) "ATTR"
    else if (expr.isInstanceOf[LetExpression]) "xsl:variable"
    else if (expr.isCallOn(classOf[Trace])) "fn:trace"
    else expr.getExpressionName
  }
  else if (info.isInstanceOf[UserFunction]) "xsl:function"
  else if (info.isInstanceOf[TemplateRule]) "xsl:template"
  else if (info.isInstanceOf[NamedTemplate]) "xsl:template"
  else if (info.isInstanceOf[GlobalParam]) "xsl:param"
  else if (info.isInstanceOf[GlobalVariable]) "xsl:variable"
  else if (info.isInstanceOf[Trace]) "fn:trace"
  else "misc"
}

class XSLTTraceListener extends AbstractTraceListener {
  override def getCodeInjector = new XSLTTraceCodeInjector

  /**
   * Generate attributes to be included in the opening trace element
   */
  override protected def getOpeningAttributes = "xmlns:xsl=\"" + NamespaceConstant.XSLT + '\"'

  /**
   * Get the trace element tagname to be used for a particular construct. Return null for
   * trace events that are ignored by this trace listener.
   *
   * @param info
   */
  /*@Nullable*/ override protected def tag(info: Traceable) = XSLTTraceListener.tagName(info)
}