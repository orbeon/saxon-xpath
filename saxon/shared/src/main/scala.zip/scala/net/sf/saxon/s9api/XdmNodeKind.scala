////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.model.Type

/**
 * Enumeration class defining the seven kinds of node defined in the XDM model
 */
object XdmNodeKind extends Enumeration {
  type XdmNodeKind = Value
  val DOCUMENT, ELEMENT, ATTRIBUTE, TEXT, COMMENT, PROCESSING_INSTRUCTION, NAMESPACE = Value
  private var number = 0d ef this (number: Int) {
    this ()
    this.number = number
  }
  protected

  def getNumber = number

  /**
   * Get the node kind corresponding to one of the integer constants in class
   * {@link net.sf.saxon.model.Type}, for example {@link Type#ELEMENT}. These integer
   * constants are chosen to be consistent with those used in DOM, though the semantics
   * of the different node kinds are slightly different.
   *
   * @param type the integer type code, for example { @link Type#ELEMENT} or { @link Type#TEXT}
   * @return the corresponding { @link XdmNodeKind};
   * @since 10.0
   */
  def forType(`type`: Int) = `type` match {
    case Type.DOCUMENT =>
      DOCUMENT
    case Type.ELEMENT =>
      ELEMENT
    case Type.ATTRIBUTE =>
      ATTRIBUTE
    case Type.TEXT =>
      TEXT
    case Type.COMMENT =>
      COMMENT
    case Type.PROCESSING_INSTRUCTION =>
      PROCESSING_INSTRUCTION
    case Type.NAMESPACE =>
      NAMESPACE
    case _ =>
      throw new IllegalArgumentException
  }
}