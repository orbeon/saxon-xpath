////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.om.FocusIterator
import net.sf.saxon.om.Item
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value._

/**
 * A FilterIterator filters an input sequence using a filter expression. Note that a FilterIterator
 * is not used where the filter is a constant number (PositionFilter is used for this purpose instead),
 * so this class does no optimizations for numeric predicates.
 */
object FilterIterator {
  @throws[XPathException]
  def testPredicateValue(iterator: SequenceIterator, position: Long, filter: Expression): Boolean = {
    val first = iterator.next
    if (first == null) return false
    if (first.isInstanceOf[NodeInfo]) true
    else if (first.isInstanceOf[BooleanValue]) {
      if (iterator.next != null) ExpressionTool.ebvError("a sequence of two or more items starting with a boolean", filter)
      first.asInstanceOf[BooleanValue].getBooleanValue
    }
    else if (first.isInstanceOf[StringValue]) {
      if (iterator.next != null) ExpressionTool.ebvError("a sequence of two or more items starting with a string", filter)
      first.getStringValueCS.length != 0
    }
    else if (first.isInstanceOf[Int64Value]) {
      if (iterator.next != null) ExpressionTool.ebvError("a sequence of two or more items starting with a numeric value", filter)
      first.asInstanceOf[Int64Value].longValue == position
    }
    else if (first.isInstanceOf[NumericValue]) {
      if (iterator.next != null) ExpressionTool.ebvError("a sequence of two or more items starting with a numeric value", filter)
      first.asInstanceOf[NumericValue].compareTo(position) == 0
    }
    else if (first.isInstanceOf[AtomicValue]) {
      ExpressionTool.ebvError("a sequence starting with an atomic value of type " + first.asInstanceOf[AtomicValue].getPrimitiveType.getDisplayName + " (" + first.toShortString + ")", filter)
      false
    }
    else {
      ExpressionTool.ebvError("a sequence starting with " + first.getGenre.getDescription + " (" + first.toShortString + ")", filter)
      false
    }
  }

  /**
   * Subclass to handle the common special case where it is statically known
   * that the filter cannot return a numeric value
   */
  final class NonNumeric(val base: SequenceIterator, val filter: Expression, val context: XPathContext)

  /**
   * Create a CompiledFilterIterator for the situation where it is known that the filter
   * expression will never evaluate to a number value. For this case we can simply
   * use the effective boolean value of the predicate
   *
   * @param base    iterator over the sequence to be filtered
   * @param filter  the filter expression
   * @param context the current context (for evaluating the filter expression as a whole).
   *                A new context will be created to evaluate the predicate.
   */
    extends FilterIterator(base, filter, context) {
    /**
     * Determine whether the context item matches the filter predicate
     */
    @throws[XPathException]
    override protected def matches = filter.effectiveBooleanValue(filterContext)
  }

}

class FilterIterator(val base: SequenceIterator, var filter: Expression, val context: XPathContext)

/**
 * Constructor
 *
 * @param base    An iteration of the items to be filtered
 * @param filter  The expression defining the filter predicate
 * @param context The context in which the expression is being evaluated
 */
  extends SequenceIterator {
  filterContext = context.newMinorContext
  this.baseValue = filterContext.trackFocus(baseValue)
  protected var base = null
  protected var filterContext = null

  /**
   * Set the base iterator
   *
   * @param base    the iterator over the sequence to be filtered
   * @param context the context in which the (outer) filter expression is evaluated
   */
  def setSequence(base: SequenceIterator, context: XPathContext) = {
    filterContext = context.newMinorContext
    this.base = filterContext.trackFocus(base)
  }

  /**
   * Get the next item if there is one
   */
  @throws[XPathException]
  override def next = getNextMatchingItem

  /**
   * Get the next item in the base sequence that matches the filter predicate
   * if there is such an item, or null if not.
   *
   * @return the next item that matches the predicate
   * @throws XPathException if a dynamic error occurs
   */
  @throws[XPathException]
  protected def getNextMatchingItem: Item = {
    var next = null
    while ( {
      (next = base.next) != null
    }) if (matches) return next
    null
  }

  /**
   * Determine whether the context item matches the filter predicate
   *
   * @return true if the context item matches
   * @throws XPathException if an error occurs evaluating the match
   */
  @throws[XPathException]
  protected def matches = { // This code is carefully designed to avoid reading more items from the
    // iteration of the filter expression than are absolutely essential.
    // The code is almost identical to the code in ExpressionTool#effectiveBooleanValue
    // except for the handling of a numeric result
    val iterator = filter.iterate(filterContext)
    FilterIterator.testPredicateValue(iterator, base.position, filter)
  }

  override def close() = base.close()
}