////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.om.Item
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.ArrayIterator
import net.sf.saxon.value.Cardinality

/**
 * CardinalityCheckingIterator returns the items in an underlying sequence
 * unchanged, but checks that the number of items conforms to the required
 * cardinality. Because cardinality checks are required to take place even
 * if the consumer of the sequence does not require all the items, we read
 * the first two items at initialization time. This is sufficient to perform
 * the checks; after that we can simply return the items from the base sequence.
 */
final class CardinalityCheckingIterator @throws[XPathException]
(var base: SequenceIterator, val requiredCardinality: Int, val role: RoleDiagnostic, var locator: Location)

/**
 * Construct an CardinalityCheckingIterator that will return the same items as the base sequence,
 * checking how many there are
 *
 * @param base                the base iterator
 * @param requiredCardinality the required Cardinality
 * @param role                information for use if a failure occurs
 * @param locator             the location in the source stylesheet or query
 * @throws XPathException if a failure is detected
 */
  extends SequenceIterator {
  first = base.next
  if (first == null) if (!Cardinality.allowsZero(requiredCardinality)) typeError("An empty sequence is not allowed as the " + role.getMessage, role.getErrorCode)
  else {
    if (requiredCardinality == StaticProperty.EMPTY) typeError("The only value allowed for the " + role.getMessage + " is an empty sequence", role.getErrorCode)
    second = base.next
    if (second != null && !Cardinality.allowsMany(requiredCardinality)) {
      val leaders = Array[Item](first, second)
      typeError("A sequence of more than one item is not allowed as the " + role.getMessage + CardinalityChecker.depictSequenceStart(new ArrayIterator[Item](leaders), 2), role.getErrorCode)
    }
  }
  /*@Nullable*/ private var first = null
  private var second = null
  private var position = 0

  @throws[XPathException]
  override def next: Item = {
    if (position < 2) if (position == 0) {
      val current = first
      position = if (first == null) -1
      else 1
      return current
    }
    else if (position == 1) {
      val current = second
      position = if (second == null) -1
      else 2
      return current
    }
    else { // position == -1
      return null
    }
    val current = base.next
    if (current == null) position = -1
    else position += 1
    current
  }

  override def close() = base.close()

  @throws[XPathException]
  private def typeError(message: String, errorCode: String) = {
    val e = new XPathException(message, errorCode, locator)
    e.setIsTypeError(!errorCode.startsWith("FORG"))
    throw e
  }
}