////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.model.ItemType
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.Item
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.pattern._
import net.sf.saxon.trans.XPathException

/**
 * A FirstItemExpression returns the first item in the sequence returned by a given
 * base expression
 */
object FirstItemExpression {
  /**
   * Static factory method
   *
   * @param base A sequence expression denoting sequence whose first item is to be returned
   * @return the FirstItemExpression, or an equivalent
   */
    def makeFirstItemExpression(base: Expression) = if (base.isInstanceOf[FirstItemExpression]) base
    else new FirstItemExpression(base)
}

final class FirstItemExpression private(val base: Expression)

/**
 * Private Constructor
 *
 * @param base A sequence expression denoting sequence whose first item is to be returned
 */
  extends SingleItemFilter(base) {
  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings
   */
  /*@NotNull*/ override def copy(rebindings: RebindingMap) = {
    val e2 = new FirstItemExpression(getBaseExpression.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, e2)
    e2
  }

  /**
   * Convert this expression to an equivalent XSLT pattern
   *
   * @param config the Saxon configuration
   * @return the equivalent pattern
   * @throws net.sf.saxon.trans.XPathException
   * if conversion is not possible
   */
  @throws[XPathException]
  override def toPattern(config: Configuration) = {
    val basePattern = getBaseExpression.toPattern(config)
    val `type` = basePattern.getItemType
    if (`type`.isInstanceOf[NodeTest]) {
      val baseExpr = getBaseExpression
      if (baseExpr.isInstanceOf[AxisExpression] && baseExpr.asInstanceOf[AxisExpression].getAxis == AxisInfo.CHILD && basePattern.isInstanceOf[NodeTestPattern]) new SimplePositionalPattern(`type`.asInstanceOf[NodeTest], 1)
      else new GeneralNodePattern(this, `type`.asInstanceOf[NodeTest])
    }
    else { // For a non-node pattern, the predicate [1] is always true
      basePattern
    }
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = EVALUATE_METHOD

  /**
   * Evaluate the expression
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext) = {
    val iter = getBaseExpression.iterate(context)
    val result = iter.next
    iter.close()
    result
  }

  override def getExpressionName = "first"

  override def toShortString = getBaseExpression.toShortString + "[1]"

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "FirstItemExpression"
}