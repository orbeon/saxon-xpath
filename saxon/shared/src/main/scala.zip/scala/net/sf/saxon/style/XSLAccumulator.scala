////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.expr.Component
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.accum.Accumulator
import net.sf.saxon.expr.accum.AccumulatorRegistry
import net.sf.saxon.expr.accum.AccumulatorRule
import net.sf.saxon.expr.instruct.Actor
import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.Optimizer
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.UType
import net.sf.saxon.om._
import net.sf.saxon.pattern.NodeTest
import net.sf.saxon.pattern.Pattern
import net.sf.saxon.trans.SimpleMode
import net.sf.saxon.trans.SymbolicName
import net.sf.saxon.trans.Visibility
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.StringValue
import net.sf.saxon.value.Whitespace

/**
 * Handler for xsl:accumulator elements in a stylesheet (XSLT 3.0).
 */
class XSLAccumulator extends StyleElement with StylesheetComponent {
  private val accumulator = new Accumulator

  /**
   * Get the corresponding Procedure object that results from the compilation of this
   * StylesheetProcedure
   */
  override def getActor = {
    if (accumulator.getDeclaringComponent == null) accumulator.makeDeclaringComponent(Visibility.PRIVATE, getContainingPackage)
    accumulator
  }

  override def getSymbolicName = {
    val qname = accumulator.getAccumulatorName
    if (qname == null) null
    else new SymbolicName(StandardNames.XSL_ACCUMULATOR, null)
  }

  override def checkCompatibility(component: Component) = {
    // no action: accumulators cannot be overridden
  }

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  /**
   * Method to handle the name attributes, which may need to be evaluated early if there are forwards
   * references to this accumulator
   */
  private def prepareSimpleAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      if (f == "name") {
        val name = Whitespace.trim(value)
        accumulator.setAccumulatorName(makeQName(name, null, "name"))
      }
      else if (f == "streamable") {
        accumulator.setDeclaredStreamable(false)
        val streamable = processStreamableAtt(value)
        accumulator.setDeclaredStreamable(streamable)
      }
      else if (attName.hasURI(NamespaceConstant.SAXON) && attName.getLocalPart == "trace") if (isExtensionAttributeAllowed(attName.getDisplayName)) accumulator.setTracing(processBooleanAttribute("saxon:trace", value))
      else {
        // report the error later
      }
    }
    if (accumulator.getAccumulatorName == null) reportAbsence("name")
  }

  override def prepareAttributes() = { //prepareSimpleAttributes();
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "name") {
        // no action
      }
      else if (f == "streamable") {
      }
      else if (f == "initial-value") accumulator.setInitialValueExpression(makeExpression(value, att))
      else if (f == "as") try {
        val requiredType = makeSequenceType(value)
        accumulator.setType(requiredType)
      } catch {
        case e: XPathException =>
          compileErrorInAttribute(e.getMessage, e.getErrorCodeLocalPart, "as")
      }
      else if (attName.hasURI(NamespaceConstant.SAXON) && attName.getLocalPart == "trace") if (isExtensionAttributeAllowed(attName.getDisplayName)) accumulator.setTracing(processBooleanAttribute("saxon:trace", value))
      else checkUnknownAttribute(attName)
      // TODO: add saxon:as
    }
    if (accumulator.getType == null) accumulator.setType(SequenceType.ANY_SEQUENCE)
    if (accumulator.getInitialValueExpression == null) {
      reportAbsence("initial-value")
      val zls = new StringLiteral(StringValue.EMPTY_STRING)
      zls.setRetainedStaticContext(makeRetainedStaticContext)
      accumulator.setInitialValueExpression(zls)
    }
  }

  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = {
    val config = compilation.getConfiguration
    // Prepare the initial value expression
    accumulator.setPackageData(compilation.getPackageData)
    accumulator.obtainDeclaringComponent(decl.getSourceElement)
    var init = accumulator.getInitialValueExpression
    val visitor = ExpressionVisitor.make(getStaticContext)
    init = init.typeCheck(visitor, config.getDefaultContextItemStaticInfo)
    val role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:accumulator-rule/select", 0)
    init = config.getTypeChecker(false).staticTypeCheck(init, accumulator.getType, role, visitor)
    init = init.optimize(visitor, config.getDefaultContextItemStaticInfo)
    val stackFrameMap = config.makeSlotManager
    ExpressionTool.allocateSlots(init, 0, stackFrameMap)
    accumulator.setSlotManagerForInitialValueExpression(stackFrameMap)
    checkInitialStreamability(init)
    accumulator.addChildExpression(init)

    // Prepare the new-value (select) expressions
    import scala.collection.JavaConversions._
    for (curr <- children(classOf[XSLAccumulatorRule].isInstance)) {
      val rule = curr.asInstanceOf[XSLAccumulatorRule]
      val pattern = rule.getMatch
      var newValueExp = rule.getNewValueExpression(compilation, decl)
      val visitor = ExpressionVisitor.make(getStaticContext)
      newValueExp = newValueExp.typeCheck(visitor, config.makeContextItemStaticInfo(pattern.getItemType, false))
      val role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:accumulator-rule/select", 0)
      newValueExp = config.getTypeChecker(false).staticTypeCheck(newValueExp, accumulator.getType, role, visitor)
      newValueExp = newValueExp.optimize(visitor, getConfiguration.makeContextItemStaticInfo(pattern.getItemType, false))
      val stackFrameMap = getConfiguration.makeSlotManager
      stackFrameMap.allocateSlotNumber(new StructuredQName("", "", "value"))
      ExpressionTool.allocateSlots(newValueExp, 1, stackFrameMap)
      val isPreDescent = !rule.isPostDescent
      val mode = if (isPreDescent) accumulator.getPreDescentRules
      else accumulator.getPostDescentRules
      val action = new AccumulatorRule(newValueExp, stackFrameMap, rule.isPostDescent)
      mode.addRule(pattern, action, decl.getModule, decl.getModule.getPrecedence, 1, 0, 0)
      checkRuleStreamability(rule, pattern, newValueExp)
      if (accumulator.isDeclaredStreamable && rule.isPostDescent && rule.isCapture) action.setCapturing(true)
      val itemType = pattern.getItemType
      if (itemType.isInstanceOf[NodeTest]) if (!itemType.getUType.overlaps(UType.DOCUMENT.union(UType.CHILD_NODE_KINDS))) rule.compileWarning("An accumulator rule that matches attribute or namespace nodes has no effect", "SXWN9999")
      else if (itemType.isInstanceOf[AtomicType]) rule.compileWarning("An accumulator rule that matches atomic values has no effect", "SXWN9999")
      accumulator.addChildExpression(newValueExp)
      accumulator.addChildExpression(pattern)
    }
    accumulator.getPreDescentRules.allocateAllPatternSlots()
    accumulator.getPostDescentRules.allocateAllPatternSlots()
  }

  /**
   * Get a name identifying the object of the expression, for example a function name, template name,
   * variable name, key name, element name, etc. This is used only where the name is known statically.
   * If there is no name, the value will be -1.
   */
  /*@NotNull*/ override def getObjectName: StructuredQName = {
    var qn = super.getObjectName
    if (qn == null) {
      val nameAtt = Whitespace.trim(getAttributeValue("", "name"))
      if (nameAtt == null) return new StructuredQName("saxon", NamespaceConstant.SAXON, "badly-named-accumulator" + generateId)
      qn = makeQName(nameAtt, null, "name")
      setObjectName(qn)
    }
    qn
  }

  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule): Unit = {
    if (accumulator.getAccumulatorName == null) prepareSimpleAttributes()
    accumulator.setImportPrecedence(decl.getPrecedence)
    if (top.getAccumulatorManager == null) {
      val styleNodeFactory = getCompilation.getStyleNodeFactory(true)
      val manager = styleNodeFactory.makeAccumulatorManager
      top.setAccumulatorManager(manager)
      getCompilation.getPackageData.setAccumulatorRegistry(manager)
    }
    val mgr = top.getAccumulatorManager
    val existing = mgr.getAccumulator(accumulator.getAccumulatorName)
    if (existing != null) {
      val existingPrec = existing.getImportPrecedence
      if (existingPrec == decl.getPrecedence) compileError("There are two accumulators with the same name (" + accumulator.getAccumulatorName.getDisplayName + ") and the same import precedence", "XTSE3350")
      if (existingPrec > decl.getPrecedence) return
    }
    mgr.addAccumulator(accumulator)
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = { //stackFrameMap = getConfiguration().makeSlotManager();
    // check the element is at the top level of the stylesheet
    checkTopLevel("XTSE0010", true)
    // only permitted child is XSLAccumulatorRule, and there must be at least one
    var foundRule = false
    import scala.collection.JavaConversions._
    for (curr <- children) {
      if (curr.isInstanceOf[XSLAccumulatorRule]) foundRule = true
      else compileError("Only xsl:accumulator-rule is allowed here", "XTSE0010")
    }
    if (!foundRule) compileError("xsl:accumulator must contain at least one xsl:accumulator-rule", "XTSE0010")
  }

  override def getSlotManager = null

  @throws[XPathException]
  override def optimize(declaration: ComponentDeclaration) = {
  }

  /**
   * Get the type of value returned by this function
   *
   * @return the declared result type, or the inferred result type
   *         if this is more precise
   */
  def getResultType = accumulator.getType

  /**
   * Generate byte code if appropriate
   *
   * @param opt the optimizer
   */
  override def generateByteCode(opt: Optimizer) = {
    // no action currently
  }

  @throws[XPathException]
  private def checkInitialStreamability(init: Expression) = {
    // Check streamability constraints
  }

  @throws[XPathException]
  private def checkRuleStreamability(rule: XSLAccumulatorRule, pattern: Pattern, newValueExp: Expression) = {
  }

  private def notStreamable(rule: StyleElement, message: String) = {
    val fallback = getConfiguration.getBooleanProperty(Feature.STREAMING_FALLBACK)
    if (fallback) {
      message += ". Falling back to non-streaming implementation"
      rule.compileWarning(message, "XTSE3430")
      rule.getCompilation.setFallbackToNonStreaming(true)
    }
    else rule.compileError(message, "XTSE3430")
  }
}