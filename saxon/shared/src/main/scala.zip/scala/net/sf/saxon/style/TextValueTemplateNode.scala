////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.ValueOf
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.linked.TextImpl
import net.sf.saxon.style.StyleElement.isYes

/**
 * A text node in an XSLT 3.0 stylesheet that may or may not contain a text value template
 */
class TextValueTemplateNode(val value: String) extends TextImpl(value) {
  private var contentExp = null
  private var staticContext = null

  def getContentExpression = contentExp

  def getStaticContext = {
    if (staticContext == null) staticContext = new TextValueTemplateContext(getParent.asInstanceOf[StyleElement], this)
    staticContext
  }

  @throws[XPathException]
  def validate() = {
    var disable = false
    val parent = getParent
    if (parent.isInstanceOf[XSLText] && isYes(parent.getAttributeValue("", "disable-output-escaping"))) disable = true
    contentExp = AttributeValueTemplate.make(getStringValue, getStaticContext)
    contentExp = new ValueOf(contentExp, disable, false)
    contentExp.setRetainedStaticContext(getParent.asInstanceOf[StyleElement].makeRetainedStaticContext)
    contentExp = getParent.asInstanceOf[StyleElement].typeCheck("tvt", contentExp)
  }
}