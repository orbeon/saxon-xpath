////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.Event
import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.model.AnyType
import net.sf.saxon.model.ComplexType
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Untyped
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.tiny.CharSlice
import net.sf.saxon.value.Whitespace
import javax.xml.transform.OutputKeys
import java.util._

/**
 * XMLIndenter: This ProxyReceiver indents elements, by adding character data where appropriate.
 * The character data is always added as "ignorable white space", that is, it is never added
 * adjacent to existing character data.
 *
 * @author Michael Kay
 */
class XMLIndenter(var emitter: XMLEmitter)

/**
 * Create an XML Indenter
 *
 * @param next the next receiver in the pipeline, always an XMLEmitter
 */
//bufferedAttributes = new AttributeCollectionImpl(getConfiguration());
  extends ProxyReceiver(next) {
  private var level = 0
  protected var indentChars = Array('\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ')
  private var sameline = false
  private var afterStartTag = false
  private var afterEndTag = true
  private var pendingWhitespace = null
  private var line = 0 // line and column measure the number of lines and columns
  private var column = 0 // .. in whitespace text nodes between tags
  private var suppressedAtLevel = -1
  private var suppressedElements = null

  /**
   * Set the properties for this indenter
   *
   * @param props the serialization properties
   */
  def setOutputProperties(props: Properties) = {
    val omit = props.getProperty(OutputKeys.OMIT_XML_DECLARATION)
    afterEndTag = omit == null || !("yes" == Whitespace.trim(omit)) || props.getProperty(OutputKeys.DOCTYPE_SYSTEM) != null
    var s = props.getProperty(SaxonOutputKeys.SUPPRESS_INDENTATION)
    if (s == null) {
      s = props.getProperty("{http://saxon.sf.net/}suppress-indentation")
      // for compatibility: since 9.3 also available in default namespace
    }
    if (s != null) {
      suppressedElements = new util.HashSet[NodeName](8)
      val st = new StringTokenizer(s, " \t\r\n")
      while ( {
        st.hasMoreTokens
      }) {
        val eqName = st.nextToken
        suppressedElements.add(FingerprintedQName.fromEQName(eqName))
      }
    }
  }

  /**
   * Start of document
   */
  @throws[XPathException]
  override def open() = emitter.open()

  /**
   * Output element start tag
   */
  @throws[XPathException]
  override def startElement(nameCode: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    if (afterStartTag || afterEndTag) {
      if (isDoubleSpaced(nameCode)) {
        nextReceiver.characters("\n", location, ReceiverOption.NONE)
        line = 0
        column = 0
      }
      indent()
    }
    else flushPendingWhitespace()
    level += 1
    if (suppressedAtLevel < 0) {
      val xmlSpace = attributes.getValue(NamespaceConstant.XML, "space")
      if (xmlSpace != null && xmlSpace.trim == "preserve") { // Note, we are suppressing indentation within an xml:space="preserve" region even if a descendant
        // specifies xml:space="default"
        suppressedAtLevel = level
      }
    }
    sameline = true
    afterStartTag = true
    afterEndTag = false
    line = 0
    if (suppressedElements != null && suppressedAtLevel == -1 && suppressedElements.contains(nameCode)) suppressedAtLevel = level
    if ((`type` ne AnyType.getInstance) && (`type` ne Untyped.getInstance) && suppressedAtLevel < 0 && `type`.isComplexType && `type`.asInstanceOf[ComplexType].isMixedContent) { // suppress indentation for elements with mixed content. (Note this also suppresses
      // indentation for all descendants of such elements. We could be smarter than this.)
      suppressedAtLevel = level
    }
    // Calculate indentation to be applied to attributes/namespaces
    if (suppressedAtLevel < 0) {
      var len = 0
      import scala.collection.JavaConversions._
      for (nbs <- namespaces) {
        import scala.collection.JavaConversions._
        for (binding <- nbs) {
          val prefix = binding.getPrefix
          if (prefix.isEmpty) len += 9 + binding.getURI.length
          else len += prefix.length + 10 + binding.getURI.length
        }
      }
      import scala.collection.JavaConversions._
      for (att <- attributes) {
        val name = att.getNodeName
        val prefix = name.getPrefix
        len += name.getLocalPart.length + att.getValue.length + 4 + (if (prefix.isEmpty) 4
        else prefix.length + 5)
      }
      if (len > getLineLength) {
        val indent = (level - 1) * getIndentation + 3
        emitter.setIndentForNextAttribute(indent)
      }
    }
    nextReceiver.startElement(nameCode, `type`, attributes, namespaces, location, properties)
  }

  /**
   * Output element end tag
   */
  @throws[XPathException]
  override def endElement() = {
    level -= 1
    if (afterEndTag && !sameline) indent()
    else flushPendingWhitespace()
    emitter.endElement()
    sameline = false
    afterEndTag = true
    afterStartTag = false
    line = 0
    if (level == (suppressedAtLevel - 1)) {
      suppressedAtLevel = -1
      // remove the suppression of indentation
    }
  }

  /**
   * Output a processing instruction
   */
  @throws[XPathException]
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = {
    if (afterEndTag) indent()
    else flushPendingWhitespace()
    emitter.processingInstruction(target, data, locationId, properties)
    //afterStartTag = false;
    //afterEndTag = false;
  }

  /**
   * Output character data
   */
  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = if (suppressedAtLevel < 0 && Whitespace.isWhite(chars)) pendingWhitespace = new Event.Text(chars, locationId, properties)
  else {
    flushPendingWhitespace()
    for (i <- 0 until chars.length) {
      val c = chars.charAt(i)
      if (c == '\n') {
        sameline = false
        line += 1
        column = 0
      }
      column += 1
    }
    emitter.characters(chars, locationId, properties)
    afterStartTag = false
    afterEndTag = false
  }

  /**
   * Output a comment
   */
  @throws[XPathException]
  override def comment(chars: CharSequence, locationId: Location, properties: Int) = {
    if (afterEndTag) indent()
    else flushPendingWhitespace()
    emitter.comment(chars, locationId, properties)
  }

  /**
   * Ask whether this Receiver (or the downstream pipeline) makes any use of the type annotations
   * supplied on element and attribute events
   *
   * @return true if the Receiver makes any use of this information. If false, the caller
   *         may supply untyped nodes instead of supplying the type annotation
   */
  override def usesTypeAnnotations = true

  /**
   * Output white space to reflect the current indentation level
   *
   * @throws XPathException if a downstream error occurs doing the output
   */
  @throws[XPathException]
  private def indent(): Unit = {
    if (suppressedAtLevel >= 0) { // indentation has been suppressed (e.g. by xmlspace="preserve")
      flushPendingWhitespace()
      return
    }
    pendingWhitespace = null // if we're adding new whitespace, we're allowed to discard existing whitespace
    var spaces = level * getIndentation
    if (line > 0) {
      spaces -= column
      if (spaces <= 0) return // there's already enough white space, don't add more
    }
    if (spaces + 2 >= indentChars.length) {
      var increment = 5 * getIndentation
      if (spaces + 2 > indentChars.length + increment) increment += spaces + 2
      val c2 = new Array[Char](indentChars.length + increment)
      System.arraycopy(indentChars, 0, c2, 0, indentChars.length)
      util.Arrays.fill(c2, indentChars.length, c2.length, ' ')
      indentChars = c2
    }
    // output the initial newline character only if line==0
    val start = if (line == 0) 0
    else 1
    //super.characters(indentChars.subSequence(start, start+spaces+1), 0, ReceiverOption.NO_SPECIAL_CHARS);
    emitter.characters(new CharSlice(indentChars, start, spaces + 1), Loc.NONE, ReceiverOption.NO_SPECIAL_CHARS)
    sameline = false
  }

  @throws[XPathException]
  private def flushPendingWhitespace() = if (pendingWhitespace != null) {
    pendingWhitespace.replay(nextReceiver)
    pendingWhitespace = null
  }

  @throws[XPathException]
  override def endDocument() = {
    if (afterEndTag) emitter.characters("\n", Loc.NONE, ReceiverOption.NONE) // if permitted, output a trailing newline, for tidier console output
    super.endDocument()
  }

  /**
   * Get the number of spaces to be used for indentation
   *
   * @return the number of spaces to be added to the indentation for each level
   */
  protected def getIndentation = 3

  /**
   * Ask whether a particular element is to be double-spaced
   *
   * @param name the element name
   * @return true if double-spacing is in effect for this element
   */
  protected def isDoubleSpaced(name: NodeName) = false

  /**
   * Get the suggested maximum length of a line
   *
   * @return the suggested maximum line length (used for wrapping attributes)
   */
  protected def getLineLength = 80
}