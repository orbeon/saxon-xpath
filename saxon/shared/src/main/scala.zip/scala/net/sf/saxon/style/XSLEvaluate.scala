////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr._
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.Choose
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.expr.parser.Token
import net.sf.saxon.expr.parser.TypeChecker
import net.sf.saxon.functions.SystemFunction
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.ma.map.MapType
import net.sf.saxon.model.AnyItemType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.Type
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XmlProcessingIncident
import net.sf.saxon.value.BooleanValue
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace
import java.util

/**
 * Handler for xsl:evaluate elements in XSLT 3.0 stylesheet. <br>
 */
class XSLEvaluate extends StyleElement {
  private[style] var xpath = null
  private[style] var requiredType = SequenceType.ANY_SEQUENCE
  private[style] var namespaceContext = null
  private[style] var contextItem = null
  private[style] var baseUri = null
  private[style] var schemaAware = null
  private[style] var withParams = null
  private[style] var options = null
  private[style] var hasFallbackChildren = false

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Specify that xsl:sort is a permitted child
   */
  override protected def isPermittedChild(child: StyleElement) = child.isInstanceOf[XSLLocalParam]

  /**
   * Determine the type of item returned by this instruction (only relevant if
   * it is an instruction).
   *
   * @return the item type returned
   */
  protected def getReturnedItemType = AnyItemType.getInstance

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return false: no, it may not contain a sequence constructor
   */
  override def mayContainSequenceConstructor = false

  override def prepareAttributes() = {
    val atts = attributes
    var xpathAtt = null
    var asAtt = null
    var contextItemAtt = null
    var baseUriAtt = null
    var namespaceContextAtt = null
    var schemaAwareAtt = null
    var withParamsAtt = null
    import scala.collection.JavaConversions._
    for (att <- atts) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      f match {
        case "xpath" =>
          xpathAtt = att.getValue
          xpath = makeExpression(xpathAtt, att)
        case "as" =>
          asAtt = att.getValue
        case "context-item" =>
          contextItemAtt = att.getValue
          contextItem = makeExpression(contextItemAtt, att)
        case "base-uri" =>
          baseUriAtt = att.getValue
          baseUri = makeAttributeValueTemplate(baseUriAtt, att)
        case "namespace-context" =>
          namespaceContextAtt = att.getValue
          namespaceContext = makeExpression(namespaceContextAtt, att)
        case "schema-aware" =>
          schemaAwareAtt = Whitespace.trim(att.getValue)
          schemaAware = makeAttributeValueTemplate(schemaAwareAtt, att)
        case "with-params" =>
          withParamsAtt = att.getValue
          withParams = makeExpression(withParamsAtt, att)
        case _ =>
          if (attName.getLocalPart == "options" && attName.getURI == NamespaceConstant.SAXON) if (isExtensionAttributeAllowed(attName.getDisplayName)) options = makeExpression(att.getValue, att)
          else checkUnknownAttribute(attName)
      }
    }
    if (xpathAtt == null) reportAbsence("xpath")
    if (asAtt != null) try requiredType = makeSequenceType(asAtt)
    catch {
      case e: XPathException =>
        compileErrorInAttribute(e.getMessage, e.getErrorCodeLocalPart, "as")
    }
    if (contextItemAtt == null) contextItem = Literal.makeEmptySequence
    if (schemaAwareAtt == null) schemaAware = new StringLiteral("no")
    else if (schemaAware.isInstanceOf[StringLiteral]) checkAttributeValue("schema-aware", schemaAwareAtt, true, StyleElement.YES_NO)
    if (withParamsAtt == null) {
      withParamsAtt = "map{}"
      withParams = makeExpression(withParamsAtt, null)
    }
    if (options == null) options = makeExpression("map{}", null)
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    getContainingPackage.setRetainUnusedFunctions()
    if (xpath == null) xpath = new StringLiteral("''")
    xpath = typeCheck("xpath", xpath)
    baseUri = typeCheck("base-uri", baseUri)
    contextItem = typeCheck("context-item", contextItem)
    namespaceContext = typeCheck("namespace-context", namespaceContext)
    schemaAware = typeCheck("schema-aware", schemaAware)
    withParams = typeCheck("with-params", withParams)
    options = typeCheck("options", options)
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLWithParam]) {
        // OK
      }
      else if (child.isInstanceOf[XSLFallback]) hasFallbackChildren = true
      else if (child.getNodeKind == Type.TEXT) { // with xml:space=preserve, white space nodes may still be there
        if (!Whitespace.isWhite(child.getStringValueCS)) compileError("No character data is allowed within xsl:evaluate", "XTSE0010")
      }
      else compileError("Child element " + Err.wrap(child.getDisplayName, Err.ELEMENT) + " is not allowed as a child of xsl:evaluate", "XTSE0010")
    }
    try {
      val visitor = makeExpressionVisitor
      val tc = getConfiguration.getTypeChecker(false)
      var role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:evaluate/xpath", 0)
      xpath = tc.staticTypeCheck(xpath, SequenceType.SINGLE_STRING, role, visitor)
      role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:evaluate/context-item", 0)
      role.setErrorCode("XTTE3210")
      contextItem = tc.staticTypeCheck(contextItem, SequenceType.OPTIONAL_ITEM, role, visitor)
      role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:evaluate/namespace-context", 0)
      role.setErrorCode("XTTE3170")
      if (namespaceContext != null) namespaceContext = tc.staticTypeCheck(namespaceContext, SequenceType.SINGLE_NODE, role, visitor)
      role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:evaluate/with-params", 0)
      role.setErrorCode("XTTE3170")
      withParams = tc.staticTypeCheck(withParams, SequenceType.makeSequenceType(MapType.ANY_MAP_TYPE, StaticProperty.EXACTLY_ONE), role, visitor)
      role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:evaluate/saxon:options", 0)
      options = tc.staticTypeCheck(options, SequenceType.makeSequenceType(MapType.ANY_MAP_TYPE, StaticProperty.EXACTLY_ONE), role, visitor)
    } catch {
      case err: XPathException =>
        compileError(err)
    }
  }

  def getTargetExpression = xpath

  def getContextItemExpression = contextItem

  def getBaseUriExpression = baseUri

  def getNamespaceContextExpression = namespaceContext

  def getSchemaAwareExpression = schemaAware

  def getWithParamsExpression = withParams

  def getOptionsExpression = options

  def getRequiredType = requiredType

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = if (getConfiguration.getBooleanProperty(Feature.DISABLE_XSL_EVALUATE)) { // If xsl:evaluate is statically disabled then we should execute any fallback children
      validationError = new XmlProcessingIncident("xsl:evaluate is not available in this configuration", "XTDE3175")
      fallbackProcessing(exec, decl, this)
    }
    else {
      val evaluateExpr = getConfiguration.makeEvaluateInstruction(this, decl)
      if (evaluateExpr.isInstanceOf[ErrorExpression]) return evaluateExpr
      // If there are any xsl:fallback children, we need to compile them, in case xsl:evaluate
      // is dynamically disabled at run-time.
      if (hasFallbackChildren) { // Generate a conditional expression switched on the value of system-property('xsl:supports-dynamic-evaluation')
        val conditions = new Array[Expression](2)
        val sysProp = SystemFunction.makeCall("system-property", makeRetainedStaticContext, new StringLiteral("Q{" + NamespaceConstant.XSLT + "}supports-dynamic-evaluation"))
        conditions(0) = new ValueComparison(sysProp, Token.FEQ, new StringLiteral("no"))
        conditions(1) = Literal.makeLiteral(BooleanValue.TRUE)
        val actions = new Array[Expression](2)
        val fallbackExpressions = new util.ArrayList[Expression]
        import scala.collection.JavaConversions._
        for (child <- children(classOf[XSLFallback].isInstance)) {
          fallbackExpressions.add(child.asInstanceOf[XSLFallback].compileSequenceConstructor(exec, decl, false))
        }
        actions(0) = new Block(fallbackExpressions.toArray(new Array[Expression](0)))
        actions(1) = evaluateExpr
        new Choose(conditions, actions)
      }
      else evaluateExpr
    }
}