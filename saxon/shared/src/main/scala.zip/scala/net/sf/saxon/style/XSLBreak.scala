////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.BreakInstr
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * A xsl:break element in the stylesheet
 */
class XSLBreak extends XSLBreakOrContinue {
  private var select = null

  override def prepareAttributes() = {
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else checkUnknownAttribute(attName)
    }
  }

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true if this instruction is allowed to contain a sequence constructor
   */
  override protected def mayContainSequenceConstructor = true

  /**
   * Check that the stylesheet element is valid. This is called once for each element, after
   * the entire tree has been built. As well as validation, it can perform first-time
   * initialisation. The default implementation does nothing; it is normally overriden
   * in subclasses.
   *
   * @param decl
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    validatePosition()
    if (xslIterate == null) compileError(getDisplayName + " must be a descendant of an xsl:iterate instruction", "XTSE3120") //XTSE0010
    if (select != null && hasChildNodes) compileError("An xsl:break element with a select attribute must be empty", "XTSE3125")
    select = typeCheck("select", select)
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = { // xsl:break containing a sequence constructor is compiled into a call on the sequence constructor, then
    // the break instruction
    var `val` = select
    if (`val` == null) `val` = compileSequenceConstructor(exec, decl, false)
    val brake = new BreakInstr
    brake.setRetainedStaticContext(makeRetainedStaticContext)
    Block.makeBlock(`val`, brake)
  }
}