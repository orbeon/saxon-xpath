////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package net.sf.saxon.gizmo

import jline.console.ConsoleReader
import jline.console.completer.Completer
import jline.console.completer.FileNameCompleter
import jline.console.completer.StringsCompleter
import java.io.File
import java.io.IOException
import java.util
import java.util.{List, SortedSet}

import jline.internal.Preconditions.checkNotNull


/**
 * Handles terminal interaction for Gizmo using the JLine2 library: https://github.com/jline/jline2
 */
object JLine2Talker {
  private val DEBUG  = false
  var debugLog: StringBuilder = null

  private def log(message: String): Unit = {
    if (DEBUG) debugLog.append(message)
  }

  class XPathCompleter(val candidates: util.List[String]) extends StringsCompleter(candidates) {
    override def complete(buffer: String, cursor: Int, candidates: util.List[CharSequence]): Int = { // Consider using a filename completer
      if (DEBUG) log(String.format("Complete buffer='%s' cursor=%d candidates='%s'", buffer, cursor, String.join("|", candidates)))
      val space  = buffer.indexOf(' ')
      if (space > 0) {
        val command  = buffer.substring(0, space)
        if (command == "load" || command == "save" || command == "transform" || command == "schema") {
          val fnc  = new FileNameCompleter() {
            override def complete(buffer: String, cursor: Int, candidates: util.List[CharSequence]): Int = { // buffer can be null
              checkNotNull(candidates)
              if (buffer == null) buffer = ""
              if (File.separator == "\\") buffer = buffer.replace('/', '\\')
              var translated  = buffer.substring(space + 1)
              val homeDir  = getUserHome
              // Special character: ~ maps to the user's home directory
              if (translated.startsWith("~" + separator)) translated = homeDir.getPath + translated.substring(1)
              else if (translated.startsWith("~")) translated = homeDir.getParentFile.getAbsolutePath
                else if (! translated.contains(separator) ) {
                    val cwd  = getUserDir.getAbsolutePath
                    translated = cwd + separator + translated
                  }
                  else if (! new File(translated).isAbsolute ) {
                      val cwd  = getUserDir.getAbsolutePath
                      translated = cwd + separator + translated
                    }
              val file  = new File(translated)
              var dir  = null
              if (translated.endsWith(separator)) dir = file
              else dir = file.getParentFile
              val entries  = if (dir == null) new Array[File](0)
              else dir.listFiles
              val index  = matchFiles(buffer, translated, entries, candidates)
              if (index == 0) space + 1
              else index
            }
          }
          if (DEBUG) log(String.format("FileName completer buffer='%s' cursor=%d candidates='%s'", buffer, cursor, String.join("|", candidates)))
          val index  = fnc.complete(buffer, cursor, candidates)
          if (DEBUG) log(String.format("Index=%d", index))
          return index
        }
      }
      var lastDelimiter  = Integer.max(cursor - 1, 0)
      if (lastDelimiter > space) while ( {
          lastDelimiter >= 0
        }) {
          val c  = buffer.charAt(lastDelimiter)
          if (Character.isAlphabetic( c ) || Character.isDigit(c) || c == '-' || c == '_' || c == '@' || c == '.' || c == ' ') lastDelimiter -= 1
          else break//todo: break is not supported
        }
      val currentWord  = buffer.substring(lastDelimiter + 1)
      import scala.collection.JavaConversions._
      for (`match` <- getStrings.asInstanceOf[SortedSet[String]] .tailSet(currentWord)) {
        if (! `match`.startsWith(currentWord) ) break//todo: break is not supported
        candidates.add(`match`)
      }
      if (candidates.isEmpty) - 1
      else lastDelimiter + 1
    }
  }

  try if (DEBUG) { // Debug mode is used during unit testing; it allows diagnostic output to be sent to
    // a local string buffer, avoiding confusion with the console output of the utility itself.
    debugLog = new StringBuilder
  }

}

class JLine2Talker @throws[IOException]
() extends Talker {
  console = new ConsoleReader(System.in, System.out)
  console.setExpandEvents(false)
  console.setHistoryEnabled(true)
  private var console  = null
  private var completer  = null

  /**
   * Send some output to the user and get some input back
   *
   * @param message output to be sent to the user
   * @return the user's response
   */
  override def exchange(message: String): String = try {
      if (JLine2Talker.DEBUG) {
        console.println(JLine2Talker.debugLog)
        JLine2Talker.debugLog.setLength(0)
      }
      if (message != null && ! message.isEmpty ) console.println(message)
      val in  = console.readLine("/>")
      if (in == null) System.exit(0)
      in.trim
    } catch {
      case e: IOException =>
        System.err.println(e.getMessage)
        throw new RuntimeException(e)
    }

  override def setAutoCompletion(candidates: util.List[String]): Unit = {
    if (completer != null) console.removeCompleter(completer)
    completer = new JLine2Talker.XPathCompleter(candidates)
    console.addCompleter(completer)
  }
}

