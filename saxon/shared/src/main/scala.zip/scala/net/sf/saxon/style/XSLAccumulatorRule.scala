////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.pattern.Pattern
import net.sf.saxon.trans.SaxonErrorCode
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * Handler for xsl:accumulator-rule elements in a stylesheet (XSLT 3.0).
 */
class XSLAccumulatorRule extends StyleElement {
  private var `match` = null
  private var postDescent = false
  private var select = null
  private var capture = false

  override def prepareAttributes() = {
    var matchAtt = null
    var newValueAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      if (attName.getURI.isEmpty) f match {
        case "match" =>
          matchAtt = value
        case "select" =>
          newValueAtt = value
          select = makeExpression(newValueAtt, att)
        case "phase" =>
          val phaseAtt = Whitespace.trim(value)
          if ("start" == phaseAtt) postDescent = false
          else if ("end" == phaseAtt) postDescent = true
          else {
            postDescent = true
            compileError("phase must be 'start' or 'end'", "XTSE0020")
          }
        case _ =>
          checkUnknownAttribute(attName)
      }
      else if (attName.hasURI(NamespaceConstant.SAXON)) if (isExtensionAttributeAllowed(attName.getDisplayName)) if (attName.getLocalPart == "capture") capture = processBooleanAttribute("saxon:capture", value)
      else checkUnknownAttribute(attName)
    }
    if (matchAtt == null) {
      reportAbsence("match")
      matchAtt = "non-existent-element"
    }
    `match` = makePattern(matchAtt, "match")
    if (capture && !postDescent) compileWarning("saxon:capture has no effect on a pre-descent accumulator rule", SaxonErrorCode.SXWN9000)
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    select = typeCheck("select", select)
    `match` = typeCheck("match", `match`)
    if (select != null && hasChildNodes) compileError("If the xsl:accumulator-rule element has a select attribute then it must have no children")
  }

  @throws[XPathException]
  def getNewValueExpression(compilation: Compilation, decl: ComponentDeclaration) = {
    if (select == null) select = compileSequenceConstructor(compilation, decl, true)
    select
  }

  def getMatch = `match`

  def setMatch(`match`: Pattern) = this.`match` = `match`

  def isPostDescent = postDescent

  def setPostDescent(postDescent: Boolean) = this.postDescent = postDescent

  def isCapture = capture

  def getSelect = select

  def setSelect(select: Expression) = this.select = select

  override def hasImplicitBinding(name: StructuredQName) = if (name.getLocalPart == "value" && name.hasURI("")) {
    val sb = new SourceBinding(this)
    sb.setVariableQName(new StructuredQName("", "", "value"))
    assert(getParent.asInstanceOf[XSLAccumulator] != null)
    sb.setDeclaredType(getParent.asInstanceOf[XSLAccumulator].getResultType)
    sb.setProperty(SourceBinding.BindingProperty.IMPLICITLY_DECLARED, true)
    sb
  }
  else null
}