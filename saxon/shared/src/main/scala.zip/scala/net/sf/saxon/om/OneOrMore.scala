////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceExtent
import java.util

/**
 * A value that is a sequence containing one or more items. The main use is in declarations of reflexive extension
 * functions, where declaring an argument of type &lt;OneOrMore&lt;IntegerValue&gt;&gt; triggers automatic type
 * checking in the same way as for a native XSLT/XQuery function declaring the type as xs:integer+.
 */
object OneOrMore {
  @throws[XPathException]
  def makeOneOrMore(sequence: Sequence) = {
    val content = new util.ArrayList[Item]
    sequence.iterate.forEachOrFail(content.add)
    if (content.isEmpty) throw new IllegalArgumentException
    new OneOrMore[Item](content)
  }
}

class OneOrMore[T <: Item] extends SequenceExtent {
  /**
   * Create a sequence containing zero or one items
   *
   * @param content The content of the sequence
   */
    def this(content: Array[T]) {
      this()
     this.value= content
      if (content.length == 0) throw new IllegalArgumentException
    }

  def this(content: util.List[T]) {
    this()
    this.value= content
    if (content.isEmpty) throw new IllegalArgumentException
  }
}