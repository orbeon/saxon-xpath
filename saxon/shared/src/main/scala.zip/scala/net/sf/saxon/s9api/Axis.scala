////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.om.AxisInfo

/**
 * This is an enumeration class containing constants representing the thirteen XPath axes
 */
object Axis extends Enumeration {
  type Axis = Value
  val ANCESTOR, ANCESTOR_OR_SELF, ATTRIBUTE, CHILD, DESCENDANT, DESCENDANT_OR_SELF, FOLLOWING, FOLLOWING_SIBLING, PARENT, PRECEDING, PRECEDING_SIBLING, SELF, NAMESPACE = Value
  private var number = 0

  /**
   * Create an Axis
   *
   * @param number the internal axis number as defined in class { @link net.sf.saxon.om.AxisInfo}
   */
  def this(number: Int) {
    this()
    this.number = number
  }

  /**
   * Get the axis number, as defined in class {@link net.sf.saxon.om.AxisInfo}
   *
   * @return the axis number
   */
  def getAxisNumber = number
}