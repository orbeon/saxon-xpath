////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.s9api.HostLanguage
import net.sf.saxon.trans.DecimalFormatManager
import net.sf.saxon.trans.DecimalSymbols
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.AttributeLocation
import net.sf.saxon.value.Whitespace

/**
 * Handler for xsl:decimal-format elements in stylesheet. <br>
 */
class XSLDecimalFormat extends StyleElement {
  private[style] var prepared = false
  private[style] var name = null
  private[style] var decimalSeparator = null
  private[style] var groupingSeparator = null
  private[style] var exponentSeparator = null
  private[style] var infinity = null
  private[style] var minusSign = null
  private[style] var NaN = null
  private[style] var percent = null
  private[style] var perMille = null
  private[style] var zeroDigit = null
  private[style] var digit = null
  private[style] var patternSeparator = null
  private[style] var symbols = null

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  override def prepareAttributes(): Unit = {
    if (prepared) return
    prepared = true
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "name" =>
          name = Whitespace.trim(value)
        case "decimal-separator" =>
          decimalSeparator = value
        case "grouping-separator" =>
          groupingSeparator = value
        case "infinity" =>
          infinity = value
        case "minus-sign" =>
          minusSign = value
        case "NaN" =>
          NaN = value
        case "percent" =>
          percent = value
        case "per-mille" =>
          perMille = value
        case "zero-digit" =>
          zeroDigit = value
        case "digit" =>
          digit = value
        case "exponent-separator" =>
          exponentSeparator = value
        case "pattern-separator" =>
          patternSeparator = value
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration): Unit = {
    checkTopLevel("XTSE0010", false)
    checkEmpty()
    val precedence = decl.getPrecedence
    if (symbols == null) return // error already reported
    if (decimalSeparator != null) setProp(DecimalSymbols.DECIMAL_SEPARATOR, decimalSeparator, precedence)
    if (groupingSeparator != null) setProp(DecimalSymbols.GROUPING_SEPARATOR, groupingSeparator, precedence)
    if (infinity != null) setProp(DecimalSymbols.INFINITY, infinity, precedence)
    if (minusSign != null) setProp(DecimalSymbols.MINUS_SIGN, minusSign, precedence)
    if (NaN != null) setProp(DecimalSymbols.NAN, NaN, precedence)
    if (percent != null) setProp(DecimalSymbols.PERCENT, percent, precedence)
    if (perMille != null) setProp(DecimalSymbols.PER_MILLE, perMille, precedence)
    if (zeroDigit != null) setProp(DecimalSymbols.ZERO_DIGIT, zeroDigit, precedence)
    if (digit != null) setProp(DecimalSymbols.DIGIT, digit, precedence)
    if (exponentSeparator != null) setProp(DecimalSymbols.EXPONENT_SEPARATOR, exponentSeparator, precedence)
    if (patternSeparator != null) setProp(DecimalSymbols.PATTERN_SEPARATOR, patternSeparator, precedence)
  }

  @throws[XPathException]
  private def setProp(propertyCode: Int, value: String, precedence: Int) = try symbols.setProperty(propertyCode, value, precedence)
  catch {
    case err: XPathException =>
      val attName = DecimalSymbols.propertyNames(propertyCode)
      err.setLocation(new AttributeLocation(this, StructuredQName.fromClarkName(attName)))
      throw err
  }

  /**
   * Method supplied by declaration elements to add themselves to a stylesheet-level index
   *
   * @param decl the Declaration being indexed. (This corresponds to the StyleElement object
   *             except in cases where one module is imported several times with different precedence.)
   * @param top  the outermost XSLStylesheet element
   */
  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = {
    prepareAttributes()
    val dfm = getCompilation.getPrincipalStylesheetModule.getDecimalFormatManager
    if (name == null) symbols = dfm.getDefaultDecimalFormat
    else {
      val formatName = makeQName(name, null, "name")
      symbols = dfm.obtainNamedDecimalFormat(formatName)
      symbols.setHostLanguage(HostLanguage.XSLT, 30)
    }
  }

  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = {
    // no action
  }
}