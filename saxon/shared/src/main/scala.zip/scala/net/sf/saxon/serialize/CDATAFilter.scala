////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.serialize.charcode.CharacterSet
import net.sf.saxon.serialize.charcode.UTF16CharacterSet
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.tiny.CharSlice
import net.sf.saxon.tree.util.FastStringBuffer
import javax.xml.transform.OutputKeys
import java.util._

/**
 * CDATAFilter: This ProxyReceiver converts character data to CDATA sections,
 * if the character data belongs to one of a set of element types to be handled this way.
 *
 * @author Michael Kay
 */
class CDATAFilter(val next: Receiver)

/**
 * Create a CDATA Filter
 *
 * @param next the next receiver in the pipeline
 */
  extends ProxyReceiver(next) {
  private var buffer = new FastStringBuffer(FastStringBuffer.C256)
  private val stack = new util.Stack[NodeName]
  private var nameList = null // names of cdata elements
  private var characterSet = null

  /**
   * Set the properties for this CDATA filter
   *
   * @param details the output properties
   * @throws net.sf.saxon.trans.XPathException
   * if an error occurs
   */
  @throws[XPathException]
  def setOutputProperties(/*@NotNull*/ details: Properties) = {
    getCdataElements(details)
    characterSet = getConfiguration.getCharacterSetFactory.getCharacterSet(details)
  }

  /**
   * Output element start tag
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    flush()
    stack.push(elemName)
    nextReceiver.startElement(elemName, `type`, attributes, namespaces, location, properties)
  }

  /**
   * Output element end tag
   */
  @throws[XPathException]
  override def endElement() = {
    flush()
    stack.pop
    nextReceiver.endElement()
  }

  /**
   * Output a processing instruction
   */
  @throws[XPathException]
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = {
    flush()
    nextReceiver.processingInstruction(target, data, locationId, properties)
  }

  /**
   * Output character data
   */
  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = if (!ReceiverOption.contains(properties, ReceiverOption.DISABLE_ESCAPING)) buffer.append(chars.toString)
  else { // if the user requests disable-output-escaping, this overrides the CDATA request. We end
    // the CDATA section and output the characters as supplied.
    flush()
    nextReceiver.characters(chars, locationId, properties)
  }

  /**
   * Output a comment
   */
  @throws[XPathException]
  override def comment(chars: CharSequence, locationId: Location, properties: Int) = {
    flush()
    nextReceiver.comment(chars, locationId, properties)
  }

  /**
   * Flush the buffer containing accumulated character data,
   * generating it as CDATA where appropriate
   */
  @throws[XPathException]
  private def flush(): Unit = {
    var cdata = false
    var end = buffer.length
    if (end == 0) return
    if (stack.isEmpty) cdata = false // text is not part of any element
    else {
      val top = stack.peek
      cdata = isCDATA(top)
    }
    if (cdata) { // If we're doing Unicode normalization, we need to do this before CDATA processing.
      // In this situation the normalizer will be the next thing in the serialization pipeline.
      if (getNextReceiver.isInstanceOf[UnicodeNormalizer]) {
        buffer = new FastStringBuffer(getNextReceiver.asInstanceOf[UnicodeNormalizer].normalize(buffer, true))
        end = buffer.length
      }
      // Check that the buffer doesn't include a character not available in the current
      // encoding
      var start = 0
      var k = 0
      while ( {
        k < end
      }) {
        var next = buffer.charAt(k)
        var skip = 1
        if (UTF16CharacterSet.isHighSurrogate(next.toChar)) {
          next = UTF16CharacterSet.combinePair(next.toChar, buffer.charAt(k + 1))
          skip = 2
        }
        if (next != 0 && characterSet.inCharset(next)) k += 1
        else { // flush out the preceding characters as CDATA
          val array = new Array[Char](k - start)
          buffer.getChars(start, k, array, 0)
          flushCDATA(array, k - start)
          while ( {
            k < end
          }) { // output consecutive non-encodable characters
            // before restarting the CDATA section
            //super.characters(CharBuffer.wrap(buffer, k, k+skip), 0, 0);
            nextReceiver.characters(buffer.subSequence(k, k + skip), Loc.NONE, ReceiverOption.DISABLE_CHARACTER_MAPS)
            k += skip
            if (k >= end) break //todo: break is not supported
            next = buffer.charAt(k)
            skip = 1
            if (UTF16CharacterSet.isHighSurrogate(next.toChar)) {
              next = UTF16CharacterSet.combinePair(next.toChar, buffer.charAt(k + 1))
              skip = 2
            }
            if (characterSet.inCharset(next)) break //todo: break is not supported
          }
          start = k
        }
      }
      val rest = new Array[Char](end - start)
      buffer.getChars(start, end, rest, 0)
      flushCDATA(rest, end - start)
    }
    else nextReceiver.characters(buffer, Loc.NONE, ReceiverOption.NONE)
    buffer.setLength(0)
  }

  /**
   * Output an array as a CDATA section. At this stage we have checked that all the characters
   * are OK, but we haven't checked that there is no "]]>" sequence in the data
   *
   * @param array the data to be output
   * @param len   the number of characters in the array actually used
   */
  @throws[XPathException]
  private def flushCDATA(array: Array[Char], len: Int): Unit = {
    if (len == 0) return
    val chprop = ReceiverOption.DISABLE_ESCAPING | ReceiverOption.DISABLE_CHARACTER_MAPS
    val loc = Loc.NONE
    nextReceiver.characters("<![CDATA[", loc, chprop)
    // Check that the character data doesn't include the substring "]]>"
    // Also get rid of any zero bytes inserted by character map expansion
    var i = 0
    var doneto = 0
    while ( {
      i < len - 2
    }) {
      if (array(i) == ']' && array(i + 1) == ']' && array(i + 2) == '>') {
        nextReceiver.characters(new CharSlice(array, doneto, i + 2 - doneto), loc, chprop)
        nextReceiver.characters("]]><![CDATA[", loc, chprop)
        doneto = i + 2
      }
      else if (array(i) == 0) {
        nextReceiver.characters(new CharSlice(array, doneto, i - doneto), loc, chprop)
        doneto = i + 1
      }
      i += 1
    }
    nextReceiver.characters(new CharSlice(array, doneto, len - doneto), loc, chprop)
    nextReceiver.characters("]]>", loc, chprop)
  }

  /**
   * See if a particular element is a CDATA element. Method is protected to allow
   * overriding in a subclass.
   *
   * @param elementName identifies the name of element we are interested
   * @return true if this element is included in cdata-section-elements
   */
  protected def isCDATA(elementName: NodeName) = nameList.contains(elementName)

  /**
   * Extract the list of CDATA elements from the output properties
   *
   * @param details the output properties
   */
  private def getCdataElements(details: Properties): Unit = {
    val isHTML = "html" == details.getProperty(OutputKeys.METHOD)
    val isHTML5 = isHTML && "5.0" == details.getProperty(OutputKeys.VERSION)
    val isHTML4 = isHTML && !isHTML5
    val cdata = details.getProperty(OutputKeys.CDATA_SECTION_ELEMENTS)
    if (cdata == null) { // this doesn't happen, but there's no harm allowing for it
      nameList = new util.HashSet[NodeName](0)
      return
    }
    nameList = new util.HashSet[NodeName](10)
    val st2 = new StringTokenizer(cdata, " \t\n\r", false)
    while ( {
      st2.hasMoreTokens
    }) {
      val expandedName = st2.nextToken
      val sq = StructuredQName.fromClarkName(expandedName)
      val uri = sq.getURI
      if (!isHTML || (isHTML4 && !(uri == "")) || (isHTML5 && !(uri == "") && !(uri == NamespaceConstant.XHTML))) nameList.add(new FingerprintedQName("", sq.getURI, sq.getLocalPart))
    }
  }
}