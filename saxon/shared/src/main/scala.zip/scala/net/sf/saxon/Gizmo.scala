////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon

import net.sf.saxon.event.Builder
import net.sf.saxon.event.ComplexContentOutputter
import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.event.Receiver
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.expr.parser.Token
import net.sf.saxon.expr.parser.XPathParser
import net.sf.saxon.gizmo.DefaultTalker
import net.sf.saxon.gizmo.JLine2Talker
import net.sf.saxon.gizmo.Talker
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.ParseOptions
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.SimpleType
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.pattern.NameTest
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.query.DynamicQueryContext
import net.sf.saxon.query.QueryResult
import net.sf.saxon.query.StaticQueryContext
import net.sf.saxon.query.XQueryExpression
import net.sf.saxon.s9api.UnprefixedElementMatchingPolicy
import net.sf.saxon.serialize.SerializationProperties
import net.sf.saxon.sxpath._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.NamespaceNode
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.tree.linked.DocumentImpl
import net.sf.saxon.tree.linked.LinkedTreeBuilder
import net.sf.saxon.tree.util.Navigator
import net.sf.saxon.tree.util.Orphan
import net.sf.saxon.value._
import javax.xml.transform.Templates
import javax.xml.transform.Transformer
import javax.xml.transform.TransformerException
import javax.xml.transform.stream.StreamResult
import javax.xml.transform.stream.StreamSource
import java.io._
import java.util._

/**
 * A Gizmo is a simple tool for performing a particular easily specified transformation on an XML
 * document, for example deleting or renaming all the elements with a particular name. The class
 * offers a command-line interface.
 */
object Gizmo {

  private class SubCommand {
    private[saxon] val name = null
    private[saxon] val helpText = null
    private[saxon] val action = null
  }

  @FunctionalInterface private trait Action {
    @throws[XPathException]
    def perform(subCommand: StringBuffer)
  }

  def main(args: Array[String]) = new Gizmo(args)

  private val keywords = Array[String]("ancestor::", "ancestor-or-self::", "array", "attribute", "cast as", "castable as", "child::", "comment()", "descendant::", "descendant-or-self::", "document-node()", "element()", "else", "empty-sequence()", "every", "except", "following::", "following-sibling::", "function", "instance of", "intersect", "item()", "namespace::", "namespace-node()", "node()", "parent::", "preceding::", "preceding-sibling::", "processing-instruction()", "return", "satisfies", "schema-attribute", "schema-element", "self::", "some", "text()", "then", "treat as", "union")
}

class Gizmo(val args: Array[String]) {
  initSubCommands()
  configuration = Configuration.newConfiguration
  configuration.setConfigurationProperty(Feature.ALLOW_SYNTAX_EXTENSIONS, true)
  env = new IndependentContext(configuration)
  var source = null
  var script = null
  var interactive = true
  for (arg <- args) {
    if (arg.startsWith("-s:")) sourceElement = arg.substring(3)
    if (arg.startsWith("-q:")) {
      script = arg.substring(3)
      interactive = false
    }
  }
  talker = initTalker(script)
  //System.err.println("Using term=" + talker.getClass().getCanonicalName());
  val sortedNames = new ArrayList[String](Arrays.asList(Gizmo.keywords))
  Collections.sort(sortedNames)
  talker.setAutoCompletion(sortedNames)
  if (sourceElement != null) try load(new StringBuffer(sourceElement))
  catch {
    case e: XPathException =>
      System.err.println(xsltExecutable.getMessage)
      System.exit(2)
  }
  else try {
    val dummy = "<dummy/>"
    val ss = new StreamSource(new StringReader(dummy))
    val options = new ParseOptions
    parseOptions.setModel(TreeModel.LINKED_TREE)
    parseOptions.setLineNumbering(true)
    currentDoc = configuration.buildDocumentTree(ss, parseOptions).getRootNode.asInstanceOf[DocumentImpl]
    typed = false
  } catch {
    case e: XPathException =>
      System.err.println(xsltExecutable.getMessage)
      System.exit(2)
  }
  env.declareNamespace("xml", NamespaceConstant.XML)
  env.declareNamespace("xsl", NamespaceConstant.XSLT)
  env.declareNamespace("saxon", NamespaceConstant.SAXON)
  env.declareNamespace("xs", NamespaceConstant.SCHEMA)
  env.declareNamespace("xsi", NamespaceConstant.SCHEMA_INSTANCE)
  env.declareNamespace("fn", NamespaceConstant.FN)
  env.declareNamespace("math", NamespaceConstant.MATH)
  env.declareNamespace("map", NamespaceConstant.MAP_FUNCTIONS)
  env.declareNamespace("array", NamespaceConstant.ARRAY_FUNCTIONS)
  env.declareNamespace("", "")
  env.setUnprefixedElementMatchingPolicy(UnprefixedElementMatchingPolicy.ANY_NAMESPACE)
  System.outputDir.println("Saxon Gizmo " + Version.getProductVersion)
  executeCommands(talker, interactive)
  private var config = null
  private var env = null
  private var currentDoc = null
  private var unsaved = false
  private val variables = new util.HashMap[StructuredQName, Sequence]
  private val subCommands = new util.HashMap[String, Gizmo.SubCommand]
  private var talker = null
  private var typed = false
  private val undoBuffer = new util.LinkedList[DocumentImpl]

  private def addCommand(name: String, helpText: String, action: Gizmo.Action) = {
    val c = new Gizmo.SubCommand
    c.name = name
    c.helpText = helpText
    c.action = action
    subCommands.put(name, c)
  }

  private def initSubCommands() = {
    addCommand("call", "call {filename} -- execute script from a file", this.call)
    addCommand("copy", "copy {expression} -- make deep copy of all selected nodes", this.copy)
    addCommand("delete", "delete {expression} -- delete all selected nodes, with their content", this.delete)
    addCommand("follow", "follow {expression} with {query} -- add result of query after each selected node", (cmd: StringBuffer) => update(cmd, "follow"))
    addCommand("help", "help {keyword} -- help on a specific command, or '?' for all commands", this.help)
    addCommand("list", "list {expression} -- display paths of selected nodes", this.list)
    addCommand("load", "load {fileName} -- load new source document from file", this.load)
    addCommand("namespace", "namespace {prefix} {uri} -- bind namespace prefix to URI", this.namespace)
    addCommand("paths", "paths -- display all distinct element paths in the document", (cmd: StringBuffer) => list(new StringBuffer("distinct-values(//*!('/'||string-join(ancestor-or-self::*!name(),'/')))")))
    addCommand("precede", "precede {expression} with {query} -- add result of query before each selected nodes", (cmd: StringBuffer) => update(cmd, "precede"))
    addCommand("prefix", "prefix {expression} with {query} -- add result of query as first child of each selected nodes", (cmd: StringBuffer) => update(cmd, "prefix"))
    addCommand("quit", "quit [now] -- stop Gizmo", (cmd: StringBuffer) => {
      def foo(cmd: StringBuffer) =
        throw new RuntimeException

      foo(cmd)
    })
    addCommand("rename", "rename {expression-1} as {expression-2} -- change the name of selected nodes", this.rename)
    addCommand("replace", "replace {expression} with {query} -- replace selected nodes with result of query", this.replace)
    addCommand("save", "save {filename} {output-property=value}... -- save current document to file", this.save)
    addCommand("schema", "schema {filename} -- load XSD 1.1 schema for use in validation", this.schema)
    addCommand("set", "set {variable} {expression} -- set variable to value of expression", this.set)
    addCommand("show", "show {expression} -- display content of all selected nodes", this.show)
    addCommand("strip", "strip -- delete whitespace text nodes", (cmd: StringBuffer) => this.delete(new StringBuffer("//text()[not(normalize-space())]")))
    addCommand("suffix", "suffix {expression} with {query} -- add result of query as last child of each selected nodes", (cmd: StringBuffer) => update(cmd, "suffix"))
    addCommand("transform", "transform {filename} -- transform current document using stylesheet in named file", this.transform)
    addCommand("undo", "undo -- revert the most recent changes", this.undo)
    addCommand("update", "update {expression} with {query} -- replace content of selected nodes with result of query", (cmd: StringBuffer) => update(cmd, "content"))
    addCommand("validate", "validate -- validate against loaded schema and/or xsi:schemaLocation", this.validate)
    addCommand("?", "", this.help)
  }

  protected def initTalker(script: String) = if (script == null) try new JLine2Talker
  catch {
    case e: IOException =>
      System.err.println(e.getMessage)
      System.exit(2)
      null
  }
  else try new DefaultTalker(new FileInputStream(new File(script)), System.out)
  catch {
    case e: FileNotFoundException =>
      System.err.println(e.getMessage)
      System.exit(2)
      null
  }

  private def executeCommands(talker: Talker, interactive: Boolean): Unit = {
    var emptyLines = 0
    while ( {
      true
    }) try {
      var command = talker.exchange("")
      if (command.isEmpty && !interactive) return
      while ( {
        command.isEmpty
      }) if ( {
        emptyLines += 1; emptyLines - 1
      } > 2) command = talker.exchange("To exit, type 'quit'. For help, type 'help'")
      emptyLines = 0
      var space = command.indexOf(' ')
      if (space < 0) space = command.length
      val keyword = command.substring(0, space)
      val remainder = command.substring(space).trim
      if (keyword == "quit") {
        var quit = true
        if (unsaved && !(remainder == "now")) while ( {
          true
        }) {
          val answer = talker.exchange("Quit without saving? (Y|N)")
          if (answer.equalsIgnoreCase("y")) break //todo: break is not supported
          else if (answer.equalsIgnoreCase("n")) {
            quit = false
            break //todo: break is not supported
          }
          else {
            //continue;
          }
        }
        if (quit) break //todo: break is not supported
        else continue //todo: continue is not supported
      }
      val cmd = subCommands.get(keyword)
      if (cmd == null) if (interactive) {
        System.out.println("Unknown command " + keyword + " (Use 'quit' to exit)")
        help(new StringBuffer("?"))
      }
      else throw new XPathException("\"Unknown command \" + cmd + \"")
      else cmd.action.perform(new StringBuffer(remainder))
    } catch {
      case e: XPathException =>
        System.out.println(e.getErrorCodeLocalPart + ": " + e.getMessage)
        if (interactive) {
          //System.out.print("|>");
        }
        else System.exit(2)
    }
  }

  private def help(command: StringBuffer) = {
    val cmd = if (command == null) null
    else command.toString.trim
    if (cmd == null || cmd.isEmpty || cmd == "help" || cmd == "?") {
      System.out.println("Commands available:")
      val commands = new util.ArrayList[String](subCommands.keySet)
      commands.sort(null)
      import scala.collection.JavaConversions._
      for (c <- commands) {
        System.out.println("  " + subCommands.get(c).helpText)
      }
    }
    else {
      val entry = subCommands.get(cmd)
      if (entry == null) help(null)
      else System.out.println(entry.helpText)
    }
  }

  /**
   * Read an XPath expression from a supplied input string, execute the expression,
   * and return an iterator over the result. As a side-effect, modify the supplied
   * StringBuffer so it contains whatever remains after parsing the expression.
   *
   * @param selection the input buffer, which is modified as a side-effect
   * @return an iterator over the results of the expression
   * @throws XPathException if evaluation of the expression fails
   */
  @throws[XPathException]
  private def getSelectedItems(selection: StringBuffer, terminator: Int) = {
    val expr = getExpression(selection, terminator)
    evaluateExpression(expr, currentDoc)
  }

  @throws[XPathException]
  private def getExpression(selection: StringBuffer, terminator: Int) = {
    val evaluator = new XPathEvaluator(config)
    evaluator.setStaticContext(env)
    import scala.collection.JavaConversions._
    for (`var` <- variables.keySet) {
      env.declareVariable(`var`)
    }
    val scanner = config.newExpressionParser("XP", false, 31)
    scanner.parse(selection.toString, 0, terminator, env)
    val endPoint = scanner.getTokenizer.currentTokenStartOffset
    val expr = evaluator.createExpression(selection.substring(0, endPoint))
    selection.replace(0, endPoint, "")
    expr
  }

  @throws[XPathException]
  private def getQuery(query: StringBuffer) = {
    val sqc = config.makeStaticQueryContext(true)
    import scala.collection.JavaConversions._
    for (`var` <- variables.keySet) {
      sqc.declareGlobalVariable(`var`, SequenceType.ANY_SEQUENCE, variables.get(`var`), false)
    }
    if (typed) sqc.setSchemaAware(true)
    val prefixes = env.iteratePrefixes
    while ( {
      prefixes.hasNext
    }) {
      val prefix = prefixes.next
      sqc.declareNamespace(prefix, env.getURIForPrefix(prefix, true))
    }
    sqc.compileQuery(query.toString)
  }

  @throws[XPathException]
  private def evaluateExpression(expr: XPathExpression, contextItem: Item) = {
    val context = expr.createDynamicContext(contextItem)
    import scala.collection.JavaConversions._
    for (`var` <- variables.entrySet) {
      val v = env.getExternalVariable(`var`.getKey)
      context.setVariable(v, `var`.getValue)
    }
    expr.iterate(context)
  }

  @throws[XPathException]
  private def evaluateQuery(expr: XQueryExpression, contextItem: Item) = {
    val context = new DynamicQueryContext(config)
    context.setContextItem(contextItem)
    expr.iterator(context)
  }

  @throws[XPathException]
  private def getQName(in: String) = StructuredQName.fromLexicalQName(in, false, true, env.getNamespaceResolver())

  @throws[XPathException]
  private def needCurrentDoc() = if (currentDoc == null) throw new XPathException("No source document available")

  @throws[XPathException]
  private def saveCurrentDoc() = {
    val builder = new LinkedTreeBuilder(config.makePipelineConfiguration)
    currentDoc.copy(builder, CopyOptions.ALL_NAMESPACES, Loc.NONE)
    val copy = builder.getCurrentRoot.asInstanceOf[DocumentImpl]
    undoBuffer.add(currentDoc)
    currentDoc = copy
    if (undoBuffer.size > 20) undoBuffer.remove(0)
  }

  @throws[XPathException]
  private def copy(buffer: StringBuffer) = {
    needCurrentDoc()
    val iter = getSelectedItems(buffer, Token.EOF)
    val builder = new LinkedTreeBuilder(config.makePipelineConfiguration)
    builder.open()
    builder.startDocument(0)
    var item = null
    while ( {
      (item = iter.next()) != null
    }) if (item.isInstanceOf[NodeInfo]) item.asInstanceOf[NodeInfo].copy(builder, CopyOptions.ALL_NAMESPACES, Loc.NONE)
    else throw new XPathException("Selected item is not a node")
    currentDoc = builder.getCurrentRoot.asInstanceOf[DocumentImpl]
    unsaved = true
  }

  @throws[XPathException]
  private def delete(buffer: StringBuffer) = {
    needCurrentDoc()
    saveCurrentDoc()
    val all = getSelectedItems(buffer, Token.EOF).materialize
    import scala.collection.JavaConversions._
    for (item <- all.asIterable) {
      if (item.isInstanceOf[MutableNodeInfo]) {
        item.asInstanceOf[MutableNodeInfo].delete()
        unsaved = true
      }
      else if (item.isInstanceOf[NamespaceNode]) {
        val parent = item.asInstanceOf[NamespaceNode].getParent
        if (parent.isInstanceOf[MutableNodeInfo]) try parent.asInstanceOf[MutableNodeInfo].removeNamespace(item.asInstanceOf[NamespaceNode].getLocalPart)
        catch {
          case e: Exception =>
            throw new XPathException("Cannot remove namespace: " + e.getMessage)
        }
        unsaved = true
      }
      else throw new XPathException("Selected item is not a mutable node")
    }
  }

  @throws[XPathException]
  private def load(source: StringBuffer) = {
    var fileName = source.toString
    fileName = fileName.replaceFirst("^~", System.getProperty("user.home"))
    val ss = new StreamSource(new File(fileName))
    val options = new ParseOptions
    options.setModel(TreeModel.LINKED_TREE)
    options.setLineNumbering(true)
    currentDoc = config.buildDocumentTree(ss, options).getRootNode.asInstanceOf[DocumentImpl]
    typed = false
    val names = new util.HashSet[String]
    var element = null
    val allElements = currentDoc.iterateAxis(AxisInfo.DESCENDANT, NodeKindTest.ELEMENT)
    while ( {
      (element = allElements.next()) != null
    }) {
      names.add(element.getLocalPart())
      var att = null
      val allAtts = element.iterateAxis(AxisInfo.ATTRIBUTE)
      while ( {
        (att = allAtts.next()) != null
      }) names.add("@" + att.getLocalPart())
    }
    val sortedNames = new util.ArrayList[String](names)
    sortedNames.addAll(util.Arrays.asList(Gizmo.keywords))
    Collections.sort(sortedNames)
    talker.setAutoCompletion(sortedNames)
  }

  @throws[XPathException]
  private def call(source: StringBuffer) = try {
    val is = new FileInputStream(source.toString)
    val talker = new DefaultTalker(is, new PrintStream(System.out))
    executeCommands(talker, false)
  } catch {
    case e: FileNotFoundException =>
      throw new XPathException("Script not found: " + e.getMessage)
  }

  @throws[XPathException]
  private def namespace(buffer: StringBuffer) = {
    val ws = buffer.indexOf(" ")
    if (ws < 0) throw new XPathException("No namespace prefix supplied")
    val prefix = buffer.substring(0, ws).trim
    val uri = buffer.substring(ws).trim
    env.declareNamespace(prefix, uri)
  }

  @throws[XPathException]
  private def rename(buffer: StringBuffer) = {
    needCurrentDoc()
    saveCurrentDoc()
    val iter = getSelectedItems(buffer, Token.AS)
    buffer.replace(0, 3, "")
    val renamer = getExpression(buffer, Token.EOF)
    var item = null
    while ( {
      (item = iter.next()) != null
    }) if (item.isInstanceOf[MutableNodeInfo]) {
      val newName = evaluateExpression(renamer, item).next()
      var newQName = null
      if (newName.isInstanceOf[QNameValue]) newQName = newName.asInstanceOf[QNameValue].getStructuredQName
      else if (newName.isInstanceOf[AtomicValue]) newQName = getQName(newName.getStringValue())
      else throw new XPathException("New name must evaluate to a string or QName")
      item.asInstanceOf[MutableNodeInfo].rename(new FingerprintedQName(newQName, config.getNamePool))
    }
    else throw new XPathException("Selected item is not a renameable node")
  }

  @throws[XPathException]
  private def replace(buffer: StringBuffer) = {
    needCurrentDoc()
    saveCurrentDoc()
    val iter = getSelectedItems(buffer, Token.WITH)
    buffer.replace(0, 5, "")
    val replacement = getQuery(buffer)
    var item = null
    while ( {
      (item = iter.next()) != null
    }) if (item.isInstanceOf[MutableNodeInfo]) {
      val target = item.asInstanceOf[MutableNodeInfo]
      var newValue = evaluateQuery(replacement, item).materialize
      if (newValue.isInstanceOf[AtomicValue]) {
        val orphan = new Orphan(config)
        orphan.setNodeKind(Type.TEXT)
        orphan.setStringValue(newValue.getStringValue())
        newValue = orphan
      }
      target.getNodeKind() match {
        case Type.DOCUMENT =>
          throw new XPathException("Cannot replace a document node")
        case Type.ELEMENT =>
        case Type.COMMENT =>
        case Type.TEXT =>
        case Type.PROCESSING_INSTRUCTION =>
          val newChildren = new util.ArrayList[NodeInfo]
          import scala.collection.JavaConversions._
          for (it <- newValue.asIterable) {
            if (it.isInstanceOf[NodeInfo]) it.asInstanceOf[NodeInfo].getNodeKind() match {
              case Type.ATTRIBUTE =>
                throw new XPathException("Cannot replace non-attribute with attribute")
              case Type.NAMESPACE =>
                throw new XPathException("Cannot replace non-namespace node with namespace node")
              case Type.DOCUMENT =>
                import scala.collection.JavaConversions._
                for (kid <- it.asInstanceOf[NodeInfo].children) {
                  newChildren.add(kid)
                }
              case _ =>
                newChildren.add(it.asInstanceOf[NodeInfo])
            }
            else if (it.isInstanceOf[AtomicValue]) {
              val orphan = new Orphan(config)
              orphan.setNodeKind(Type.TEXT)
              orphan.setStringValue(it.getStringValue())
              newChildren.add(orphan)
            }
          }
          if (!newChildren.isEmpty) {
            val childArray = newChildren.toArray(new Array[NodeInfo](0))
            target.replace(childArray, true)
          }
        case Type.ATTRIBUTE =>
          target.getParent().asInstanceOf[MutableNodeInfo].removeAttribute(target)
          if (newValue.getLength() == 0) {
            // no further action
          }
          else if (newValue.getLength() == 1 && newValue.itemAt(0).isInstanceOf[NodeInfo] && newValue.itemAt(0).asInstanceOf[NodeInfo].getNodeKind() == Type.ATTRIBUTE) {
            val att = newValue.itemAt(0).asInstanceOf[NodeInfo]
            target.getParent().asInstanceOf[MutableNodeInfo].addAttribute(NameOfNode.makeName(att), att.getSchemaType.asInstanceOf[SimpleType], att.getStringValueCS(), 0)
          }
          else throw new XPathException("Replacement for an attribute must be an attribute")
        case Type.NAMESPACE =>
        case _ =>
          throw new XPathException("Cannot replace a namespace node")
      }
    }
    else throw new XPathException("Selected item is not a mutable node")
    unsaved = true
  }

  @throws[XPathException]
  private def undo(buffer: StringBuffer) = {
    val len = undoBuffer.size
    if (len > 0) currentDoc = undoBuffer.remove(len - 1)
    else throw new XPathException("Nothing to undo")
  }

  @throws[XPathException]
  private def update(buffer: StringBuffer, where: String) = {
    needCurrentDoc()
    saveCurrentDoc()
    val iter = getSelectedItems(buffer, Token.WITH)
    buffer.replace(0, 5, "")
    val newContent = getQuery(buffer)
    var item = null
    while ( {
      (item = iter.next()) != null
    }) if (item.isInstanceOf[MutableNodeInfo]) {
      val target = item.asInstanceOf[MutableNodeInfo]
      val newValue = evaluateQuery(newContent, item).materialize
      if (newValue.isInstanceOf[AtomicValue] && where == "content") target.replaceStringValue(newValue.asInstanceOf[AtomicValue].getStringValueCS)
      else {
        val replacement = new util.ArrayList[NodeInfo]
        val replacementAtts = new util.ArrayList[NodeInfo]
        import scala.collection.JavaConversions._
        for (it <- newValue.asIterable) {
          if (it.isInstanceOf[NodeInfo]) it.asInstanceOf[NodeInfo].getNodeKind() match {
            case Type.ATTRIBUTE =>
              replacementAtts.add(it.asInstanceOf[NodeInfo])
            case Type.NAMESPACE =>
              throw new XPathException("Cannot replace namespace nodes")
            case Type.DOCUMENT =>
              import scala.collection.JavaConversions._
              for (kid <- it.asInstanceOf[NodeInfo].children) {
                replacement.add(kid)
              }
            case _ =>
              replacement.add(it.asInstanceOf[NodeInfo])
          }
          else if (it.isInstanceOf[AtomicValue]) {
            val orphan = new Orphan(config)
            orphan.setNodeKind(Type.TEXT)
            orphan.setStringValue(it.getStringValue())
            replacement.add(orphan)
          }
        }
        if (!replacementAtts.isEmpty && !(where == "prefix" || where == "update")) throw new XPathException("Cannot supply attributes for " + where + " command (use 'prefix')")
        if (!replacement.isEmpty) {
          val childArray = replacement.toArray(new Array[NodeInfo](0))
          where match {
            case "content" =>
              target.replace(childArray, true)
            case "precede" =>
              target.insertSiblings(childArray, true, true)
            case "follow" =>
              target.insertSiblings(childArray, false, true)
            case "prefix" =>
              target.insertChildren(childArray, true, true)
            case "suffix" =>
            case _ =>
              target.insertChildren(childArray, false, true)
          }
        }
        import scala.collection.JavaConversions._
        for (att <- replacementAtts) {
          val attName = NameOfNode.makeName(att)
          val existing = target.iterateAxis(AxisInfo.ATTRIBUTE, new NameTest(Type.ATTRIBUTE, attName, config.getNamePool)).next
          if (existing != null) target.removeAttribute(existing)
          target.addAttribute(attName, BuiltInAtomicType.UNTYPED_ATOMIC, att.getStringValue(), 0)
        }
      }
    }
    else throw new XPathException("Selected item is not a mutable node")
    unsaved = true
  }

  @throws[XPathException]
  private def save(buffer: StringBuffer): Unit = {
    needCurrentDoc()
    val tokens = new Whitespace.Tokenizer(buffer)
    val fileName = tokens.next
    if (fileName == null) throw new XPathException("No file name supplied")
    val dest = new File(fileName.getStringValue)
    if (dest.exists) while ( {
      true
    }) {
      val answer = talker.exchange("Overwrite existing file? (Y|N)")
      if (answer.equalsIgnoreCase("y")) break //todo: break is not supported
      else if (answer.equalsIgnoreCase("n")) return
      else {
      }
    }
    val out = new StreamResult(dest)
    val props = new SerializationProperties
    var prop = null
    while ( {
      (prop = tokens.next) != null
    }) try {
      val parts = prop.getStringValue.split("=")
      props.setProperty(parts(0).trim, parts(1).trim)
    } catch {
      case e: Exception =>
        System.out.println("Unrecognized output property '" + prop)
    }
    val s = config.getSerializerFactory.getReceiver(out, props)
    s.open()
    currentDoc.copy(s, CopyOptions.ALL_NAMESPACES, Loc.NONE)
    s.close()
    System.out.println("Written to " + new File(fileName.getStringValue).getAbsolutePath)
    unsaved = false
  }

  @throws[XPathException]
  private def schema(buffer: StringBuffer) = {
    if (!config.isLicensedFeature(Configuration.LicenseFeature.SCHEMA_VALIDATION)) throw new XPathException("Schema processing is not supported in this Saxon configuration")
    var fileName = buffer.toString
    fileName = fileName.replaceFirst("^~", System.getProperty("user.home"))
    config.loadSchema(new File(fileName).getAbsoluteFile.toURI.toString)
  }

  @throws[XPathException]
  private def set(buffer: StringBuffer) = {
    val ws = buffer.indexOf("=")
    if (ws < 0 || ws == buffer.length - 1) throw new XPathException("Format: set name = value")
    var varName = buffer.substring(0, ws).trim
    if (varName.startsWith("$")) varName = varName.substring(1)
    val saved = currentDoc
    val value = getSelectedItems(new StringBuffer(buffer.substring(ws + 1)), Token.EOF).materialize
    if (varName == ".") {
      saveCurrentDoc()
      if (value.getLength() == 1 && value.itemAt(0).isInstanceOf[DocumentImpl]) currentDoc = value.itemAt(0).asInstanceOf[DocumentImpl]
      else try {
        val builder = new LinkedTreeBuilder(config.makePipelineConfiguration)
        val cco = new ComplexContentOutputter(builder)
        cco.open()
        cco.startDocument(0)
        import scala.collection.JavaConversions._
        for (it <- value.asIterable) {
          cco.append(it)
        }
        cco.endDocument()
        cco.close()
        currentDoc = builder.getCurrentRoot.asInstanceOf[DocumentImpl]
      } catch {
        case e: XPathException =>
          throw new XPathException("Cannot save the value as a document (" + e.getMessage + ")")
      }
    }
    else {
      val name = getQName(varName)
      variables.put(name, value)
      currentDoc = saved
    }
  }

  @throws[XPathException]
  private def validate(buffer: StringBuffer) = {
    if (!config.isLicensedFeature(Configuration.LicenseFeature.SCHEMA_VALIDATION)) throw new XPathException("Schema processing is not supported in this Saxon configuration")
    needCurrentDoc()
    saveCurrentDoc()
    val pipe = config.makePipelineConfiguration
    val builder = new LinkedTreeBuilder(pipe)
    builder.open()
    val options = new ParseOptions
    options.setSchemaValidationMode(Validation.STRICT)
    val `val` = config.getDocumentValidator(builder, currentDoc.getSystemId, options, Loc.NONE)
    currentDoc.copy(`val`, CopyOptions.ALL_NAMESPACES, Loc.NONE)
    builder.close()
    currentDoc = builder.getCurrentRoot.asInstanceOf[DocumentImpl]
    unsaved = true
    typed = true
  }

  @throws[XPathException]
  private def list(buffer: StringBuffer) = {
    needCurrentDoc()
    val iter = getSelectedItems(buffer, Token.EOF)
    val value = iter.materialize
    val size = value.getLength()
    if (size != 1) System.out.println("Found " + size + " items")
    import scala.collection.JavaConversions._
    for (item <- value.asIterable) {
      if (item.isInstanceOf[NodeInfo]) {
        val lineNumber = item.asInstanceOf[NodeInfo].getLineNumber
        val prefix = if (lineNumber >= 0) "Line " + lineNumber + ": "
        else ""
        System.out.println(prefix + Navigator.getPath(item.asInstanceOf[NodeInfo]))
      }
      else System.out.println(item.getStringValue())
    }
  }

  @throws[XPathException]
  private def show(buffer: StringBuffer) = {
    needCurrentDoc()
    if (buffer.toString.trim.isEmpty) buffer = new StringBuffer(".")
    val iter = getSelectedItems(buffer, Token.EOF)
    val value = iter.materialize
    val size = value.getLength()
    if (size != 1) System.out.println("Found " + size + " items")
    import scala.collection.JavaConversions._
    for (item <- value.asIterable) {
      if (item.isInstanceOf[NodeInfo]) System.out.println(QueryResult.serialize(item.asInstanceOf[NodeInfo]))
      else if (item.isInstanceOf[AtomicValue]) System.out.println(item.getStringValue())
      else {
        val sw = new StringWriter
        val props = new SerializationProperties
        props.setProperty("method", "adaptive")
        val r = config.getSerializerFactory.getReceiver(new StreamResult(sw), props)
        r.append(item)
        System.out.println(sw.toString)
      }
    }
  }

  @throws[XPathException]
  private def transform(buffer: StringBuffer) = try {
    needCurrentDoc()
    saveCurrentDoc()
    var fileName = buffer.toString
    fileName = fileName.replaceFirst("^~", System.getProperty("user.home"))
    val ss = new StreamSource(new File(fileName))
    val templates = new TransformerFactoryImpl(config).newTemplates(ss)
    val transformer = templates.newTransformer
    val result = new LinkedTreeBuilder(config.makePipelineConfiguration)
    result.open()
    transformer.transform(currentDoc, result)
    result.close()
    currentDoc = result.getCurrentRoot.asInstanceOf[DocumentImpl]
  } catch {
    case e: TransformerException =>
      throw XPathException.makeXPathException(e)
  }
}