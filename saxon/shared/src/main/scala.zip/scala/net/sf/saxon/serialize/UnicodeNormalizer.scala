////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.om.NodeName
import net.sf.saxon.s9api.Location
import net.sf.saxon.serialize.codenorm.Normalizer
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.Whitespace

/**
 * UnicodeNormalizer: This ProxyReceiver performs unicode normalization on the contents
 * of attribute and text nodes.
 */
class UnicodeNormalizer @throws[XPathException]
(val form: String, val next: Receiver) extends ProxyReceiver(next) {
  var fb = 0
  form match {
    case "NFC" =>
      fb = Normalizer.C
    case "NFD" =>
      fb = Normalizer.D
    case "NFKC" =>
      fb = Normalizer.KC
    case "NFKD" =>
      fb = Normalizer.KD
    case _ =>
      val err = new XPathException("Unknown normalization form " + form)
      err.setErrorCode("SESU0011")
      throw err
  }
  normalizer = Normalizer.make(fb, getConfiguration)
  private var normalizer = null

  /**
   * Get the underlying normalizer
   *
   * @return the underlying Normalizer
   */
  def getNormalizer = normalizer

  /**
   * Notify the start of an element
   *
   * @param elemName   the name of the element.
   * @param type       the type annotation of the element.
   * @param attributes the attributes of this element
   * @param namespaces the in-scope namespaces of this element: generally this is all the in-scope
   *                   namespaces, without relying on inheriting namespaces from parent elements
   * @param location   an object providing information about the module, line, and column where the node originated
   * @param properties bit-significant properties of the element node. If there are no relevant
   *                   properties, zero is supplied. The definitions of the bits are in class { @link ReceiverOption}
   * @throws XPathException if an error occurs
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    val am2 = attributes.apply((attInfo: AttributeInfo) => {
      def foo(attInfo: AttributeInfo) = {
        val newValue = normalize(attInfo.getValue, ReceiverOption.contains(attInfo.getProperties, ReceiverOption.USE_NULL_MARKERS)).toString
        new AttributeInfo(attInfo.getNodeName, attInfo.getType, newValue, attInfo.getLocation, attInfo.getProperties)
      }

      foo(attInfo)
    })
    nextReceiver.startElement(elemName, `type`, am2, namespaces, location, properties)
  }

  /**
   * Output character data
   */
  @throws[XPathException]
  override def characters(/*@NotNull*/ chars: CharSequence, locationId: Location, properties: Int) = if (Whitespace.isWhite(chars)) nextReceiver.characters(chars, locationId, properties)
  else nextReceiver.characters(normalize(chars, ReceiverOption.contains(properties, ReceiverOption.USE_NULL_MARKERS)), locationId, properties)

  def normalize(in: CharSequence, containsNullMarkers: Boolean) = if (containsNullMarkers) {
    val out = new FastStringBuffer(in.length)
    val s = in.toString
    var start = 0
    var nextNull = s.indexOf(0.toChar)
    while ( {
      nextNull >= 0
    }) {
      out.cat(normalizer.normalize(s.substring(start, nextNull)))
      out.cat(0.toChar)
      start = nextNull + 1
      nextNull = s.indexOf(0.toChar, start)
      out.append(s.substring(start, nextNull))
      out.cat(0.toChar)
      start = nextNull + 1
      nextNull = s.indexOf(0.toChar, start)
    }
    out.cat(normalizer.normalize(s.substring(start)))
    out.condense
  }
  else normalizer.normalize(in)
}