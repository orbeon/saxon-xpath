////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.functions.FunctionLibraryList
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.trans.Mode
import net.sf.saxon.trans.SymbolicName
import net.sf.saxon.trans.Visibility
import net.sf.saxon.trans.XPathException

/**
 * Represents an xsl:override element in a package manifest.
 */
class XSLOverride extends StyleElement {
  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      checkUnknownAttribute(attName)
    }
  }

  /**
   * Validate this element
   *
   * @param decl Not used
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    import scala.collection.JavaConversions._
    for (curr <- children) {
      if (curr.getNodeKind == Type.TEXT) compileError("Character content is not allowed as a child of xsl:override", "XTSE0010")
      else if (curr.isInstanceOf[XSLFunction] || curr.isInstanceOf[XSLTemplate] || curr.isInstanceOf[XSLGlobalVariable] || curr.isInstanceOf[XSLAttributeSet]) {
        // OK
      }
      else curr.asInstanceOf[StyleElement].compileError("Element " + curr.getDisplayName + " is not allowed as a child of xsl:override", "XTSE0010")
    }
  }

  @throws[XPathException]
  override def postValidate(): Unit = {
    val parent = getParent.asInstanceOf[XSLUsePackage]
    assert(parent != null)
    if (parent.getUsedPackage != null) {
      import scala.collection.JavaConversions._
      for (curr <- children) {
        if (curr.isInstanceOf[XSLFunction] || curr.isInstanceOf[XSLTemplate] || curr.isInstanceOf[XSLGlobalVariable] || curr.isInstanceOf[XSLAttributeSet]) {
          val procedure = curr.asInstanceOf[StylesheetComponent]
          val name = procedure.getSymbolicName
          if (name == null) if (curr.isInstanceOf[XSLTemplate]) {
            val decl = curr.asInstanceOf[XSLTemplate]
            if (decl.getMatch == null) decl.compileError("An overriding template with no name must have a match pattern")
            val modeNames = decl.getModeNames
            for (modeName <- modeNames) {
              if (modeName == Mode.OMNI_MODE) curr.asInstanceOf[StyleElement].compileError("An overriding template rule must not specify mode=\"#all\"", "XTSE3440")
              else if (modeName == Mode.UNNAMED_MODE_NAME) {
                modeName = decl.getDefaultMode
                if (modeName == Mode.UNNAMED_MODE_NAME) curr.asInstanceOf[StyleElement].compileError("An overriding template rule must not belong to the unnamed mode", "XTSE3440")
              }
            }
          }
          else {
            curr.asInstanceOf[StyleElement].compileError("An overriding component (other than a template rule) must have a name", "XTSE3440")
            return
          }
          else {
            val overridden = parent.getUsedPackage.getComponent(name)
            if (overridden == null) {
              curr.asInstanceOf[StyleElement].compileError("There is no " + StandardNames.getLocalName(name.getComponentKind) + " named " + name.getShortName + " in the used package", "XTSE3058")
              return
            }
            var overriddenVis = overridden.getVisibility
            if (overriddenVis == null) overriddenVis = Visibility.PRIVATE
            if ((overriddenVis eq Visibility.FINAL) || (overriddenVis eq Visibility.PRIVATE)) {
              curr.asInstanceOf[StyleElement].compileError("The " + StandardNames.getLocalName(name.getComponentKind) + " named " + name.getShortName + " in the used package cannot be overridden because its visibility is " + overriddenVis.show, "XTSE3060")
              return
            }
            procedure.checkCompatibility(overridden)
          }
        }
      }
    }
  }

  /**
   * Add a function library that recognizes the function call xsl:original, which is permitted
   * within a function that overrides another
   *
   * @param list the function library list to which the new function library should be added
   */
  def addXSLOverrideFunctionLibrary(list: FunctionLibraryList) = list.addFunctionLibrary(XSLOriginalLibrary.getInstance)
}