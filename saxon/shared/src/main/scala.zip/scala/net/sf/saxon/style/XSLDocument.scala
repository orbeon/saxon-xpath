////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.instruct.DocumentInstr
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * An xsl:document instruction in the stylesheet. <BR>
 * This instruction creates a document node in the result tree, optionally
 * validating it.
 */
class XSLDocument extends StyleElement {
  private var validationAction = Validation.STRIP
  /*@Nullable*/ private var schemaType = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var validationAtt = null
    var typeAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "validation") validationAtt = Whitespace.trim(value)
      else if (f == "type") typeAtt = Whitespace.trim(value)
      else checkUnknownAttribute(attName)
    }
    if (validationAtt == null) validationAction = getDefaultValidation
    else validationAction = validateValidationAttribute(validationAtt)
    if (typeAtt != null) {
      if (!isSchemaAware) compileError("The @type attribute is available only with a schema-aware XSLT processor", "XTSE1660")
      schemaType = getSchemaType(typeAtt)
      validationAction = Validation.BY_TYPE
    }
    if (typeAtt != null && validationAtt != null) compileError("The @validation and @type attributes are mutually exclusive", "XTSE1505")
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    //
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val inst = new DocumentInstr(false, null)
    inst.setValidationAction(validationAction, schemaType)
    var b = compileSequenceConstructor(exec, decl, true)
    if (b == null) b = Literal.makeEmptySequence
    inst.setContentExpression(b)
    inst.setLocation(allocateLocation)
    inst
  }
}