////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.model._
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value._

/**
 * An IntegerRangeTest is an expression of the form
 * E = N to M
 * where N and M are both expressions of type integer.
 * The result of the expression is true if any value in the result of E is a numeric value in the
 * range N to M. Any untyped atomic values in E are converted to integers; values that cannot be converted
 * result in an error.
 */
class IntegerRangeTest(val value: Expression, val min: Expression, val max: Expression)

/**
 * Construct a IntegerRangeTest
 *
 * @param value the integer value to be tested to see if it is in the range min to max inclusive
 * @param min   the lowest permitted value
 * @param max   the highest permitted value
 */
  extends Expression {
  valueOp = new Operand(this, value, OperandRole.ATOMIC_SEQUENCE)
  minOp = new Operand(this, min, OperandRole.SINGLE_ATOMIC)
  maxOp = new Operand(this, max, OperandRole.SINGLE_ATOMIC)
  private var valueOp = null
  private var minOp = null
  private var maxOp = null

  override def operands = operandList(valueOp, minOp, maxOp)

  def getValue = valueOp.getChildExpression

  def setValue(value: Expression) = valueOp.setChildExpression(value)

  def getMin = minOp.getChildExpression

  def setMin(min: Expression) = minOp.setChildExpression(min)

  def getMax = maxOp.getChildExpression

  def setMax(max: Expression) = maxOp.setChildExpression(max)

  /**
   * Type-check the expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = { // Already done, we only get one of these expressions after the operands have been analyzed
    this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    if (Literal.isEmptySequence(getMin) || Literal.isEmptySequence(getMax) || Literal.isEmptySequence(getValue)) return new Literal(BooleanValue.FALSE)
    if (getMin.isInstanceOf[Literal] && getMax.isInstanceOf[Literal] && getValue.isInstanceOf[Literal]) {
      val result = evaluateItem(visitor.makeDynamicContext)
      return new Literal(result)
    }
    this
  }

  /**
   * Get the data type of the items returned
   */
  override def getItemType = BuiltInAtomicType.BOOLEAN

  /**
   * Determine the static cardinality
   */
  override def computeCardinality = StaticProperty.EXACTLY_ONE

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be re-bound
   */
  override def copy(rebindings: RebindingMap) = {
    val exp = new IntegerRangeTest(getValue.copy(rebindings), getMin.copy(rebindings), getMax.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, exp)
    exp
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = EVALUATE_METHOD

  /**
   * Is this expression the same as another expression?
   *
   * @param other the expression to be compared with this one
   * @return true if the two expressions are statically equivalent
   */
  override def equals(other: Any) = other.isInstanceOf[IntegerRangeTest] && other.asInstanceOf[IntegerRangeTest].getValue.isEqual(getValue) && other.asInstanceOf[IntegerRangeTest].getMin.isEqual(getMin) && other.asInstanceOf[IntegerRangeTest].getMax.isEqual(getMax)

  /**
   * Hashcode supporting equals()
   */
  override def computeHashCode = {
    var h = getValue.hashCode + 77
    h ^= getMin.hashCode ^ getMax.hashCode
    h
  }

  /**
   * Evaluate the expression
   */
  @throws[XPathException]
  override def evaluateItem(c: XPathContext): BooleanValue = {
    var minVal = null
    var maxVal = null
    var toDouble = null
    val iter = getValue.iterate(c)
    var atom = null
    while ( {
      (atom = iter.next.asInstanceOf[AtomicValue]) != null
    }) {
      if (minVal == null) {
        minVal = getMin.evaluateItem(c).asInstanceOf[IntegerValue]
        if (minVal == null) return BooleanValue.FALSE
        maxVal = getMax.evaluateItem(c).asInstanceOf[IntegerValue]
        if (maxVal == null || maxVal.compareTo(minVal) < 0) { // bug 3666
          return BooleanValue.FALSE
        }
      }
      var v = null
      if (atom.isInstanceOf[UntypedAtomicValue]) {
        if (toDouble == null) toDouble = BuiltInAtomicType.DOUBLE.getStringConverter(c.getConfiguration.getConversionRules)
        val result = toDouble.convertString(atom.getStringValueCS)
        if (result.isInstanceOf[ValidationFailure]) {
          val e = new XPathException("Failed to convert untypedAtomic value {" + atom.getStringValueCS + "}  to xs:integer", "FORG0001")
          e.setLocation(getLocation)
          throw e
        }
        else v = result.asAtomic.asInstanceOf[DoubleValue]
      }
      else if (atom.isInstanceOf[NumericValue]) v = atom.asInstanceOf[NumericValue]
      else {
        val e = new XPathException("Cannot compare value of type " + atom.getUType + " to xs:integer", "XPTY0004")
        e.setIsTypeError(true)
        e.setLocation(getLocation)
        throw e
      }
      if (v.isWholeNumber && v.compareTo(minVal) >= 0 && v.compareTo(maxVal) <= 0) return BooleanValue.TRUE
    }
    BooleanValue.FALSE
  }

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in export() output displaying the expression.
   */
  override def getExpressionName = "intRangeTest"

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("intRangeTest", this)
    getValue.`export`(destination)
    getMin.`export`(destination)
    getMax.`export`(destination)
    destination.endElement
  }

  /**
   * <p>The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form.</p>
   * <p>For subclasses of Expression that represent XPath expressions, the result should always be a string that
   * parses as an XPath 3.0 expression. </p>
   *
   * @return a representation of the expression as a string
   */
  override def toString = ExpressionTool.parenthesize(getValue) + " = (" + ExpressionTool.parenthesize(getMin) + " to " + ExpressionTool.parenthesize(getMax) + ")"
}