////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

/**
 * An implementation of NodeName that encapsulates an integer fingerprint, a string prefix, and a reference to the NamePool from which
 * the fingerprint was allocated.
 */
class CodedName(var fingerprint: Int, var prefix: String, var pool: NamePool) //        if (fingerprint >> 20 != 0) {
//            throw new IllegalArgumentException();
//        }
  extends NodeName {
  /**
   * Get the prefix of the QName.
   *
   * @return the prefix. Returns the empty string if the name is unprefixed.
   */
  override def getPrefix = prefix

  /**
   * Get the namespace URI of the QName.
   *
   * @return the URI. Returns the empty string to represent the no-namespace
   */
  override def getURI = pool.getURI(fingerprint)

  /**
   * Get the local part of the QName
   *
   * @return the local part of the QName
   */
  override def getLocalPart = pool.getLocalName(fingerprint)

  /**
   * Get the display name, that is the lexical QName in the form [prefix:]local-part
   *
   * @return the lexical QName
   */
  override def getDisplayName = if (prefix.isEmpty) getLocalPart
  else prefix + ":" + getLocalPart

  /**
   * Get the name in the form of a StructuredQName
   *
   * @return the name in the form of a StructuredQName
   */
  override def getStructuredQName = {
    val qn = pool.getUnprefixedQName(fingerprint)
    if (prefix.isEmpty) qn
    else new StructuredQName(prefix, qn.getURI, qn.getLocalPart)
  }

  /**
   * Test whether this name is in a given namespace
   *
   * @param ns the namespace to be tested against
   * @return true if the name is in the specified namespace
   */
  override def hasURI(ns: String) = getURI == ns

  /**
   * Get a {@link net.sf.saxon.om.NamespaceBinding} whose (prefix, uri) pair are the prefix and URI of this
   * node name
   *
   * @return the corresponding NamespaceBinding
   */
  override def getNamespaceBinding = new NamespaceBinding(prefix, pool.getURI(fingerprint))

  /**
   * Ask whether this node name representation has a known fingerprint
   *
   * @return true if the method getFingerprint() will
   *         return a result other than -1
   */
  override def hasFingerprint = true

  /**
   * Get the fingerprint of this name if known. This method should not to any work to allocate
   * a fingerprint if none is already available
   *
   * @return the fingerprint if known; otherwise -1
   */
  override def getFingerprint = fingerprint

  /**
   * Get the nameCode of this name, allocating a new code from the namepool if necessary
   *
   * @param namePool the NamePool used to allocate the name
   * @return a nameCode for this name, newly allocated if necessary
   */
  override def obtainFingerprint(namePool: NamePool) = fingerprint

  /**
   * Returns a hash code value for the object.
   */
  override def hashCode = StructuredQName.computeHashCode(getURI, getLocalPart)

  /**
   * Indicates whether some other object is "equal to" this one.
   */
  override def equals(obj: Any) = if (obj.isInstanceOf[NodeName]) {
    val n = obj.asInstanceOf[NodeName]
    if (n.hasFingerprint) getFingerprint == n.getFingerprint
    else n.getLocalPart == getLocalPart && n.hasURI(getURI)
  }
  else false

  override def isIdentical(other: IdentityComparable) = other.isInstanceOf[NodeName] && this == other && this.getPrefix == other.asInstanceOf[NodeName].getPrefix()

  /**
   * Get a hashCode that offers the guarantee that if A.isIdentical(B), then A.identityHashCode() == B.identityHashCode()
   *
   * @return a hashCode suitable for use when testing for identity.
   */
  override def identityHashCode = hashCode ^ getPrefix.hashCode

  /**
   * The toString() method returns the value of getDisplayName(), that is, the lexical QName
   *
   * @return the value as a lexical QName
   */
  override def toString = getDisplayName
}