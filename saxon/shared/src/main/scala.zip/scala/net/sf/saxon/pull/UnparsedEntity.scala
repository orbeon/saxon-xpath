////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.pull

/**
 * This class is used to represent unparsed entities in the PullProvider interface
 */
class UnparsedEntity {
  private var name = null
  private var systemId = null
  private var publicId = null
  private var baseURI = null

  /**
   * Get the name of the unparsed entity
   *
   * @return the name of the unparsed entity
   */
  def getName = name

  /**
   * Set the name of the unparsed entity
   *
   * @param name the name of the unparsed entity
   */
  def setName(name: String) = this.name = name

  /**
   * Get the system identifier of the unparsed entity
   *
   * @return the system identifier of the unparsed entity
   */
  def getSystemId = systemId

  /**
   * Set the system identifier of the unparsed entity
   *
   * @param systemId the system identifier of the unparsed entity
   */
  def setSystemId(systemId: String) = this.systemId = systemId

  /**
   * Get the public identifier of the unparsed entity
   *
   * @return the public identifier of the unparsed entity
   */
  def getPublicId = publicId

  /**
   * Set the public identifier of the unparsed entity
   *
   * @param publicId the public identifier of the unparsed entity
   */
  def setPublicId(publicId: String) = this.publicId = publicId

  /**
   * Get the base URI of the unparsed entity
   *
   * @return the base URI  of the unparsed entity
   */
  def getBaseURI = baseURI

  /**
   * Set the base URI of the unparsed entity
   *
   * @param baseURI the base URI  of the unparsed entity
   */
  def setBaseURI(baseURI: String) = this.baseURI = baseURI
}