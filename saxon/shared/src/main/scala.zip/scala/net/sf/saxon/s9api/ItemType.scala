////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.lib.ConversionRules
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.StandardURIChecker
import net.sf.saxon.ma.arrays.ArrayItem
import net.sf.saxon.ma.arrays.ArrayItemType
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.ma.map.MapType
import net.sf.saxon.model._
import net.sf.saxon.om.Function
import net.sf.saxon.om.Item
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.pattern.AnyNodeTest
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.pattern.NodeTest
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.NumericValue

/**
 * An item type, as defined in the XPath/XQuery specifications.
 * <p>This class contains a number of static constant fields
 * referring to instances that represent simple item types, such as
 * <code>item()</code>, <code>node()</code>, and <code>xs:anyAtomicType</code>. These named types are currently
 * based on the definitions in XSD 1.0 and XML 1.0. They may be changed in a future version to be based
 * on a later version.</p>
 * <p>More complicated item types, especially those that are dependent on information in a schema,
 * are available using factory methods on the {@link ItemTypeFactory} object. The factory methods can
 * also be used to create variants of the types that use the rules given in the XML 1.1 and/or XSD 1.1 specifications.</p>
 */
@SuppressWarnings(Array("WeakerAccess")) object ItemType {
  private val defaultConversionRules = new ConversionRules
  /**
   * ItemType representing the type item(), that is, any item at all
   */
  var ANY_ITEM = new ItemType() {
    override def getConversionRules = defaultConversionRules

    override

    def matches(item: XdmItem) = true

    override

    def subsumes(other: ItemType) = true

    override

    def getUnderlyingItemType = AnyItemType.getInstance
  }
  /**
   * ItemType representing the type function(*), that is, any function
   */
  var ANY_FUNCTION = new ItemType() {
    override def matches(item: XdmItem) = item.getUnderlyingValue.isInstanceOf[Function]

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.isInstanceOf[FunctionItemType]

    override

    def getUnderlyingItemType = AnyFunctionType.getInstance
  }
  /**
   * ItemType representing the type node(), that is, any node
   */
  val ANY_NODE = new ItemType() {
    override def matches(item: XdmItem) = item.getUnderlyingValue.isInstanceOf[NodeInfo]

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.isInstanceOf[NodeTest]

    override

    def getUnderlyingItemType = AnyNodeTest.getInstance
  }
  /**
   * ItemType representing the ATTRIBUTE node() type
   */
  val ATTRIBUTE_NODE = new ItemType() {
    override def matches(item: XdmItem) = {
      val it = item.getUnderlyingValue
      it.isInstanceOf[NodeInfo] && it.asInstanceOf[NodeInfo].getNodeKind == Type.ATTRIBUTE
    }

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.getUType eq UType.ATTRIBUTE

    override

    def getUnderlyingItemType = NodeKindTest.ATTRIBUTE
  }
  /**
   * ItemType representing the COMMENT node() type
   */
  val COMMENT_NODE = new ItemType() {
    override def matches(item: XdmItem) = {
      val it = item.getUnderlyingValue
      it.isInstanceOf[NodeInfo] && it.asInstanceOf[NodeInfo].getNodeKind == Type.COMMENT
    }

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.getUType eq UType.COMMENT

    override

    def getUnderlyingItemType = NodeKindTest.COMMENT
  }
  /**
   * ItemType representing the TEXT node() type
   */
  val TEXT_NODE = new ItemType() {
    override def matches(item: XdmItem) = {
      val it = item.getUnderlyingValue
      it.isInstanceOf[NodeInfo] && it.asInstanceOf[NodeInfo].getNodeKind == Type.TEXT
    }

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.getUType eq UType.TEXT

    override

    def getUnderlyingItemType = NodeKindTest.TEXT
  }
  /**
   * ItemType representing the ELEMENT node() type
   */
  val ELEMENT_NODE = new ItemType() {
    override def matches(item: XdmItem) = {
      val it = item.getUnderlyingValue
      it.isInstanceOf[NodeInfo] && it.asInstanceOf[NodeInfo].getNodeKind == Type.ELEMENT
    }

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.getUType eq UType.ELEMENT

    override

    def getUnderlyingItemType = NodeKindTest.ELEMENT
  }
  /**
   * ItemType representing the DOCUMENT node() type
   */
  val DOCUMENT_NODE = new ItemType() {
    override def matches(item: XdmItem) = {
      val it = item.getUnderlyingValue
      it.isInstanceOf[NodeInfo] && it.asInstanceOf[NodeInfo].getNodeKind == Type.DOCUMENT
    }

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.getUType eq UType.DOCUMENT

    override

    def getUnderlyingItemType = NodeKindTest.DOCUMENT
  }
  /**
   * ItemType representing the NAMESPACE node() type
   */
  val NAMESPACE_NODE = new ItemType() {
    override def matches(item: XdmItem) = {
      val it = item.getUnderlyingValue
      it.isInstanceOf[NodeInfo] && it.asInstanceOf[NodeInfo].getNodeKind == Type.NAMESPACE
    }

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.getUType eq UType.NAMESPACE

    override

    def getUnderlyingItemType = NodeKindTest.NAMESPACE
  }
  /**
   * ItemType representing the PROCESSING_INSTRUCTION node() type
   */
  val PROCESSING_INSTRUCTION_NODE = new ItemType() {
    override def matches(item: XdmItem) = {
      val it = item.getUnderlyingValue
      it.isInstanceOf[NodeInfo] && it.asInstanceOf[NodeInfo].getNodeKind == Type.PROCESSING_INSTRUCTION
    }

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.getUType eq UType.PI

    override

    def getUnderlyingItemType = NodeKindTest.PROCESSING_INSTRUCTION
  }
  /**
   * ItemType representing the type map(*), that is, any map
   */
  val ANY_MAP = new ItemType() {
    override def matches(item: XdmItem) = item.getUnderlyingValue.isInstanceOf[MapItem]

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.isInstanceOf[MapType]

    override

    def getUnderlyingItemType = MapType.ANY_MAP_TYPE
  }
  /**
   * ItemType representing the type array(*), that is, any array
   */
  val ANY_ARRAY = new ItemType() {
    override def matches(item: XdmItem) = item.getUnderlyingValue.isInstanceOf[ArrayItem]

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.isInstanceOf[ArrayItemType]

    override

    def getUnderlyingItemType = ArrayItemType.ANY_ARRAY_TYPE
  }
  /**
   * ItemType representing the type xs:anyAtomicType, that is, any atomic value
   */
  val ANY_ATOMIC_VALUE = new ItemType() {
    override def matches(item: XdmItem) = item.getUnderlyingValue.isInstanceOf[AtomicValue]

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.isInstanceOf[AtomicType]

    override

    def getUnderlyingItemType = BuiltInAtomicType.ANY_ATOMIC
  }
  /**
   * ItemType representing the type xs:error: a type with no instances
   */
  val ERROR = new ItemType() {
    override def matches(item: XdmItem) = false

    override

    def subsumes(other: ItemType) = other.getUnderlyingItemType.isInstanceOf[ErrorType]

    override

    def getUnderlyingItemType = ErrorType.getInstance
  }

  /**
   * ItemType representing a built-in atomic type
   */
  private[s9api] object BuiltInAtomicItemType {
    def makeVariant(`type`: ItemType.BuiltInAtomicItemType, conversionRules: ConversionRules) = new ItemType.BuiltInAtomicItemType(`type`.underlyingType, conversionRules)
  }

  private[s9api] class BuiltInAtomicItemType(var underlyingType: BuiltInAtomicType, var conversionRules: ConversionRules) extends ItemType {
    override def getConversionRules = conversionRules

    override def matches(item: XdmItem): Boolean = {
      val value = item.getUnderlyingValue
      if (!value.isInstanceOf[AtomicValue]) return false
      val `type` = value.asInstanceOf[AtomicValue].getItemType
      subsumesUnderlyingType(`type`)
    }

    override def subsumes(other: ItemType): Boolean = {
      val otherType = other.getUnderlyingItemType
      if (!otherType.isPlainType) return false
      val `type` = otherType.asInstanceOf[AtomicType]
      subsumesUnderlyingType(`type`)
    }

    private def subsumesUnderlyingType(`type`: AtomicType): Boolean = {
      var builtIn = if (`type`.isInstanceOf[BuiltInAtomicType]) `type`.asInstanceOf[BuiltInAtomicType]
      else `type`.getBuiltInBaseType.asInstanceOf[BuiltInAtomicType]
      while ( {
        true
      }) {
        if (builtIn.isSameType(underlyingType)) return true
        val base = builtIn.getBaseType
        if (!base.isInstanceOf[BuiltInAtomicType]) return false
        builtIn = base.asInstanceOf[BuiltInAtomicType]
      }
    }

    override def getUnderlyingItemType = underlyingType
  }

  /**
   * ItemType representing the primitive type xs:string
   */
  val STRING = atomic(BuiltInAtomicType.STRING, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:boolean
   */
  val BOOLEAN = atomic(BuiltInAtomicType.BOOLEAN, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:duration
   */
  val DURATION = atomic(BuiltInAtomicType.DURATION, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:dateTime
   */
  val DATE_TIME = atomic(BuiltInAtomicType.DATE_TIME, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:date
   */
  val DATE = atomic(BuiltInAtomicType.DATE, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:time
   */
  val TIME = atomic(BuiltInAtomicType.TIME, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:gYearMonth
   */
  val G_YEAR_MONTH = atomic(BuiltInAtomicType.G_YEAR_MONTH, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:gMonth
   */
  val G_MONTH = atomic(BuiltInAtomicType.G_MONTH, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:gMonthDay
   */
  val G_MONTH_DAY = atomic(BuiltInAtomicType.G_MONTH_DAY, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:gYear
   */
  val G_YEAR = atomic(BuiltInAtomicType.G_YEAR, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:gDay
   */
  val G_DAY = atomic(BuiltInAtomicType.G_DAY, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:hexBinary
   */
  val HEX_BINARY = atomic(BuiltInAtomicType.HEX_BINARY, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:base64Binary
   */
  val BASE64_BINARY = atomic(BuiltInAtomicType.BASE64_BINARY, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:anyURI
   */
  val ANY_URI = atomic(BuiltInAtomicType.ANY_URI, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:QName
   */
  val QNAME = atomic(BuiltInAtomicType.QNAME, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:NOTATION
   */
  val NOTATION = atomic(BuiltInAtomicType.NOTATION, defaultConversionRules)
  /**
   * ItemType representing the XPath-defined type xs:untypedAtomic
   */
  val UNTYPED_ATOMIC = atomic(BuiltInAtomicType.UNTYPED_ATOMIC, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:decimal
   */
  val DECIMAL = atomic(BuiltInAtomicType.DECIMAL, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:float
   */
  val FLOAT = atomic(BuiltInAtomicType.FLOAT, defaultConversionRules)
  /**
   * ItemType representing the primitive type xs:double
   */
  val DOUBLE = atomic(BuiltInAtomicType.DOUBLE, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:integer
   */
  val INTEGER = atomic(BuiltInAtomicType.INTEGER, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:nonPositiveInteger
   */
  val NON_POSITIVE_INTEGER = atomic(BuiltInAtomicType.NON_POSITIVE_INTEGER, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:negativeInteger
   */
  val NEGATIVE_INTEGER = atomic(BuiltInAtomicType.NEGATIVE_INTEGER, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:long
   */
  val LONG = atomic(BuiltInAtomicType.LONG, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:int
   */
  val INT = atomic(BuiltInAtomicType.INT, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:short
   */
  val SHORT = atomic(BuiltInAtomicType.SHORT, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:byte
   */
  val BYTE = atomic(BuiltInAtomicType.BYTE, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:nonNegativeInteger
   */
  val NON_NEGATIVE_INTEGER = atomic(BuiltInAtomicType.NON_NEGATIVE_INTEGER, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:positiveInteger
   */
  val POSITIVE_INTEGER = atomic(BuiltInAtomicType.POSITIVE_INTEGER, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:unsignedLong
   */
  val UNSIGNED_LONG = atomic(BuiltInAtomicType.UNSIGNED_LONG, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:unsignedInt
   */
  val UNSIGNED_INT = atomic(BuiltInAtomicType.UNSIGNED_INT, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:unsignedShort
   */
  val UNSIGNED_SHORT = atomic(BuiltInAtomicType.UNSIGNED_SHORT, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:unsignedByte
   */
  val UNSIGNED_BYTE = atomic(BuiltInAtomicType.UNSIGNED_BYTE, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:yearMonthDuration
   */
  val YEAR_MONTH_DURATION = atomic(BuiltInAtomicType.YEAR_MONTH_DURATION, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:dayTimeDuration
   */
  val DAY_TIME_DURATION = atomic(BuiltInAtomicType.DAY_TIME_DURATION, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:normalizedString
   */
  val NORMALIZED_STRING = atomic(BuiltInAtomicType.NORMALIZED_STRING, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:token
   */
  val TOKEN = atomic(BuiltInAtomicType.TOKEN, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:language
   */
  val LANGUAGE = atomic(BuiltInAtomicType.LANGUAGE, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:Name
   */
  val NAME = atomic(BuiltInAtomicType.NAME, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:NMTOKEN
   */
  val NMTOKEN = atomic(BuiltInAtomicType.NMTOKEN, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:NCName
   */
  val NCNAME = atomic(BuiltInAtomicType.NCNAME, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:ID
   */
  val ID = atomic(BuiltInAtomicType.ID, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:IDREF
   */
  val IDREF = atomic(BuiltInAtomicType.IDREF, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:ENTITY
   */
  val ENTITY = atomic(BuiltInAtomicType.ENTITY, defaultConversionRules)
  /**
   * ItemType representing the built-in (but non-primitive) type xs:dateTimeStamp
   * (introduced in XSD 1.1)
   */
  val DATE_TIME_STAMP = atomic(BuiltInAtomicType.DATE_TIME_STAMP, defaultConversionRules)

  /**
   * Create an ItemType representing a built-in atomic type.
   *
   * @param underlyingType  the BuiltInAtomicType object representing this type
   * @param conversionRules the conversion rules to be used
   * @return the ItemType.
   */
  private def atomic(underlyingType: BuiltInAtomicType, conversionRules: ConversionRules) = new ItemType.BuiltInAtomicItemType(underlyingType, conversionRules)

  /**
   * ItemType representing the built-in union type xs:numeric defined in XDM 3.1
   */
  val NUMERIC = new ItemType() {
    override def getConversionRules = defaultConversionRules

    override

    def matches(item: XdmItem) = item.getUnderlyingValue.isInstanceOf[NumericValue]

    override

    def subsumes(other: ItemType) = DECIMAL.subsumes(other) || DOUBLE.subsumes(other) || FLOAT.subsumes(other)

    override

    def getUnderlyingItemType = NumericType.getInstance
  }
  try defaultConversionRules.setStringToDoubleConverter(StringToDouble.getInstance)
  defaultConversionRules.setNotationSet(null)
  defaultConversionRules.setURIChecker(StandardURIChecker.getInstance)
}

@SuppressWarnings(Array("WeakerAccess")) abstract class ItemType {
  /**
   * Get the conversion rules implemented by this type. The conversion rules reflect variations
   * between different versions of the W3C specifications, for example XSD 1.1 allows "+INF" as
   * a lexical representation of xs:double, while XSD 1.0 does not.
   *
   * @return the conversion rules
   */
    /*@Nullable*/ def getConversionRules = ItemType.defaultConversionRules

  /**
   * Determine whether this item type matches a given item.
   *
   * @param item the item to be tested against this item type
   * @return true if the item matches this item type, false if it does not match.
   */
  def matches(item: XdmItem)

  /**
   * Determine whether this ItemType subsumes another ItemType. Specifically,
   * <code>A.subsumes(B)</code> is true if every value that matches the ItemType B also matches
   * the ItemType A.
   *
   * @param other the other ItemType
   * @return true if this ItemType subsumes the other ItemType. This includes the case where A and B
   *         represent the same ItemType.
   * @since 9.1
   */
  def subsumes(other: ItemType)

  /**
   * Method to get the underlying Saxon implementation object
   * <p>This gives access to Saxon methods that may change from one release to another.</p>
   *
   * @return the underlying Saxon implementation object
   */
  def getUnderlyingItemType

  /**
   * Get the name of the type, if it has one
   *
   * @return the name of the type, or null if it is either an anonymous schema-defined type,
   *         or an XDM-defined type such as node() or map().
   * @since 9.7
   */
  def getTypeName = {
    val `type` = getUnderlyingItemType
    if (`type`.isInstanceOf[SchemaType]) {
      val name = `type`.asInstanceOf[SchemaType].getStructuredQName
      if (name == null) null
      else new QName(name)
    }
    else null
  }

  /**
   * Test whether two ItemType objects represent the same type
   *
   * @param other the other ItemType object
   * @return true if the other object is an ItemType representing the same type
   * @since 9.5
   */
  override final def equals(other: Any) = other.isInstanceOf[ItemType] && getUnderlyingItemType == other.asInstanceOf[ItemType].getUnderlyingItemType

  /**
   * Get a hash code with semantics corresponding to the equals() method
   *
   * @return the hash code
   * @since 9.5
   */
  override final def hashCode = getUnderlyingItemType.hashCode

  /**
   * Get a string representation of the type. This will be a string that conforms to the
   * XPath ItemType production, for example a QName (always in "Q{uri}local" format, or a construct
   * such as "node()" or "map(*)". If the type is an anonymous schema type, the name of the nearest
   * named base type will be given, preceded by the character "&lt;".
   *
   * @return a string representation of the type
   * @since 9.7
   */
  override def toString: String = {
    val `type` = getUnderlyingItemType
    if (`type`.isInstanceOf[SchemaType]) {
      var marker = ""
      var st = `type`.asInstanceOf[SchemaType]
      var name = null
      while ( {
        true
      }) {
        name = st.getStructuredQName
        if (name != null) return marker + name.getEQName
        else {
          marker = "<"
          st = st.getBaseType
          if (st == null) return "Q{" + NamespaceConstant.SCHEMA + "}anyType"
        }
      }
    }
    else `type`.toString
  }
}