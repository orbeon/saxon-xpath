////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr._
import net.sf.saxon.expr.instruct.ApplyTemplates
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.expr.sort.SortExpression
import net.sf.saxon.expr.sort.SortKeyDefinitionList
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.pattern.AnyNodeTest
import net.sf.saxon.pattern.NameTest
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.Mode
import net.sf.saxon.trans.SymbolicName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.rules.RuleManager
import net.sf.saxon.value.Whitespace
import java.util

/**
 * An xsl:apply-templates element in the stylesheet
 */
class XSLApplyTemplates extends StyleElement {
  /*@Nullable*/ private var select = null
  private var modeName = null // null if no name specified or if conventional values such as #current used
  private var useCurrentMode = false
  private var useTailRecursion = false
  private var defaultedSelectExpression = true
  private var mode = null
  private var modeAttribute = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  override def prepareAttributes() = {
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "mode" =>
          modeAttribute = Whitespace.trim(value)
        case "select" =>
          selectAtt = value
          select = makeExpression(selectAtt, att)
          defaultedSelectExpression = false
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (modeAttribute != null) modeAttribute match {
      case "#current" =>
        useCurrentMode = true
      case "#unnamed" =>
        modeName = Mode.UNNAMED_MODE_NAME
      case "#default" =>
      // do nothing;
      case _ =>
        modeName = makeQName(modeAttribute, null, "mode")
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = { // get the Mode object
    if (useCurrentMode) { // give a warning if we're not inside an xsl:template
      if (iterateAxis(AxisInfo.ANCESTOR, new NameTest(Type.ELEMENT, StandardNames.XSL_TEMPLATE, getNamePool)).next == null) issueWarning("Specifying mode=\"#current\" when not inside an xsl:template serves no useful purpose", this)
    }
    else {
      val psm = getPrincipalStylesheetModule
      if (modeName == null) { // XSLT 3.0 allows a default mode to be specified on a containing element
        modeName = getDefaultMode
        if ((modeName == null || modeName == Mode.UNNAMED_MODE_NAME) && psm.isDeclaredModes && !psm.getRuleManager.isUnnamedModeExplicit) compileError("The unnamed mode must be explicitly declared in an xsl:mode declaration", "XTSE3085")
      }
      else if (modeName == Mode.UNNAMED_MODE_NAME && psm.isDeclaredModes && !psm.getRuleManager.isUnnamedModeExplicit) compileError("The #unnamed mode must be explicitly declared in an xsl:mode declaration", "XTSE3085")
      val sName = new SymbolicName(StandardNames.XSL_MODE, modeName)
      val containingPackage = decl.getSourceElement.getContainingPackage
      val componentIndex = containingPackage.getComponentIndex
      // see if there is a mode with this name in a used package
      val existing = componentIndex.get(sName)
      if (existing != null) mode = existing.getActor.asInstanceOf[Mode]
      if (mode == null) {
        if (psm.isDeclaredModes) compileError("Mode name " + modeName.getDisplayName + " must be explicitly declared in an xsl:mode declaration", "XTSE3085")
        mode = psm.getRuleManager.obtainMode(modeName, true)
      }
    }
    // handle sorting if requested
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.getNodeKind == Type.TEXT) { // with xml:space=preserve, white space nodes may still be there
        if (!Whitespace.isWhite(child.getStringValueCS)) compileError("No character data is allowed within xsl:apply-templates", "XTSE0010")
      }
      else if (!(child.isInstanceOf[XSLSort] || child.isInstanceOf[XSLWithParam])) compileError("Invalid element " + Err.wrap(child.getDisplayName, Err.ELEMENT) + " within xsl:apply-templates", "XTSE0010")
    }
    if (select == null) {
      var here = new ContextItemExpression
      val role = new RoleDiagnostic(RoleDiagnostic.CONTEXT_ITEM, "", 0)
      role.setErrorCode("XTTE0510")
      here = new ItemChecker(here, AnyNodeTest.getInstance, role)
      select = new SimpleStepExpression(here, new AxisExpression(AxisInfo.CHILD, null))
      //select = new AxisExpression(AxisInfo.CHILD, null);
      select.setLocation(allocateLocation)
      select.setRetainedStaticContext(makeRetainedStaticContext)
    }
    select = typeCheck("select", select)
  }

  /**
   * Mark tail-recursive calls on templates and functions.
   * For most instructions, this does nothing.
   */
  override def markTailCalls = {
    useTailRecursion = true
    true
  }

  @throws[XPathException]
  override def compile(compilation: Compilation, decl: ComponentDeclaration) = {
    val sortKeys = makeSortKeys(compilation, decl)
    if (sortKeys != null) useTailRecursion = false
    assert(select != null)
    var sortedSequence = select
    if (sortKeys != null) sortedSequence = new SortExpression(select, sortKeys)
    compileSequenceConstructor(compilation, decl, true)
    val rm = compilation.getPrincipalStylesheetModule.getRuleManager
    val app = new ApplyTemplates(sortedSequence, useCurrentMode, useTailRecursion, defaultedSelectExpression, isWithinDeclaredStreamableConstruct, mode, rm)
    app.setActualParams(getWithParamInstructions(app, compilation, decl, false))
    app.setTunnelParams(getWithParamInstructions(app, compilation, decl, true))
    app
  }
}