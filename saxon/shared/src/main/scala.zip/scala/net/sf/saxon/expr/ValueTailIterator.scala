////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.Item
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.GroundedIterator
import net.sf.saxon.tree.iter.LookaheadIterator
import java.util

/**
 * <tt>ValueTailIterator</tt> iterates over a base sequence starting at an element other than the first.
 * It is used in the case where the base sequence is "grounded", that is, it exists in memory and
 * supports efficient direct addressing.
 */
class ValueTailIterator(var baseValue: GroundedValue, var start: Int // zero-based
                       )

/**
 * Construct a ValueTailIterator
 *
 * @param base  The items to be filtered
 * @param start The position of the first item to be included (zero-based)
 */
  extends SequenceIterator with GroundedIterator with LookaheadIterator {
  pos = 0
  private var pos = 0

  @throws[XPathException]
  override def next = baseValue.itemAt(start + {
    pos += 1; pos - 1
  })

  override def hasNext = baseValue.itemAt(start + pos) != null

  /**
   * Return a Value containing all the items in the sequence returned by this
   * SequenceIterator. This should be an "in-memory" value, not a Closure.
   *
   * @return the corresponding Value
   */
  override def materialize = if (start == 0) baseValue
  else baseValue.subsequence(start, Integer.MAX_VALUE)

  override def getResidue = if (start == 0 && pos == 0) baseValue
  else baseValue.subsequence(start + pos, Integer.MAX_VALUE)

  /**
   * Get properties of this iterator, as a bit-significant integer.
   *
   * @return the properties of this iterator. This will be some combination of
   *         properties such as { @link net.sf.saxon.om.SequenceIterator.Property#GROUNDED}, { @link net.sf.saxon.om.SequenceIterator.Property#LAST_POSITION_FINDER},
   *                                    and { @link net.sf.saxon.om.SequenceIterator.Property#LOOKAHEAD}. It is always
   *                                    acceptable to return the value zero, indicating that there are no known special properties.
   *                                    It is acceptable for the properties of the iterator to change depending on its state.
   */
  override def getProperties = util.EnumSet.of(Property.LOOKAHEAD, Property.GROUNDED)
}