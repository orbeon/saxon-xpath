////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.tree.jiter.MonoIterator
import java.util

/**
 * Represents the binding of a prefix to a URI. Also, in some contexts, represents an unbinding, by
 * virtue of the URI being set to a zero length string.
 *
 * @since 9.4
 */
object NamespaceBinding {
  val XML = new NamespaceBinding("xml", NamespaceConstant.XML)
  val DEFAULT_UNDECLARATION = new NamespaceBinding("", "")
  val EMPTY_ARRAY = new Array[NamespaceBinding](0)

  /**
   * Create a binding of a prefix to a URI. Static factory method for the convenience of compiled bytecode;
   * reuses standard NamespaceBinding objects where possible
   *
   * @param prefix the prefix: either an NCName, or a zero-length string to bind the default namespace.
   *               Must not be null.
   * @param uri    the namespace URI: either a URI, or a zero-length string to unbind the prefix. Must
   *               not be null.
   * @return the namespace binding object
   */
  def makeNamespaceBinding(prefix: CharSequence, uri: CharSequence) = if (prefix.length == 0 && uri.length == 0) DEFAULT_UNDECLARATION
  else if (prefix == "xml" && uri == NamespaceConstant.XML) XML
  else new NamespaceBinding(prefix.toString, uri.toString)
}

final class NamespaceBinding(var prefix: String, var uri: String)

/**
 * Create a binding of a prefix to a URI
 *
 * @param prefix the prefix: either an NCName, or a zero-length string to bind the default namespace.
 *               Must not be null.
 * @param uri    the namespace URI: either a URI, or a zero-length string to unbind the prefix. Must
 *               not be null.
 */
  extends NamespaceBindingSet {
  if (prefix == null || displayValue == null) throw new NullPointerException

  override def getURI(prefix: String) = if (prefix == this.prefix) uri
  else null

  /**
   * Get the prefix part of the binding
   *
   * @return the prefix. Never null. The zero-length string indicates a binding for the default namespace.
   */
  def getPrefix = prefix

  /**
   * Get the URI part of the binding
   *
   * @return the URI. Never null. The zero-length string indicates an unbinding of the prefix. For the
   *         default namespace (prefix="") this indicates that the prefix refers to names in no namespace; for other
   *         prefixes, it indicates that the prefix is not bound to any namespace and therefore cannot be used.
   */
  def getURI = uri

  /**
   * Ask whether this is a binding for the XML namespace
   *
   * @return true if this is the binding of the prefix "xml" to the standard XML namespace.
   */
  def isXmlNamespace = prefix == "xml"

  /**
   * Ask whether this is an undeclaration of the default prefix, that is, a namespace binding
   * corresponding to <code>xmlns=""</code>
   *
   * @return true if this corresponding to <code>xmlns=""</code>
   */
  def isDefaultUndeclaration = prefix.isEmpty && uri.isEmpty

  /**
   * Returns an iterator over this singleton set of namespace bindings.
   *
   * @return an Iterator.
   */
  override def iterator = new MonoIterator[NamespaceBinding](this)

  /**
   * Test if this namespace binding is the same as another
   *
   * @param obj the comparand
   * @return true if the comparand is a Namespace binding of the same prefix to the same URI
   */
  override def equals(obj: Any) = obj.isInstanceOf[NamespaceBinding] && prefix == obj.asInstanceOf[NamespaceBinding].getPrefix && uri == obj.asInstanceOf[NamespaceBinding].getURI

  override def hashCode = prefix.hashCode ^ uri.hashCode

  override def toString = prefix + "=" + uri
}