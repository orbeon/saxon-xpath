////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.expr.sort.AtomicMatchKey
import net.sf.saxon.model._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value._
import java.math.BigDecimal
import java.math.BigInteger
import java.net.URI
import java.time._

/**
 * The class XdmAtomicValue represents an item in an XPath 2.0 sequence that is an atomic value.
 * The value may belong to any of the 19 primitive types defined in XML Schema, or to a type
 * derived from these primitive types, or the XPath 2.0 type xs:untypedAtomic. The type may
 * be either a built-in type or a user-defined type.
 * <p>An <code>XdmAtomicValue</code> is immutable.</p>
 */
object XdmAtomicValue {
  /**
   * Attempt conversion from an arbitrary Java object
   *
   * @param value the value to convert from. This must either be an instance of { @link AtomicValue}
   *                                                                                    or { @link QName},
   *                                                                                    or one of the basic Java types Boolean, Integer, Long, Short, Character, Byte,
   *                                                                                    String, Double, Float, BigDecimal, BigInteger, URI, ZonedDateTime,
   *                                                                                    LocalDateTime, or LocalDate
   * @return the result of the conversion if successful
   * @throws IllegalArgumentException if conversion from this kind of Object is not supported
   * @since 10.0 (extended in 10.0 to handle additional data types ZonedDateTime, LocalDateTime, LocalDate)
   */
    def makeAtomicValue(value: Any) = if (value.isInstanceOf[AtomicValue]) new XdmAtomicValue(value.asInstanceOf[AtomicValue], true)
    else if (value.isInstanceOf[Boolean]) new XdmAtomicValue(value.asInstanceOf[Boolean])
    else if (value.isInstanceOf[Integer]) new XdmAtomicValue(value.asInstanceOf[Integer])
    else if (value.isInstanceOf[Long]) new XdmAtomicValue(value.asInstanceOf[Long])
    else if (value.isInstanceOf[Short]) new XdmAtomicValue(value.asInstanceOf[Short])
    else if (value.isInstanceOf[Character]) new XdmAtomicValue(value.asInstanceOf[Character])
    else if (value.isInstanceOf[Byte]) new XdmAtomicValue(value.asInstanceOf[Byte])
    else if (value.isInstanceOf[String]) new XdmAtomicValue(value.asInstanceOf[String])
    else if (value.isInstanceOf[Double]) new XdmAtomicValue(value.asInstanceOf[Double])
    else if (value.isInstanceOf[Float]) new XdmAtomicValue(value.asInstanceOf[Float])
    else if (value.isInstanceOf[BigDecimal]) new XdmAtomicValue(value.asInstanceOf[BigDecimal])
    else if (value.isInstanceOf[BigInteger]) new XdmAtomicValue(IntegerValue.makeIntegerValue(value.asInstanceOf[BigInteger]), true)
    else if (value.isInstanceOf[URI]) new XdmAtomicValue(value.asInstanceOf[URI])
    else if (value.isInstanceOf[QName]) new XdmAtomicValue(value.asInstanceOf[QName])
    else if (value.isInstanceOf[ZonedDateTime]) new XdmAtomicValue(value.asInstanceOf[ZonedDateTime])
    else if (value.isInstanceOf[LocalDateTime]) new XdmAtomicValue(value.asInstanceOf[LocalDateTime])
    else if (value.isInstanceOf[LocalDate]) new XdmAtomicValue(value.asInstanceOf[LocalDate])
    else if (value.isInstanceOf[XdmAtomicValue]) value.asInstanceOf[XdmAtomicValue]
    else throw new IllegalArgumentException(value.toString)
}

class XdmAtomicValue private() extends XdmItem {
  def this(value: AtomicValue, flag: Boolean) {
    this()
    setValue(value)
  }

  /**
   * Create an <tt>xs:boolean</tt> atomic value
   *
   * @param value the boolean value, true or false
   */
  def this(value: Boolean) {
    this(BooleanValue.get(value), true)
  }

  /**
   * Create an <tt>xs:long</tt> atomic value
   *
   * @param value the <tt>xs:integer</tt> value, as a long
   */
  def this(value: Long) {
    this(Int64Value.makeDerived(value, BuiltInAtomicType.LONG), true)
  }

  /**
   * Create an <tt>xs:int</tt> atomic value
   *
   * @param value the <tt>xs:integer</tt> value, as a long
   */
  def this(value: Int) {
    this(Int64Value.makeDerived(value, BuiltInAtomicType.INT), true)
  }

  /**
   * Create an <tt>xs:short</tt> atomic value
   *
   * @param value the <tt>xs:integer</tt> value, as a long
   */
  def this(value: Short) {
    this(Int64Value.makeDerived(value, BuiltInAtomicType.SHORT), true)
  }

  def this(value: Byte) {
    this(Int64Value.makeDerived(value, BuiltInAtomicType.BYTE), true)
  }

  /**
   * Create an <tt>xs:decimal</tt> atomic value
   *
   * @param value the <tt>xs:decimal</tt> value, as a BigDecimal
   */
  def this(value: BigDecimal) {
    this(new BigDecimalValue(value), true)
  }

  /**
   * Create an <tt>xs:double</tt> atomic value
   *
   * @param value the <tt>xs:double</tt> value, as a double
   */
  def this(value: Double) {
    this(new DoubleValue(value), true)
  }

  /**
   * Create an <tt>xs:float</tt> atomic value
   *
   * @param value the <tt>xs:float</tt> value, as a float
   */
  def this(value: Float) {
    this(new FloatValue(value), true)
  }

  /**
   * Create an <tt>xs:string</tt> atomic value
   *
   * @param value the <tt>xs:string</tt> value, as a string
   */
  def this(value: String) {
    this(new StringValue(value), true)
  }

  /**
   * Create an <tt>xs:anyURI</tt> atomic value
   *
   * @param value the <tt>xs:anyURI</tt> value, as a URI
   */
  def this(value: URI) {
    this(new AnyURIValue(value.toString), true)
  }

  /**
   * Create an <tt>xs:QName</tt> atomic value
   *
   * @param value the <tt>xs:QName</tt> value, as a QName
   */
  def this(value: QName) {
    this(new QNameValue(value.getStructuredQName, BuiltInAtomicType.QNAME), true)
  }

  /**
   * Create an <tt>xs:dateTime</tt> atomic value from a {@link Instant}. The resulting value
   * will always have a timezone component.
   *
   * @param value the <tt>xs:dateTime</tt> value in the form of a { @link Instant}
   * @since 10.0
   */
  def this(value: Instant) {
    this(DateTimeValue.fromJavaInstant(value), true)
  }

  /**
   * Create an <tt>xs:dateTime</tt> atomic value from a {@link ZonedDateTime}. The resulting value
   * will always have a timezone component. Note that the timezone offset (e.g. -05:00) is retained,
   * but the civil time zone identity (e.g. America/New_York) is lost.
   *
   * @param value the <tt>xs:dateTime</tt> value in the form of a { @link ZonedDateTime}
   * @since 10.0
   */
  def this(value: ZonedDateTime) {
    this(DateTimeValue.fromZonedDateTime(value), true)
  }

  /**
   * Create an <tt>xs:dateTime</tt> atomic value from a {@link OffsetDateTime}. The resulting value
   * will always have a timezone component. The timezone offset (e.g. -05:00) is retained.
   *
   * @param value the <tt>xs:dateTime</tt> value in the form of a { @link OffsetDateTime}
   * @since 10.0
   */
  def this(value: OffsetDateTime) {
    this(DateTimeValue.fromOffsetDateTime(value), true)
  }

  /**
   * Create an <tt>xs:dateTime</tt> atomic value from a {@link LocalDateTime}. The resulting value
   * will have no timezone component.
   *
   * @param value the <tt>xs:dateTime</tt> value in the form of a { @link LocalDateTime}
   * @since 10.0
   */
  def this(value: LocalDateTime) {
    this(DateTimeValue.fromLocalDateTime(value), true)
  }

  /**
   * Create an <tt>xs:date</tt> atomic value from a {@link LocalDate}. The resulting value
   * will have no timezone component.
   *
   * @param value the <tt>xs:dateTime</tt> value in the form of a { @link LocalDate}
   * @since 10.0
   */
  def this(value: LocalDate) {
    this(new DateValue(value), true)
  }

  /**
   * Construct an atomic value given its lexical representation and the name of the required
   * built-in atomic type.
   * <p>This method cannot be used to construct values that are namespace-sensitive (QNames and Notations)</p>
   *
   * @param lexicalForm the value in the lexical space of the target data type. More strictly, the input
   *                    value before the actions of the whitespace facet for the target data type are applied.
   * @param type        the required atomic type. This must either be one of the built-in
   *                    atomic types defined in XML Schema, or a user-defined type whose definition appears
   *                    in a schema that is known to the Processor. It must not be an abstract type.
   * @throws SaxonApiException if the type is unknown, or is not atomic, or is namespace-sensitive;
   *                           or if the value supplied in <tt>lexicalForm</tt> is not in the lexical space of the specified atomic
   *                           type.
   */
  @throws(classOf[SaxonApiException])
  def this(lexicalForm: String, `type`: ItemType) = {
    this()
    val it = `type`.getUnderlyingItemType
    if (!it.isPlainType) throw new SaxonApiException("Requested type is not atomic")
    if (it.asInstanceOf[AtomicType].isAbstract) throw new SaxonApiException("Requested type is an abstract type")
    if (it.asInstanceOf[AtomicType].isNamespaceSensitive) throw new SaxonApiException("Requested type is namespace-sensitive")
    try {
      val converter = it.asInstanceOf[AtomicType].getStringConverter(`type`.getConversionRules)
      setValue(converter.convertString(lexicalForm).asAtomic)
    } catch {
      case e: ValidationException =>
        throw new SaxonApiException(e)
    }
  }

  /**
   * Get the underlying implementation object representing the value. This method allows
   * access to lower-level Saxon functionality, including classes and methods that offer
   * no guarantee of stability across releases.
   *
   * @return the underlying implementation object representing the value
   * @since 9.8 (previously inherited from XdmValue which returns a Sequence)
   */
  override def getUnderlyingValue = super.getUnderlyingValue.asInstanceOf[AtomicValue]

  /**
   * Get the result of converting the atomic value to a string. This has the same
   * effect as the XPath string() function.
   */
  override def toString = getStringValue

  /**
   * Get the primitive type of this atomic value, as a QName. The primitive types for this purpose are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is xs:anyAtomicType.
   *
   * @return a QName naming the primitive type of this atomic value. This will always be an atomic type.
   */
  /*@NotNull*/ def getPrimitiveTypeName = {
    val value = getUnderlyingValue
    val `type` = value.getPrimitiveType
    new QName(`type`.getStructuredQName)
  }

  /**
   * Get the type of this atomic value, as a QName.
   *
   * @return a QName naming the type of this atomic value. This will always be an atomic type.
   */
  def getTypeName = {
    val value = getUnderlyingValue
    val `type` = value.getItemType
    new QName(`type`.getStructuredQName)
  }

  /**
   * Get the value as a Java object of the nearest equivalent type.
   * <p>The result type is as follows:</p>
   * <table>
   * <tr><th>XPath type</th>      <th>Java class</th></tr>
   * <tr><td>xs:string</td>       <td>String</td></tr>
   * <tr><td>xs:integer</td>      <td>java.math.BigInteger</td></tr>
   * <tr><td>xs:decimal</td>      <td>java.math.BigDecimal</td></tr>
   * <tr><td>xs:double</td>       <td>Double</td></tr>
   * <tr><td>xs:float</td>        <td>Float</td></tr>
   * <tr><td>xs:boolean</td>      <td>Boolean</td></tr>
   * <tr><td>xs:QName</td>        <td>QName</td></tr>
   * <tr><td>xs:anyURI</td>       <td>String</td></tr>
   * <tr><td>xs:dateTime</td>     <td>ZonedDateTime or LocalDateTime (depending whether a timezone is present)</td></tr>
   * <tr><td>xs:date</td>         <td>LocalDate (dropping any timezone)</td></tr>
   * <tr><td>xs:untypedAtomic</td><td>String</td></tr>
   * <tr><td>Other types</td>     <td>currently String, but this may change in the future</td></tr>
   * </table>
   *
   * @return the value, converted to a Java object of a suitable type
   * @since 10.0 (added additional return types for xs:dateTime and xs:date)
   */
  @SuppressWarnings(Array(Array("AutoBoxing"))) def getValue = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[StringValue]) av.getStringValue
    else if (av.isInstanceOf[IntegerValue]) av.asInstanceOf[IntegerValue].asBigInteger
    else if (av.isInstanceOf[DoubleValue]) av.asInstanceOf[DoubleValue].getDoubleValue
    else if (av.isInstanceOf[FloatValue]) av.asInstanceOf[FloatValue].getFloatValue
    else if (av.isInstanceOf[BooleanValue]) av.asInstanceOf[BooleanValue].getBooleanValue
    else if (av.isInstanceOf[BigDecimalValue]) av.asInstanceOf[BigDecimalValue].getDecimalValue
    else if (av.isInstanceOf[DateTimeValue]) if (av.asInstanceOf[DateTimeValue].hasTimezone) av.asInstanceOf[DateTimeValue].toZonedDateTime
    else av.asInstanceOf[DateTimeValue].toLocalDateTime
    else if (av.isInstanceOf[DateValue]) av.asInstanceOf[DateValue].toLocalDate
    else if (av.isInstanceOf[QNameValue]) {
      val q = av.asInstanceOf[QNameValue]
      new QName(q.getPrefix, q.getNamespaceURI, q.getLocalName)
    }
    else av.getStringValue
  }

  /**
   * Get the value converted to a boolean using the XPath casting rules
   *
   * @return the result of converting to a boolean (Note: this is not the same as the
   *         effective boolean value).
   * @throws SaxonApiException if the value cannot be cast to a boolean
   */
  @throws[SaxonApiException]
  def getBooleanValue = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[BooleanValue]) av.asInstanceOf[BooleanValue].getBooleanValue
    else if (av.isInstanceOf[NumericValue]) !av.isNaN && av.asInstanceOf[NumericValue].signum != 0
    else if (av.isInstanceOf[StringValue]) {
      val s = av.getStringValue.trim
      "1" == s || "true" == s
    }
    else throw new SaxonApiException("Cannot cast item to a boolean")
  }

  /**
   * Get the value converted to an integer using the XPath casting rules
   *
   * @return the result of converting to an integer
   * @throws SaxonApiException if the value cannot be cast to an integer
   */
  @throws[SaxonApiException]
  def getLongValue = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[BooleanValue]) if (av.asInstanceOf[BooleanValue].getBooleanValue) 0L
    else 1L
    else if (av.isInstanceOf[NumericValue]) try av.asInstanceOf[NumericValue].longValue
    catch {
      case e: XPathException =>
        throw new SaxonApiException("Cannot cast item to an integer")
    }
    else if (av.isInstanceOf[StringValue]) {
      val converter = StringToDouble.getInstance
      converter.stringToNumber(av.getStringValueCS).toLong
    }
    else throw new SaxonApiException("Cannot cast item to an integer")
  }

  /**
   * Get the value converted to a double using the XPath casting rules.
   * <p>If the value is a string, the XSD 1.1 rules are used, which means that the string
   * "+INF" is recognised.</p>
   *
   * @return the result of converting to a double
   * @throws SaxonApiException if the value cannot be cast to a double
   */
  @throws[SaxonApiException]
  def getDoubleValue = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[BooleanValue]) if (av.asInstanceOf[BooleanValue].getBooleanValue) 0.0
    else 1.0
    else if (av.isInstanceOf[NumericValue]) av.asInstanceOf[NumericValue].getDoubleValue
    else if (av.isInstanceOf[StringValue]) try {
      val converter = StringToDouble11.getInstance
      converter.stringToNumber(av.getStringValueCS)
    } catch {
      case e: NumberFormatException =>
        throw new SaxonApiException(e.getMessage)
    }
    else throw new SaxonApiException("Cannot cast item to a double")
  }

  /**
   * Get the value converted to a decimal using the XPath casting rules
   *
   * @return the result of converting to a decimal
   * @throws SaxonApiException if the value cannot be cast to a double
   */
  @throws[SaxonApiException]
  def getDecimalValue = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[BooleanValue]) if (av.asInstanceOf[BooleanValue].getBooleanValue) BigDecimal.ZERO
    else BigDecimal.ONE
    else if (av.isInstanceOf[NumericValue]) try av.asInstanceOf[NumericValue].getDecimalValue
    catch {
      case e: XPathException =>
        throw new SaxonApiException("Cannot cast item to a decimal")
    }
    else if (av.isInstanceOf[StringValue]) new BigDecimal(av.getStringValueCS.toString)
    else throw new SaxonApiException("Cannot cast item to a decimal")
  }

  /**
   * For an XdmAtomicValue representing an xs:QName or xs:NOTATION value,
   * get the value as an instance of QName
   *
   * @return the corresponding QName if the value is an xs:QName or xs:NOTATION,
   *         or null otherwise
   */
  def getQNameValue = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[QualifiedNameValue]) new QName(av.asInstanceOf[QualifiedNameValue].getStructuredQName)
    else null
  }

  /**
   * For an XdmAtomicValue representing an xs:dateTime value including timezone,
   * get the value as an instance of {@link Instant}
   *
   * @return the corresponding Instant if the value is an xs:dateTime including
   *         a timezone; otherwise null
   * @since 10.0
   */
  def getInstant = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[DateTimeValue] && av.asInstanceOf[DateTimeValue].hasTimezone) av.asInstanceOf[DateTimeValue].toJavaInstant
    else null
  }

  /**
   * For an XdmAtomicValue representing an xs:dateTime value including timezone,
   * get the value as an instance of {@link ZonedDateTime}
   *
   * @return the corresponding ZonedDateTime if the value is an xs:dateTime including
   *         a timezone; otherwise null
   * @since 10.0
   */
  def getZonedDateTime = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[DateTimeValue] && av.asInstanceOf[DateTimeValue].hasTimezone) av.asInstanceOf[DateTimeValue].toZonedDateTime
    else null
  }

  /**
   * For an XdmAtomicValue representing an xs:dateTime value including timezone,
   * get the value as an instance of {@link OffsetDateTime}
   *
   * @return the corresponding OffsetDateTime if the value is an xs:dateTime including
   *         a timezone; otherwise null
   * @since 10.0
   */
  def getOffsetDateTime = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[DateTimeValue] && av.asInstanceOf[DateTimeValue].hasTimezone) av.asInstanceOf[DateTimeValue].toOffsetDateTime
    else null
  }

  /**
   * For an XdmAtomicValue representing an xs:dateTime value,
   * get the value as an instance of {@link LocalDateTime}. Any timezone
   * information in the value is discarded
   *
   * @return the corresponding LocalDateTime if the value is an xs:dateTime; otherwise null
   * @since 10.0
   */
  def getLocalDateTime = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[DateTimeValue]) av.asInstanceOf[DateTimeValue].toLocalDateTime
    else null
  }

  /**
   * For an XdmAtomicValue representing an xs:date value,
   * get the value as an instance of {@link LocalDate}. Any timezone
   * information in the value is discarded
   *
   * @return the corresponding LocalDate if the value is an xs:date; otherwise null
   * @since 10.0
   */
  def getLocalDate = {
    val av = getUnderlyingValue
    if (av.isInstanceOf[DateValue]) av.asInstanceOf[DateValue].toLocalDate
    else null
  }

  /**
   * Compare values for equality.
   * Two atomic values are considered equal if they are equal according to the
   * rules of the op:is-same-key() operation, used when comparing keys in maps
   *
   * @param other the value to be compared
   * @return true if the values are deemed equal
   */
  override def equals(other: Any) = if (other.isInstanceOf[XdmAtomicValue]) {
    val a = getUnderlyingValue.asMapKey
    val b = other.asInstanceOf[XdmAtomicValue].getUnderlyingValue.asMapKey
    a == b
  }
  else false

  /**
   * Get a hashcode that reflects the rules for equality matching
   *
   * @return a suitable hashcode
   */
  override def hashCode = getUnderlyingValue.asMapKey.hashCode
}