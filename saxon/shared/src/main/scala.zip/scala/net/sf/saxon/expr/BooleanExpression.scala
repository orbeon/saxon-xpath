////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser._
import net.sf.saxon.functions.BooleanFn
import net.sf.saxon.functions.SystemFunction
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.model.UType
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.BooleanValue
import java.util

/**
 * Boolean expression: two truth values combined using AND or OR.
 */
object BooleanExpression {
  /**
   * Construct a list containing the "anded" subexpressions of an expression:
   * if the expression is (A and B and C), this returns (A, B, C).
   *
   * @param exp  the expression to be decomposed
   * @param list the list to which the subexpressions are to be added.
   */
    def listAndComponents(exp: Expression, list: util.List[Expression]) = if (exp.isInstanceOf[BooleanExpression] && exp.asInstanceOf[BooleanExpression].getOperator == Token.AND) {
      import scala.collection.JavaConversions._
      for (o <- exp.operands) {
        listAndComponents(o.getChildExpression, list)
      }
    }
    else list.add(exp)
}

abstract class BooleanExpression(val p1: Expression, val operator: Int, val p2: Expression)

/**
 * Construct a boolean expression
 *
 * @param p1       the first operand
 * @param operator one of { @link Token#AND} or { @link Token#OR}
 * @param p2 the second operand
 */
  extends BinaryExpression(p1, operator, p2) with Negatable {
  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = Token.tokens(getOperator) + "-expression"

  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = {
    getLhs.typeCheck(visitor, contextInfo)
    getRhs.typeCheck(visitor, contextInfo)
    val th = visitor.getConfiguration.getTypeHierarchy
    val err0 = TypeChecker.ebvError(getLhsExpression, th)
    if (err0 != null) {
      err0.setLocator(getLocation)
      throw err0
    }
    val err1 = TypeChecker.ebvError(getRhsExpression, th)
    if (err1 != null) {
      err1.setLocator(getLocation)
      throw err1
    }
    // Precompute the EBV of any constant operand
    if (getLhsExpression.isInstanceOf[Literal] && !(getLhsExpression.asInstanceOf[Literal]).getValue.isInstanceOf[BooleanValue]) setLhsExpression(Literal.makeLiteral(BooleanValue.get(getLhsExpression.effectiveBooleanValue(visitor.makeDynamicContext)), this))
    if (getRhsExpression.isInstanceOf[Literal] && !(getRhsExpression.asInstanceOf[Literal]).getValue.isInstanceOf[BooleanValue]) setRhsExpression(Literal.makeLiteral(BooleanValue.get(getRhsExpression.effectiveBooleanValue(visitor.makeDynamicContext)), this))
    preEvaluate
  }

  /**
   * Determine the static cardinality. Returns [1..1]
   */
  override def computeCardinality = StaticProperty.EXACTLY_ONE

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo) = {
    optimizeChildren(visitor, contextItemType)
    val forStreaming = visitor.isOptimizeForStreaming
    setLhsExpression(ExpressionTool.unsortedIfHomogeneous(getLhsExpression, forStreaming))
    setRhsExpression(ExpressionTool.unsortedIfHomogeneous(getRhsExpression, forStreaming))
    val op0 = BooleanFn.rewriteEffectiveBooleanValue(getLhsExpression, visitor, contextItemType)
    if (op0 != null) setLhsExpression(op0)
    val op1 = BooleanFn.rewriteEffectiveBooleanValue(getRhsExpression, visitor, contextItemType)
    if (op1 != null) setRhsExpression(op1)
    preEvaluate
  }

  /**
   * Evaluate the expression statically if either or both operands are literals. For example,
   * (true() or X) returns true().
   *
   * @return a boolean literal if the expression can be evaluated now, or the original expression
   *         otherwise.
   */
  protected def preEvaluate

  protected def forceToBoolean(in: Expression) = if ((in.getItemType eq BuiltInAtomicType.BOOLEAN) && in.getCardinality == StaticProperty.ALLOWS_ONE) in
  else SystemFunction.makeCall("boolean", getRetainedStaticContext, in)

  /**
   * Check whether this specific instance of the expression is negatable
   *
   * @return true if it is
   * @param th the type hierarchy, if needed
   */
  override def isNegatable(th: TypeHierarchy) = true

  /**
   * Return the negation of this boolean expression, that is, an expression that returns true
   * when this expression returns false, and vice versa
   *
   * @return the negation of this expression
   */
  override def negate

  /**
   * Evaluate the expression
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext) = BooleanValue.get(effectiveBooleanValue(context))

  /**
   * Evaluate as a boolean.
   */
  @throws[XPathException]
  override def effectiveBooleanValue(c: XPathContext)

  /**
   * Determine the data type of the expression
   *
   * @return BuiltInAtomicType.BOOLEAN
   */
  override def getItemType = BuiltInAtomicType.BOOLEAN

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType static information about the context item
   */
  override def getStaticUType(contextItemType: UType) = UType.BOOLEAN

  override protected def getOperandRole(arg: Int) = OperandRole.INSPECT
}