////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.functions.AbstractFunction
import net.sf.saxon.lib.ConversionRules
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AnyURIValue
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.StringValue

/**
 * Function to perform a cast to a union type
 */
object UnionConstructorFunction {
  /**
   * Static method to perform the cast of an atomic value to a union type
   *
   * @param value      the input value to be converted. Must not be null.
   * @param targetType the union type to which the value is to be converted
   * @param nsResolver the namespace context, required if the type is namespace-sensitive
   * @param rules      the conversion rules
   * @return the result of the conversion (may be a sequence if the union includes list types in its membership)
   * @throws XPathException if the conversion fails
   */
    @throws[XPathException]
    def cast(value: AtomicValue, targetType: UnionType, nsResolver: NamespaceResolver, rules: ConversionRules): AtomicSequence = { //ConversionRules rules = context.getConfiguration().getConversionRules();
      if (value == null) throw new NullPointerException
      // 1. If the value is a string or untypedAtomic, try casting to each of the member types
      if (value.isInstanceOf[StringValue] && !value.isInstanceOf[AnyURIValue]) try return targetType.getTypedValue(value.getStringValueCS, nsResolver, rules)
      catch {
        case e: ValidationException =>
          e.setErrorCode("FORG0001")
          throw e
      }
      // 2. If the value is an instance of a type in the transitive membership of the union, return it unchanged
      val label = value.getItemType
      val memberTypes = targetType.getPlainMemberTypes
      // 2a. Is the type annotation itself a member type of the union?
      import scala.collection.JavaConversions._
      for (member <- memberTypes) {
        if (label == member) return value
      }
      // 2b. Failing that, is some supertype of the type annotation a member type of the union?
      import scala.collection.JavaConversions._
      for (member <- memberTypes) {
        var t = label
        while ( {
          t != null
        }) if (t == member) return value
        else t = if (t.getBaseType.isInstanceOf[AtomicType]) t.getBaseType.asInstanceOf[AtomicType]
        else null
      }
      // 3. if the value can be cast to any of the member types, return the result of that cast
      import scala.collection.JavaConversions._
      for (`type` <- memberTypes) {
        if (`type`.isInstanceOf[AtomicType]) {
          val c = rules.getConverter(value.getItemType, `type`.asInstanceOf[AtomicType])
          if (c != null) {
            val result = c.convert(value)
            if (result.isInstanceOf[AtomicValue]) return result.asInstanceOf[AtomicValue]
          }
        }
      }
      throw new XPathException("Cannot convert the supplied value to " + targetType.getDescription, "FORG0001")
    }
}

class UnionConstructorFunction(var targetType: UnionType, var resolver: NamespaceResolver, var allowEmpty: Boolean)

/**
 * Create a cast expression to a union type
 *
 * @param targetType the union type that is the result of the cast
 * @param allowEmpty true if an empty sequence may be supplied as input, converting to an empty sequence on output
 */
  extends AbstractFunction {
  /**
   * Get the usage (in terms of streamability analysis) of the single operand
   *
   * @return the operand usage
   */
  protected def getOperandRole = OperandRole.SINGLE_ATOMIC

  /**
   * Ask whether the value of the operand is allowed to be empty
   *
   * @return true if an empty sequence may be supplied as input, converting to an empty sequence on output
   */
  def isAllowEmpty = allowEmpty

  /**
   * Get the union type that is the target of this cast operation
   *
   * @return the target type of the cast
   */
  def getTargetType = targetType

  /**
   * Get the namespace resolver that will be used to resolve any namespace-sensitive values (such as QNames) when casting
   *
   * @return the namespace resolver, or null if there is none.
   */
  def getNamespaceResolver = resolver

  /**
   * Get the item type of the function item
   *
   * @return the function item's type
   */
  override def getFunctionItemType = {
    val resultType = targetType.getResultTypeOfCast
    val argType = if (allowEmpty) SequenceType.OPTIONAL_ATOMIC
    else SequenceType.SINGLE_ATOMIC
    new SpecificFunctionType(Array[SequenceType](argType), resultType)
  }

  /**
   * Get the name of the function, or null if it is anonymous
   *
   * @return the function name, or null for an anonymous inline function
   */
  override def getFunctionName = targetType.getTypeName

  /**
   * Get a description of this function for use in error messages. For named functions, the description
   * is the function name (as a lexical QName). For others, it might be, for example, "inline function",
   * or "partially-applied ends-with function".
   *
   * @return a description of the function for use in error messages
   */
  override def getDescription = getFunctionName.getDisplayName

  /**
   * Get the arity of the function
   *
   * @return the number of arguments in the function signature
   */
  override def getArity = 1

  /**
   * Method to perform the cast of an atomic value to a union type
   *
   * @param value   the input value to be converted. Must not be null.
   * @param context the evaluation context
   * @return the result of the conversion (may be a sequence if the union includes list types in its membership)
   * @throws net.sf.saxon.trans.XPathException if the conversion fails
   */
  @throws[XPathException]
  def cast(value: AtomicValue, context: XPathContext): AtomicSequence = {
    val rules = context.getConfiguration.getConversionRules
    if (value == null) throw new NullPointerException
    if (value.isInstanceOf[StringValue] && !value.isInstanceOf[AnyURIValue]) try return targetType.getTypedValue(value.getStringValueCS, resolver, rules)
    catch {
      case e: ValidationException =>
        e.setErrorCode("FORG0001")
        throw e
    }
    val label = value.getItemType
    val memberTypes = targetType.asInstanceOf[UnionType].getPlainMemberTypes
    // 2a. Is the type annotation itself a member type of the union, and of the union type itself?
    if (targetType.asInstanceOf[UnionType].isPlainType) {
      import scala.collection.JavaConversions._
      for (member <- memberTypes) {
        if (label == member) return value
      }
      import scala.collection.JavaConversions._
      for (member <- memberTypes) {
        var t = label
        while ( {
          t != null
        }) if (t == member) return value
        else t = if (t.getBaseType.isInstanceOf[AtomicType]) t.getBaseType.asInstanceOf[AtomicType]
        else null
      }
    }
    import scala.collection.JavaConversions._
    for (`type` <- memberTypes) {
      if (`type`.isInstanceOf[AtomicType]) {
        val c = rules.getConverter(value.getItemType, `type`.asInstanceOf[AtomicType])
        if (c != null) {
          val result = c.convert(value)
          if (result.isInstanceOf[AtomicValue]) { // 3b. if the union type has constraining facets then the value must satisfy these
            if (!targetType.isPlainType) {
              val vf = targetType.checkAgainstFacets(result.asInstanceOf[AtomicValue], rules)
              if (vf == null) return result.asInstanceOf[AtomicValue]
            }
            else return result.asInstanceOf[AtomicValue]
          }
        }
      }
    }
    throw new XPathException("Cannot convert the supplied value to " + targetType.getDescription, "FORG0001")
  }

  /**
   * Invoke the function
   *
   * @param context the XPath dynamic evaluation context
   * @param args    the actual arguments to be supplied
   * @return the result of invoking the function
   * @throws net.sf.saxon.trans.XPathException if a dynamic error occurs within the function
   */
  @throws[XPathException]
  override def call(context: XPathContext, args: Array[Sequence]): AtomicSequence = {
    val `val` = args(0).head.asInstanceOf[AtomicValue]
    if (`val` == null) if (allowEmpty) return EmptyAtomicSequence.getInstance
    else {
      val e = new XPathException("Cast expression does not allow an empty sequence to be supplied", "XPTY0004")
      e.setIsTypeError(true)
      throw e
    }
    cast(`val`, context)
  }
}