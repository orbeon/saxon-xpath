////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.oper.OperandArray
import net.sf.saxon.expr.parser._
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.JavaExternalObjectType
import net.sf.saxon.om.Function
import net.sf.saxon.om.Sequence
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.NoDynamicContextException
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.SequenceType
import java.util.Collections

/**
 * Abstract superclass for calls to system-defined and user-defined functions
 */
object FunctionCall {
  /**
   * Utility routine used in constructing error messages: get the word "argument" or "arguments"
   *
   * @param num the number of arguments
   * @return the singular or plural word
   */
    def pluralArguments(num: Int) = if (num == 1) "one argument"
    else num + " arguments"
}

abstract class FunctionCall extends Expression {
  private var operanda = null

  /**
   * Set the data structure for the operands of this expression. This must be created during initialisation of the
   * expression and must not be subsequently changed
   *
   * @param operanda the data structure for expression operands
   */
  protected def setOperanda(operanda: OperandArray) = this.operanda = operanda

  /**
   * Get the data structure holding the operands of this expression.
   *
   * @return the data structure holding expression operands
   */
  def getOperanda = operanda

  override def operands = if (operanda != null) operanda.operands
  else { // happens during expression tree construction
    Collections.emptyList
  }

  /**
   * Get the target function to be called
   *
   * @param context the dynamic evaluation context
   * @return the target function
   * @throws XPathException if the target function cannot be determined
   */
  @throws[XPathException]
  def getTargetFunction(context: XPathContext)

  /**
   * Get the qualified of the function being called
   *
   * @return the qualified name. May be null if the function is anonymous.
   */
  def getFunctionName

  /**
   * Determine the number of actual arguments supplied in the function call
   *
   * @return the arity (the number of arguments)
   */
  final def getArity = getOperanda.getNumberOfOperands

  /**
   * Method called by the expression parser when all arguments have been supplied
   *
   * @param args the expressions contained in the argument list of the function call
   */
  def setArguments(args: Array[Expression]) = setOperanda(new OperandArray(this, args))

  protected def setOperanda(args: Array[Expression], roles: Array[OperandRole]) = setOperanda(new OperandArray(this, args, roles))

  /**
   * Get the expressions supplied as actual arguments to the function
   *
   * @return the array of expressions supplied in the argument list of the function call. The array
   *         is newly constructed to ensure that modifications to the array have no effect.
   */
  def getArguments = {
    val result = new Array[Expression](getArity)
    var i = 0
    import scala.collection.JavaConversions._
    for (o <- operands) {
      result({
        i += 1; i - 1
      }) = o.getChildExpression
    }
    result
  }

  /**
   * Get the expression supplied as the Nth argument
   *
   * @param n the required argument, zero-based
   * @return the expression supplied in the relevant position
   * @throws java.lang.IllegalArgumentException if the value of n is out of range
   */
  def getArg(n: Int) = getOperanda.getOperandExpression(n)

  /**
   * Set the expression to be used as the Nth argument
   *
   * @param n     the required argument, zero-based
   * @param child the expression to be used in the relevant position
   * @throws java.lang.IllegalArgumentException if the value of n is out of range
   */
  def setArg(n: Int, child: Expression) = {
    getOperanda.setOperand(n, child)
    adoptChildExpression(child)
  }

  /**
   * Simplify the arguments of the function.
   * Called from the simplify() method of each function.
   *
   * @param env the static context
   * @return the result of simplifying the arguments of the expression
   * @throws net.sf.saxon.trans.XPathException if an error occurs
   */
  @throws[XPathException]
  final protected def simplifyArguments(env: StaticContext) = {
    for (i <- 0 until getArguments.length) {
      val exp = getArg(i).simplify
      if (exp ne getArg(i)) {
        adoptChildExpression(exp)
        setArg(i, exp)
      }
    }
    this
  }

  /**
   * Type-check the expression. This also calls preEvaluate() to evaluate the function
   * if all the arguments are constant; functions that do not require this behavior
   * can override the preEvaluate method.
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = {
    typeCheckChildren(visitor, contextInfo)
    checkArguments(visitor)
    preEvaluateIfConstant(visitor)
  }

  @throws[XPathException]
  protected def preEvaluateIfConstant(visitor: ExpressionVisitor): Expression = {
    val opt = visitor.obtainOptimizer
    if (opt.isOptionSet(OptimizerOptions.CONSTANT_FOLDING)) {
      var fixed = true
      import scala.collection.JavaConversions._
      for (o <- operands) {
        if (!o.getChildExpression.isInstanceOf[Literal]) fixed = false
      }
      if (fixed) try return preEvaluate(visitor)
      catch {
        case err: NoDynamicContextException =>
          // Early evaluation failed, typically because the implicit timezone is not yet known.
          // Try again later at run-time.
          return this
      }
    }
    this
  }

  /**
   * Check the function call against the declared function signature, applying the
   * function conversion rules to each argument as necessary
   *
   * @param target  the function being called
   * @param visitor an expression visitor
   * @throws XPathException if there is a type error
   */
  @throws[XPathException]
  def checkFunctionCall(target: Function, visitor: ExpressionVisitor) = {
    val tc = visitor.getConfiguration.getTypeChecker(visitor.getStaticContext.isInBackwardsCompatibleMode)
    val argTypes = target.getFunctionItemType.getArgumentTypes
    val n = target.getArity
    for (i <- 0 until n) {
      val name = if (getFunctionName == null) ""
      else getFunctionName.getDisplayName
      val role = new RoleDiagnostic(RoleDiagnostic.FUNCTION, name, i)
      setArg(i, tc.staticTypeCheck(getArg(i), argTypes(i), role, visitor))
    }
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    optimizeChildren(visitor, contextItemType)
    val opt = visitor.obtainOptimizer
    if (opt.isOptionSet(OptimizerOptions.CONSTANT_FOLDING)) {
      var fixed = true
      import scala.collection.JavaConversions._
      for (o <- operands) {
        if (!o.getChildExpression.isInstanceOf[Literal]) {
          fixed = false
          break //todo: break is not supported
        }
      }
      if (fixed) return preEvaluate(visitor)
    }
    this
  }

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   */
  override def getNetCost = 5

  /**
   * Pre-evaluate a function at compile time. Functions that do not allow
   * pre-evaluation, or that need access to context information, can override this method.
   *
   * @param visitor an expression visitor
   * @return the result of the early evaluation, or the original expression, or potentially
   *         a simplified expression
   * @throws net.sf.saxon.trans.XPathException if evaluation fails
   */
  @throws[XPathException]
  def preEvaluate(visitor: ExpressionVisitor): Expression = {
    if ((getIntrinsicDependencies & ~StaticProperty.DEPENDS_ON_STATIC_CONTEXT) != 0) return this
    try {
      val lit = Literal.makeLiteral(iterate(visitor.getStaticContext.makeEarlyEvaluationContext).materialize, this)
      Optimizer.trace(visitor.getConfiguration, "Pre-evaluated function call " + toShortString, lit)
      lit
    } catch {
      case e: NoDynamicContextException =>
        // early evaluation failed, usually because implicit timezone required
        this
      case e: UnsupportedOperationException =>
        //e.printStackTrace();
        if (e.getCause.isInstanceOf[NoDynamicContextException]) this
        else throw e
    }
  }

  /**
   * Method supplied by each class of function to check arguments during parsing, when all
   * the argument expressions have been read
   *
   * @param visitor the expression visitor
   * @throws net.sf.saxon.trans.XPathException if the arguments are incorrect
   */
  @throws[XPathException]
  protected def checkArguments(visitor: ExpressionVisitor) = {
    // default: do nothing
  }

  /**
   * Check number of arguments. <BR>
   * A convenience routine for use in subclasses.
   *
   * @param min the minimum number of arguments allowed
   * @param max the maximum number of arguments allowed
   * @return the actual number of arguments
   * @throws net.sf.saxon.trans.XPathException if the number of arguments is out of range
   */
  @throws[XPathException]
  protected def checkArgumentCount(min: Int, max: Int) = {
    val numArgs = getArity
    var msg = null
    if (min == max && numArgs != min) msg = "Function " + getDisplayName + " must have " + FunctionCall.pluralArguments(min)
    else if (numArgs < min) msg = "Function " + getDisplayName + " must have at least " + FunctionCall.pluralArguments(min)
    else if (numArgs > max) msg = "Function " + getDisplayName + " must have no more than " + FunctionCall.pluralArguments(max)
    if (msg != null) {
      val err = new XPathException(msg, "XPST0017")
      err.setIsStaticError(true)
      err.setLocation(getLocation)
      throw err
    }
    numArgs
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   * <p>The default implementation of this method assumes that an expression does no navigation other than
   * the navigation done by evaluating its subexpressions, and that the subexpressions are evaluated in the
   * same context as the containing expression. The method must be overridden for any expression
   * where these assumptions do not hold. For example, implementations exist for AxisExpression, ParentExpression,
   * and RootExpression (because they perform navigation), and for the doc(), document(), and collection()
   * functions because they create a new navigation root. Implementations also exist for PathExpression and
   * FilterExpression because they have subexpressions that are evaluated in a different context from the
   * calling expression.</p>
   *
   * @param pathMap      the PathMap to which the expression should be added
   * @param pathMapNodes the node in the PathMap representing the focus at the point where this expression
   *                     is called. Set to null if this expression appears at the top level, in which case the expression, if it
   *                     is registered in the path map at all, must create a new path map root.
   * @return the pathMapNode representing the focus established by this expression, in the case where this
   *         expression is the first operand of a path expression or filter expression. For an expression that does
   *         navigation, it represents the end of the arc in the path map that describes the navigation route. For other
   *         expressions, it is the same as the input pathMapNode.
   */
  def addExternalFunctionCallToPathMap(pathMap: PathMap, pathMapNodes: PathMap.PathMapNodeSet) = { // Except in the case of system functions, we have no idea where a function call might
    // navigate, so we assume the worst, and register that the path has unknown dependencies
    val result = new PathMap.PathMapNodeSet
    import scala.collection.JavaConversions._
    for (o <- operands) {
      result.addNodeSet(o.getChildExpression.addToPathMap(pathMap, pathMapNodes))
    }
    result.setHasUnknownDependencies()
    result
  }

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "functionCall"

  /**
   * Get the name of the function for display in messages
   *
   * @return the name of the function as a lexical QName
   */
  final def getDisplayName = {
    val fName = getFunctionName
    if (fName == null) "(anonymous)"
    else fName.getDisplayName
  }

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   */
  override def toString = {
    val buff = new FastStringBuffer(FastStringBuffer.C64)
    val fName = getFunctionName
    var f = null
    if (fName == null) f = "$anonymousFunction"
    else if (fName.hasURI(NamespaceConstant.FN)) f = fName.getLocalPart
    else f = fName.getEQName
    buff.append(f)
    var first = true
    import scala.collection.JavaConversions._
    for (o <- operands) {
      buff.append(if (first) "("
      else ", ")
      buff.append(o.getChildExpression.toString)
      first = false
    }
    buff.append(if (first) "()"
    else ")")
    buff.toString
  }

  /**
   * Produce a short string identifying the expression for use in error messages
   *
   * @return a short string, sufficient to identify the expression
   */
  override def toShortString = {
    val fName = getFunctionName
    (if (fName == null) "$anonFn"
    else fName.getDisplayName) + "(" + (if (getArity == 0) ""
    else "...") + ")"
  }

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    out.startElement("functionCall", this)
    if (getFunctionName == null) throw new AssertionError("Exporting call to anonymous function")
    else out.emitAttribute("name", getFunctionName.getDisplayName)
    import scala.collection.JavaConversions._
    for (o <- operands) {
      o.getChildExpression.`export`(out)
    }
    out.endElement
  }

  /**
   * Determine whether two expressions are equivalent
   */
  override def equals(o: Any): Boolean = {
    if (!o.isInstanceOf[FunctionCall]) return false
    if (getFunctionName == null) return this eq o
    val f = o.asInstanceOf[FunctionCall]
    if (!(getFunctionName == f.getFunctionName)) return false
    if (getArity != f.getArity) return false
    for (i <- 0 until getArity) {
      if (!getArg(i).isEqual(f.getArg(i))) return false
    }
    true
  }

  /**
   * Get hashCode in support of equals() method
   */
  override def computeHashCode: Int = {
    if (getFunctionName == null) return super.computeHashCode
    var h = getFunctionName.hashCode
    for (i <- 0 until getArity) {
      h ^= getArg(i).hashCode
    }
    h
  }

  /**
   * Return an Iterator to iterate over the values of a sequence. The value of every
   * expression can be regarded as a sequence, so this method is supported for all
   * expressions. This default implementation handles iteration for expressions that
   * return singleton values: for non-singleton expressions, the subclass must
   * provide its own implementation.
   *
   * @param context supplies the context for evaluation
   * @return a SequenceIterator that can be used to iterate over the result
   *         of the expression
   * @throws net.sf.saxon.trans.XPathException if any dynamic error occurs evaluating the
   *                                           expression
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = {
    val target = getTargetFunction(context)
    val actualArgs = evaluateArguments(context)
    try target.call(context, actualArgs).iterate
    catch {
      case e: XPathException =>
        e.maybeSetLocation(getLocation)
        e.maybeSetContext(context)
        e.maybeSetFailingExpression(this)
        throw e
    }
  }

  @throws[XPathException]
  def evaluateArguments(context: XPathContext) = {
    val numArgs = getArity
    val actualArgs = new Array[Sequence](numArgs)
    for (i <- 0 until numArgs) {
      actualArgs(i) = ExpressionTool.lazyEvaluate(getArg(i), context, false)
    }
    actualArgs
  }

  /**
   * When a call to a Java extension function appears in a context where there the required type
   * is a Java external object (typically an xsl:variable with a declared type, or as an argument
   * to another Java extension function), notify this required type so that the process of converting
   * the result to an XDM value can be short-circuited.
   *
   * @param requiredType the required type of the result of the function, determined by the context
   *                     in which the function call appears
   * @return Ok if the type has been successfully adjusted
   * @throws XPathException if the required return type is incompatible with the type actually returned
   *                        by the Java method
   */
  @throws[XPathException]
  def adjustRequiredType(requiredType: JavaExternalObjectType) = false
}