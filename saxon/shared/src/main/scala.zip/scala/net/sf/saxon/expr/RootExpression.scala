////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser._
import net.sf.saxon.model._
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.Item
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.pattern.AnyNodeTest
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.pattern.NodeTestPattern
import net.sf.saxon.pattern.Pattern
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.SingletonIterator

/**
 * An expression whose value is always a set of nodes containing a single node,
 * the document root. This corresponds to the XPath Expression "/", including the implicit
 * "/" at the start of a path expression with a leading "/".
 */
class RootExpression() extends Expression {
  private var contextMaybeUndefined = true
  private var doneWarnings = false

  /**
   * Type-check the expression.
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, /*@Nullable*/ contextInfo: ContextItemStaticInfo): Expression = {
    val th = visitor.getConfiguration.getTypeHierarchy
    if (contextInfo == null || contextInfo.getItemType == null || contextInfo.getItemType == ErrorType.getInstance) {
      val err = new XPathException(noContextMessage + ": the context item is absent")
      err.setErrorCode("XPDY0002")
      err.setIsTypeError(true)
      err.setLocation(getLocation)
      throw err
    }
    else if (!doneWarnings && contextInfo.isParentless && (th.relationship(contextInfo.getItemType, NodeKindTest.DOCUMENT) eq Affinity.DISJOINT)) {
      visitor.issueWarning(noContextMessage + ": the context item is parentless and is not a document node", getLocation)
      doneWarnings = true
    }
    contextMaybeUndefined = contextInfo.isPossiblyAbsent
    if (th.isSubType(contextInfo.getItemType, NodeKindTest.DOCUMENT)) { // this rewrite is important for streamability analysis
      val cie = new ContextItemExpression
      ExpressionTool.copyLocationInfo(this, cie)
      cie.setStaticInfo(contextInfo)
      return cie
    }
    val relation = th.relationship(contextInfo.getItemType, AnyNodeTest.getInstance)
    if (relation eq Affinity.DISJOINT) {
      val err = new XPathException(noContextMessage + ": the context item is not a node")
      err.setErrorCode("XPTY0020")
      err.setIsTypeError(true)
      err.setLocation(getLocation)
      throw err
    }
    this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws net.sf.saxon.trans.XPathException if an error is discovered during this phase
   *                                           (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo) = { // repeat the check: in XSLT insufficient information is available the first time
    typeCheck(visitor, contextItemType)
  }

  override def computeSpecialProperties = StaticProperty.ORDERED_NODESET | StaticProperty.CONTEXT_DOCUMENT_NODESET | StaticProperty.SINGLE_DOCUMENT_NODESET | StaticProperty.NO_NODES_NEWLY_CREATED

  /**
   * Ask whether there is a possibility that the context item will be undefined
   *
   * @return true if this is a possibility
   */
  def isContextPossiblyUndefined = contextMaybeUndefined

  /**
   * Customize the error message on type checking
   */
  protected def noContextMessage = "Leading '/' selects nothing"

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any) = other.isInstanceOf[RootExpression]

  /**
   * Specify that the expression returns a singleton
   */
  override final def computeCardinality = StaticProperty.EXACTLY_ONE

  /**
   * Determine the data type of the items returned by this expression
   *
   * @return Type.NODE
   */
  override def getItemType = NodeKindTest.DOCUMENT

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType
   */
  override def getStaticUType(contextItemType: UType) = UType.DOCUMENT

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = EVALUATE_METHOD

  /**
   * get HashCode for comparing two expressions
   */
  override def computeHashCode = "RootExpression".hashCode

  /**
   * Return the first element selected by this Expression
   *
   * @param context The evaluation context
   * @return the NodeInfo of the first selected element, or null if no element
   *         is selected
   */
  @throws[XPathException]
  def getNode(context: XPathContext): NodeInfo = {
    val current = context.getContextItem
    if (current == null) dynamicError("Finding root of tree: the context item is absent", "XPDY0002", context)
    if (current.isInstanceOf[NodeInfo]) {
      val doc = current.asInstanceOf[NodeInfo].getRoot
      if (doc.getNodeKind != Type.DOCUMENT) dynamicError("The root of the tree containing the context item is not a document node", "XPDY0050", context)
      return doc
    }
    typeError("Finding root of tree: the context item is not a node", "XPTY0020", context)
    // dummy return; we never get here
    null
  }

  /**
   * Determine which aspects of the context the expression depends on. The result is
   * a bitwise-or'ed value composed from constants such as StaticProperty.VARIABLES and
   * StaticProperty.CURRENT_NODE
   */
  override def getIntrinsicDependencies = StaticProperty.DEPENDS_ON_CONTEXT_DOCUMENT

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings
   */
  override def copy(rebindings: RebindingMap) = {
    val exp = new RootExpression
    ExpressionTool.copyLocationInfo(this, exp)
    exp
  }

  /**
   * Convert this expression to an equivalent XSLT pattern
   *
   * @param config the Saxon configuration
   * @return the equivalent pattern
   * @throws net.sf.saxon.trans.XPathException
   * if conversion is not possible
   */
  @throws[XPathException]
  override def toPattern(config: Configuration) = new NodeTestPattern(NodeKindTest.DOCUMENT)

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   *
   * @param pathMap the PathMap to which the expression should be added
   * @param pathMapNodeSet
   * @return the pathMapNode representing the focus established by this expression, in the case where this
   *         expression is the first operand of a path expression or filter expression
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = {
    if (pathMapNodeSet == null) {
      val cie = new ContextItemExpression
      ExpressionTool.copyLocationInfo(this, cie)
      pathMapNodeSet = new PathMap.PathMapNodeSet(pathMap.makeNewRoot(cie))
    }
    pathMapNodeSet.createArc(AxisInfo.ANCESTOR_OR_SELF, NodeKindTest.DOCUMENT)
  }

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   */
  override def toString = "(/)"

  override def getExpressionName = "root"

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("root", this)
    destination.endElement
  }

  /**
   * Evaluate the expression in a given context to return an iterator
   *
   * @param context the evaluation context
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = SingletonIterator.makeIterator(getNode(context))

  @throws[XPathException]
  override def evaluateItem(context: XPathContext) = getNode(context)

  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext) = getNode(context) != null

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "RootExpression"
}