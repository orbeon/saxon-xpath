////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.XPathContext
import net.sf.saxon.functions.AccessorFn
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ConversionResult
import net.sf.saxon.model.ValidationFailure
import net.sf.saxon.om.SequenceTool
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.NoDynamicContextException
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.math.BigDecimal
import java.math.RoundingMode
import java.util._

/**
 * A value of type xs:time
 */
object TimeValue {
  /**
   * Static factory method: create a time value from a supplied string, in
   * ISO 8601 format
   *
   * @param s the time in the lexical format hh:mm:ss[.ffffff] followed optionally by
   *          timezone in the form [+-]hh:mm or Z
   * @return either a TimeValue corresponding to the xs:time, or a ValidationFailure
   *         if the supplied value was invalid
   */
    /*@NotNull*/ def makeTimeValue(s: CharSequence): ConversionResult = { // input must have format hh:mm:ss[.fff*][([+|-]hh:mm | Z)]
      val tv = new TimeValue
      val tok = new StringTokenizer(Whitespace.trimWhitespace(s).toString, "-:.+Z", true)
      if (!tok.hasMoreElements) return badTime("too short", s)
      var part = tok.nextElement.asInstanceOf[String]
      if (part.length != 2) return badTime("hour must be two digits", s)
      var value = DurationValue.simpleInteger(part)
      if (value < 0) return badTime("Non-numeric hour component", s)
      tv.hour = value.toByte
      if (tv.hour > 24) return badTime("hour is out of range", s)
      if (!tok.hasMoreElements) return badTime("too short", s)
      if (!(":" == tok.nextElement)) return badTime("wrong delimiter after hour", s)
      if (!tok.hasMoreElements) return badTime("too short", s)
      part = tok.nextElement.asInstanceOf[String]
      if (part.length != 2) return badTime("minute must be two digits", s)
      value = DurationValue.simpleInteger(part)
      if (value < 0) return badTime("Non-numeric minute component", s)
      tv.minute = value.toByte
      if (tv.minute > 59) return badTime("minute is out of range", s)
      if (tv.hour == 24 && tv.minute != 0) return badTime("If hour is 24, minute must be 00", s)
      if (!tok.hasMoreElements) return badTime("too short", s)
      if (!(":" == tok.nextElement)) return badTime("wrong delimiter after minute", s)
      if (!tok.hasMoreElements) return badTime("too short", s)
      part = tok.nextElement.asInstanceOf[String]
      if (part.length != 2) return badTime("second must be two digits", s)
      value = DurationValue.simpleInteger(part)
      if (value < 0) return badTime("Non-numeric second component", s)
      tv.second = value.toByte
      if (tv.second > 59) return badTime("second is out of range", s)
      if (tv.hour == 24 && tv.second != 0) return badTime("If hour is 24, second must be 00", s)
      var tz = 0
      var negativeTz = false
      var state = 0
      while ( {
        tok.hasMoreElements
      }) {
        if (state == 9) return badTime("characters after the end", s)
        val delim = tok.nextElement.asInstanceOf[String]
        if ("." == delim) {
          if (state != 0) return badTime("decimal separator occurs twice", s)
          if (!tok.hasMoreElements) return badTime("decimal point must be followed by digits", s)
          part = tok.nextElement.asInstanceOf[String]
          if (part.length > 9 && part.matches("^[0-9]+$")) part = part.substring(0, 9)
          value = DurationValue.simpleInteger(part)
          if (value < 0) return badTime("Non-numeric fractional seconds component", s)
          val fractionalSeconds = '.' + part.toDouble
          tv.nanosecond = fractionalSeconds * 1000000000.round.toInt
          if (tv.hour == 24 && tv.nanosecond != 0) return badTime("If hour is 24, fractional seconds must be 0", s)
          state = 1
        }
        else if ("Z" == delim) {
          if (state > 1) return badTime("Z cannot occur here", s)
          tz = 0
          state = 9 // we've finished
          tv.setTimezoneInMinutes(0)
        }
        else if ("+" == delim || "-" == delim) {
          if (state > 1) return badTime(delim + " cannot occur here", s)
          state = 2
          if (!tok.hasMoreElements) return badTime("missing timezone", s)
          part = tok.nextElement.asInstanceOf[String]
          if (part.length != 2) return badTime("timezone hour must be two digits", s)
          value = DurationValue.simpleInteger(part)
          if (value < 0) return badTime("Non-numeric timezone hour component", s)
          tz = value * 60
          if (tz > 14 * 60) return badTime("timezone hour is out of range", s)
          if ("-" == delim) negativeTz = true
        }
        else if (":" == delim) {
          if (state != 2) return badTime("colon cannot occur here", s)
          state = 9
          part = tok.nextElement.asInstanceOf[String]
          value = DurationValue.simpleInteger(part)
          if (value < 0) return badTime("Non-numeric timezone minute component", s)
          val tzminute = value
          if (part.length != 2) return badTime("timezone minute must be two digits", s)
          if (tzminute > 59) return badTime("timezone minute is out of range", s)
          tz += tzminute
          if (negativeTz) tz = -tz
          tv.setTimezoneInMinutes(tz)
        }
        else return badTime("timezone format is incorrect", s)
      }
      if (state == 2 || state == 3) return badTime("timezone incomplete", s)
      if (tv.hour == 24) tv.hour = 0
      tv.typeLabel = BuiltInAtomicType.TIME
      tv
    }

  private def badTime(msg: String, value: CharSequence) = {
    val err = new ValidationFailure("Invalid time " + Err.wrap(value, Err.VALUE) + " (" + msg + ")")
    err.setErrorCode("FORG0001")
    err
  }
}

final class TimeValue private() extends CalendarValue with Comparable[_] {
  private var hour = 0
  private var minute = 0
  private var second = 0
  private var nanosecond = 0

  /**
   * Construct a time value given the hour, minute, second, and microsecond components.
   * This constructor performs no validation.
   *
   * @param hour        the hour value, 0-23
   * @param minute      the minutes value, 0-59
   * @param second      the seconds value, 0-59
   * @param microsecond the number of microseconds, 0-999999
   * @param tz          the timezone displacement in minutes from UTC. Supply the value
   *                    { @link CalendarValue#NO_TIMEZONE} if there is no timezone component.
   * @deprecated since 10.0: use the constructor { @link #TimeValue(byte, byte, byte, int, int, String)}
   *                                                     that accepts nanosecond precision
   */
  def this(hour: Byte, minute: Byte, second: Byte, microsecond: Int, tz: Int) {
    this()
    this.hour = hour
    this.minute = minute
    this.second = second
    this.nanosecond = microsecond * 1000
    setTimezoneInMinutes(tz)
    typeLabel = BuiltInAtomicType.TIME
  }

  /**
   * Private constructor to construct a time value given the hour, minute, second, and nanosecond components.
   * This constructor performs no validation.
   *
   * @param hour       the hour value, 0-23
   * @param minute     the minutes value, 0-59
   * @param second     the seconds value, 0-59
   * @param nanosecond the number of microseconds, 0-999999
   * @param tz         the timezone displacement in minutes from UTC. Supply the value
   *                   { @link CalendarValue#NO_TIMEZONE} if there is no timezone component.
   * @param flag used to disambiguate this constructor. Must be set to "".
   */
  def this(hour: Byte, minute: Byte, second: Byte, nanosecond: Int, tz: Int, flag: String){
    this()
    if (!flag.isEmpty) throw new IllegalArgumentException
    this.hour = hour
    this.minute = minute
    this.second = second
    this.nanosecond = nanosecond
    setTimezoneInMinutes(tz)
    typeLabel = BuiltInAtomicType.TIME
  }

  /**
   * Factory method to construct a time value given the hour, minute, second, and nanosecond components.
   * This constructor performs no validation.
   *
   * @param hour       the hour value, 0-23
   * @param minute     the minutes value, 0-59
   * @param second     the seconds value, 0-59
   * @param nanosecond the number of nanoseconds, 0-999_999_999
   * @param tz         the timezone displacement in minutes from UTC. Supply the value
   *                   { @link CalendarValue#NO_TIMEZONE} if there is no timezone component.
   */
  def makeTimeValue(hour: Byte, minute: Byte, second: Byte, nanosecond: Int, tz: Int) = new TimeValue(hour, minute, second, nanosecond, tz, "")

  /**
   * Constructor: create a time value given a Java calendar object
   *
   * @param calendar holds the date and time
   * @param tz       the timezone offset in minutes, or NO_TIMEZONE indicating that there is no timezone
   */
  def this(calendar: GregorianCalendar, tz: Int) {
    this()
    hour = calendar.get(Calendar.HOUR_OF_DAY).toByte
    minute = calendar.get(Calendar.MINUTE).toByte
    second = calendar.get(Calendar.SECOND).toByte
    nanosecond = calendar.get(Calendar.MILLISECOND) * 1000000
    setTimezoneInMinutes(tz)
    typeLabel = BuiltInAtomicType.TIME
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.TIME

  /**
   * Get the hour component, 0-23
   *
   * @return the hour
   */
  def getHour = hour

  /**
   * Get the minute component, 0-59
   *
   * @return the minute
   */
  def getMinute = minute

  /**
   * Get the second component, 0-59
   *
   * @return the second
   */
  def getSecond = second

  /**
   * Get the microsecond component, 0-999_999
   *
   * @return the nanoseconds component divided by 1000, rounded towards zero
   */
  def getMicrosecond = nanosecond / 1000

  /**
   * Get the nanosecond component, 0-999_999
   *
   * @return the nanoseconds
   */
  def getNanosecond = nanosecond

  /**
   * Convert to string
   *
   * @return ISO 8601 representation, in the localized timezone
   *         (the timezone held within the value).
   */
  override def getPrimitiveStringValue = {
    val sb = new FastStringBuffer(FastStringBuffer.C16)
    appendTwoDigits(sb, hour)
    sb.cat(':')
    appendTwoDigits(sb, minute)
    sb.cat(':')
    appendTwoDigits(sb, second)
    if (nanosecond != 0) {
      sb.cat('.')
      var ms = nanosecond
      var div = 100000000
      while ( {
        ms > 0
      }) {
        val d = ms / div
        sb.cat((d + '0').toChar)
        ms = ms % div
        div /= 10
      }
    }
    if (hasTimezone) appendTimezone(sb)
    sb
  }

  /**
   * Get the canonical lexical representation as defined in XML Schema. This is not always the same
   * as the result of casting to a string according to the XPath rules. For an xs:time it is the
   * time adjusted to UTC
   *
   * @return the canonical lexical representation if defined in XML Schema
   */
  override def getCanonicalLexicalRepresentation = if (hasTimezone && getTimezoneInMinutes != 0) adjustTimezone(0).getStringValueCS
  else getStringValueCS

  /**
   * Convert to a DateTime value. The date components represent a reference date, as defined
   * in the spec for comparing times.
   */
  override def toDateTime = new DateTimeValue(1972, 12.toByte, 31.toByte, hour, minute, second, nanosecond, getTimezoneInMinutes)

  /**
   * Get a Java Calendar object corresponding to this time, on a reference date
   */
  override def getCalendar: GregorianCalendar = { // create a calendar using the specified timezone
    val tz = if (hasTimezone) getTimezoneInMinutes * 60000
    else 0
    val zone = new SimpleTimeZone(tz, "LLL")
    val calendar = new GregorianCalendar(zone)
    calendar.setLenient(false)
    if (tz < calendar.getMinimum(Calendar.ZONE_OFFSET) || tz > calendar.getMaximum(Calendar.ZONE_OFFSET)) return adjustTimezone(0).getCalendar
    // use a reference date of 1972-12-31
    calendar.set(1972, Calendar.DECEMBER, 31, hour, minute, second)
    calendar.set(Calendar.MILLISECOND, nanosecond / 1000000)
    calendar.set(Calendar.ZONE_OFFSET, tz)
    calendar.set(Calendar.DST_OFFSET, 0)
    calendar.getTime
    calendar
  }

  /**
   * Make a copy of this time value,
   * but with a different type label
   *
   * @param typeLabel the new type label. This must be a subtype of xs:time.
   */
  override def copyAsSubType(typeLabel: AtomicType) = {
    val v = new TimeValue(hour, minute, second, nanosecond, getTimezoneInMinutes, "")
    v.typeLabel = typeLabel
    v
  }

  /**
   * Return a new time with the same normalized value, but
   * in a different timezone. This is called only for a TimeValue that has an explicit timezone
   *
   * @param timezone the new timezone offset, in minutes
   * @return the time in the new timezone. This will be a new TimeValue unless no change
   *         was required to the original value
   */
  override def adjustTimezone(timezone: Int) = {
    val dt = toDateTime.adjustTimezone(timezone)
    new TimeValue(dt.getHour, dt.getMinute, dt.getSecond, dt.getNanosecond, dt.getTimezoneInMinutes, "")
  }

  /**
   * Get a component of the value. Returns null if the timezone component is
   * requested and is not present.
   *
   * @param component the required component
   */
  /*@Nullable*/ @throws[XPathException]
  override def getComponent(component: AccessorFn.Component) = component match {
    case HOURS =>
      Int64Value.makeIntegerValue(hour)
    case MINUTES =>
      Int64Value.makeIntegerValue(minute)
    case SECONDS =>
      var d = BigDecimal.valueOf(nanosecond)
      d = d.divide(BigDecimalValue.BIG_DECIMAL_ONE_BILLION, 6, RoundingMode.HALF_UP)
      d = d.add(BigDecimal.valueOf(second))
      new BigDecimalValue(d)
    case WHOLE_SECONDS => //(internal use only)
      Int64Value.makeIntegerValue(second)
    case MICROSECONDS =>
      new Int64Value(nanosecond / 1000)
    case NANOSECONDS =>
      new Int64Value(nanosecond)
    case TIMEZONE =>
      if (hasTimezone) DayTimeDurationValue.fromMilliseconds(60000L * getTimezoneInMinutes)
      else null
    case _ =>
      throw new IllegalArgumentException("Unknown component for time: " + component)
  }

  /**
   * Compare the value to another dateTime value
   *
   * @param other The other dateTime value
   * @return negative value if this one is the earler, 0 if they are chronologically equal,
   *         positive value if this one is the later. For this purpose, dateTime values with an unknown
   *         timezone are considered to be UTC values (the Comparable interface requires
   *         a total ordering).
   * @throws ClassCastException if the other value is not a TimeValue (the parameter
   *                            is declared as Object to satisfy the Comparable interface)
   */
  override def compareTo(other: Any) = {
    val otherTime = other.asInstanceOf[TimeValue]
    if (getTimezoneInMinutes == otherTime.getTimezoneInMinutes) if (hour != otherTime.hour) IntegerValue.signum(hour - otherTime.hour)
    else if (minute != otherTime.minute) IntegerValue.signum(minute - otherTime.minute)
    else if (second != otherTime.second) IntegerValue.signum(second - otherTime.second)
    else if (nanosecond != otherTime.nanosecond) IntegerValue.signum(nanosecond - otherTime.nanosecond)
    else 0
    else toDateTime.compareTo(otherTime.toDateTime)
  }

  /**
   * Compare the value to another dateTime value
   *
   * @param other            The other dateTime value
   * @param implicitTimezone The implicit timezone assumed for a value with no timezone
   * @return negative value if this one is the earler, 0 if they are chronologically equal,
   *         positive value if this one is the later. For this purpose, dateTime values with an unknown
   *         timezone are considered to be UTC values (the Comparable interface requires
   *         a total ordering).
   * @throws ClassCastException        if the other value is not a DateTimeValue (the parameter
   *                                   is declared as Object to satisfy the Comparable interface)
   * @throws NoDynamicContextException if the implicit timezone is required and is not available
   *                                   (because the function is called at compile time)
   */
  @throws[NoDynamicContextException]
  override def compareTo(other: CalendarValue, implicitTimezone: Int) = {
    if (!other.isInstanceOf[TimeValue]) throw new ClassCastException("Time values are not comparable to " + other.getClass)
    val otherTime = other.asInstanceOf[TimeValue]
    if (getTimezoneInMinutes == otherTime.getTimezoneInMinutes) { // The values have the same time zone, or neither has a timezone
      compareTo(other)
    }
    else toDateTime.compareTo(otherTime.toDateTime, implicitTimezone)
  }

  override def getSchemaComparable = new TimeValue#TimeComparable

  private class TimeComparable extends Comparable[_] {
    def asTimeValue = thisTimeValue

    override def compareTo(o: Any) = if (o.isInstanceOf[TimeValue#TimeComparable]) {
      val dt0 = asTimeValue.toDateTime
      val dt1 = o.asInstanceOf[TimeValue#TimeComparable].asTimeValue.toDateTime
      dt0.getSchemaComparable.compareTo(dt1.getSchemaComparable)
    }
    else SequenceTool.INDETERMINATE_ORDERING

    override def equals(o: Any) = compareTo(o) == 0

    override def hashCode = thisTimeValue.toDateTime.getSchemaComparable.hashCode
  }

  override def equals(other: Any) = other.isInstanceOf[TimeValue] && compareTo(other) == 0

  override def hashCode = DateTimeValue.hashCode(1951, 10.toByte, 11.toByte, hour, minute, second, nanosecond, getTimezoneInMinutes)

  /**
   * Add a duration to a dateTime
   *
   * @param duration the duration to be added (may be negative)
   * @return the new date
   * @throws net.sf.saxon.trans.XPathException
   * if the duration is an xs:duration, as distinct from
   * a subclass thereof
   */
  @throws[XPathException]
  override def add(duration: DurationValue) = if (duration.isInstanceOf[DayTimeDurationValue]) {
    val dt = toDateTime.add(duration)
    new TimeValue(dt.getHour, dt.getMinute, dt.getSecond, dt.getNanosecond, getTimezoneInMinutes, "")
  }
  else {
    val err = new XPathException("Time+Duration arithmetic is supported only for xs:dayTimeDuration")
    err.setErrorCode("XPTY0004")
    err.setIsTypeError(true)
    throw err
  }

  /**
   * Determine the difference between two points in time, as a duration
   *
   * @param other   the other point in time
   * @param context XPath dynamic evaluation context
   * @return the duration as an xs:dayTimeDuration
   * @throws XPathException for example if one value is a date and the other is a time
   */
  @throws[XPathException]
  override def subtract(other: CalendarValue, context: XPathContext) = {
    if (!other.isInstanceOf[TimeValue]) {
      val err = new XPathException("First operand of '-' is a time, but the second is not")
      err.setIsTypeError(true)
      throw err
    }
    super.subtract(other, context)
  }
}