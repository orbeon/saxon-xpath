////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package net.sf.saxon.style

import net.sf.saxon.trans.XPathException

import net.sf.saxon.tree.util.FastStringBuffer

import java.util.ArrayList

//remove if not needed
import scala.collection.JavaConversions._

/**
 * A class to handle a set of package version ranges
 * <p>This implements the semantics given in
 * <a href="http://www.w3.org/TR/xslt-30/#package-versions">http://www.w3.org/TR/xslt-30/#package-versions</a>,
 * where a comma-separated sequence of package-version ranges are declared as one of:</p>
 * <ul>
 * <li>'*' - any version</li>
 * <li><code>package-version</code> - an exact match</li>
 * <li><code>package-version'.*'</code> - any package whose version starts with the given prefix</li>
 * <li><code>package-version'+'</code> - any package whose version orders equal or later than the given version</li>
 * <li><code>'to 'package-version</code> - any package whose version orders equal or earlier than the given version</li>
 * <li><code>package-version' to 'package-version</code> - any package whose version orders equal to or between the given versions</li>
 * </ul>
 */
class PackageVersionRanges /**
 * Generate a set of package version ranges
 *
 * @param s Input string describing the ranges in the grammar described in
 *          <a href="http://www.w3.org/TR/xslt-30/#package-versions">http://www.w3.org/TR/xslt-30/#package-versions</a>
 * @throws XPathException
 */
(s: String) {

  var ranges: ArrayList[PackageVersionRange] =
    new ArrayList[PackageVersionRange]()

  private class PackageVersionRange(var display: String) {

    var low: PackageVersion = _

    var high: PackageVersion = _

    var all: Boolean = false

    var prefix: Boolean = false

    if ("*" == s) {
      all = true
    } else if (s.endsWith("+")) {
      low = new PackageVersion(s.replace("+", ""))
      high = PackageVersion.MAX_VALUE
    } else if (s.endsWith(".*")) {
      prefix = true
      low = new PackageVersion(s.replace(".*", ""))
    } else if (s.matches(".*\\s*to\\s+.*")) {
      val range: Array[String] = s.split("\\s*to\\s+")
      if (range.length > 2) {
        throw new XPathException("Invalid version range:" + s, "XTSE0020")
      }
      low =
        if (range(0).==("")) PackageVersion.ZERO
        else new PackageVersion(range(0))
      high = new PackageVersion(range(1))
    } else {
      low = new PackageVersion(s)
      high = low
    }

    def contains(v: PackageVersion): Boolean =
      if (all) {
        true
      } else if (prefix) {
        low.isPrefix(v)
      } else {
        low.compareTo(v) <= 0 && v.compareTo(high) <= 0
      }

    override def toString(): String = display

  }

  for (p <- s.trim().split("\\s*,\\s*")) {
    ranges.add(new PackageVersionRange(p))
  }

  /**
   * Test whether a given package version lies within any of the ranges described in this PackageVersionRanges
   * @param version The version to be checked
   * @return  true if the version is contained in any of the ranges, false otherwise
   */
  def contains(version: PackageVersion): Boolean =
    ranges.find(_.contains(version)).map(_ => true).getOrElse(false)

  override def toString(): String =
    if (ranges.size == 1) {
      ranges.get(0).display
    } else {
      val buffer: FastStringBuffer = new FastStringBuffer(256)
      for (r <- ranges) {
        buffer.append(r.display)
        buffer.append(",")
      }
      buffer.setLength(buffer.length - 1)
      buffer.toString
    }

}

