////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * A SubsequenceIterator selects a subsequence of a sequence
 */

package net.sf.saxon.expr

import net.sf.saxon.om.EnumSetTool

import net.sf.saxon.om.GroundedValue

import net.sf.saxon.om.Item

import net.sf.saxon.om.SequenceIterator

import net.sf.saxon.trans.XPathException

import net.sf.saxon.tree.iter.ArrayIterator

import net.sf.saxon.tree.iter.LookaheadIterator

import java.util.EnumSet

import SubsequenceIterator._

//remove if not needed
import scala.collection.JavaConversions._

object SubsequenceIterator {

  def make[T <: Item](base: SequenceIterator,
                      min: Int,
                      max: Int): SequenceIterator =
    if (base.isInstanceOf[ArrayIterator]) {
      base.asInstanceOf[ArrayIterator[T]].makeSliceIterator(min, max)
    } else if (max == java.lang.Integer.MAX_VALUE) {
      TailIterator.make(base, min)
    } else if (base.getProperties.contains(SequenceIterator.Property.GROUNDED) &&
      min > 4) {
      var value: GroundedValue = base.materialize()
      value = value.subsequence(min - 1, max - min + 1)
      value.iterate()
    } else {
      new SubsequenceIterator(base, min, max)
    }

}

class SubsequenceIterator private (private var base: SequenceIterator,
                                   private var min: Int,
                                   private var max: Int)
  extends SequenceIterator
    with LastPositionFinder
    with LookaheadIterator {

  private var basePosition: Int = 0

  /*@Nullable*/

  private var nextItem: Item = null

  if (min < 1) {
    min = 1
  }

  if (max < min) {
    nextItem = null
    return
  }

  var i: Int = 1

  while ({ i += 1; i - 1 } <= min) {
    nextItem = base.next() { basePosition += 1; basePosition - 1 }
    if (nextItem == null) {
      //break
    }
  }

  def hasNext(): Boolean = nextItem != null

  def next(): Item = {
    if (nextItem == null) {
      null
    }
    val current: Item = nextItem
    if (basePosition < max) {
      nextItem = base.next() { basePosition += 1; basePosition - 1 }
    } else {
      nextItem = null
      base.close()
    }
    current
  }

  def close(): Unit = {
    base.close()
  }

  def getProperties(): EnumSet[Property] = {
    val p: EnumSet[Property] = EnumSetTool.intersect(
      base.getProperties,
      EnumSet.of(Property.LAST_POSITION_FINDER))
    EnumSetTool.union(p, EnumSet.of(Property.LOOKAHEAD))
  }

  def getLength(): Int = {
    val lastBase: Int = base.asInstanceOf[LastPositionFinder].getLength
    val z: Int = Math.min(lastBase, max)
    Math.max(z - min + 1, 0)
  }

}
