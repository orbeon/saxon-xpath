////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.tree

import net.sf.saxon.Configuration
import net.sf.saxon.event.Receiver
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.tree.iter.ListIterator
import net.sf.saxon.tree.iter.PrependAxisIterator
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.tree.util.Navigator
import net.sf.saxon.value.StringValue
import java.util
import java.util.function.Predicate

/**
 * This class represents a namespace node; it is used in several tree models.
 */
object NamespaceNode {
  /**
   * Factory method to create an iterator over the in-scope namespace nodes of an element
   *
   * @param element the node whose namespaces are required
   * @param test    used to filter the returned nodes
   * @return an iterator over the namespace nodes that satisfy the test
   */
    /*@NotNull*/ def makeIterator(element: NodeInfo, test: Predicate[_ >: NodeInfo]) = {
      val nodes = new util.ArrayList[NodeInfo]
      val bindings = element.getAllNamespaces.iterator
      var position = 0
      var foundXML = false
      while ( {
        bindings.hasNext
      }) {
        val binding = bindings.next
        if (binding.getPrefix == "xml") foundXML = true
        val node = new NamespaceNode(element, binding, {
          position += 1; position - 1
        })
        if (test.test(node)) nodes.add(node)
      }
      if (!foundXML) {
        val node = new NamespaceNode(element, NamespaceBinding.XML, position)
        if (test.test(node)) nodes.add(node)
      }
      new ListIterator.OfNodes(nodes)
    }
}

class NamespaceNode(var element: NodeInfo, var nsBinding: NamespaceBinding, var position: Int)

/**
 * Create a namespace node
 *
 * @param element  the parent element of the namespace node
 * @param nscode   the namespace code, representing the prefix and URI of the namespace binding
 * @param position maintains document order among namespace nodes for the same element
 */
  extends NodeInfo {
  fingerprint = -1 // evaluated lazily to avoid NamePool access
  private[tree] var fingerprint = 0

  /**
   * Get information about the tree to which this NodeInfo belongs
   *
   * @return the TreeInfo
   * @since 9.7
   */
  override def getTreeInfo = element.getTreeInfo

  /**
   * To implement {@link Sequence}, this method returns the item itself
   *
   * @return this item
   */
  override def head = this

  /**
   * Get the kind of node. This will be a value such as Type.ELEMENT or Type.ATTRIBUTE
   *
   * @return an integer identifying the kind of node. These integer values are the
   *         same as those used in the DOM
   * @see net.sf.saxon.model.Type
   */
  override def getNodeKind = Type.NAMESPACE

  /**
   * Determine whether this is the same node as another node.
   * Note: a.equals(b) if and only if generateId(a)==generateId(b).
   * This method has the same semantics as isSameNode() in DOM Level 3, but
   * works on Saxon NodeInfo objects rather than DOM Node objects.
   *
   * @param other the node to be compared with this node
   * @return true if this NodeInfo object and the supplied NodeInfo object represent
   *         the same node in the tree.
   */
  override def equals(other: Any) = other.isInstanceOf[NamespaceNode] && element == other.asInstanceOf[NamespaceNode].element && nsBinding == other.asInstanceOf[NamespaceNode].nsBinding

  /**
   * The hashCode() method obeys the contract for hashCode(): that is, if two objects are equal
   * (represent the same node) then they must have the same hashCode()
   *
   * @since 8.7 Previously, the effect of the equals() and hashCode() methods was not defined. Callers
   *        should therefore be aware that third party implementations of the NodeInfo interface may
   *        not implement the correct semantics.
   */
  override def hashCode = element.hashCode ^ (position << 13)

  /**
   * Get the System ID for the node.
   *
   * @return the System Identifier of the entity in the source document
   *         containing the node, or null if not known. Note this is not the
   *         same as the base URI: the base URI can be modified by xml:base, but
   *         the system ID cannot.
   */
  /*@Nullable*/ override def getSystemId = element.getSystemId

  /**
   * Get the Public ID of the entity containing the node.
   *
   * @return the Public Identifier of the entity in the source document
   *         containing the node, or null if not known or not applicable
   * @since 9.7
   */
  override def getPublicId = element.getPublicId

  /**
   * Get the Base URI for the node, that is, the URI used for resolving a relative URI contained
   * in the node. This will be the same as the System ID unless xml:base has been used.
   *
   * @return the base URI of the node
   */
  override def getBaseURI = null // the base URI of a namespace node is the empty sequence
  /**
   * Get line number
   *
   * @return the line number of the node in its original source document; or
   *         -1 if not available
   */
  override def getLineNumber = element.getLineNumber

  /**
   * Get column number
   *
   * @return the column number of the node in its original source document; or
   *         -1 if not available
   */
  override def getColumnNumber = element.getColumnNumber

  /**
   * Get an immutable copy of this Location object. By default Location objects may be mutable, so they
   * should not be saved for later use. The result of this operation holds the same location information,
   * but in an immutable form.
   */
  override def saveLocation = this

  /**
   * Determine the relative position of this node and another node, in document order.
   * The other node will always be in the same document.
   *
   * @param other The other node, whose position is to be compared with this
   *              node
   * @return -1 if this node precedes the other node, +1 if it follows the
   *         other node, or 0 if they are the same node. (In this case,
   *         isSameNode() will always return true, and the two nodes will
   *         produce the same result for generateId())
   */
  override def compareOrder(other: NodeInfo) = if (other.isInstanceOf[NamespaceNode] && element == other.asInstanceOf[NamespaceNode].element) {
    val c = position - other.asInstanceOf[NamespaceNode].position
    Integer.compare(c, 0)
  }
  else if (element == other) +1
  else element.compareOrder(other)

  /**
   * Return the string value of the node. The interpretation of this depends on the type
   * of node. For a namespace node, it is the namespace URI.
   *
   * @return the string value of the node
   */
  override def getStringValue = nsBinding.getURI

  /**
   * Get the value of the item as a CharSequence. This is in some cases more efficient than
   * the version of the method that returns a String.
   */
  override def getStringValueCS = getStringValue

  /**
   * Ask whether this NodeInfo implementation holds a fingerprint identifying the name of the
   * node in the NamePool. If the answer is true, then the {@link #getFingerprint} method must
   * return the fingerprint of the node. If the answer is false, then the {@link #getFingerprint}
   * method should throw an {@code UnsupportedOperationException}. In the case of unnamed nodes
   * such as text nodes, the result can be either true (in which case getFingerprint() should
   * return -1) or false (in which case getFingerprint may throw an exception).
   *
   * @return true if the implementation of this node provides fingerprints.
   * @since 9.8; previously Saxon relied on using <code>FingerprintedNode</code> as a marker interface.
   */
  override def hasFingerprint = true

  /**
   * Get fingerprint. The fingerprint is a coded form of the expanded name
   * of the node: two nodes
   * with the same name code have the same namespace URI and the same local name.
   * A fingerprint of -1 should be returned for a node with no name.
   *
   * @return an integer fingerprint; two nodes with the same fingerprint have
   *         the same expanded QName
   */
  override def getFingerprint: Int = {
    if (fingerprint == -1) if (nsBinding.getPrefix.isEmpty) return -1
    else fingerprint = element.getConfiguration.getNamePool.allocateFingerprint("", nsBinding.getPrefix)
    fingerprint
  }

  /**
   * Get the local part of the name of this node. This is the name after the ":" if any.
   *
   * @return the local part of the name. For an unnamed node, returns "". Unlike the DOM
   *         interface, this returns the full name in the case of a non-namespaced name.
   */
  override def getLocalPart = nsBinding.getPrefix

  /**
   * Get the URI part of the name of this node. This is the URI corresponding to the
   * prefix, or the URI of the default namespace if appropriate.
   *
   * @return The URI of the namespace of this node. Since the name of a namespace
   *         node is always an NCName (the namespace prefix), this method always returns "".
   */
  override def getURI = ""

  /**
   * Get the display name of this node. For elements and attributes this is [prefix:]localname.
   * For unnamed nodes, it is an empty string.
   *
   * @return The display name of this node. For a node with no name, return
   *         an empty string.
   */
  override def getDisplayName = getLocalPart

  /**
   * Get the prefix of the name of the node. This is defined only for elements and attributes.
   * If the node has no prefix, or for other kinds of node, return a zero-length string.
   *
   * @return The prefix of the name of the node.
   */
  override def getPrefix = ""

  /**
   * Get the configuration
   */
  override def getConfiguration = element.getConfiguration

  /**
   * Get the NamePool that holds the namecode for this node
   *
   * @return the namepool
   */
  def getNamePool = getConfiguration.getNamePool

  /**
   * Get the type annotation of this node, if any. The type annotation is represented as
   * SchemaType object.
   * <p>Types derived from a DTD are not reflected in the result of this method.</p>
   *
   * @return For element and attribute nodes: the type annotation derived from schema
   *         validation (defaulting to xs:untyped and xs:untypedAtomic in the absence of schema
   *         validation). For comments, text nodes, processing instructions, and namespaces: null.
   *         For document nodes, either xs:untyped if the document has not been validated, or
   *         xs:anyType if it has.
   * @since 9.4
   */
  override def getSchemaType = BuiltInAtomicType.STRING

  /**
   * Get the NodeInfo object representing the parent of this node
   *
   * @return the parent of this node; null if this node has no parent
   */
  override def getParent = element

  /**
   * Return an iteration over all the nodes reached by the given axis from this node
   * that match a given NodeTest
   *
   * @param axisNumber an integer identifying the axis; one of the constants
   *                   defined in class net.sf.saxon.om.Axis
   * @param nodeTest   A pattern to be matched by the returned nodes; nodes
   *                   that do not match this pattern are not included in the result
   * @return a NodeEnumeration that scans the nodes reached by the axis in
   *         turn.
   * @throws UnsupportedOperationException if the namespace axis is
   *                                       requested and this axis is not supported for this implementation.
   * @see net.sf.saxon.om.AxisInfo
   */
  override def iterateAxis(axisNumber: Int, nodeTest: Predicate[_ >: NodeInfo]) = axisNumber match {
    case AxisInfo.ANCESTOR =>
      element.iterateAxis(AxisInfo.ANCESTOR_OR_SELF, nodeTest)
    case AxisInfo.ANCESTOR_OR_SELF =>
      if (nodeTest.test(this)) new PrependAxisIterator(this, element.iterateAxis(AxisInfo.ANCESTOR_OR_SELF, nodeTest))
      else element.iterateAxis(AxisInfo.ANCESTOR_OR_SELF, nodeTest)
    case AxisInfo.ATTRIBUTE =>
    case AxisInfo.CHILD =>
    case AxisInfo.DESCENDANT =>
    case AxisInfo.DESCENDANT_OR_SELF =>
    case AxisInfo.FOLLOWING_SIBLING =>
    case AxisInfo.NAMESPACE =>
    case AxisInfo.PRECEDING_SIBLING =>
      EmptyIterator.ofNodes
    case AxisInfo.FOLLOWING =>
      new Navigator.AxisFilter(new Navigator.FollowingEnumeration(this), nodeTest)
    case AxisInfo.PARENT =>
      Navigator.filteredSingleton(element, nodeTest)
    case AxisInfo.PRECEDING =>
      new Navigator.AxisFilter(new Navigator.PrecedingEnumeration(this, false), nodeTest)
    case AxisInfo.SELF =>
      Navigator.filteredSingleton(this, nodeTest)
    case AxisInfo.PRECEDING_OR_ANCESTOR =>
      new Navigator.AxisFilter(new Navigator.PrecedingEnumeration(this, true), nodeTest)
    case _ =>
      throw new IllegalArgumentException("Unknown axis number " + axisNumber)
  }

  /**
   * Get the string value of a given attribute of this node
   *
   * @param uri   the namespace URI of the attribute name. Supply the empty string for an attribute
   *              that is in no namespace
   * @param local the local part of the attribute name.
   * @return the attribute value if it exists, or null if it does not exist. Always returns null
   *         if this node is not an element.
   * @since 9.4
   */
  override def getAttributeValue(uri: String, local: String) = null

  /**
   * Get the root node of the tree containing this node
   *
   * @return the NodeInfo representing the top-level ancestor of this node.
   *         This will not necessarily be a document node
   */
  override def getRoot = element.getRoot

  /**
   * Determine whether the node has any children.
   * <p>Note: the result is equivalent to
   * <code>getEnumeration(Axis.CHILD, AnyNodeTest.getInstance()).hasNext()</code></p>
   *
   * @return True if the node has one or more children
   */
  override def hasChildNodes = false

  /**
   * Get a character string that uniquely identifies this node.
   * Note: a.isSameNode(b) if and only if generateId(a)==generateId(b)
   *
   * @param buffer buffer to hold a string that uniquely identifies this node, across all
   *               documents.
   */
  override def generateId(buffer: FastStringBuffer) = {
    element.generateId(buffer)
    buffer.append("n")
    buffer.append(Integer.toString(position))
  }

  /**
   * Copy this node to a given outputter
   *
   * @param out         the Receiver to which the node should be copied
   * @param copyOptions a selection of the options defined in { @link CopyOptions}
   * @param locationId If non-zero, identifies the location of the instruction
   */
  @throws[XPathException]
  override def copy(out: Receiver, copyOptions: Int, locationId: Location) = out.append(this)

  /**
   * Get all namespace undeclarations and undeclarations defined on this element.
   *
   * @param buffer If this is non-null, and the result array fits in this buffer, then the result
   *               may overwrite the contents of this array, to avoid the cost of allocating a new array on the heap.
   * @return An array of integers representing the namespace declarations and undeclarations present on
   *         this element. For a node other than an element, return null. Otherwise, the returned array is a
   *         sequence of namespace codes, whose meaning may be interpreted by reference to the name pool. The
   *         top half word of each namespace code represents the prefix, the bottom half represents the URI.
   *         If the bottom half is zero, then this is a namespace undeclaration rather than a declaration.
   *         The XML namespace is never included in the list. If the supplied array is larger than required,
   *         then the first unused entry will be set to -1.
   *         <p>For a node other than an element, the method returns null.</p>
   */
  override def getDeclaredNamespaces(buffer: Array[NamespaceBinding]) = null

  /**
   * Get all the namespace bindings that are in-scope for this element.
   * <p>For an element return all the prefix-to-uri bindings that are in scope. This may include
   * a binding to the default namespace (represented by a prefix of ""). It will never include
   * "undeclarations" - that is, the namespace URI will never be empty; the effect of an undeclaration
   * is to remove a binding from the in-scope namespaces, not to add anything.</p>
   * <p>For a node other than an element, returns null.</p>
   *
   * @return the in-scope namespaces for an element, or null for any other kind of node.
   */
  override def getAllNamespaces = null

  /**
   * Set the system identifier for this Source.
   * <p>The system identifier is optional if the source does not
   * get its data from a URL, but it may still be useful to provide one.
   * The application can use a system identifier, for example, to resolve
   * relative URIs and to include in error messages and warnings.</p>
   *
   * @param systemId The system identifier as a URL string.
   */
  override def setSystemId(systemId: String) = {
    // no action: namespace nodes have the same base URI as their parent
  }

  /**
   * Get the typed value.
   *
   * @return the typed value.
   * @since 8.5
   */
  @throws[XPathException]
  override def atomize = new StringValue(getStringValueCS)

  override def isStreamed = element.isStreamed
}