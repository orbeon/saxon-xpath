////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.om.EnumSetTool
import net.sf.saxon.om.Item
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.LookaheadIterator
import java.util

/**
 * ItemMappingIterator applies a mapping function to each item in a sequence.
 * The mapping function either returns a single item, or null (representing an
 * empty sequence).
 * <p>This is a specialization of the more general MappingIterator class, for use
 * in cases where a single input item never maps to a sequence of more than one
 * output item.</p>
 */
class ItemMappingIterator extends SequenceIterator with LookaheadIterator with LastPositionFinder {
  private var base = null
  private var action = null
  private var oneToOne = false

  /**
   * Construct an ItemMappingIterator that will apply a specified DummyItemMappingFunction to
   * each Item returned by the base iterator.
   *
   * @param base   the base iterator
   * @param action the mapping function to be applied.
   */
  def this(base: SequenceIterator, action: ItemMappingFunction) {
    this()
    this.base = base
    this.action = action
  }

  /**
   * Construct an ItemMappingIterator that will apply a specified ItemMappingFunction to
   * each Item returned by the base iterator.
   *
   * @param base     the base iterator
   * @param action   the mapping function to be applied
   * @param oneToOne true if this iterator is one-to-one
   */
  def this(base: SequenceIterator, action: ItemMappingFunction, oneToOne: Boolean) {
    this()
    this.base = base
    this.action = action
    this.oneToOne = oneToOne
  }

  /**
   * Say whether this ItemMappingIterator is one-to-one: that is, for every input item, there is
   * always exactly one output item. The default is false.
   *
   * @param oneToOne true if this iterator is one-to-one
   */
  def setOneToOne(oneToOne: Boolean) = this.oneToOne = oneToOne

  /**
   * Ask whether this ItemMappingIterator is one-to-one: that is, for every input item, there is
   * always exactly one output item. The default is false.
   *
   * @return true if this iterator is one-to-one
   */
  def isOneToOne = oneToOne

  /**
   * Get the base (input) iterator
   *
   * @return the iterator over the input sequence
   */
  protected def getBaseIterator = base

  /**
   * Get the mapping function (the function applied to each item in the input sequence
   *
   * @return the mapping function
   */
  protected def getMappingFunction = action

  override def hasNext = { // Must only be called if this is a lookahead iterator, which will only be true if the base iterator
    // is a lookahead iterator and one-to-one is true
    base.asInstanceOf[LookaheadIterator].hasNext
  }

  @throws[XPathException]
  override def next: Item = while ( {
    true
  }) {
    val nextSource = base.next
    if (nextSource == null) return null
    // Call the supplied mapping function
    val current = action.mapItem(nextSource)
    if (current != null) return current
    // otherwise go round the loop to get the next item from the base sequence
  }

  override def close() = base.close()

  @throws[XPathException]
  override def getLength = { // Must only be called if this is a last-position-finder iterator, which will only be true if the base iterator
    // is a last-position-finder iterator and one-to-one is true
    base.asInstanceOf[LastPositionFinder].getLength
  }

  /**
   * Get properties of this iterator, as a bit-significant integer.
   *
   * @return the properties of this iterator. This will be some combination of
   *         properties such as { @link net.sf.saxon.om.SequenceIterator.Property#GROUNDED},
   *                                    { @link net.sf.saxon.om.SequenceIterator.Property#LAST_POSITION_FINDER},
   *                                    and { @link net.sf.saxon.om.SequenceIterator.Property#LOOKAHEAD}. It is always
   *                                    acceptable to return the value zero, indicating that there are no known special properties.
   *                                    It is acceptable for the properties of the iterator to change depending on its state.
   */
  override def getProperties = if (oneToOne) EnumSetTool.intersect(base.getProperties, util.EnumSet.of(Property.LAST_POSITION_FINDER, Property.LOOKAHEAD))
  else util.EnumSet.noneOf(classOf[SequenceIterator.Property])
}