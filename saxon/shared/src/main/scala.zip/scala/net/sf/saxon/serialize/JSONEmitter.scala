////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.ma.json.JsonReceiver
import net.sf.saxon.serialize.charcode.CharacterSet
import net.sf.saxon.serialize.codenorm.Normalizer
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.BooleanValue
import net.sf.saxon.value.IntegerValue
import net.sf.saxon.value.NumericValue
import javax.xml.transform.OutputKeys
import javax.xml.transform.stream.StreamResult
import java.io.IOException
import java.io.Writer
import java.util.Properties
import java.util

/**
 * This class implements the back-end text generation of the JSON serialization method. It takes
 * as input a sequence of event-based calls such as startArray, endArray, startMap, endMap,
 * and generates the lexical JSON output.
 *
 * @author Michael H. Kay
 */
class JSONEmitter @throws[XPathException]
(val pipe: PipelineConfiguration, val result: StreamResult, val outputProperties: Properties) {
  setOutputProperties(outputProperties)
  this.result = new ExpandedStreamResult(pipelineConfiguration.getConfiguration, result, outputProperties)
  private var result = null
  private var writer = null
  private var normalizer = null
  private var characterMap = null
  private var outputProperties = null
  private var characterSet = null
  private var isIndenting = false
  private var indentSpaces = 2
  private var maxLineLength = 0
  private var first = true
  private var afterKey = false
  private var level = 0
  private val oneLinerStack = new util.Stack[Boolean]
  private var unfailing = false

  /**
   * Set output properties
   *
   * @param details the output serialization properties
   */
  def setOutputProperties(details: Properties) = {
    this.outputProperties = details
    if ("yes" == details.getProperty(OutputKeys.INDENT)) isIndenting = true
    if ("yes" == details.getProperty(SaxonOutputKeys.UNFAILING)) unfailing = true
    val max = details.getProperty(SaxonOutputKeys.LINE_LENGTH)
    if (max != null) try maxLineLength = max.toInt
    catch {
      case err: NumberFormatException =>

      // ignore the error.
    }
    val spaces = details.getProperty(SaxonOutputKeys.INDENT_SPACES)
    if (spaces != null) try indentSpaces = spaces.toInt
    catch {
      case err: NumberFormatException =>
    }
  }

  /**
   * Get the output properties
   *
   * @return the properties that were set using setOutputProperties
   */
  def getOutputProperties = outputProperties

  /**
   * Set the Unicode normalizer to be used for normalizing strings.
   *
   * @param normalizer the normalizer to be used
   */
  def setNormalizer(normalizer: Normalizer) = this.normalizer = normalizer

  /**
   * Set the CharacterMap to be used, if any
   *
   * @param map the character map
   */
  def setCharacterMap(map: CharacterMap) = this.characterMap = map

  /**
   * Output the key for an entry in a map. The corresponding value must be supplied
   * in the following call.
   *
   * @param key the value of the key, without any escaping of special characters
   * @throws XPathException if any error occurs
   */
  @throws[XPathException]
  def writeKey(key: String) = {
    conditionalComma(false)
    emit('"')
    emit(escape(key))
    emit("\":")
    if (isIndenting) emit(" ")
    afterKey = true
  }

  /**
   * Append a singleton value (number, string, or boolean) to the output
   *
   * @param item the atomic value to be appended, or null to append "null"
   * @throws XPathException if the operation fails
   */
  @throws[XPathException]
  def writeAtomicValue(item: AtomicValue) = {
    conditionalComma(false)
    if (item == null) emit("null")
    else if (item.isInstanceOf[NumericValue]) {
      val num = item.asInstanceOf[NumericValue]
      if (num.isNaN) if (unfailing) emit("NaN")
      else throw new XPathException("JSON has no way of representing NaN", "SERE0020")
      else if (Double.isInfinite(num.getDoubleValue)) if (unfailing) emit(if (num.getDoubleValue < 0) "-INF"
      else "INF")
      else throw new XPathException("JSON has no way of representing Infinity", "SERE0020")
      else if (item.isInstanceOf[IntegerValue]) { // " Implementations MAY serialize the numeric value using any
        //   lexical representation of a JSON number defined in [RFC 7159]. "
        // This avoids exponential notation for integers such as 1123456.
        emit(num.longValue + "")
      }
      else if (num.isWholeNumber && !num.isNegativeZero && num.abs.compareTo(1000000000000000000L) < 0) emit(num.longValue + "")
      else emit(num.getStringValue)
    }
    else if (item.isInstanceOf[BooleanValue]) emit(item.getStringValue)
    else {
      emit('"')
      emit(escape(item.getStringValue))
      emit('"')
    }
  }

  /**
   * Output the start of an array. This call must be followed by the members of the
   * array, followed by a call on {@link #endArray()}.
   *
   * @param oneLiner True if the caller thinks the value should be output without extra newlines
   *                 after the open bracket or before the close bracket,
   *                 even when indenting is on.
   * @throws XPathException if any failure occurs
   */
  @throws[XPathException]
  def startArray(oneLiner: Boolean) = {
    emitOpen('[', oneLiner)
    level += 1
  }

  /**
   * Output the end of an array
   *
   * @throws XPathException if any failure occurs
   */
  @throws[XPathException]
  def endArray() = emitClose(']', {
    level -= 1; level + 1
  })

  /**
   * Output the start of an map. This call must be followed by the entries in the
   * map (each starting with a call on {@link #writeKey(String)}, followed by a call on
   * {@link #endMap()}.
   *
   * @param oneLiner True if the caller thinks the value should be output without extra newlines
   *                 after the open bracket or before the close bracket,
   *                 even when indenting is on.
   * @throws XPathException if any failure occurs
   */
  @throws[XPathException]
  def startMap(oneLiner: Boolean) = {
    emitOpen('{', oneLiner)
    level += 1
  }

  @throws[XPathException]
  def endMap() = emitClose('}', {
    level -= 1; level + 1
  })

  @throws[XPathException]
  private def emitOpen(bracket: Char, oneLiner: Boolean) = {
    conditionalComma(true)
    oneLinerStack.push(oneLiner)
    //        if (isIndenting) {
    //            emit(' ');
    //        }
    emit(bracket)
    first = true
    if (isIndenting) if (oneLiner) emit(' ')
    else {
      //indent(level + 1);
    }
  }

  @throws[XPathException]
  private def emitClose(bracket: Char, level: Int) = {
    val oneLiner = oneLinerStack.pop
    if (isIndenting) if (oneLiner) emit(' ')
    else indent(level)
    emit(bracket)
    first = false
  }

  @throws[XPathException]
  private def conditionalComma(opening: Boolean) = {
    val wasFirst = first
    if (first) first = false
    else if (!afterKey) emit(',')
    if (wasFirst && afterKey) emit(' ')
    else if (isIndenting && !afterKey && level != 0) {
      emit('\n')
      for (i <- 0 until indentSpaces * (level + 1)) {
        emit(' ')
      }
    }
    afterKey = false
  }

  @throws[XPathException]
  private def indent(level: Int) = {
    emit('\n')
    for (i <- 0 until indentSpaces * level) {
      emit(' ')
    }
  }

  @throws[XPathException]
  private def escape(cs: CharSequence): CharSequence = if (characterMap != null) {
    val out = new FastStringBuffer(cs.length)
    cs = characterMap.map(cs, true)
    val s = cs.toString
    var prev = 0
    while ( {
      true
    }) {
      val start = s.indexOf(0, prev)
      if (start >= 0) {
        out.cat(simpleEscape(s.substring(prev, start)))
        val end = s.indexOf(0, start + 1)
        out.append(s.substring(start + 1, end))
        prev = end + 1
      }
      else {
        out.cat(simpleEscape(s.substring(prev)))
        return out
      }
    }
  }
  else simpleEscape(cs)

  @throws[XPathException]
  private def simpleEscape(cs: CharSequence) = {
    if (normalizer != null) cs = normalizer.normalize(cs)
    JsonReceiver.escape(cs, false, (c: Int) => c < 31 || (c >= 127 && c <= 159) || !characterSet.inCharset(c))
  }

  @throws[XPathException]
  private def emit(s: CharSequence) = {
    if (writer == null) {
      writer = result.obtainWriter
      characterSet = result.getCharacterSet
    }
    try writer.append(s)
    catch {
      case e: IOException =>
        throw new XPathException(e)
    }
  }

  @throws[XPathException]
  private def emit(c: Char) = emit(c + "")

  /**
   * End of the document.
   */
  @throws[XPathException]
  def close() = {
    if (first) emit("null")
    if (writer != null) try writer.close()
    catch {
      case e: IOException =>

      // no action
    }
  }
}