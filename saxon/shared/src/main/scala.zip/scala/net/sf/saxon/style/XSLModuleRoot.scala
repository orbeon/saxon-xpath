////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.om.NodeInfo
import net.sf.saxon.trans.XPathException

/**
 * Class representing xsl:stylesheet, xsl:transform, or xsl:package
 */
object XSLModuleRoot {
  val ANNOTATION_UNSPECIFIED = 0
  val ANNOTATION_STRIP = 1
  val ANNOTATION_PRESERVE = 2
}

abstract class XSLModuleRoot extends StyleElement {
  /**
   * Ask whether it is required that modes be explicitly declared
   *
   * @return true if modes referenced within this package be explicitly declared
   */
    def isDeclaredModes = false

  /**
   * Process the attributes of every node in the stylesheet module
   */
  @throws[XPathException]
  override def processAllAttributes() = {
    prepareAttributes()
    import scala.collection.JavaConversions._
    for (node <- children(classOf[StyleElement].isInstance)) {
      try node.asInstanceOf[StyleElement].processAllAttributes
      catch {
        case err: XPathException =>
          node.asInstanceOf[StyleElement].compileError(err)
      }
    }
  }

  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = compileError(getDisplayName + " can appear only as the outermost element", "XTSE0010")

  /**
   * Get the value of the input-type-annotations attribute, for this module alone.
   * The value is an or-ed combination of the two bits
   * {@link #ANNOTATION_STRIP} and {@link #ANNOTATION_PRESERVE}
   *
   * @return the value if the input-type-annotations attribute in this stylesheet module
   */
  def getInputTypeAnnotationsAttribute: Int = {
    val inputTypeAnnotationsAtt = getAttributeValue("", "input-type-annotations")
    if (inputTypeAnnotationsAtt != null) inputTypeAnnotationsAtt match {
      case "strip" =>
        return XSLModuleRoot.ANNOTATION_STRIP
      case "preserve" =>
        return XSLModuleRoot.ANNOTATION_PRESERVE
      case "unspecified" =>
        return XSLModuleRoot.ANNOTATION_UNSPECIFIED
      case _ =>
        compileError("Invalid value for input-type-annotations attribute. " + "Permitted values are (strip, preserve, unspecified)", "XTSE0020")
        return XSLModuleRoot.ANNOTATION_UNSPECIFIED
    }
    -1
  }
}