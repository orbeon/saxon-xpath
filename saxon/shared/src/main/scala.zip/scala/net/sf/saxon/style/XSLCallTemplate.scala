////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.CallTemplate
import net.sf.saxon.expr.instruct.NamedTemplate
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace
import java.util

/**
 * An xsl:call-template element in the stylesheet
 */
object XSLCallTemplate {
  private val ERROR_TEMPLATE_NAME = new StructuredQName("saxon", NamespaceConstant.SAXON, "error-template")
}

class XSLCallTemplate extends StyleElement {
  private var calledTemplateName = null // the name of the called template
  private var template = null // the template to be called (which may subsequently be overridden in another package)
  private var useTailRecursion = false

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  override def prepareAttributes(): Unit = {
    var nameAttribute = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "name") nameAttribute = Whitespace.trim(value)
      else checkUnknownAttribute(attName)
    }
    if (nameAttribute == null) {
      calledTemplateName = XSLCallTemplate.ERROR_TEMPLATE_NAME
      reportAbsence("name")
      return
    }
    calledTemplateName = makeQName(nameAttribute, null, "name")
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLWithParam]) {
        // OK;
      }
      else if (child.isInstanceOf[XSLFallback] && mayContainFallback) {
        // xsl:fallback is not allowed on xsl:call-template, but is allowed on saxon:call-template (cheat!)
      }
      else if (child.getNodeKind == Type.TEXT) { // with xml:space=preserve, white space nodes may still be there
        if (!Whitespace.isWhite(child.getStringValueCS)) compileError("No character data is allowed within xsl:call-template", "XTSE0010")
      }
      else compileError("Child element " + Err.wrap(child.getDisplayName, Err.ELEMENT) + " is not allowed as a child of xsl:call-template", "XTSE0010")
    }
    if (!(calledTemplateName == XSLCallTemplate.ERROR_TEMPLATE_NAME)) template = findTemplate(calledTemplateName)
  }

  @throws[XPathException]
  override def postValidate() = { // check that a parameter is supplied for each required parameter
    // of the called template
    if (template != null) checkParams()
    else throw new AssertionError("Target template not known")
  }

  @throws[XPathException]
  private def checkParams() = {
    val declaredParams = template.getLocalParamDetails
    import scala.collection.JavaConversions._
    for (param <- declaredParams) {
      if (param.isRequired && !param.isTunnel) {
        var ok = false
        import scala.collection.JavaConversions._
        for (withParam <- children(classOf[XSLWithParam].isInstance)) {
          if (withParam.asInstanceOf[XSLWithParam].getVariableQName == param.name) {
            ok = true
            break //todo: break is not supported
          }
        }
        if (!ok) compileError("No value supplied for required parameter " + Err.wrap(param.name.getDisplayName, Err.VARIABLE), "XTSE0690")
      }
    }
    // check that every supplied parameter is declared in the called
    // template
    import scala.collection.JavaConversions._
    for (w <- children) {
      if (w.isInstanceOf[XSLWithParam] && !(w.asInstanceOf[XSLWithParam]).isTunnelParam) {
        val withParam = w.asInstanceOf[XSLWithParam]
        var ok = false
        import scala.collection.JavaConversions._
        for (param <- declaredParams) {
          if (param.name == withParam.getVariableQName && !param.isTunnel) { // Note: see bug 10534
            ok = true
            val required = param.requiredType
            withParam.checkAgainstRequiredType(required)
            break //todo: break is not supported
          }
        }
        if (!ok && !xPath10ModeIsEnabled) compileError("Parameter " + withParam.getVariableQName.getDisplayName + " is not declared in the called template", "XTSE0680")
      }
    }
  }

  @throws[XPathException]
  private def findTemplate(templateName: StructuredQName): NamedTemplate = {
    val pack = getPrincipalStylesheetModule
    val template = pack.getNamedTemplate(templateName)
    if (template == null) {
      if (templateName.hasURI(NamespaceConstant.XSLT) && templateName.getLocalPart == "original") { // Handle xsl:original
        return getXslOriginal(StandardNames.XSL_TEMPLATE).asInstanceOf[NamedTemplate]
      }
      compileError("Cannot find a template named " + calledTemplateName, "XTSE0650")
    }
    template
  }

  /**
   * Mark tail-recursive calls on templates and functions.
   * For most instructions, this does nothing.
   */
  override def markTailCalls = {
    useTailRecursion = true
    true
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = {
    if (template == null) return null // error already reported
    val call = new CallTemplate(template, calledTemplateName, useTailRecursion, isWithinDeclaredStreamableConstruct)
    call.setLocation(allocateLocation)
    call.setActualParameters(getWithParamInstructions(call, exec, decl, false), getWithParamInstructions(call, exec, decl, true))
    call
  }
}