////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.Configuration
import net.sf.saxon.event._
import net.sf.saxon.expr.Component
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.expr.parser.RetainedStaticContext
import net.sf.saxon.lib.Logger
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.model.Untyped
import net.sf.saxon.om._
import net.sf.saxon.serialize.SerializationProperties
import net.sf.saxon.serialize.charcode.UTF16CharacterSet
import net.sf.saxon.style.StylesheetPackage
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.Whitespace
import javax.xml.transform.OutputKeys
import javax.xml.transform.stream.StreamResult
import java.util

/**
 * This class handles the display of an abstract expression tree in an XML format
 * with some slight resemblance to XQueryX
 */
object ExpressionPresenter {
  /**
   * Make a receiver, using default output properties, with serialized output going
   * to a specified OutputStream
   *
   * @param config the Configuration
   * @param out    the OutputStream
   * @return a Receiver that directs serialized output to this output stream
   * @throws XPathException
   */
    /*@Nullable*/ @throws[XPathException]
    def defaultDestination(/*@NotNull*/ config: Configuration, out: Logger) = {
      val props = makeDefaultProperties(config)
      config.getSerializerFactory.getReceiver(out.asStreamResult, props)
    }

  /**
   * Make a Properties object containing defaulted serialization attributes for the expression tree
   *
   * @return a default set of properties
   */
  def makeDefaultProperties(config: Configuration) = {
    val props = new SerializationProperties
    props.setProperty(OutputKeys.METHOD, "xml")
    props.setProperty(OutputKeys.INDENT, "yes")
    if (config.isLicensedFeature(Configuration.LicenseFeature.PROFESSIONAL_EDITION)) {
      props.setProperty(SaxonOutputKeys.INDENT_SPACES, "1")
      props.setProperty(SaxonOutputKeys.LINE_LENGTH, "4096")
    }
    props.setProperty(OutputKeys.OMIT_XML_DECLARATION, "no")
    props.setProperty(OutputKeys.ENCODING, "utf-8")
    props.setProperty(OutputKeys.VERSION, "1.0")
    props.setProperty(SaxonOutputKeys.SINGLE_QUOTES, "yes")
    props
  }

  /**
   * Static method to escape a string using Javascript escaping conventions
   *
   * @param in the string to be escaped
   */
  def jsEscape(in: String) = {
    val out = new FastStringBuffer(in.length)
    for (i <- 0 until in.length) {
      val c = in.charAt(i)
      c match {
        case '\'' =>
          out.append("\\'")
        case '"' =>
          out.append("\\\"")
        case '\b' =>
          out.append("\\b")
        case '\f' =>
          out.append("\\f")
        case '\n' =>
          out.append("\\n")
        case '\r' =>
          out.append("\\r")
        case '\t' =>
          out.append("\\t")
        case '\\' =>
          out.append("\\\\")
        case _ =>
          if (c < 32 || (c > 127 && c < 160) || c > UTF16CharacterSet.SURROGATE1_MIN) {
            out.append("\\u")
            val hex = new StringBuilder(Integer.toHexString(c).toUpperCase)
            while ( {
              hex.length < 4
            }) hex.insert(0, "0")
            out.append(hex.toString)
          }
          else out.cat(c)
      }
    }
    out.toString
  }

  trait Options {}

  class ExportOptions extends ExpressionPresenter.Options {
    var target = ""
    var targetVersion = 0
    var rootPackage = null
    var componentMap = null
    var packageMap = null
    var explaining = false
    var suppressStaticContext = false
    var addStaticType = false
  }

}


/**
 * Make an uncommitted ExpressionPresenter. This must be followed by a call on init()
 */
class ExpressionPresenter(){
  private var config = null
  private var receiver = null
  private var cco = null
  private var depth = 0
  private var inStartTag = false
  private var nextRole = null
  private val expressionStack = new util.Stack[Expression]
  private val nameStack = new util.Stack[String]
  private var namespaceMap = NamespaceMap.emptyMap
  private var defaultNamespace = null
  private var options = new ExpressionPresenter.ExportOptions
  private var relocatable = false

  /**
   * Make an ExpressionPresenter that writes indented output to the standard error output
   * destination of the Configuration
   *
   * @param config the Saxon configuration
   */
  def this(config: Configuration) {
    this(config, config.getLogger)
  }

  /**
   * Make an ExpressionPresenter that writes indented output to a specified output stream,
   * with checksumming
   *
   * @param config   the Saxon configuration
   * @param out      the output destination
   * @param checksum true if a checksum is to be written at the end of the file
   */
  def this(config: Configuration, out: StreamResult, checksum: Boolean) {
    this()
    init(config, out, checksum)
  }

  /**
   * Make an ExpressionPresenter that writes indented output to a specified output stream
   *
   * @param config the Saxon configuration
   * @param out    the output destination
   */
  def this(config: Configuration, out: StreamResult) {
    this(config, out, false)
  }

  def init(config: Configuration, out: StreamResult, checksum: Boolean) = {
    val props = ExpressionPresenter.makeDefaultProperties(config)
    if (config.getXMLVersion == Configuration.XML11) if ("JS" == getOptions.asInstanceOf[ExpressionPresenter.ExportOptions].target) config.getLogger.warning("For target=JS, the SEF file will use XML 1.0, which disallows control characters")
    else props.setProperty(OutputKeys.VERSION, "1.1")
    try {
      receiver = config.getSerializerFactory.getReceiver(out, props)
      receiver = new NamespaceReducer(receiver)
      if (checksum) receiver = new CheckSumFilter(receiver)
      cco = new ComplexContentOutputter(receiver)
    } catch {
      case err: XPathException =>
        err.printStackTrace()
        throw new InternalError(err.getMessage)
    }
    this.config = config
    try {
      cco.open()
      cco.startDocument(ReceiverOption.NONE)
    } catch {
      case err: XPathException =>
        err.printStackTrace()
        throw new InternalError(err.getMessage)
    }
  }

  def init(config: Configuration, out: Receiver, checksum: Boolean) = {
    receiver = out
    receiver = new NamespaceReducer(receiver)
    if (checksum) receiver = new CheckSumFilter(receiver)
    cco = new ComplexContentOutputter(receiver)
    this.config = config
    try {
      cco.open()
      cco.startDocument(ReceiverOption.NONE)
    } catch {
      case err: XPathException =>
        err.printStackTrace()
        throw new InternalError(err.getMessage)
    }
  }

  /**
   * Make an ExpressionPresenter that writes indented output to a specified output stream
   *
   * @param config the Saxon configuration
   * @param out    the output stream
   */
  def this(config: Configuration, out: Logger) {
    this(config, out.asStreamResult)
  }

  /**
   * Make an ExpressionPresenter for a given Configuration using a user-supplied Receiver
   * to accept the output
   *
   * @param config   the Configuration
   * @param receiver the user-supplied Receiver
   */
  def this(config: Configuration, receiver: Receiver) {
    this()
    this.config = config
    this.receiver = receiver
    this.cco = new ComplexContentOutputter(receiver)
    try {
      cco.open()
      cco.startDocument(ReceiverOption.NONE)
    } catch {
      case err: XPathException =>
        err.printStackTrace()
        throw new InternalError(err.getMessage)
    }
  }

  /**
   * Set the default namespace, used for subsequent calls on startElement.
   * Must be consistent throughout the whole document
   *
   * @param namespace the default namespace
   */
  def setDefaultNamespace(namespace: String) = {
    defaultNamespace = namespace
    namespaceMap = namespaceMap.put("", namespace)
  }

  /**
   * Set the options
   */
  def setOptions(options: ExpressionPresenter.Options) = this.options = options

  /**
   * Get the options
   *
   * @return the options, or null if none have been set
   */
  def getOptions = options

  /**
   * Ask whether the package can be deployed to a different location, with a different base URI
   *
   * @return if true then static-base-uri() represents the deployed location of the package,
   *         rather than its compile time location
   */
  def isRelocatable = relocatable

  /**
   * Say whether the package can be deployed to a different location, with a different base URI
   *
   * @param relocatable if true then static-base-uri() represents the deployed location of the package,
   *                    rather than its compile time location
   */
  def setRelocatable(relocatable: Boolean) = this.relocatable = relocatable

  /**
   * Start an element representing an expression in the expression tree
   *
   * @param name the name of the element
   * @param expr the expression represented
   * @return the depth of the tree before this element: for diagnostics, this can be compared
   *         with the value returned by endElement
   */
  def startElement(name: String, expr: Expression) = {
    val parent = if (expressionStack.isEmpty) null
    else expressionStack.peek
    expressionStack.push(expr)
    nameStack.push("*" + name)
    val n = _startElement(name)
    if (parent == null || (expr.getRetainedStaticContext ne parent.getRetainedStaticContext)) if (expr.getRetainedStaticContext == null) {
      //        throw new AssertionError("Export failure: no retained static context on " + expr.toShortString());
    }
    else emitRetainedStaticContext(expr.getRetainedStaticContext, if (parent == null) null
    else parent.getRetainedStaticContext)
    val mod = expr.getLocation.getSystemId
    if (mod != null && parent != null && (parent.getLocation.getSystemId == null || !(parent.getLocation.getSystemId == mod))) emitAttribute("module", truncatedModuleName(mod))
    val lineNr = expr.getLocation.getLineNumber
    if (parent == null || (parent.getLocation.getLineNumber != lineNr && lineNr != -1)) emitAttribute("line", lineNr + "")
    n
  }

  private def truncatedModuleName(module: String): String = if (!relocatable) module
  else { // If not exporting the base URI, cut the filename used for diagnostic location of errors down to its last component
    val parts = module.split("/")
    for (p <- parts.length - 1 to 0 by -1) {
      if (!parts(p).isEmpty) return parts(p)
    }
    module
  }

  def emitRetainedStaticContext(sc: RetainedStaticContext, parentSC: RetainedStaticContext) = try {
    if (!(options.asInstanceOf[ExpressionPresenter.ExportOptions]).suppressStaticContext && !relocatable && sc.getStaticBaseUri != null && (parentSC == null || !(sc.getStaticBaseUri == parentSC.getStaticBaseUri))) emitAttribute("baseUri", sc.getStaticBaseUriString)
    if (!(sc.getDefaultCollationName == NamespaceConstant.CODEPOINT_COLLATION_URI) && (parentSC == null || !(sc.getDefaultCollationName == parentSC.getDefaultCollationName))) emitAttribute("defaultCollation", sc.getDefaultCollationName)
    if (!sc.getDefaultElementNamespace.isEmpty && (parentSC == null || !(sc.getDefaultElementNamespace == parentSC.getDefaultElementNamespace))) emitAttribute("defaultElementNS", sc.getDefaultElementNamespace)
    if (!(NamespaceConstant.FN == sc.getDefaultFunctionNamespace)) emitAttribute("defaultFunctionNS", sc.getDefaultFunctionNamespace)
    if (!(options.asInstanceOf[ExpressionPresenter.ExportOptions]).suppressStaticContext && (parentSC == null || !sc.declaresSameNamespaces(parentSC))) {
      val fsb = new FastStringBuffer(FastStringBuffer.C256)
      val iter = sc.iteratePrefixes
      while ( {
        iter.hasNext
      }) {
        val p = iter.next
        var uri = sc.getURIForPrefix(p, true)
        fsb.append(p)
        fsb.append("=")
        if (Whitespace.containsWhitespace(uri)) throw new XPathException("Cannot export a stylesheet if namespaces contain whitespace: '" + uri + "'")
        if (uri == NamespaceConstant.getUriForConventionalPrefix(p)) uri = "~"
        fsb.append(uri)
        fsb.append(" ")
      }
      emitAttribute("ns", Whitespace.trim(fsb))
    }
  } catch {
    case e: XPathException =>
      throw new AssertionError(e)
  }

  /**
   * Start an element
   *
   * @param name the name of the element
   * @return the depth of the tree before this element: for diagnostics, this can be compared
   *         with the value returned by endElement
   */
  def startElement(name: String) = {
    nameStack.push(name)
    _startElement(name)
  }

  private def _startElement(name: String) = { //System.err.println("start " + name + " at " + new XPathException("").getStackTrace().length);
    try {
      if (inStartTag) {
        cco.startContent()
        inStartTag = false
      }
      var nodeName = null
      if (defaultNamespace == null) nodeName = new NoNamespaceName(name)
      else nodeName = new FingerprintedQName("", defaultNamespace, name)
      cco.startElement(nodeName, Untyped.getInstance, Loc.NONE, ReceiverOption.NONE)
      if (nextRole != null) {
        emitAttribute("role", nextRole)
        nextRole = null
      }
    } catch {
      case err: XPathException =>
        err.printStackTrace()
        throw new InternalError(err.getMessage)
    }
    inStartTag = true {
      depth += 1; depth - 1
    }
  }

  /**
   * Set the role of the next element to be output
   *
   * @param role the value of the role output to be used
   */
  def setChildRole(role: String) = nextRole = role

  /**
   * Output an attribute node
   *
   * @param name  the name of the attribute
   * @param value the value of the attribute
   */
  def emitAttribute(name: String, value: String) = if (value != null) {
    if (name == "module") value = truncatedModuleName(value)
    try cco.attribute(new NoNamespaceName(name), BuiltInAtomicType.UNTYPED_ATOMIC, value, Loc.NONE, ReceiverOption.NONE)
    catch {
      case err: XPathException =>
        err.printStackTrace()
        throw new InternalError(err.getMessage)
    }
  }

  /**
   * Output a QName-valued attribute node
   *
   * @param name  the name of the attribute
   * @param value the value of the attribute
   */
  def emitAttribute(name: String, value: StructuredQName) = {
    val attVal = value.getEQName
    try cco.attribute(new NoNamespaceName(name), BuiltInAtomicType.UNTYPED_ATOMIC, attVal, Loc.NONE, ReceiverOption.NONE)
    catch {
      case err: XPathException =>
        err.printStackTrace()
        throw new InternalError(err.getMessage)
    }
  }

  /**
   * Output a namespace declaration. All namespaces should be declared at the top level.
   *
   * @param prefix the namespace prefix
   * @param uri    the namespace URI
   */
  def namespace(prefix: String, uri: String) = try cco.namespace(prefix, uri, ReceiverOption.NONE)
  catch {
    case e: XPathException =>
      e.printStackTrace()
      throw new InternalError(e.getMessage)
  }

  /**
   * End an element in the expression tree
   *
   * @return the depth of the tree after ending this element. For diagnostics, this can be compared with the
   *         value returned by startElement()
   */
  def endElement = { //System.err.println("end at " + new XPathException("").getStackTrace().length);
    try {
      if (inStartTag) {
        cco.startContent()
        inStartTag = false
      }
      cco.endElement()
    } catch {
      case err: XPathException =>
        err.printStackTrace()
        throw new InternalError(err.getMessage)
    }
    val name = nameStack.pop
    if (name.startsWith("*")) expressionStack.pop {
      depth -= 1; depth
    }
  }

  /**
   * Start a child element in the output
   *
   * @param name the name of the child element
   */
  def startSubsidiaryElement(name: String) = startElement(name)

  /**
   * End a child element in the output
   */
  def endSubsidiaryElement() = endElement

  /**
   * Close the output
   */
  def close() = try {
    if (receiver.isInstanceOf[CheckSumFilter]) {
      val c = receiver.asInstanceOf[CheckSumFilter].getChecksum
      cco.processingInstruction(CheckSumFilter.SIGMA, Integer.toHexString(c), Loc.NONE, ReceiverOption.NONE)
    }
    cco.endDocument()
    cco.close()
  } catch {
    case err: XPathException =>
      err.printStackTrace()
      throw new InternalError(err.getMessage)
  }

  /**
   * Get the Saxon configuration
   *
   * @return the Saxon configuration
   */
  def getConfiguration = config

  /**
   * Get the name pool
   *
   * @return the name pool
   */
  def getNamePool = config.getNamePool

  /**
   * Get the type hierarchy cache
   *
   * @return the type hierarchy cache
   */
  def getTypeHierarchy = config.getTypeHierarchy
}