////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.model.SimpleType
import net.sf.saxon.s9api.Location
import net.sf.saxon.tree.jiter.MonoIterator
import java.util

/**
 * An implementation of AttributeMap for use when there is exactly one attribute
 */
object SingletonAttributeMap {
  def of(att: AttributeInfo) = if (att.isInstanceOf[SingletonAttributeMap]) att.asInstanceOf[SingletonAttributeMap]
  else new SingletonAttributeMap(att.getNodeName, att.getType, att.getValue, att.getLocation, att.getProperties)
}

class SingletonAttributeMap private(val nodeName: NodeName, val `type`: SimpleType, val value: String, val location: Location, val properties: Int) extends AttributeInfo(nodeName, `type`, value, location, properties) with AttributeMap {
  /**
   * Return the number of attributes in the map.
   *
   * @return The number of attributes in the map.
   */
  override def size = 1

  override def get(name: NodeName) = if (name == getNodeName) this
  else null

  override def get(uri: String, local: String) = if (getNodeName.getLocalPart == local && getNodeName.hasURI(uri)) this
  else null

  override def getByFingerprint(fingerprint: Int, namePool: NamePool) = if (getNodeName.obtainFingerprint(namePool) == fingerprint) this
  else null

  override def put(att: AttributeInfo) = if (getNodeName == att.getNodeName) SingletonAttributeMap.of(att)
  else {
    val list = new util.ArrayList[AttributeInfo](2)
    list.add(this)
    list.add(att)
    new SmallAttributeMap(list)
  }

  override def remove(name: NodeName) = if (name == getNodeName) EmptyAttributeMap.getInstance
  else this

  override def iterator = new MonoIterator[AttributeInfo](this)

  override def apply(mapper: Function[AttributeInfo, AttributeInfo]) = SingletonAttributeMap.of(mapper.apply(this))

  override def asList = {
    val list = new util.ArrayList[AttributeInfo](1)
    list.add(this)
    list
  }

  override def itemAt(index: Int) = if (index == 0) this
  else throw new IndexOutOfBoundsException(index + " of 1")
}