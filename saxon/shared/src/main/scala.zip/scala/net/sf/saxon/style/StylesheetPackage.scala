////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.PreparedStylesheet
import net.sf.saxon.expr.Component
import net.sf.saxon.expr.ComponentBinding
import net.sf.saxon.expr.PackageData
import net.sf.saxon.expr.instruct._
import net.sf.saxon.functions.ExecutableFunctionLibrary
import net.sf.saxon.functions.FunctionLibrary
import net.sf.saxon.functions.FunctionLibraryList
import net.sf.saxon.functions.registry.ConstructorFunctionLibrary
import net.sf.saxon.model.Affinity
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.om.Action
import net.sf.saxon.om.SpaceStrippingRule
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.pattern.NodeTest
import net.sf.saxon.query.XQueryFunctionLibrary
import net.sf.saxon.s9api.HostLanguage
import net.sf.saxon.serialize.CharacterMap
import net.sf.saxon.serialize.CharacterMapIndex
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans._
import net.sf.saxon.trans.rules.RuleManager
import net.sf.saxon.tree.util.FastStringBuffer
import java.util._
import net.sf.saxon.trans.Visibility.PRIVATE

/**
 * A (compiled) stylesheet package. This may be created either by compiling a source XSLT package,
 * or by loading a saved package from disk. It therefore has no references to source XSLT documents.
 */
object StylesheetPackage {
  private val TRACING = false
}

class StylesheetPackage(val config: Configuration)

/**
 * Create a stylesheet package
 *
 * @param config the Saxon Configuration
 */
  extends PackageData(config) {
  setHostLanguage(HostLanguage.XSLT)
  setAccumulatorRegistry(configuration.makeAccumulatorRegistry)
  private var packageVersion = null
  private var packageName = null
  private val usedPackages = new util.ArrayList[StylesheetPackage]
  private var xsltVersion = 0
  private var ruleManager = null
  private var characterMapIndex = null
  private var createsSecondaryResultDocuments = false
  private val completionActions = new util.ArrayList[Action]
  protected var globalContextRequirement = null
  private var containsGlobalContextItemDeclaration = false
  protected var stripperRules = null
  private var stripsWhitespace = false
  private var stripsTypeAnnotations = false
  protected var defaultOutputProperties = null
  private var defaultMode = null
  private var declaredModes = false
  protected var namedOutputProperties = new util.HashMap[StructuredQName, Properties](4)
  // table of imported schemas. The members of this set are strings holding the target namespace.
  protected var schemaIndex = new util.HashSet[String](10)
  private var functionLibrary = null
  private var queryFunctions = null
  private var overriding = null
  private var underriding = null
  private var maxFunctionArity = -1
  private var retainUnusedFunctions = false
  private var implicitPackage = false
  private val componentIndex = new util.HashMap[SymbolicName, Component](20)
  protected var hiddenComponents = new util.ArrayList[Component]
  protected var overriddenComponents = new util.HashMap[SymbolicName, Component]
  private val abstractComponents = new util.HashMap[SymbolicName, Component]

  /**
   * Get a map containing all the components in this package, indexed by symbolic name
   *
   * @return a map containing all the components in the package. This does not include components
   *         in used packages, except to the extent that they have been copied into this package.
   */
  def getComponentIndex = componentIndex

  /**
   * Get the packages referenced from this package in an xsl:use-package declaration
   *
   * @return the packages used by this package
   */
  def getUsedPackages = usedPackages

  /**
   * Add a package to the list of packages directly used by this one
   *
   * @param pack the used package
   */
  def addUsedPackage(pack: StylesheetPackage) = usedPackages.add(pack)

  /**
   * Ask whether a given library package is within the package subtree rooted at this package
   *
   * @param pack the library package
   * @return true if the given library package is in the transitive contents of this package
   */
  def contains(pack: StylesheetPackage): Boolean = {
    import scala.collection.JavaConversions._
    for (p <- usedPackages) {
      if ((p eq pack) || p.contains(pack)) return true
    }
    false
  }

  /**
   * Set the version of the XSLT language specification to which the package manifest conforms
   *
   * @param version the version (times ten) as an integer
   */
  def setVersion(version: Int) = this.xsltVersion = version

  /**
   * Set the name of the package
   *
   * @param packageName the name of the package. This is supposed to be an absolute URI, but Saxon accepts any string.
   */
  def setPackageName(packageName: String) = this.packageName = packageName

  /**
   * Get the version of the XSLT language specification to which the package manifest conforms
   *
   * @return the version of the xslPackage, times ten, as an integer
   */
  def getVersion = xsltVersion

  /**
   * Get the package-version identifier appearing on the xsl:package element
   *
   * @return the version identifier as a structured entity
   */
  def getPackageVersion = packageVersion

  /**
   * Set the package-version identifier appearing on the xsl:package element
   *
   * @param version the version identifier as a structured entity
   */
  def setPackageVersion(version: PackageVersion) = packageVersion = version

  /**
   * Get the name identifier of the xsl:package as an absolute URI
   *
   * @return a string value. This is supposed to be an absolute URI, but Saxon accepts any string.
   */
  def getPackageName = packageName

  /**
   * Ask if this is an implicit package (one rooted at xsl:stylesheet or xsl:transform rather than xsl:package
   *
   * @return true if this package was rooted at an xsl:stylesheet or xsl:transform element
   */
  def isImplicitPackage = implicitPackage

  /**
   * Say whether this is an implicit package (one rooted at xsl:stylesheet or xsl:transform rather than xsl:package
   *
   * @param implicitPackage true if this package was rooted at an xsl:stylesheet or xsl:transform element
   */
  def setImplicitPackage(implicitPackage: Boolean) = this.implicitPackage = implicitPackage

  /**
   * Ask whether the package was compiled with just-in-time compilation of template rules enabled
   *
   * @return false (always) for Saxon-HE
   */
  def isJustInTimeCompilation = false

  /**
   * Say whether the package was compiled with just-in-time compilation of template rules enabled.
   * This method is called by the compiler itself and should not be called by users. The setting is ignored
   * in Saxon-HE.
   *
   * @param justInTimeCompilation set to true if just-in-time compilation was enabled when the package was compiled
   */
  def setJustInTimeCompilation(justInTimeCompilation: Boolean) = {
    // no action
  }

  /**
   * Get the rule manager, which knows about all the modes present in the package
   *
   * @return the rule manager
   */
  def getRuleManager = ruleManager

  /**
   * Set the rule manager, which knows about all the modes present in the package
   *
   * @param ruleManager the rule manager
   */
  def setRuleManager(ruleManager: RuleManager) = this.ruleManager = ruleManager

  /**
   * Get the default mode for the package
   *
   * @return the default mode for the package as a whole (this may change for individual elements/subtrees within
   *         the package)
   */
  def getDefaultMode = defaultMode

  /**
   * Set the default mode for the package
   *
   * @param defaultMode the default mode for the package
   */
  def setDefaultMode(defaultMode: StructuredQName) = this.defaultMode = defaultMode

  /**
   * Say whether it is required that modes be explicitly declared
   *
   * @param declared true if modes referenced within this package must be explicitly declared
   */
  def setDeclaredModes(declared: Boolean) = declaredModes = declared

  /**
   * Ask whether it is required that modes be explicitly declared
   *
   * @return true if modes referenced within this package must be explicitly declared
   */
  def isDeclaredModes = declaredModes

  /**
   * Get the whitespace stripping rules for this package
   *
   * @return the whitespace stripping rules (based on xsl:strip-space and xsl:preserve-space)
   */
  def getSpaceStrippingRule = stripperRules

  /**
   * Get the index of named character maps defined in this package
   *
   * @return the index of character maps
   */
  def getCharacterMapIndex = characterMapIndex

  /**
   * Set the index of named character maps defined in this package
   *
   * @param characterMapIndex the index of named character maps
   */
  def setCharacterMapIndex(characterMapIndex: CharacterMapIndex) = this.characterMapIndex = characterMapIndex

  /**
   * Ask whether the package contains an xsl:result-document instruction
   *
   * @return true if the package contains an xsl:result-document instruction
   */
  def isCreatesSecondaryResultDocuments = createsSecondaryResultDocuments

  /**
   * Say whether the package contains an xsl:result-document instruction
   *
   * @param createsSecondaryResultDocuments true if the package contains an xsl:result-document instruction
   */
  def setCreatesSecondaryResultDocuments(createsSecondaryResultDocuments: Boolean) = this.createsSecondaryResultDocuments = createsSecondaryResultDocuments

  /**
   * Ask whether the package defines that type annotations should be stripped from input
   * documents loaded from within this package
   *
   * @return true if documents loaded by this package should have any type annotations stripped.
   */
  def isStripsTypeAnnotations = stripsTypeAnnotations

  /**
   * Say whether the package defines that type annotations should be stripped from input
   * documents loaded from within this package
   *
   * @param stripsTypeAnnotations set to true if documents loaded by this package
   *                              should have any type annotations stripped.
   */
  def setStripsTypeAnnotations(stripsTypeAnnotations: Boolean) = this.stripsTypeAnnotations = stripsTypeAnnotations

  /**
   * Get the whitespace stripping rules for source documents loaded from within this package
   *
   * @return the whitespace stripping rules for this package
   */
  def getStripperRules = stripperRules

  /**
   * Set the whitespace stripping rules for source documents loaded from within this package
   *
   * @param stripperRules the whitespace stripping rules for this package
   */
  def setStripperRules(stripperRules: SpaceStrippingRule) = this.stripperRules = stripperRules

  /**
   * Set the default (unnamed) serialization properties to be used for documents output
   * using xsl:result-document instructions within this package
   *
   * @param props the default serialization properties for this package
   */
  def setDefaultOutputProperties(props: Properties) = defaultOutputProperties = props

  /**
   * Define a named set serialization properties to be used for documents output
   * using xsl:result-document instructions within this package
   *
   * @param name  the name of the serialization property set
   * @param props the serialization properties
   */
  def setNamedOutputProperties(name: StructuredQName, props: Properties) = namedOutputProperties.put(name, props)

  /**
   * Get a set of named output properties
   *
   * @param name the output declaration name
   * @return the corresponding properties; or null if the name is unknown
   */
  def getNamedOutputProperties(name: StructuredQName) = namedOutputProperties.get(name)

  /**
   * Get the set of namespaces of schema declarations imported into this package
   *
   * @return the set of imported namespaces
   */
  def getSchemaNamespaces = schemaIndex

  /**
   * Set the required context item type. Used when there is an xsl:global-context-item child element
   *
   * @param requirement details of the requirement for the global context item
   */
  @throws[XPathException]
  def setContextItemRequirements(requirement: GlobalContextRequirement) = {
    if (containsGlobalContextItemDeclaration) { // the new requirements must be consistent with the existing requirements
      if ((!requirement.isAbsentFocus && globalContextRequirement.isAbsentFocus) || (requirement.isMayBeOmitted && !globalContextRequirement.isMayBeOmitted)) throw new XPathException("The package contains two xsl:global-context-item declarations with conflicting @use attributes", "XTSE3087")
      val th = getConfiguration.getTypeHierarchy
      if (th.relationship(requirement.getRequiredItemType, globalContextRequirement.getRequiredItemType) ne Affinity.SAME_TYPE) throw new XPathException("The package contains two xsl:global-context-item declarations with conflicting item types", "XTSE3087")
    }
    containsGlobalContextItemDeclaration = true
    globalContextRequirement = requirement
  }

  /**
   * Get the required context item type and other details of the global context item.
   * Used when there is an xsl:global-context-item child element
   *
   * @return details of the requirement for the global context item
   */
  def getContextItemRequirements = globalContextRequirement

  /**
   * Say whether there is an xsl:strip-space declaration in the stylesheet package
   *
   * @param strips true if an xsl:strip-space declaration has been found
   */
  def setStripsWhitespace(strips: Boolean) = this.stripsWhitespace = strips

  /**
   * Ask whether there is an xsl:strip-space declaration in the stylesheet package
   *
   * @return true if an xsl:strip-space declaration has been found
   */
  def isStripsWhitespace = this.stripsWhitespace

  /**
   * Register a callback action to be performed during the completion phase of building the package
   *
   * @param action the callback action
   */
  def addCompletionAction(action: Action) = completionActions.add(action)

  /**
   * Perform all registered completion actions for the package
   *
   * @throws XPathException if any of these completion actions fails
   */
  @throws[XPathException]
  protected def complete() = { // Perform the completion actions
    import scala.collection.JavaConversions._
    for (a <- completionActions) {
      a.doAction()
    }
    allocateBinderySlots()
  }

  /**
   * Allocate slots to global variables. Slot numbers are unique within a package
   */
  def allocateBinderySlots() = {
    val slotManager = getConfiguration.makeSlotManager
    import scala.collection.JavaConversions._
    for (c <- componentIndex.values) {
      registerGlobalVariable(c, slotManager)
    }
    import scala.collection.JavaConversions._
    for (c <- hiddenComponents) {
      registerGlobalVariable(c, slotManager)
    }
    setGlobalSlotManager(slotManager)
  }

  /**
   * Register a global variable declared within this package, allocating it a slot
   * number within the Bindery
   *
   * @param c           the component representing a global variable; it may also be another
   *                    kind of component, but in this case it is ignored
   * @param slotManager the SlotManager defining the allocation of variables to
   *                    slots in the Bindery
   */
  private def registerGlobalVariable(c: Component, slotManager: SlotManager) = if (c.getActor.isInstanceOf[GlobalVariable]) {
    val `var` = c.getActor.asInstanceOf[GlobalVariable]
    val slot = slotManager.allocateSlotNumber(`var`.getVariableQName)
    `var`.setPackageData(this)
    `var`.setBinderySlotNumber(slot)
    if (c.getVisibility ne Visibility.HIDDEN) addGlobalVariable(`var`)
  }

  /**
   * Add a component to the package
   *
   * @param component the component to be added
   */
  def addComponent(component: Component) = {
    val name = component.getActor.getSymbolicName
    componentIndex.put(name, component)
    if ((component.getVisibility eq Visibility.ABSTRACT) && (component.getContainingPackage eq this)) abstractComponents.put(component.getActor.getSymbolicName, component)
  }

  override def addGlobalVariable(variable: GlobalVariable) = {
    super.addGlobalVariable(variable)
    val name = variable.getSymbolicName
    if (componentIndex.get(name) == null) {
      var comp = variable.getDeclaringComponent
      if (comp == null) comp = variable.makeDeclaringComponent(PRIVATE, this)
      addComponent(comp)
    }
  }

  /**
   * Get the maximum arity of functions in this package
   *
   * @return the maximum arity
   */
  def getMaxFunctionArity = {
    if (maxFunctionArity == -1) {
      import scala.collection.JavaConversions._
      for (c <- componentIndex.values) {
        if (c.getActor.isInstanceOf[UserFunction]) if (c.getActor.asInstanceOf[UserFunction].getArity > maxFunctionArity) maxFunctionArity = c.getActor.asInstanceOf[UserFunction].getArity
      }
    }
    maxFunctionArity
  }

  /**
   * Get the component within this package having a given symbolic name
   *
   * @param name the symbolic name of the required component
   * @return the requested component, or null if it does not exist in the package
   */
  def getComponent(name: SymbolicName) = componentIndex.get(name)

  def addHiddenComponent(component: Component) = hiddenComponents.add(component)

  /**
   * If this component overrides a component named N, get the component that N overrides (that
   * is, the component identified by xsl:original appearing within the overriding declaration of N)
   *
   * @param name the name N
   * @return if there is an overriding declaration of N, then the original declaration of N from the
   *         used package; otherwise null
   */
  def getOverriddenComponent(name: SymbolicName) = overriddenComponents.get(name)

  def addOverriddenComponent(comp: Component) = overriddenComponents.put(comp.getActor.getSymbolicName, comp)

  /**
   * Add modified copies of components from a package that is referenced from this one in an xsl:use-package declaration
   *
   * @param usedPackage the used package
   * @param acceptors   abstraction of a list of xsl:accept declarations, which can modify the visibility of accepted components
   * @param overrides   the set of names of components from the used package that are overridden in the using package
   * @throws XPathException if duplicate components are found
   */
  @throws[XPathException]
  def addComponentsFromUsedPackage(usedPackage: StylesheetPackage, acceptors: util.List[XSLAccept], overrides: util.Set[SymbolicName]) = {
    usedPackages.add(usedPackage)
    trace("=== Adding components from " + usedPackage.getPackageName + " to " + getPackageName + " ===")
    // Create copies of the components in the used package, with suitably adjusted visibility
    // Create a mapping from components in the used package to their corresponding components
    // in the using package, so that we can re-bind the component bindings
    val correspondence = new util.HashMap[Component, Component]
    import scala.collection.JavaConversions._
    for (namedComponentEntry <- usedPackage.componentIndex.entrySet) {
      val name = namedComponentEntry.getKey
      val oldC = namedComponentEntry.getValue
      val oldV = oldC.getVisibility
      var newV = null
      if (overrides.contains(name) && !oldC.getActor.isInstanceOf[Mode]) newV = Visibility.HIDDEN
      else {
        var acceptedVisibility = explicitAcceptedVisibility(name, acceptors)
        if (acceptedVisibility != null) {
          if (!XSLAccept.isCompatible(oldV, acceptedVisibility)) throw new XPathException("Cannot accept a " + oldV.show + " component (" + name + ") from package " + usedPackage.getPackageName + " with visibility " + acceptedVisibility.show, "XTSE3040")
          newV = acceptedVisibility
        }
        else {
          acceptedVisibility = wildcardAcceptedVisibility(name, acceptors)
          if (acceptedVisibility != null) if (XSLAccept.isCompatible(oldV, acceptedVisibility)) newV = acceptedVisibility
        }
        if (newV == null) if ((oldV eq Visibility.PUBLIC) || (oldV eq Visibility.FINAL)) newV = Visibility.PRIVATE
        else newV = Visibility.HIDDEN
      }
      trace(oldC.getActor.getSymbolicName + " (" + oldV.show + ") becomes " + newV.show)
      val newC = Component.makeComponent(oldC.getActor, newV, VisibilityProvenance.DERIVED, this, oldC.getDeclaringPackage)
      correspondence.put(oldC, newC)
      newC.setBaseComponent(oldC)
      if (overrides.contains(name)) { // Note: overrides is all the overrides, not only those for this xsl:use-package;
        // but we have already checked that xsl:override declarations match something in the
        // right package.
        overriddenComponents.put(name, newC)
        if (newV ne Visibility.ABSTRACT) abstractComponents.remove(name)
      }
      if (newC.getVisibility eq Visibility.HIDDEN) hiddenComponents.add(newC)
      else if (componentIndex.get(name) != null) if (!oldC.getActor.isInstanceOf[Mode]) throw new XPathException("Duplicate " + namedComponentEntry.getKey, "XTSE3050", oldC.getActor)
      else {
        componentIndex.put(name, newC)
        if (oldC.getActor.isInstanceOf[Mode] && ((oldV eq Visibility.PUBLIC) || (oldV eq Visibility.FINAL))) {
          val existing = getRuleManager.obtainMode(name.getComponentName, false)
          if (existing != null) throw new XPathException("Duplicate " + namedComponentEntry.getKey, "XTSE3050", oldC.getActor)
          else {
            //getRuleManager().registerMode((Mode)oldC.getCode());
          }
        }
      }
      if (newC.getActor.isInstanceOf[Mode] && overrides.contains(name)) addCompletionAction(() => {
        def foo() = {
          trace("Doing mode completion for " + newC.getActor.getSymbolicName)
          val oldBindings = newC.getBaseComponent.getComponentBindings
          val newBindings = newC.getComponentBindings
          for (i <- 0 until oldBindings.size) {
            val name12 = oldBindings.get(i).getSymbolicName
            var target = null
            if (overrides.contains(name12)) { // if there is an override in this package, we bind to it
              target = getComponent(name12)
              if (target == null) throw new AssertionError("We know there's an override for " + name12 + ", but we can't find it")
            }
            else { // otherwise we bind to the component in this package that corresponds to the component in the used package
              target = correspondence.get(oldBindings.get(i).getTarget)
              if (target == null) throw new AssertionError("Saxon can't find the new component corresponding to " + name12)
            }
            val newBinding = new ComponentBinding(name12, target)
            newBindings.set(i, newBinding)
          }
        }

        foo()
      })
      else addCompletionAction(() => {
        def foo() = {
          trace("Doing normal completion for " + newC.getActor.getSymbolicName)
          val oldBindings = newC.getBaseComponent.getComponentBindings
          val newBindings = new util.ArrayList[ComponentBinding](oldBindings.size)
          makeNewComponentBindings(overrides, correspondence, oldBindings, newBindings)
          newC.setComponentBindings(newBindings)
        }

        foo()
      })
    }
    import scala.collection.JavaConversions._
    for (oldC <- usedPackage.hiddenComponents) {
      trace(oldC.getActor.getSymbolicName + " (HIDDEN, declared in " + oldC.getDeclaringPackage.getPackageName + ") becomes HIDDEN")
      val newC = Component.makeComponent(oldC.getActor, Visibility.HIDDEN, VisibilityProvenance.DERIVED, this, oldC.getDeclaringPackage)
      correspondence.put(oldC, newC)
      newC.setBaseComponent(oldC)
      hiddenComponents.add(newC)
      addCompletionAction(() => {
        def foo() = {
          val oldBindings = newC.getBaseComponent.getComponentBindings
          val newBindings = new util.ArrayList[ComponentBinding](oldBindings.size)
          makeNewComponentBindings(overrides, correspondence, oldBindings, newBindings)
          newC.setComponentBindings(newBindings)
        }

        foo()
      })
    }
    if (usedPackage.isCreatesSecondaryResultDocuments) setCreatesSecondaryResultDocuments(true)
  }

  private def makeNewComponentBindings(overrides: util.Set[SymbolicName], correspondence: util.Map[Component, Component], oldBindings: util.List[ComponentBinding], newBindings: util.List[ComponentBinding]) = {
    import scala.collection.JavaConversions._
    for (oldBinding <- oldBindings) {
      val name = oldBinding.getSymbolicName
      var target = null
      if (overrides.contains(name)) {
        target = getComponent(name)
        if (target == null) throw new AssertionError("We know there's an override for " + name + ", but we can't find it")
      }
      else {
        target = correspondence.get(oldBinding.getTarget)
        if (target == null) throw new AssertionError("Saxon can't find the new component corresponding to " + name)
      }
      val newBinding = new ComponentBinding(name, target)
      newBindings.add(newBinding)
    }
  }

  private def trace(message: String) = if (StylesheetPackage.TRACING) System.err.println(message)

  @throws[XPathException]
  private def explicitAcceptedVisibility(name: SymbolicName, acceptors: util.List[XSLAccept]): Visibility = {
    import scala.collection.JavaConversions._
    for (acceptor <- acceptors) {
      import scala.collection.JavaConversions._
      for (test <- acceptor.getExplicitComponentTests) {
        if (test.matches(name)) return acceptor.getVisibility
      }
    }
    null
  }

  @throws[XPathException]
  private def wildcardAcceptedVisibility(name: SymbolicName, acceptors: util.List[XSLAccept]): Visibility = { // Note: last one wins
    var vis = null
    import scala.collection.JavaConversions._
    for (acceptor <- acceptors) {
      import scala.collection.JavaConversions._
      for (test <- acceptor.getWildcardComponentTests) {
        if (test.getQNameTest.asInstanceOf[NodeTest].getDefaultPriority == -0.25 && test.matches(name)) vis = acceptor.getVisibility
      }
    }
    if (vis != null) return vis
    import scala.collection.JavaConversions._
    for (acceptor <- acceptors) {
      import scala.collection.JavaConversions._
      for (test <- acceptor.getWildcardComponentTests) {
        if (test.matches(name)) vis = acceptor.getVisibility
      }
    }
    vis
  }

  /**
   * Create the function library containing stylesheet functions declared in this package
   */
  def createFunctionLibrary() = {
    val functionLibrary = new FunctionLibraryList
    val includeHOF = !("HE" == getTargetEdition || "JS" == getTargetEdition)
    functionLibrary.addFunctionLibrary(if (includeHOF) config.getXSLT30FunctionSet
    else new Configuration().getXSLT30FunctionSet)
    functionLibrary.addFunctionLibrary(new StylesheetFunctionLibrary(this, true))
    functionLibrary.addFunctionLibrary(config.getBuiltInExtensionLibraryList)
    functionLibrary.addFunctionLibrary(new ConstructorFunctionLibrary(config))
    if ("JS" == getTargetEdition) addIxslFunctionLibrary(functionLibrary)
    queryFunctions = new XQueryFunctionLibrary(config)
    functionLibrary.addFunctionLibrary(queryFunctions)
    functionLibrary.addFunctionLibrary(config.getIntegratedFunctionLibrary)
    config.addExtensionBinders(functionLibrary)
    functionLibrary.addFunctionLibrary(new StylesheetFunctionLibrary(this, false))
    this.functionLibrary = functionLibrary
  }

  protected def addIxslFunctionLibrary(functionLibrary: FunctionLibraryList) = {
  }

  /**
   * Get the function library.
   *
   * @return the function library
   */
  def getFunctionLibrary = functionLibrary

  /**
   * Get the library of functions exposed by this stylesheet package, that
   * is, functions whose visibility is public or final
   */
  def getPublicFunctions = new PublicStylesheetFunctionLibrary(functionLibrary)

  /**
   * Get the library of functions imported from XQuery
   *
   * @return the XQuery function library
   */
  def getXQueryFunctionLibrary = queryFunctions

  /**
   * Set details of functions available for calling anywhere in this package. This is the
   * function library used for resolving run-time references to functions, for example
   * from xsl:evaluate, function-available(), or function-lookup().
   *
   * @param overriding  library of stylesheet functions declared with override=yes
   * @param underriding library of stylesheet functions declared with override=no
   */
  def setFunctionLibraryDetails(library: FunctionLibraryList, overriding: ExecutableFunctionLibrary, underriding: ExecutableFunctionLibrary) = {
    if (library != null) this.functionLibrary = library
    this.overriding = overriding
    this.underriding = underriding
  }

  /**
   * Get the function with a given name and arity
   *
   * @param name the symbolic name of the function (QName plus arity)
   * @return the requested function, or null if none can be found
   */
  protected def getFunction(name: SymbolicName.F): UserFunction = if (name.getArity == -1) { // supports the single-argument function-available() function
    val maximumArity = 20
    for (a <- 0 until maximumArity) {
      val sn = new SymbolicName.F(name.getComponentName, a)
      val uf = getFunction(sn)
      if (uf != null) {
        uf.incrementReferenceCount()
        return uf
      }
    }
    null
  }
  else {
    val component = getComponentIndex.get(name)
    if (component != null) {
      val uf = component.getActor.asInstanceOf[UserFunction]
      uf.incrementReferenceCount()
      uf
    }
    else null
  }

  /**
   * Ask whether private functions for which there are no static references need to be
   * retained
   *
   * @return true if such functions need to be retained, typically because the stylesheet
   *         package uses xsl:evaluate or fn:function-lookup
   */
  def isRetainUnusedFunctions = retainUnusedFunctions

  /**
   * Say that private functions need to be retained, typically because the stylesheet
   * package uses xsl:evaluate or fn:function-lookup
   */
  def setRetainUnusedFunctions() = this.retainUnusedFunctions = true

  /**
   * Copy information from this package to the PreparedStylesheet.
   *
   * @param pss the PreparedStylesheet to be updated
   * @throws net.sf.saxon.trans.XPathException if the PreparedStylesheet cannot be updated
   */
  @throws[XPathException]
  def updatePreparedStylesheet(pss: PreparedStylesheet) = {
    import scala.collection.JavaConversions._
    for (entry <- componentIndex.entrySet) {
      if (entry.getValue.getVisibility eq Visibility.ABSTRACT) abstractComponents.put(entry.getKey, entry.getValue)
    }
    pss.setTopLevelPackage(this)
    if (isSchemaAware || !schemaIndex.isEmpty) pss.setSchemaAware(true)
    pss.setHostLanguage(HostLanguage.XSLT)
    //pss.setStylesheetFunctionLibrary(stylesheetFunctionLibrary);
    val libraryList = new FunctionLibraryList
    import scala.collection.JavaConversions._
    for (lib <- functionLibrary.getLibraryList) {
      if (lib.isInstanceOf[StylesheetFunctionLibrary]) if (lib.asInstanceOf[StylesheetFunctionLibrary].isOverrideExtensionFunction) {
        libraryList.addFunctionLibrary(overriding)
        //pss.getStylesheetFunctions().addFunctionLibrary(overriding);
      }
      else {
        libraryList.addFunctionLibrary(underriding)
        //pss.getStylesheetFunctions().addFunctionLibrary(underriding);
      }
      else libraryList.addFunctionLibrary(lib)
    }
    pss.setFunctionLibrary(libraryList)
    if (!pss.createsSecondaryResult) pss.setCreatesSecondaryResult(mayCreateSecondaryResultDocuments)
    pss.setDefaultOutputProperties(defaultOutputProperties)
    import scala.collection.JavaConversions._
    for (entry <- namedOutputProperties.entrySet) {
      pss.setOutputProperties(entry.getKey, entry.getValue)
    }
    // Build the index of named character maps
    if (characterMapIndex != null) {
      import scala.collection.JavaConversions._
      for (cm <- characterMapIndex) {
        pss.getCharacterMapIndex.putCharacterMap(cm.getName, cm)
      }
    }
    // Finish off the lists of template rules
    //        ruleManager.checkConsistency();
    //        ruleManager.computeRankings();
    //        ruleManager.invertStreamableTemplates();
    //        if (config.obtainOptimizer().isOptionSet(OptimizerOptions.RULE_SET)) {
    //            ruleManager.optimizeRules();
    //        }
    pss.setRuleManager(ruleManager)
    // Add named templates to the prepared stylesheet
    import scala.collection.JavaConversions._
    for (comp <- componentIndex.values) {
      if (comp.getActor.isInstanceOf[NamedTemplate]) {
        val t = comp.getActor.asInstanceOf[NamedTemplate]
        pss.putNamedTemplate(t.getTemplateName, t)
      }
    }
    // Share the component index with the prepared stylesheet
    pss.setComponentIndex(componentIndex)
    // Register stylesheet parameters
    import scala.collection.JavaConversions._
    for (comp <- componentIndex.values) {
      if (comp.getActor.isInstanceOf[GlobalParam]) {
        val gv = comp.getActor.asInstanceOf[GlobalParam]
        pss.registerGlobalParameter(gv)
      }
    }
    // Set the requirements for the global context item
    if (globalContextRequirement != null) pss.setGlobalContextRequirement(globalContextRequirement)
  }

  private def mayCreateSecondaryResultDocuments: Boolean = {
    if (createsSecondaryResultDocuments) return true
    import scala.collection.JavaConversions._
    for (p <- usedPackages) {
      if (p.mayCreateSecondaryResultDocuments) return true
    }
    false
  }

  def getAbstractComponents = abstractComponents

  /**
   * Output the abstract expression tree to the supplied destination.
   *
   * @param presenter the expression presenter used to display the structure
   */
  @throws[XPathException]
  def `export`(presenter: ExpressionPresenter) = throw new XPathException("Exporting a stylesheet requires Saxon-EE")

  @throws[XPathException]
  def checkForAbstractComponents() = {
    import scala.collection.JavaConversions._
    for (entry <- componentIndex.entrySet) {
      if ((entry.getValue.getVisibility eq Visibility.ABSTRACT) && (entry.getValue.getContainingPackage eq this)) abstractComponents.put(entry.getKey, entry.getValue)
    }
    if (!abstractComponents.isEmpty) {
      val buff = new FastStringBuffer(256)
      var count = 0
      import scala.collection.JavaConversions._
      for (name <- abstractComponents.keySet) {
        if ( {
          count += 1; count - 1
        } > 0) buff.append(", ")
        buff.append(name.toString)
        if (buff.length > 300) {
          buff.append(" ...")
          break //todo: break is not supported
        }
      }
      throw new XPathException("The package is not executable, because it contains abstract components: " + buff, "XTSE3080")
    }
  }

  /**
   * Ask whether a non-streamable construct has been found, forcing the entire stylesheet
   * to fall back to unstreamed processing
   *
   * @return true if the stylesheet must fall back to unstreamed processing
   */
  def isFallbackToNonStreaming = true

  def setFallbackToNonStreaming() = {
    // No action except in EE
  }
}