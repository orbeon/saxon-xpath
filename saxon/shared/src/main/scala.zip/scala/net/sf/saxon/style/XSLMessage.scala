////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.Message
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * An xsl:message element in the stylesheet. <br>
 */
final class XSLMessage extends StyleElement {
  private var terminate = null
  private var select = null
  private var errorCode = null
  private var timer = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var terminateAtt = null
    var selectAtt = null
    var errorCodeAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val value = att.getValue
      val attName = att.getNodeName
      val f = attName.getDisplayName
      f match {
        case "terminate" =>
          terminateAtt = Whitespace.trim(value)
          terminate = makeAttributeValueTemplate(terminateAtt, att)
        case "select" =>
          selectAtt = value
          select = makeExpression(selectAtt, att)
        case "error-code" =>
          errorCodeAtt = value
          errorCode = makeAttributeValueTemplate(errorCodeAtt, att)
        case _ =>
          if (attName.hasURI(NamespaceConstant.SAXON) && attName.getLocalPart == "time") {
            isExtensionAttributeAllowed(attName.getDisplayName)
            val timed = processBooleanAttribute("saxon:time", value)
            if (timed) timer = makeExpression("format-dateTime(Q{http://saxon.sf.net/}timestamp(),'[Y0001]-[M01]-[D01]T[H01]:[m01]:[s01].[f,3-3] - ')", att)
          }
          else checkUnknownAttribute(attName)
      }
    }
    if (terminateAtt == null) {
      terminateAtt = "no"
      terminate = makeAttributeValueTemplate(terminateAtt, null)
    }
    checkAttributeValue("terminate", terminateAtt, true, StyleElement.YES_NO)
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    select = typeCheck("select", select)
    terminate = typeCheck("terminate", terminate)
    if (errorCode == null) errorCode = new StringLiteral("Q{http://www.w3.org/2005/xqt-errors}XTMM9000")
    else errorCode = typeCheck("error-code", errorCode)
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val b = compileSequenceConstructor(exec, decl, true)
    if (b != null) if (select == null) select = b
    else {
      select = Block.makeBlock(select, b)
      select.setLocation(allocateLocation)
    }
    if (timer != null) select = Block.makeBlock(timer, select)
    if (select == null) select = new StringLiteral("xsl:message (no content)")
    if (errorCode.isInstanceOf[StringLiteral]) { // resolve any QName prefix now
      val code = errorCode.asInstanceOf[StringLiteral].getStringValue
      if (code.contains(":") && !code.startsWith("Q{")) {
        val name = makeQName(code, null, "error-code")
        errorCode = new StringLiteral(name.getEQName)
      }
    }
    val m = new Message(select, terminate, errorCode)
    m.setRetainedStaticContext(makeRetainedStaticContext)
    m
  }
}