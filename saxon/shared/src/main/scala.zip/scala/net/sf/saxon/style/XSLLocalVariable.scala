////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import java.util

/**
 * Handler for xsl:variable elements acting as local variable declarations in a stylesheet. <br>
 * The xsl:variable element has mandatory attribute name and optional attribute select
 */
object XSLLocalVariable {
  private val permittedAttributes = util.EnumSet.of(SourceBinding.BindingProperty.SELECT, SourceBinding.BindingProperty.AS)
}

class XSLLocalVariable extends XSLGeneralVariable {
  /**
   * Ask whether this element contains a binding for a variable with a given name; and if it does,
   * return the source binding information
   *
   * @param name the variable name
   * @return the binding information if this element binds a variable of this name; otherwise null
   */
    override def getBindingInformation(name: StructuredQName) = if (name == sourceBinding.getVariableQName) sourceBinding
    else null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction (well, it can be, anyway)
   */
  override def isInstruction = true

  override def prepareAttributes() = sourceBinding.prepareAttributes(XSLLocalVariable.permittedAttributes)

  /**
   * Get the static type of the variable. This is the declared type, unless the value
   * is statically known and constant, in which case it is the actual type of the value.
   */
  def getRequiredType = sourceBinding.getInferredType(true)

  @throws[XPathException]
  override def fixupReferences() = {
    sourceBinding.fixupReferences(null)
    super.fixupReferences()
  }

  /**
   * Process this local variable declaration by expanding any sequence constructor and setting
   * the select expression to the result
   *
   * @param exec the executable
   * @param decl the declaration being compiled
   * @throws XPathException if an error occurs
   */
  @throws[XPathException]
  def compileLocalVariable(exec: Compilation, decl: ComponentDeclaration) = { //if (!sourceBinding.getReferences().isEmpty()) {
    sourceBinding.handleSequenceConstructor(exec, decl)
    //}
  }
}