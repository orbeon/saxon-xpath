////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.NamespaceConstructor
import net.sf.saxon.model.Type
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.StringValue

/**
 * An xsl:namespace element in the stylesheet. (XSLT 2.0)
 */
class XSLNamespace extends XSLLeafNodeConstructor {
  /*@Nullable*/ private[style] var name = null

  override def prepareAttributes() = name = prepareAttributesNameAndSelect

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    name = typeCheck("name", name)
    select = typeCheck("select", select)
    var countChildren = 0
    var firstChild = null
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLFallback]) continue //todo: continue is not supported
      if (select != null) {
        val errorCode = getErrorCodeForSelectPlusContent
        compileError("An " + getDisplayName + " element with a select attribute must be empty", errorCode)
      }
      countChildren += 1
      if (firstChild == null) firstChild = child
      else break //todo: break is not supported
    }
    if (select == null) if (countChildren == 0) { // there are no child nodes and no select attribute
      select = new StringLiteral(StringValue.EMPTY_STRING)
      select.setRetainedStaticContext(makeRetainedStaticContext)
    }
    else if (countChildren == 1) { // there is exactly one child node
      if (firstChild.getNodeKind == Type.TEXT) { // it is a text node: optimize for this case
        select = new StringLiteral(firstChild.getStringValueCS)
        select.setRetainedStaticContext(makeRetainedStaticContext)
      }
    }
  }

  /**
   * Get the error code to be returned when the element has a select attribute but is not empty.
   *
   * @return the error code defined for this condition, for this particular instruction
   */
  override protected def getErrorCodeForSelectPlusContent = "XTSE0910"

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val inst = new NamespaceConstructor(name)
    compileContent(exec, decl, inst, new StringLiteral(StringValue.SINGLE_SPACE))
    inst
  }
}