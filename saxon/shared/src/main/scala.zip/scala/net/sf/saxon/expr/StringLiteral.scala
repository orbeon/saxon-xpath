////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.value.StringValue

/**
 * Subclass of Literal used specifically for string literals, as this is a common case
 */
class StringLiteral(val value: StringValue)

/**
 * Create a StringLiteral that wraps a StringValue
 *
 * @param value the StringValue
 */
  extends Literal(value.asInstanceOf[GroundedValue]) {
  /**
   * Create a StringLiteral that wraps any CharSequence (including, of course, a String)
   *
   * @param value the CharSequence to be wrapped
   */
  def this(value: CharSequence) {
    this(StringValue.makeStringValue(value))
  }

  /**
   * Get the value represented by this Literal
   *
   * @return the constant value
   */
  override def getValue = super.getValue.asInstanceOf[StringValue]

  /**
   * Get the string represented by this StringLiteral
   *
   * @return the underlying string
   */
  def getStringValue = { //noinspection RedundantCast
    getValue.asInstanceOf[StringValue].getStringValue
  }

  /*@NotNull*/ override def copy(rebindings: RebindingMap) = {
    val stringLiteral = new StringLiteral(getValue)
    ExpressionTool.copyLocationInfo(this, stringLiteral)
    stringLiteral
  }
}