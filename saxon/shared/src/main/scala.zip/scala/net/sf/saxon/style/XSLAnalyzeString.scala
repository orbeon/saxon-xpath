////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.AnalyzeString
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.regex.RegularExpression
import net.sf.saxon.trans.XPathException
import java.util

/**
 * An xsl:analyze-string elements in the stylesheet. New at XSLT 2.0<BR>
 */
class XSLAnalyzeString extends StyleElement {
  /*@Nullable*/ private var select = null
  private var regex = null
  private var flags = null
  private var matching = null
  private var nonMatching = null
  private var pattern = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain an xsl:fallback
   * instruction
   */
  override def mayContainFallback = true

  override def prepareAttributes() = {
    var selectAtt = null
    var regexAtt = null
    var flagsAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "regex" =>
          regexAtt = value
          regex = makeAttributeValueTemplate(regexAtt, att)
        case "select" =>
          selectAtt = value
          select = makeExpression(selectAtt, att)
        case "flags" =>
          flagsAtt = value // not trimmed, see bugzilla 4315
          flags = makeAttributeValueTemplate(flagsAtt, att)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (selectAtt == null) {
      reportAbsence("select")
      select = makeExpression(".", null) // for error recovery
    }
    if (regexAtt == null) {
      reportAbsence("regex")
      regex = makeAttributeValueTemplate("xxx", null)
    }
    if (flagsAtt == null) {
      flagsAtt = ""
      flags = makeAttributeValueTemplate("", null)
    }
    if (regex.isInstanceOf[StringLiteral] && flags.isInstanceOf[StringLiteral]) try {
      val regex = this.regex.asInstanceOf[StringLiteral].getStringValue
      val flagstr = flags.asInstanceOf[StringLiteral].getStringValue
      val warnings = new util.ArrayList[String]
      pattern = getConfiguration.compileRegularExpression(regex, flagstr, if (getEffectiveVersion >= 30) "XP30"
      else "XP20", warnings)
      import scala.collection.JavaConversions._
      for (w <- warnings) {
        issueWarning(w, this)
      }
    } catch {
      case err: XPathException =>
        if ("FORX0001" == err.getErrorCodeLocalPart) invalidFlags("Error in regular expression flags: " + err.getMessage)
        else invalidRegex("Error in regular expression: " + err.getMessage)
    }
  }

  private def invalidRegex(message: String) = {
    compileErrorInAttribute(message, "XTDE1140", "regex")
    // prevent it being reported more than once
    setDummyRegex()
  }

  private def invalidFlags(message: String) = {
    compileErrorInAttribute(message, "XTDE1145", "flags")
    setDummyRegex()
  }

  private def setDummyRegex() = try pattern = getConfiguration.compileRegularExpression("x", "", "XP20", null)
  catch {
    case err: XPathException =>
      throw new IllegalStateException
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = { //checkWithinTemplate();
    var foundFallback = false
    import scala.collection.JavaConversions._
    for (curr <- children) {
      if (curr.isInstanceOf[XSLFallback]) foundFallback = true
      else if (curr.isInstanceOf[XSLMatchingSubstring]) {
        val b = curr.getLocalPart == "matching-substring"
        if (b) {
          if (matching != null || nonMatching != null || foundFallback) compileError("xsl:matching-substring element must come first", "XTSE0010")
          matching = curr.asInstanceOf[StyleElement]
        }
        else {
          if (nonMatching != null || foundFallback) compileError("xsl:non-matching-substring cannot appear here", "XTSE0010")
          nonMatching = curr.asInstanceOf[StyleElement]
        }
      }
      else compileError("Only xsl:matching-substring and xsl:non-matching-substring are allowed here", "XTSE0010")
    }
    if (matching == null && nonMatching == null) compileError("At least one xsl:matching-substring or xsl:non-matching-substring element must be present", "XTSE1130")
    select = typeCheck("select", select)
    regex = typeCheck("regex", regex)
    flags = typeCheck("flags", flags)
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    var matchingBlock = null
    if (matching != null) matchingBlock = matching.compileSequenceConstructor(exec, decl, false)
    var nonMatchingBlock = null
    if (nonMatching != null) nonMatchingBlock = nonMatching.compileSequenceConstructor(exec, decl, false)
    try new AnalyzeString(select, regex, flags, if (matchingBlock == null) null
    else matchingBlock.simplify, if (nonMatchingBlock == null) null
    else nonMatchingBlock.simplify, pattern)
    catch {
      case e: XPathException =>
        compileError(e)
        null
    }
  }
}