////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.event.EventMonitor
import net.sf.saxon.event.Outputter
import net.sf.saxon.event.OutputterEventBuffer
import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.expr.instruct.BreakInstr
import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.lib.ErrorReporter
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.pattern.QNameTest
import net.sf.saxon.s9api.XmlProcessingError
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Cardinality
import java.util

/**
 * This class implements a try/catch expression. It consists of a try expression, and a sequence of Nametest/Catch
 * expression pairs. If the try expression succeeds, its result is returned; otherwise the error code of the
 * exception is matched against each of the Nametests in turn, and the first matching catch expression is
 * evaluated.
 */
object TryCatch {

  class CatchClause {
    var slotNumber = -1
    var catchOp = null
    var nameTest = null
  }

}

class TryCatch(val tryExpr: Expression) extends Expression {
  this.tryOp = new Operand(this, tryExpr, OperandRole.SAME_FOCUS_ACTION)
  private var tryOp = null
  private val catchClauses = new util.ArrayList[TryCatch.CatchClause]
  private var rollbackOutput = false

  def addCatchExpression(test: QNameTest, catchExpr: Expression) = {
    val clause = new TryCatch.CatchClause
    clause.catchOp = new Operand(this, catchExpr, OperandRole.SAME_FOCUS_ACTION)
    clause.nameTest = test
    catchClauses.add(clause)
  }

  def setRollbackOutput(rollback: Boolean) = this.rollbackOutput = rollback

  def isRollbackOutput = this.rollbackOutput

  /**
   * Get the "try" operand
   *
   * @return the primary operand to be evaluated
   */
  def getTryOperand = tryOp

  /**
   * Get the "try" expression
   *
   * @return the primary expression to be evaluated
   */
  def getTryExpr = tryOp.getChildExpression

  /**
   * Get the list of catch clauses
   *
   * @return the list of catch clauses
   */
  def getCatchClauses = catchClauses

  /**
   * Ask whether this expression is an instruction. In XSLT streamability analysis this
   * is used to distinguish constructs corresponding to XSLT instructions from other constructs,
   * typically XPath expressions.
   *
   * @return true (if this construct exists at all in an XSLT environment, then it represents an instruction)
   */
  override def isInstruction = true

  /**
   * Ask whether common subexpressions found in the operands of this expression can
   * be extracted and evaluated outside the expression itself. The result is irrelevant
   * in the case of operands evaluated with a different focus, which will never be
   * extracted in this way, even if they have no focus dependency.
   *
   * @return false for this kind of expression
   */
  override def allowExtractingCommonSubexpressions = false

  /**
   * Determine the cardinality of the function.
   */
  override def computeCardinality = {
    var card = getTryExpr.getCardinality
    import scala.collection.JavaConversions._
    for (catchClause <- catchClauses) {
      card = Cardinality.union(card, catchClause.catchOp.getChildExpression.getCardinality)
    }
    card
  }

  /**
   * Determine the item type of the value returned by the function
   */
  /*@NotNull*/ override def getItemType = {
    var `type` = getTryExpr.getItemType
    import scala.collection.JavaConversions._
    for (catchClause <- catchClauses) {
      `type` = Type.getCommonSuperType(`type`, catchClause.catchOp.getChildExpression.getItemType)
    }
    `type`
  }

  /**
   * Get the immediate sub-expressions of this expression, with information about the relationship
   * of each expression to its parent expression. Default implementation
   * returns a zero-length array, appropriate for an expression that has no
   * sub-expressions.
   *
   * @return an iterator containing the sub-expressions of this expression
   */
  override def operands = {
    val list = new util.ArrayList[Operand]
    list.add(tryOp)
    import scala.collection.JavaConversions._
    for (cc <- catchClauses) {
      list.add(cc.catchOp)
    }
    list
  }

  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = {
    optimizeChildren(visitor, contextInfo)
    var e = getParentExpression
    while ( {
      e != null
    }) {
      if (e.isInstanceOf[LetExpression] && ExpressionTool.dependsOnVariable(getTryExpr, Array[Binding](e.asInstanceOf[LetExpression]))) e.asInstanceOf[LetExpression].setNeedsEagerEvaluation(true)
      e = e.getParentExpression
    }
    this
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Is this expression the same as another expression?
   *
   * @param other the expression to be compared with this one
   * @return true if the two expressions are statically equivalent
   */
  override def equals(other: Any) = other.isInstanceOf[TryCatch] && other.asInstanceOf[TryCatch].tryOp.getChildExpression.isEqual(tryOp.getChildExpression) && other.asInstanceOf[TryCatch].catchClauses == catchClauses

  /**
   * Hashcode supporting equals()
   */
  override def computeHashCode = {
    var h = 0x836b12a0
    for (i <- 0 until catchClauses.size) {
      h ^= catchClauses.get(i).hashCode << i
    }
    h + tryOp.getChildExpression.hashCode
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be re-bound
   */
  override def copy(rebindings: RebindingMap) = {
    val t2 = new TryCatch(tryOp.getChildExpression.copy(rebindings))
    import scala.collection.JavaConversions._
    for (clause <- catchClauses) {
      t2.addCatchExpression(clause.nameTest, clause.catchOp.getChildExpression.copy(rebindings))
    }
    t2.setRollbackOutput(rollbackOutput)
    ExpressionTool.copyLocationInfo(this, t2)
    t2
  }

  /**
   * Evaluate as a singleton item
   *
   * @param c the dynamic XPath evaluation context
   */
  @throws[XPathException]
  override def evaluateItem(c: XPathContext): Item = {
    val c1 = c.newMinorContext
    try ExpressionTool.eagerEvaluate(tryOp.getChildExpression, c1).head
    catch {
      case err: XPathException =>
        if (err.isGlobalError) err.setIsGlobalError(false)
        else {
          var code = err.getErrorCodeQName
          if (code == null) code = new StructuredQName("saxon", NamespaceConstant.SAXON, "XXXX9999")
          import scala.collection.JavaConversions._
          for (clause <- catchClauses) {
            if (clause.nameTest.matches(code)) {
              val caught = clause.catchOp.getChildExpression
              val c2 = c.newContext
              c2.setCurrentException(err)
              return caught.evaluateItem(c2)
            }
          }
        }
        err.setHasBeenReported(false)
        throw err
    }
  }

  /**
   * Iterate over the results of the function
   */
  @throws[XPathException]
  override def iterate(c: XPathContext): SequenceIterator = {
    val c1 = c.newContext
    c1.createThreadManager()
    c1.setErrorReporter(new TryCatch#FilteringErrorReporter(c.getErrorReporter))
    try { // Need to do eager iteration of the first argument to flush any errors out
      val v = ExpressionTool.eagerEvaluate(tryOp.getChildExpression, c1)
      c1.waitForChildThreads()
      // check for xsl:break within xsl:try - test iterate-035
      val tci = c1.getTailCallInfo
      if (tci.isInstanceOf[BreakInstr]) tci.asInstanceOf[BreakInstr].markContext(c)
      v.iterate
    } catch {
      case err: XPathException =>
        if (err.isGlobalError) err.setIsGlobalError(false)
        else {
          var code = err.getErrorCodeQName
          if (code == null) code = new StructuredQName("saxon", NamespaceConstant.SAXON, "XXXX9999")
          import scala.collection.JavaConversions._
          for (clause <- catchClauses) {
            if (clause.nameTest.matches(code)) {
              val caught = clause.catchOp.getChildExpression
              val c2 = c.newContext
              c2.setCurrentException(err)
              // check for xsl:break within xsl:catch - test iterate-036
              val v = ExpressionTool.eagerEvaluate(caught, c2)
              val tci = c2.getTailCallInfo
              if (tci.isInstanceOf[BreakInstr]) tci.asInstanceOf[BreakInstr].markContext(c)
              return v.iterate
            }
          }
        }
        err.setHasBeenReported(false)
        throw err
    }
  }

  @throws[XPathException]
  override def process(output: Outputter, context: XPathContext): Unit = {
    val pipe = output.getPipelineConfiguration
    val c1 = context.newContext
    c1.createThreadManager()
    c1.setErrorReporter(new TryCatch#FilteringErrorReporter(context.getErrorReporter))
    //Outputter original = context.getReceiver();
    var o2 = null
    if (rollbackOutput) {
      o2 = new OutputterEventBuffer
      o2.setPipelineConfiguration(pipe)
    }
    else {
      o2 = new EventMonitor(output)
      o2.setPipelineConfiguration(pipe)
    }
    try {
      tryOp.getChildExpression.process(o2, c1)
      c1.waitForChildThreads()
      //context.setReceiver(original);
      val tci = c1.getTailCallInfo
      if (tci.isInstanceOf[BreakInstr]) tci.asInstanceOf[BreakInstr].markContext(context)
      if (rollbackOutput) o2.asInstanceOf[OutputterEventBuffer].replay(output)
    } catch {
      case err: XPathException =>
        if (err.isGlobalError) err.setIsGlobalError(false)
        else {
          var code = err.getErrorCodeQName
          if (code == null) code = new StructuredQName("saxon", NamespaceConstant.SAXON, "XXXX9999")
          import scala.collection.JavaConversions._
          for (clause <- catchClauses) {
            if (clause.nameTest.matches(code)) {
              if (o2.isInstanceOf[EventMonitor] && o2.asInstanceOf[EventMonitor].hasBeenWrittenTo) { // rollback=no was specified, and output has been written, so we cannot recover
                val message = err.getMessage + ". The error could not be caught, because rollback-output=no was specified, and output was already written to the result tree"
                val xe = new XPathException(message, "XTDE3530")
                xe.setLocation(err.getLocator)
                xe.setXPathContext(context)
                throw xe
              }
              val caught = clause.catchOp.getChildExpression
              val c2 = context.newContext
              c2.setCurrentException(err)
              val v = ExpressionTool.eagerEvaluate(caught, c2)
              val tci = c2.getTailCallInfo
              if (tci.isInstanceOf[BreakInstr]) tci.asInstanceOf[BreakInstr].markContext(context)
              v.asInstanceOf[GroundedValue].iterate.forEachOrFail((item: Item) => output.append(item))
              return
            }
          }
        }
        err.setHasBeenReported(false)
        throw err
    }
  }

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "tryCatch" // used in ExpressionVisitor
  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   *
   * @param out the expression presenter used to display the structure
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    out.startElement("try", this)
    if (rollbackOutput) out.emitAttribute("flags", "r")
    tryOp.getChildExpression.`export`(out)
    import scala.collection.JavaConversions._
    for (clause <- catchClauses) {
      out.startElement("catch")
      out.emitAttribute("errors", clause.nameTest.exportQNameTest)
      //            out.emitAttribute("err", clause.nameTest.toString());
      //            if ("JS".equals(((ExpressionPresenter.ExportOptions) out.getOptions()).target)) {
      //                int targetVersion = ((ExpressionPresenter.ExportOptions) out.getOptions()).targetVersion;
      //                out.emitAttribute("test", clause.nameTest.generateJavaScriptNameTest(targetVersion));
      //            }
      clause.catchOp.getChildExpression.`export`(out)
      out.endElement
    }
    out.endElement
  }

  /**
   * An error listener that filters out reporting of any errors that are caught be the try/catch
   */
  private class FilteringErrorReporter private[expr](var base: ErrorReporter) extends ErrorReporter {
    private def isCaught(err: XmlProcessingError): Boolean = {
      val code = err.getErrorCode.getStructuredQName
      import scala.collection.JavaConversions._
      for (clause <- catchClauses) {
        if (clause.nameTest.matches(code)) return true
      }
      false
    }

    override def report(error: XmlProcessingError) = if (error.isWarning || !isCaught(error)) base.report(error)
  }

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "TryCatch"
}