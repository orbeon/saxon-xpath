////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.event.Outputter
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.flwor.LocalVariableBinding
import net.sf.saxon.expr.instruct.GlobalParam
import net.sf.saxon.expr.instruct.LocalParam
import net.sf.saxon.expr.instruct.LocalParamBlock
import net.sf.saxon.expr.parser._
import net.sf.saxon.lib.StandardDiagnostics
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.pattern.NodeTest
import net.sf.saxon.s9api.Location
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.IntegerValue
import net.sf.saxon.value.SequenceType

/**
 * Variable reference: a reference to a variable. This may be an XSLT-defined variable, a range
 * variable defined within the XPath expression, or a variable defined in some other static context.
 */
abstract class VariableReference extends Expression with BindingReference {
  /*@Nullable*/ protected var binding = null // This will be null until fixup() is called; it will also be null
  // if the variable reference has been inlined
  protected var staticType = null
  protected var constantValue = null
  private var variableName = null
  private var flattened = false
  private var inLoop = false
  private var filtered = false

  /**
   * Create a Variable Reference
   */
  def this(name: StructuredQName) {
    this()
    variableName = name
  }

  /**
   * Create a Variable Reference
   *
   * @param binding the variable binding to which this variable refers
   */
  def this(binding: Binding) {
    this()
    //System.err.println("Creating varRef1");
    variableName = binding.getVariableQName
    fixup(binding)
  }

  /**
   * Set the variable name
   *
   * @param name the name of the variable
   */
  def setVariableName(name: StructuredQName) = variableName = name

  /**
   * Get the variable name
   *
   * @return the name of the variable
   */
  def getVariableName = variableName

  /**
   * Create a clone copy of this VariableReference
   *
   * @return the cloned copy
   * @param rebindings variables that need to switch to new bindings
   */
  /*@NotNull*/ override def copy(rebindings: RebindingMap)

  override def getNetCost = 0

  protected def copyFrom(ref: VariableReference) = {
    binding = ref.binding
    staticType = ref.staticType
    constantValue = ref.constantValue
    variableName = ref.variableName
    flattened = ref.flattened
    inLoop = ref.inLoop
    filtered = ref.filtered
    ExpressionTool.copyLocationInfo(ref, this)
  }

  /**
   * Set static type. This is a callback from the variable declaration object. As well
   * as supplying the static type, it may also supply a compile-time value for the variable.
   * As well as the type information, other static properties of the value are supplied:
   * for example, whether the value is an ordered node-set.
   *
   * @param type       the static type of the variable
   * @param value      the value of the variable if this is a compile-time constant, or null otherwise
   * @param properties static properties of the expression to which the variable is bound
   */
  override def setStaticType(`type`: SequenceType, value: GroundedValue, properties: Int) = { // System.err.println(this + " Set static type = " + type);
    if (`type` == null) `type` = SequenceType.ANY_SEQUENCE
    staticType = `type`
    constantValue = value
    // Although the variable may be a context document node-set at the point it is defined,
    // the context at the point of use may be different, so this property cannot be transferred.
    val dependencies = getDependencies
    staticProperties = (properties & ~StaticProperty.CONTEXT_DOCUMENT_NODESET & ~StaticProperty.ALL_NODES_NEWLY_CREATED) | StaticProperty.NO_NODES_NEWLY_CREATED | `type`.getCardinality | dependencies
  }

  /**
   * Mark an expression as being "flattened". This is a collective term that includes extracting the
   * string value or typed value, or operations such as simple value construction that concatenate text
   * nodes before atomizing. The implication of all of these is that although the expression might
   * return nodes, the identity of the nodes has no significance. This is called during type checking
   * of the parent expression. At present, only variable references take any notice of this notification.
   */
  override def setFlattened(flattened: Boolean) = this.flattened = flattened

  /**
   * Test whether this variable reference is flattened - that is, whether it is atomized etc
   *
   * @return true if the value of the variable is atomized, or converted to a string or number
   */
  def isFlattened = flattened

  /**
   * Mark an expression as filtered: that is, it appears as the base expression in a filter expression.
   * This notification currently has no effect except when the expression is a variable reference.
   */
  override def setFiltered(filtered: Boolean) = this.filtered = filtered

  /**
   * Determine whether this variable reference is filtered
   *
   * @return true if the value of the variable is filtered by a predicate
   */
  def isFiltered = filtered

  /**
   * Ask whether this variable reference appears in a loop relative to its declaration.
   * By default, when in doubt, returns true. This is calculated during type-checking.
   *
   * @return true if this variable reference occurs in a loop, where the variable declaration is
   *         outside the loop
   */
  def isInLoop = inLoop

  /**
   * Say whether this variable reference appears in a loop relative to its declaration.
   *
   * @param inLoop true if this variable reference occurs in a loop, where the variable declaration is
   *               outside the loop
   */
  def setInLoop(inLoop: Boolean) = this.inLoop = inLoop

  /**
   * Type-check the expression. At this stage details of the static type must be known.
   * If the variable has a compile-time value, this is substituted for the variable reference
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    if (constantValue != null) {
      binding = null
      return Literal.makeLiteral(constantValue, this)
    }
    //        if (staticType == null) {
    //            throw new IllegalStateException("Variable $" + getDisplayName() + " has not been fixed up");
    //        }
    //  following code removed because it causes error181 to blow the stack - need to check for circularities well
    //            if (binding instanceof GlobalVariable) {
    //                ((GlobalVariable)binding).typeCheck(visitor, AnyItemType.getInstance());
    //            }
    if (binding != null) {
      recomputeInLoop()
      binding.addReference(this, inLoop)
    }
    this
  }

  def recomputeInLoop() = inLoop = ExpressionTool.isLoopingReference(this, binding)

  /**
   * Optimize the expression. At this stage details of the static type must be known.
   * If the variable has a compile-time value, this is substituted for the variable reference
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    if (binding.isInstanceOf[LetExpression] && binding.asInstanceOf[LetExpression].getSequence.isInstanceOf[Literal] && !(binding.asInstanceOf[LetExpression]).isIndexedVariable) {
      val `val` = binding.asInstanceOf[LetExpression].getSequence
      Optimizer.trace(visitor.getConfiguration, "Replaced variable " + getDisplayName + " by its value", `val`)
      binding = null
      return `val`.copy(new RebindingMap)
    }
    if (constantValue != null) {
      binding = null
      val result = Literal.makeLiteral(constantValue, this)
      ExpressionTool.copyLocationInfo(this, result)
      Optimizer.trace(visitor.getConfiguration, "Replaced variable " + getDisplayName + " by its value", result)
      return result
    }
    if (binding.isInstanceOf[GlobalParam] && binding.asInstanceOf[GlobalParam].isStatic) {
      val select = binding.asInstanceOf[GlobalParam].getBody
      if (select.isInstanceOf[Literal]) {
        binding = null
        Optimizer.trace(visitor.getConfiguration, "Replaced static parameter " + getDisplayName + " by its value", select)
        return select
      }
    }
    this
  }

  /**
   * Fix up this variable reference to a Binding object, which enables the value of the variable
   * to be located at run-time.
   */
  override def fixup(newBinding: Binding) = {
    val indexed = binding.isInstanceOf[LocalBinding] && binding.asInstanceOf[LocalBinding].isIndexedVariable
    this.binding = newBinding
    if (indexed && newBinding.isInstanceOf[LocalBinding]) newBinding.asInstanceOf[LocalBinding].setIndexedVariable()
    resetLocalStaticProperties()
  }

  /**
   * Provide additional information about the type of the variable, typically derived by analyzing
   * the initializer of the variable binding
   *
   * @param type          the item type of the variable
   * @param cardinality   the cardinality of the variable
   * @param constantValue the actual value of the variable, if this is known statically, otherwise null
   * @param properties    additional static properties of the variable's initializer
   */
  def refineVariableType(`type`: ItemType, cardinality: Int, constantValue: GroundedValue, properties: Int) = {
    val th = getConfiguration.getTypeHierarchy
    val oldItemType = getItemType
    var newItemType = oldItemType
    if (th.isSubType(`type`, oldItemType)) newItemType = `type`
    if (oldItemType.isInstanceOf[NodeTest] && `type`.isInstanceOf[AtomicType]) { // happens when all references are flattened
      newItemType = `type`
    }
    var newcard = cardinality & getCardinality
    if (newcard == 0) { // this will probably lead to a type error later
      newcard = getCardinality
    }
    val seqType = SequenceType.makeSequenceType(newItemType, newcard)
    setStaticType(seqType, constantValue, properties)
  }

  /**
   * Determine the data type of the expression, if possible
   *
   * @return the type of the variable, if this can be determined statically;
   *         otherwise Type.ITEM (meaning not known in advance)
   */
  override def getItemType: ItemType = if (staticType == null || (staticType.getPrimaryType eq AnyItemType.getInstance)) {
    if (binding != null) {
      val st = binding.getRequiredType
      if (st != null) return st.getPrimaryType
    }
    AnyItemType.getInstance
  }
  else staticType.getPrimaryType

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType the static context item type
   */
  override def getStaticUType(contextItemType: UType): UType = {
    if (binding != null) if (binding.isGlobal || binding.isInstanceOf[LocalParam] || (binding.isInstanceOf[LetExpression] && binding.asInstanceOf[LetExpression].isInstruction) || binding.isInstanceOf[LocalVariableBinding]) {
      val st = binding.getRequiredType
      if (st != null) return st.getPrimaryType.getUType
      else return UType.ANY
    }
    else if (binding.isInstanceOf[Assignation]) return binding.asInstanceOf[Assignation].getSequence.getStaticUType(contextItemType)
    UType.ANY
  }

  /**
   * For an expression that returns an integer or a sequence of integers, get
   * a lower and upper bound on the values of the integers that may be returned, from
   * static analysis. The default implementation returns null, meaning "unknown" or
   * "not applicable". Other implementations return an array of two IntegerValue objects,
   * representing the lower and upper bounds respectively. The values
   * UNBOUNDED_LOWER and UNBOUNDED_UPPER are used by convention to indicate that
   * the value may be arbitrarily large. The values MAX_STRING_LENGTH and MAX_SEQUENCE_LENGTH
   * are used to indicate values limited by the size of a string or the size of a sequence.
   *
   * @return the lower and upper bounds of integer values in the result, or null to indicate
   *         unknown or not applicable.
   */
  override def getIntegerBounds = if (binding != null) binding.getIntegerBoundsForVariable
  else null

  /**
   * Get the static cardinality
   */
  override def computeCardinality = if (staticType == null) if (binding == null) StaticProperty.ALLOWS_ZERO_OR_MORE
  else if (binding.isInstanceOf[LetExpression]) binding.getRequiredType.getCardinality
  else if (binding.isInstanceOf[Assignation]) StaticProperty.EXACTLY_ONE
  else if (binding.getRequiredType == null) StaticProperty.ALLOWS_ZERO_OR_MORE
  else binding.getRequiredType.getCardinality
  else staticType.getCardinality

  /**
   * Determine the special properties of this expression
   *
   * @return { @link StaticProperty#NO_NODES_NEWLY_CREATED} (unless the variable is assignable using saxon:assign)
   */
  override def computeSpecialProperties = {
    var p = super.computeSpecialProperties
    if (binding == null || !binding.isAssignable) { // if the variable reference is assignable, we mustn't move it, or any expression that contains it,
      // out of a loop. The way to achieve this is to treat it as a "creative" expression, because the
      // optimizer recognizes such expressions and handles them with care...
      p |= StaticProperty.NO_NODES_NEWLY_CREATED
    }
    if (binding.isInstanceOf[Assignation]) {
      val exp = binding.asInstanceOf[Assignation].getSequence
      if (exp != null) p |= exp.getSpecialProperties & StaticProperty.NOT_UNTYPED_ATOMIC
    }
    if (staticType != null && !Cardinality.allowsMany(staticType.getCardinality) && staticType.getPrimaryType.isInstanceOf[NodeTest]) p |= StaticProperty.SINGLE_DOCUMENT_NODESET
    p & ~StaticProperty.ALL_NODES_NEWLY_CREATED
  }

  /**
   * Test if this expression is the same as another expression.
   * (Note, we only compare expressions that
   * have the same static and dynamic context).
   */
  override def equals(other: Any) = other.isInstanceOf[VariableReference] && (binding eq other.asInstanceOf[VariableReference].binding) && binding != null

  /**
   * get HashCode for comparing two expressions
   */
  override def computeHashCode = if (binding == null) 73619830
  else binding.hashCode

  override def getIntrinsicDependencies = {
    var d = 0
    if (binding == null) { // assume the worst
      d |= StaticProperty.DEPENDS_ON_LOCAL_VARIABLES | StaticProperty.DEPENDS_ON_ASSIGNABLE_GLOBALS | StaticProperty.DEPENDS_ON_RUNTIME_ENVIRONMENT
    }
    else if (binding.isGlobal) {
      if (binding.isAssignable) d |= StaticProperty.DEPENDS_ON_ASSIGNABLE_GLOBALS
      if (binding.isInstanceOf[GlobalParam]) d |= StaticProperty.DEPENDS_ON_RUNTIME_ENVIRONMENT
    }
    else d |= StaticProperty.DEPENDS_ON_LOCAL_VARIABLES
    d
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided. This implementation provides both all three methods
   * natively.
   */
  override def getImplementationMethod = (if (Cardinality.allowsMany(getCardinality)) 0
  else EVALUATE_METHOD) | ITERATE_METHOD | PROCESS_METHOD

  /**
   * Get the innermost scoping expression of this expression, for expressions that directly
   * depend on something in the dynamic context. For example, in the case of a local variable
   * reference this is the expression that causes the relevant variable to be bound; for a
   * context item expression it is the innermost focus-setting container. For expressions
   * that have no intrinsic dependency on the dynamic context, the value returned is null;
   * the scoping container for such an expression is the innermost scoping container of its
   * operands.
   *
   * @return the innermost scoping container of this expression
   */
  override def getScopingExpression: Expression = {
    if (binding.isInstanceOf[Expression]) if (binding.isInstanceOf[LocalParam] && binding.asInstanceOf[LocalParam].getParentExpression.isInstanceOf[LocalParamBlock]) {
      val block = binding.asInstanceOf[LocalParam].getParentExpression.asInstanceOf[LocalParamBlock]
      return block.getParentExpression
    }
    else return binding.asInstanceOf[Expression]
    var parent = getParentExpression
    while ( {
      parent != null
    }) {
      if (parent.hasVariableBinding(binding)) return parent
      parent = parent.getParentExpression
    }
    null
  }

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   * <p>The default implementation of this method assumes that an expression does no navigation other than
   * the navigation done by evaluating its subexpressions, and that the subexpressions are evaluated in the
   * same context as the containing expression. The method must be overridden for any expression
   * where these assumptions do not hold. For example, implementations exist for AxisExpression, ParentExpression,
   * and RootExpression (because they perform navigation), and for the doc(), document(), and collection()
   * functions because they create a new navigation root. Implementations also exist for PathExpression and
   * FilterExpression because they have subexpressions that are evaluated in a different context from the
   * calling expression.</p>
   *
   * @param pathMap        the PathMap to which the expression should be added
   * @param pathMapNodeSet the PathMapNodeSet to which the paths embodied in this expression should be added
   * @return the pathMapNodeSet representing the points in the source document that are both reachable by this
   *         expression, and that represent possible results of this expression. For an expression that does
   *         navigation, it represents the end of the arc in the path map that describes the navigation route. For other
   *         expressions, it is the same as the input pathMapNode.
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = pathMap.getPathForVariable(getBinding)

  /**
   * Get the value of this variable in a given context.
   *
   * @param c the XPathContext which contains the relevant variable bindings
   * @return the value of the variable, if it is defined
   * @throws XPathException if the variable is undefined
   */
  @throws[XPathException]
  override def iterate(c: XPathContext) = try {
    val actual = evaluateVariable(c)
    assert(actual != null)
    actual.iterate
  } catch {
    case err: XPathException =>
      err.maybeSetLocation(getLocation)
      throw err
    case err: NullPointerException =>
      err.printStackTrace()
      val msg = "Internal error: no value for variable $" + getDisplayName + " at line " + getLocation.getLineNumber + (if (getLocation.getSystemId == null) ""
      else " of " + getLocation.getSystemId)
      new StandardDiagnostics().printStackTrace(c, c.getConfiguration.getLogger, 2)
      throw new AssertionError(msg)
    case err: AssertionError =>
      err.printStackTrace()
      val msg = err.getMessage + ". Variable reference $" + getDisplayName + " at line " + getLocation.getLineNumber + (if (getLocation.getSystemId == null) ""
      else " of " + getLocation.getSystemId)
      new StandardDiagnostics().printStackTrace(c, c.getConfiguration.getLogger, 2)
      throw new AssertionError(msg)
  }

  @throws[XPathException]
  override def evaluateItem(c: XPathContext) = try {
    val actual = evaluateVariable(c)
    assert(actual != null)
    actual.head
  } catch {
    case err: XPathException =>
      err.maybeSetLocation(getLocation)
      throw err
  }

  @throws[XPathException]
  override def process(output: Outputter, c: XPathContext) = try {
    val iter = evaluateVariable(c).iterate
    val loc = getLocation
    iter.forEachOrFail((item: Item) => output.append(item, loc, ReceiverOption.ALL_NAMESPACES))
  } catch {
    case err: XPathException =>
      err.maybeSetLocation(getLocation)
      throw err
  }

  /**
   * Evaluate this variable
   *
   * @param c the XPath dynamic context
   * @return the value of the variable
   * @throws XPathException if any error occurs
   */
  @throws[XPathException]
  def evaluateVariable(c: XPathContext) = try binding.evaluateVariable(c)
  catch {
    case err: NullPointerException =>
      if (binding == null) throw new IllegalStateException("Variable $" + variableName.getDisplayName + " has not been fixed up")
      else throw err
  }

  /**
   * Get the object bound to the variable
   *
   * @return the Binding which declares this variable and associates it with a value
   */
  def getBinding = binding

  /**
   * Get the display name of the variable. This is taken from the variable binding if possible
   *
   * @return the display name (a lexical QName
   */
  def getDisplayName = if (binding != null) binding.getVariableQName.getDisplayName
  else variableName.getDisplayName

  /**
   * Get the EQName of the variable. This is taken from the variable binding if possible.
   * The returned name is in the format Q{uri}local if in a namespace, or the local name
   * alone if not.
   *
   * @return the EQName, or the local name if not in a namespace
   */
  def getEQName = if (binding != null) {
    val q = binding.getVariableQName
    if (q.hasURI("")) q.getLocalPart
    else q.getEQName
  }
  else variableName.getEQName

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   */
  override def toString = {
    val d = getEQName
    "$" + (if (d == null) "$"
    else d)
  }

  /**
   * Produce a short string identifying the expression for use in error messages
   *
   * @return a short string, sufficient to identify the expression
   */
  override def toShortString = "$" + getDisplayName

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in export() output displaying the expression.
   */
  override def getExpressionName = "varRef"

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("varRef", this)
    destination.emitAttribute("name", variableName)
    if (binding.isInstanceOf[LocalBinding]) destination.emitAttribute("slot", "" + binding.asInstanceOf[LocalBinding].getLocalSlotNumber)
    destination.endElement
  }

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "VariableReference"
}