////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.lib.Validation

/**
 * Enumeration class defining different schema validation (or construction) modes
 */
object ValidationMode extends Enumeration {
  type ValidationMode = Value
  val

  /**
   * Strict validation
   */
  STRICT,

  /**
   * Lax validation
   */
  LAX,

  /**
   * Preserve existing type annotations if any
   */
  PRESERVE,

  /**
   * Remove any existing type annotations, mark as untyped
   */
  STRIP,

  /**
   * Value indication no preference: the choice is defined elsewhere
   */
  DEFAULT = Value
  private var number = 0d

  this (number: Int) {
    this()
    this.number = number
  }
  protected def getNumber = number /*@NotNull*/
  protected def get(number: Int) = number match {
    case Validation.STRICT =>
      STRICT
    case Validation.LAX =>
      LAX
    case Validation.STRIP =>
      STRIP
    case Validation.PRESERVE =>
      PRESERVE
    case Validation.DEFAULT =>
    case _ =>
      DEFAULT
  }
}