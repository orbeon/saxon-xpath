////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.SequenceInstr
import net.sf.saxon.lib.Feature
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * An xsl:sequence element in the stylesheet.
 */
class XSLSequence extends StyleElement {
  private var select = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return in XSLT 2.0, false. In XSLT 3.0 true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  /**
   * Determine whether this type of element is allowed to contain an xsl:fallback
   * instruction
   */
  override def mayContainFallback = true

  def getSelectExpression = select

  def setSelectExpression(select: Expression) = this.select = select

  override def prepareAttributes() = {
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (!child.isInstanceOf[XSLFallback]) {
        if (select != null) compileError("An " + getDisplayName + " element with a select attribute must be empty", "XTSE3185")
        break //todo: break is not supported
      }
    }
    select = typeCheck("select", select)
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    if (select == null) select = compileSequenceConstructor(exec, decl, false)
    if (getConfiguration.getBooleanProperty(Feature.STRICT_STREAMABILITY)) select = new SequenceInstr(select)
    select
  }
}