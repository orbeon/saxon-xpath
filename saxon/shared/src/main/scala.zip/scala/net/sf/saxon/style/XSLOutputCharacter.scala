////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.serialize.charcode.UTF16CharacterSet
import net.sf.saxon.trans.XPathException

/**
 * An xsl:output-character element in the stylesheet. <br>
 */
class XSLOutputCharacter extends StyleElement {
  private var codepoint = -1
  // the character to be substituted, as a Unicode codepoint (may be > 65535)
  private var replacementString = null

  override def prepareAttributes(): Unit = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "character") {
        val s = value
        s.length match {
          case 0 =>
            compileError("character attribute must not be zero-length", "XTSE0020")
            codepoint = 256 // for error recovery
          case 1 =>
            codepoint = s.charAt(0)
          case 2 =>
            if (UTF16CharacterSet.isHighSurrogate(s.charAt(0)) && UTF16CharacterSet.isLowSurrogate(s.charAt(1))) codepoint = UTF16CharacterSet.combinePair(s.charAt(0), s.charAt(1))
            else {
              compileError("character attribute must be a single XML character", "XTSE0020")
              codepoint = 256
            }
          case _ =>
            compileError("character attribute must be a single XML character", "XTSE0020")
            codepoint = 256
        }
      }
      else if (f == "string") replacementString = value
      else checkUnknownAttribute(attName)
    }
    if (codepoint == -1) {
      reportAbsence("character")
      return
    }
    if (replacementString == null) reportAbsence("string")
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = if (!getParent.isInstanceOf[XSLCharacterMap]) compileError("xsl:output-character may appear only as a child of xsl:character-map", "XTSE0010")

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = null

  def getCodePoint = codepoint

  def getReplacementString = replacementString
}