////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.event.Outputter
import net.sf.saxon.expr.instruct.DocumentInstr
import net.sf.saxon.expr.instruct.TailCall
import net.sf.saxon.expr.instruct.TailCallReturner
import net.sf.saxon.expr.parser._
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.UType
import net.sf.saxon.om._
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.IntegerValue
import net.sf.saxon.value.SequenceType
import java.util
import java.util.function.BiConsumer

/**
 * A LetExpression represents the XQuery construct let $x := expr return expr. It is used
 * also for XSLT local variables.
 */
class LetExpression()

/**
 * Create a LetExpression
 */
//System.err.println("let");
  extends Assignation with TailCallReturner {
  //private int evaluationMode = ExpressionTool.UNDECIDED;
  private var evaluator = null
  private var needsEagerEvaluation = false
  private var needsLazyEvaluation = false
  private var isInstruction = false

  /**
   * Say whether this expression originates as an XSLT instruction
   *
   * @param inst true if this is an xsl:variable instruction
   */
  def setInstruction(inst: Boolean) = isInstruction = inst

  /**
   * Ask whether this expression is an instruction. In XSLT streamability analysis this
   * is used to distinguish constructs corresponding to XSLT instructions from other constructs.
   *
   * @return true if this construct originates as an XSLT instruction
   */
  override def isInstruction = isInstruction

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "let"

  /**
   * Say that this variable must be evaluated eagerly. This is a requirement for example
   * for variables appearing within a try/catch, or for variables referenced from within
   * a construct that uses multi-threading, for example xsl:result-document or a multi-threaded
   * xsl:for-each.
   *
   * @param req set to true if eager evaluation is required
   */
  def setNeedsEagerEvaluation(req: Boolean) = {
    if (req && needsLazyEvaluation) {
      // No action - see bug #2903, Lazy evaluation wins
    }
    this.needsEagerEvaluation = req
  }

  def setNeedsLazyEvaluation(req: Boolean) = {
    if (req && needsEagerEvaluation) this.needsEagerEvaluation = false // Bug 2903: lazy evaluation wins
    this.needsLazyEvaluation = req
  }

  def isNeedsLazyEvaluation = needsLazyEvaluation

  /**
   * Ask whether the expression can be lifted out of a loop, assuming it has no dependencies
   * on the controlling variable/focus of the loop
   *
   * @param forStreaming true if we are handling streaming code (where rewrites need to be more cautious)
   */
  override def isLiftable(forStreaming: Boolean) = super.isLiftable(forStreaming) && !needsEagerEvaluation

  override def resetLocalStaticProperties() = {
    super.resetLocalStaticProperties()
    references = new util.ArrayList[VariableReference] // bug 3233
    if ((evaluator eq Evaluator.VARIABLE) && !getSequence.isInstanceOf[VariableReference]) {
      evaluator = null
      setEvaluator()
    }
  }

  /**
   * Type-check the expression. This also has the side-effect of counting the number of references
   * to the variable (treating references that occur within a loop specially)
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = { // The order of events is critical here. First we ensure that the type of the
    // sequence expression is established. This is used to establish the type of the variable,
    // which in turn is required when type-checking the action part.
    getSequenceOp.typeCheck(visitor, contextInfo)
    val role = new RoleDiagnostic(RoleDiagnostic.VARIABLE, getVariableQName.getDisplayName, 0)
    //role.setSourceLocator(this);
    setSequence(TypeChecker.strictTypeCheck(getSequence, requiredType, role, visitor.getStaticContext))
    val actualItemType = getSequence.getItemType
    refineTypeInformation(actualItemType, getSequence.getCardinality, if (getSequence.isInstanceOf[Literal]) getSequence.asInstanceOf[Literal].getValue
    else null, getSequence.getSpecialProperties, this)
    getActionOp.typeCheck(visitor, contextInfo)
    this
  }

  /**
   * Determine whether this expression implements its own method for static type checking
   *
   * @return true - this expression has a non-trivial implementation of the staticTypeCheck()
   *         method
   */
  override def implementsStaticTypeCheck = true

  /**
   * Static type checking for let expressions is delegated to the expression itself,
   * and is performed on the "action" expression, to allow further delegation to the branches
   * of a conditional
   *
   * @param req                 the required type
   * @param backwardsCompatible true if backwards compatibility mode applies
   * @param role                the role of the expression in relation to the required type
   * @param visitor             an expression visitor
   * @return the expression after type checking (perhaps augmented with dynamic type checking code)
   * @throws XPathException if failures occur, for example if the static type of one branch of the conditional
   *                        is incompatible with the required type
   */
  @throws[XPathException]
  override def staticTypeCheck(req: SequenceType, backwardsCompatible: Boolean, role: RoleDiagnostic, visitor: ExpressionVisitor) = {
    val tc = visitor.getConfiguration.getTypeChecker(backwardsCompatible)
    setAction(tc.staticTypeCheck(getAction, req, role, visitor))
    this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    val opt = visitor.obtainOptimizer
    // if this is a construct of the form "let $j := EXP return $j" replace it with EXP
    // Remarkably, people do write this, and it can also be produced by previous rewrites
    // Note that type checks will already have been added to the sequence expression
    if (getAction.isInstanceOf[VariableReference] && (getAction.asInstanceOf[VariableReference].getBinding eq this) && !ExpressionTool.changesXsltContext(getSequence)) {
      getSequenceOp.optimize(visitor, contextItemType)
      opt.trace("Eliminated trivial variable " + getVariableName, getSequence)
      return getSequence
    }
    if (getSequence.isInstanceOf[Literal] && opt.isOptionSet(OptimizerOptions.INLINE_VARIABLES)) { // inline the variable: replace all references by the constant value
      // This relies on the fact that optimizing the action part will cause any references to be inlined
      opt.trace("Inlined constant variable " + getVariableName, getSequence)
      replaceVariable(getSequence)
      return getAction.optimize(visitor, contextItemType)
    }
    // if this is an XSLT construct of the form <xsl:variable>text</xsl:variable>, try to replace
    // it by <xsl:variable select="..."/>. This can be done if all the references to the variable use
    // its value as a string (rather than, say, as a node or as a boolean)
    if (getSequence.isInstanceOf[DocumentInstr] && getSequence.asInstanceOf[DocumentInstr].isTextOnly) { // Ensure the list of references is accurate
      verifyReferences()
      // Check whether all uses of the variable are atomized or stringified
      if (allReferencesAreFlattened) {
        var stringValueExpression = getSequence.asInstanceOf[DocumentInstr].getStringValueExpression
        stringValueExpression = stringValueExpression.typeCheck(visitor, contextItemType)
        setSequence(stringValueExpression)
        requiredType = SequenceType.SINGLE_UNTYPED_ATOMIC
        adoptChildExpression(getSequence)
        refineTypeInformation(requiredType.getPrimaryType, requiredType.getCardinality, null, 0, this)
      }
    }
    // If the initializing expression has (potential) side-effects, prevent optimizations such as elimination
    // of unused variables
    if (getSequence.hasSpecialProperty(StaticProperty.HAS_SIDE_EFFECTS)) needsEagerEvaluation = true
    // Removal of redundant variables, and inlining of variables that are only used once, depends on accurate
    // knowledge of all references to the variable. The problem is that obtaining this knowledge can be expensive:
    // see bug 2707. On the other hand, failing to do these optimizations is not fatal. So the general approach
    // is that we limit the time spent discovering the information, and we don't do the optimization unless
    // it is safe.
    // Typically on entry to optimize(), the typeCheck() method has already been called, and this has set up
    // a list of references. First we examine this list of references and remove any that are "dead", that is
    // they no longer have this LetExpression as an ancestor in the expression tree. This function also checks
    // whether any of these references are known to be in a loop, and returns true if so.
    hasLoopingReference |= removeDeadReferences
    if (!needsEagerEvaluation) { // If there are less than two references, and none is in a loop, then there is potential
      // for optimization. But we now need to be absolutely sure that we have an accurate list
      // of references.
      var considerRemoval = ((references != null && references.size < 2) || getSequence.isInstanceOf[VariableReference]) && !isIndexedVariable && !hasLoopingReference && !needsEagerEvaluation
      if (considerRemoval) {
        verifyReferences()
        // At this point the list of references is either accurate, or null
        considerRemoval = references != null
      }
      if (considerRemoval && references.isEmpty) { // variable is not used - no need to evaluate it
        getActionOp.optimize(visitor, contextItemType)
        opt.trace("Eliminated unused variable " + getVariableName, getAction)
        return getAction
      }
      // Don't inline context-dependent variables in a streamable template. See strmode011.
      // The reason for this is that a variable <xsl:variable><xsl:copy-of select="."/></xsl:variable>
      // can be evaluated in streaming mode, but an arbitrary expression using copy() inline can't (e.g.
      // if it appears in a path expression or as an operand of an arithmetic expression)
      if (considerRemoval && references.size == 1 && ExpressionTool.dependsOnFocus(getSequence)) {
        if (visitor.isOptimizeForStreaming) considerRemoval = false
        // Disallow inlining if the focus of the variable reference differs from the containing binding.
        var child = references.get(0)
        var parent = child.getParentExpression
        while ( {
          parent != null && (parent ne this)
        }) {
          val operand = ExpressionTool.findOperand(parent, child)
          assert(operand != null)
          if (!operand.hasSameFocus) {
            considerRemoval = false
            break //todo: break is not supported
          }
          child = parent
          parent = child.getParentExpression
        }
      }
      if (considerRemoval && references.size == 1) if (ExpressionTool.changesXsltContext(getSequence)) { // Don't inline variables whose initializer might contain a call to xsl:result-document
        considerRemoval = false
      }
      else if ((getSequence.getDependencies & StaticProperty.DEPENDS_ON_CURRENT_GROUP) ne 0) { // Don't inline variables that depend on current-group() or current-grouping-key()
        considerRemoval = false
      }
      else if (references.get(0).isInLoop) { // Don't inline variables where the variable reference is evaluated repeatedly
        considerRemoval = false
      }
      if (considerRemoval && (references.size == 1 || getSequence.isInstanceOf[Literal] || getSequence.isInstanceOf[VariableReference]) && opt.isOptionSet(OptimizerOptions.INLINE_VARIABLES)) {
        inlineReferences()
        opt.trace("Inlined references to $" + getVariableName, getAction)
        references = null
        return getAction.optimize(visitor, contextItemType)
      }
    }
    var tries = 0
    while ( {
      {
        tries += 1; tries - 1
      } < 5
    }) {
      val seq0 = getSequence
      getSequenceOp.optimize(visitor, contextItemType)
      if (getSequence.isInstanceOf[Literal] && !isIndexedVariable) return optimize(visitor, contextItemType)
      if (seq0 eq getSequence) break //todo: break is not supported
    }
    tries = 0
    while ( {
      {
        tries += 1; tries - 1
      } < 5
    }) {
      val act0 = getAction
      getActionOp.optimize(visitor, contextItemType)
      if (act0 eq getAction) break //todo: break is not supported
      if (!isIndexedVariable && !needsEagerEvaluation) {
        verifyReferences()
        if (references != null && references.size < 2) if (references.isEmpty) { // We may have removed references to the variable; try again at eliminating this expression.
          hasLoopingReference = false
          return optimize(visitor, contextItemType)
        }
        else { // there is one remaining reference; try again at inlining if it's not in a loop
          if (!references.get(0).isInLoop) return optimize(visitor, contextItemType)
        }
      }
    }
    // Don't use lazy evaluation for a variable that is referenced inside the "try" part of a contained try catch (XSLT3 test try-031)
    setEvaluator()
    this
  }

  def setEvaluator() = if (needsEagerEvaluation) setEvaluator(ExpressionTool.eagerEvaluator(getSequence))
  else if (isIndexedVariable) setEvaluator(Evaluator.MAKE_INDEXED_VARIABLE)
  else if (evaluator == null) setEvaluator(ExpressionTool.lazyEvaluator(getSequence, getNominalReferenceCount > 1))

  private def inlineReferences() = { // Note that the list of references might include references that are no longer reachable on the tree.
    // We therefore take no action if (a) the parent of the reference is null, or (b) the reference is
    // not found among the children of its parent.
    import scala.collection.JavaConversions._
    for (ref <- references) {
      val parent = ref.getParentExpression
      if (parent != null) {
        val o = ExpressionTool.findOperand(parent, ref)
        if (o != null) o.setChildExpression(getSequence.copy(new RebindingMap))
        ExpressionTool.resetStaticProperties(parent)
      }
    }
  }

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   *
   * @return a rough estimate of the evaluation cost
   */
  override def getCost = getSequence.getCost + getAction.getCost

  /**
   * Determine whether all references to this variable are using the value either
   * (a) by atomizing it, or (b) by taking its string value. (This excludes usages
   * such as testing the existence of a node or taking the effective boolean value).
   *
   * @return true if all references are known to atomize (or stringify) the value,
   *         false otherwise. The value false may indicate "not known".
   */
  private def allReferencesAreFlattened = references != null && references.stream.allMatch(VariableReference.isFlattened)

  /**
   * Determine whether this is a vacuous expression as defined in the XQuery update specification
   *
   * @return true if this expression is vacuous
   */
  override def isVacuousExpression = getAction.isVacuousExpression

  /**
   * Check that any elements and attributes constructed or returned by this expression are acceptable
   * in the content model of a given complex type. It's always OK to say yes, since the check will be
   * repeated at run-time. The process of checking element and attribute constructors against the content
   * model of a complex type also registers the type of content expected of those constructors, so the
   * static validation can continue recursively.
   */
  @throws[XPathException]
  override def checkPermittedContents(parentType: SchemaType, whole: Boolean) = getAction.checkPermittedContents(parentType, whole)

  /**
   * For an expression that returns an integer or a sequence of integers, get
   * a lower and upper bound on the values of the integers that may be returned, from
   * static analysis. The default implementation returns null, meaning "unknown" or
   * "not applicable". Other implementations return an array of two IntegerValue objects,
   * representing the lower and upper bounds respectively. The values
   * UNBOUNDED_LOWER and UNBOUNDED_UPPER are used by convention to indicate that
   * the value may be arbitrarily large. The values MAX_STRING_LENGTH and MAX_SEQUENCE_LENGTH
   * are used to indicate values limited by the size of a string or the size of a sequence.
   *
   * @return the lower and upper bounds of integer values in the result, or null to indicate
   *         unknown or not applicable.
   */
  /*@Nullable*/ override def getIntegerBounds = getAction.getIntegerBounds

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = getAction.getImplementationMethod

  /**
   * Get the properties of this object to be included in trace messages, by supplying
   * the property values to a supplied consumer function
   *
   * @param consumer the function to which the properties should be supplied, as (property name,
   *                 value) pairs.
   */
  override def gatherProperties(consumer: BiConsumer[String, AnyRef]) = consumer.accept("name", getVariableQName)

  /**
   * Iterate over the result of the expression to return a sequence of items
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = { // minimize stack consumption by evaluating nested LET expressions iteratively
    var let = this
    while ( {
      true
    }) {
      val `val` = let.eval(context)
      context.setLocalVariable(let.getLocalSlotNumber, `val`)
      if (let.getAction.isInstanceOf[LetExpression]) let = let.getAction.asInstanceOf[LetExpression]
      else break //todo: break is not supported
    }
    let.getAction.iterate(context)
  }

  /**
   * Evaluate the variable.
   *
   * @param context the dynamic evaluation context
   * @return the result of evaluating the expression that is bound to the variable
   */
  @throws[XPathException]
  def eval(context: XPathContext) = {
    if (evaluator == null) setEvaluator(ExpressionTool.lazyEvaluator(getSequence, getNominalReferenceCount > 1))
    try {
      val savedOutputState = context.getTemporaryOutputState
      context.setTemporaryOutputState(StandardNames.XSL_VARIABLE)
      val result = evaluator.evaluate(getSequence, context)
      context.setTemporaryOutputState(savedOutputState)
      result
    } catch {
      case e: ClassCastException =>
        // Probably the evaluation mode is wrong, as a result of an expression rewrite. Try again.
        assert(false)
        val savedOutputState = context.getTemporaryOutputState
        context.setTemporaryOutputState(StandardNames.XSL_VARIABLE)
        val result = Evaluator.EAGER_SEQUENCE.evaluate(getSequence, context)
        context.setTemporaryOutputState(savedOutputState)
        result
    }
  }

  /**
   * Evaluate the expression as a singleton
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext) = {
    var let = this
    while ( {
      true
    }) {
      val `val` = let.eval(context)
      context.setLocalVariable(let.getLocalSlotNumber, `val`)
      if (let.getAction.isInstanceOf[LetExpression]) let = let.getAction.asInstanceOf[LetExpression]
      else break //todo: break is not supported
    }
    let.getAction.evaluateItem(context)
  }

  /**
   * Get the effective boolean value of the expression. This returns false if the value
   * is the empty sequence, a zero-length string, a number equal to zero, or the boolean
   * false. Otherwise it returns true.
   *
   * @param context The context in which the expression is to be evaluated
   * @return the effective boolean value
   * @throws net.sf.saxon.trans.XPathException
   * if any dynamic error occurs evaluating the
   * expression
   */
  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext) = {
    var let = this
    while ( {
      true
    }) {
      val `val` = let.eval(context)
      context.setLocalVariable(let.getLocalSlotNumber, `val`)
      if (let.getAction.isInstanceOf[LetExpression]) let = let.getAction.asInstanceOf[LetExpression]
      else break //todo: break is not supported
    }
    let.getAction.effectiveBooleanValue(context)
  }

  /**
   * Process this expression as an instruction, writing results to the current
   * outputter
   */
  @throws[XPathException]
  override def process(output: Outputter, context: XPathContext) = {
    var let = this
    while ( {
      true
    }) {
      val `val` = let.eval(context)
      context.setLocalVariable(let.getLocalSlotNumber, `val`)
      if (let.getAction.isInstanceOf[LetExpression]) let = let.getAction.asInstanceOf[LetExpression]
      else break //todo: break is not supported
    }
    let.getAction.process(output, context)
  }

  /**
   * Determine the data type of the items returned by the expression, if possible
   *
   * @return one of the values Type.STRING, Type.BOOLEAN, Type.NUMBER, Type.NODE,
   *         or Type.ITEM (meaning not known in advance)
   */
  override def getItemType = getAction.getItemType

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType the type of the context item
   */
  override def getStaticUType(contextItemType: UType): UType = {
    if (isInstruction) return UType.ANY
    getAction.getStaticUType(contextItemType)
  }

  /**
   * Determine the static cardinality of the expression
   */
  override def computeCardinality = getAction.getCardinality

  /**
   * Get the static properties of this expression (other than its type). The result is
   * bit-signficant. These properties are used for optimizations. In general, if
   * property bit is set, it is true, but if it is unset, the value is unknown.
   */
  override def computeSpecialProperties = {
    var props = getAction.getSpecialProperties
    val seqProps = getSequence.getSpecialProperties
    if ((seqProps & StaticProperty.NO_NODES_NEWLY_CREATED) eq 0) props &= ~StaticProperty.NO_NODES_NEWLY_CREATED
    props
  }

  /**
   * Mark tail function calls
   */
  override def markTailFunctionCalls(qName: StructuredQName, arity: Int) = ExpressionTool.markTailFunctionCalls(getAction, qName, arity)

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables whose binding needs to change
   */
  override def copy(rebindings: RebindingMap) = {
    val let = new LetExpression
    rebindings.put(this, let)
    let.isIndexedVariable = isIndexedVariable
    let.hasLoopingReference = hasLoopingReference
    let.setNeedsEagerEvaluation(needsEagerEvaluation)
    let.setNeedsLazyEvaluation(needsLazyEvaluation)
    let.setVariableQName(variableName)
    let.setRequiredType(requiredType)
    let.setSequence(getSequence.copy(rebindings))
    let.setInstruction(isInstruction)
    ExpressionTool.copyLocationInfo(this, let)
    val newAction = getAction.copy(rebindings)
    let.setAction(newAction)
    let
  }

  /**
   * ProcessLeavingTail: called to do the real work of this instruction.
   * The results of the instruction are written
   * to the current Receiver, which can be obtained via the Controller.
   *
   * @param output  the destination for the result
   * @param context The dynamic context of the transformation, giving access to the current node,
   *                the current variables, etc.
   * @return null if the instruction has completed execution; or a TailCall indicating
   *         a function call or template call that is delegated to the caller, to be made after the stack has
   *         been unwound so as to save stack space.
   */
  @throws[XPathException]
  override def processLeavingTail(output: Outputter, context: XPathContext) = {
    var let = this
    while ( {
      true
    }) {
      val `val` = let.eval(context)
      context.setLocalVariable(let.getLocalSlotNumber, `val`)
      if (let.getAction.isInstanceOf[LetExpression]) let = let.getAction.asInstanceOf[LetExpression]
      else break //todo: break is not supported
    }
    if (let.getAction.isInstanceOf[TailCallReturner]) let.getAction.asInstanceOf[TailCallReturner].processLeavingTail(output, context)
    else {
      let.getAction.process(output, context)
      null
    }
  }

  /**
   * Evaluate an updating expression, adding the results to a Pending Update List.
   * The default implementation of this method, which is used for non-updating expressions,
   * throws an UnsupportedOperationException
   *
   * @param context the XPath dynamic evaluation context
   * @param pul     the pending update list to which the results should be written
   */
  @throws[XPathException]
  override def evaluatePendingUpdates(context: XPathContext, pul: PendingUpdateList) = {
    var let = this
    while ( {
      true
    }) {
      val `val` = let.eval(context)
      context.setLocalVariable(let.getLocalSlotNumber, `val`)
      if (let.getAction.isInstanceOf[LetExpression]) let = let.getAction.asInstanceOf[LetExpression]
      else break //todo: break is not supported
    }
    let.getAction.evaluatePendingUpdates(context, pul)
  }

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   *
   * @return a representation of the expression as a string
   */
  override def toString = "let $" + getVariableEQName + " := " + getSequence + " return " + ExpressionTool.parenthesize(getAction)

  /**
   * Produce a short string identifying the expression for use in error messages
   *
   * @return a short string, sufficient to identify the expression
   */
  override def toShortString = "let $" + getVariableName + " := ..."

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    out.startElement("let", this)
    out.emitAttribute("var", variableName)
    if (getRequiredType ne SequenceType.ANY_SEQUENCE) out.emitAttribute("as", getRequiredType.toAlphaCode)
    if (isIndexedVariable) out.emitAttribute("indexable", "true")
    out.emitAttribute("slot", getLocalSlotNumber + "")
    if (evaluator == null) setEvaluator(ExpressionTool.lazyEvaluator(getSequence, getNominalReferenceCount > 1))
    out.emitAttribute("eval", getEvaluator.getEvaluationMode.getCode + "")
    getSequence.`export`(out)
    getAction.`export`(out)
    out.endElement
  }

  def setEvaluator(evaluator: Evaluator) = this.evaluator = evaluator

  def setEvaluationMode(mode: EvaluationMode.type) = this.evaluator = mode.getEvaluator

  def getEvaluator = evaluator
}