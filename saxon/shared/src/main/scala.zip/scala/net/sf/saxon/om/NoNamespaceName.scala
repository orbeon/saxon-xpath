////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

/**
 * An implementation of NodeName for the common case of a name in no namespace
 */
final class NoNamespaceName extends NodeName {
  private var localName = null
  private var nameCode = -1

  def this(localName: String) {
    this()
    this.localName = localName
  }

  def this(localName: String, nameCode: Int) {
    this()
    this.localName = localName
    this.nameCode = nameCode
  }

  /**
   * Get the prefix of the QName.
   *
   * @return the prefix. Returns the empty string if the name is unprefixed.
   */
  override def getPrefix = ""

  /**
   * Get the namespace URI of the QName.
   *
   * @return the URI. Returns the empty string to represent the no-namespace
   */
  override def getURI = ""

  /**
   * Get the local part of the QName
   *
   * @return the local part of the QName
   */
  override def getLocalPart = localName

  /**
   * Get the display name, that is the lexical QName in the form [prefix:]local-part
   *
   * @return the lexical QName
   */
  override def getDisplayName = localName

  /**
   * Get the name in the form of a StructuredQName
   *
   * @return the name in the form of a StructuredQName
   */
  override def getStructuredQName = new StructuredQName("", "", getLocalPart)

  /**
   * Test whether this name is in a given namespace
   *
   * @param ns the namespace to be tested against
   * @return true if the name is in the specified namespace
   */
  override def hasURI(ns: String) = ns.isEmpty

  /**
   * Get a {@link net.sf.saxon.om.NamespaceBinding} whose (prefix, uri) pair are the prefix and URI of this
   * node name
   *
   * @return the corresponding NamespaceBinding
   */
  override def getNamespaceBinding = NamespaceBinding.DEFAULT_UNDECLARATION

  /**
   * Ask whether this node name representation has a known namecode and fingerprint
   *
   * @return true if the methods getFingerprint() and getNameCode() will
   *         return a result other than -1
   */
  override def hasFingerprint = nameCode != -1

  /**
   * Get the fingerprint of this name if known. This method should not to any work to allocate
   * a fingerprint if none is already available
   *
   * @return the fingerprint if known; otherwise -1
   */
  override def getFingerprint = nameCode & NamePool.FP_MASK

  /**
   * Get the nameCode of this name, allocating a new code from the name pool if necessary
   *
   * @param namePool the NamePool used to allocate the name
   * @return a nameCode for this name, newly allocated if necessary
   */
  override def obtainFingerprint(namePool: NamePool) = if (nameCode == -1) nameCode = namePool.allocateFingerprint("", localName)
  else nameCode

  /**
   * Returns a hash code value for the object.
   */
  override def hashCode = StructuredQName.computeHashCode("", localName)

  /**
   * Indicates whether some other object is "equal to" this one.
   */
  override def equals(/*@NotNull*/ obj: Any) = obj.isInstanceOf[NodeName] && obj.asInstanceOf[NodeName].getLocalPart == localName && obj.asInstanceOf[NodeName].hasURI("")

  override def toString = localName

  /**
   * Determine whether two IdentityComparable objects are identical. This is a stronger
   * test than equality (even schema-equality); for example two dateTime values are not identical unless
   * they are in the same timezone.
   *
   * @param other the value to compare with
   * @return true if the two values are indentical, false otherwise
   */
  override def isIdentical(other: IdentityComparable) = other.isInstanceOf[NodeName] && this == other && other.asInstanceOf[NodeName].getPrefix.isEmpty

  /**
   * Get a hashCode that offers the guarantee that if A.isIdentical(B), then A.identityHashCode() == B.identityHashCode()
   *
   * @return a hashCode suitable for use when testing for identity.
   */
  override def identityHashCode = hashCode ^ getPrefix.hashCode
}