////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.expr.instruct.ResultDocument
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.regex.UnicodeString
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.tree.util.Navigator
import net.sf.saxon.z.IntHashMap
import java.util
import java.util.Properties

/**
 * This class handles a set of serialization parameters provided in the form of an XDM instance
 * as specified in the Serialization 3.0 definition, section 3.1
 */
object SerializationParamsHandler {
  val NAMESPACE = NamespaceConstant.OUTPUT

  /**
   * Check that no no-namespace attributes are present on an element, unless they have a specified local name
   *
   * @param element      the element to be checked
   * @param allowedNames a list of permitted local names of attributes, in sorted order
   * @throws XPathException if there is a no-namespace attribute present whose name is not the name supplied
   */
  @throws[XPathException]
  private def restrictAttributes(element: NodeInfo, allowedNames: String*) = {
    import scala.collection.JavaConversions._
    for (att <- element.attributes) {
      val name = att.getNodeName
      if ("" == name.getURI && util.Arrays.binarySearch(allowedNames, name.getLocalPart) < 0) throw new XPathException("In serialization parameters, attribute @" + name.getLocalPart + " must not appear on element " + element.getDisplayName, "SEPM0017")
    }
  }

  /**
   * Check that a given attribute is present on an element, and return its value
   *
   * @param element   the element to be checked
   * @param localName the required attribute
   * @return the value of the attribute
   * @throws XPathException if the attribute does not exist
   */
  @throws[XPathException]
  private def getAttribute(element: NodeInfo, localName: String) = {
    val value = element.getAttributeValue("", localName)
    if (value == null) throw new XPathException("In serialization parameters, attribute @" + localName + " is missing on element " + element.getDisplayName)
    value
  }
}

class SerializationParamsHandler() {
  private[serialize] var properties = null
  private[serialize] var characterMap = null
  private[serialize] var locator = null

  def this(props: Properties) {
    this()
    this.properties = props
  }

  /**
   * Set the location of the instruction to be used for error message reporting
   *
   * @param locator the location for error reporting
   */
  def setLocator(locator: Location) = this.locator = locator

  /**
   * Set the serialization parameters in the form of an XDM instance
   *
   * @param node either the serialization-parameters element node, or a document node having
   *             this element as its only child
   * @throws XPathException if incorrect serialization parameters are found
   */
  @throws[XPathException]
  def setSerializationParams(node: NodeInfo) = {
    if (properties == null) properties = new Properties
    if (node.getNodeKind == Type.DOCUMENT) node = Navigator.getOutermostElement(node.getTreeInfo)
    if (node.getNodeKind != Type.ELEMENT) throw new XPathException("Serialization params: node must be a document or element node")
    if (!(node.getLocalPart == "serialization-parameters")) throw new XPathException("Serialization params: element name must be 'serialization-parameters")
    if (!(node.getURI == SerializationParamsHandler.NAMESPACE)) throw new XPathException("Serialization params: element namespace must be " + SerializationParamsHandler.NAMESPACE)
    SerializationParamsHandler.restrictAttributes(node)
    val nodeNames = new util.HashSet[NodeName]
    val kids = node.iterateAxis(AxisInfo.CHILD, NodeKindTest.ELEMENT)
    var child = null
    while ( {
      (child = kids.next) != null
    }) {
      if (!nodeNames.add(NameOfNode.makeName(child))) throw new XPathException("Duplicated serialization parameter " + child.getDisplayName, "SEPM0019")
      val lname = child.getLocalPart
      var uri = child.getURI
      if (uri.isEmpty) throw new XPathException("Serialization parameter " + lname + " is in no namespace", "SEPM0017")
      if (NamespaceConstant.OUTPUT == uri) uri = ""
      if ("" == uri && lname == "use-character-maps") {
        SerializationParamsHandler.restrictAttributes(child)
        val gKids = child.iterateAxis(AxisInfo.CHILD, NodeKindTest.ELEMENT)
        var gChild = null
        val map = new IntHashMap[String]
        while ( {
          (gChild = gKids.next) != null
        }) {
          SerializationParamsHandler.restrictAttributes(gChild, "character", "map-string")
          if (!(gChild.getURI == SerializationParamsHandler.NAMESPACE && gChild.getLocalPart == "character-map")) if (gChild.getURI == SerializationParamsHandler.NAMESPACE || gChild.getURI.isEmpty) throw new XPathException("Invalid child of use-character-maps: " + gChild.getDisplayName, "SEPM0017")
          val ch = SerializationParamsHandler.getAttribute(gChild, "character")
          val str = SerializationParamsHandler.getAttribute(gChild, "map-string")
          val chValue = UnicodeString.makeUnicodeString(ch)
          if (chValue.uLength != 1) throw new XPathException("In the serialization parameters, the value of @character in the character map " + "must be a single Unicode character", "SEPM0017")
          val code = chValue.uCharAt(0)
          val prev = map.put(code, str)
          if (prev != null) throw new XPathException("In the serialization parameters, the character map contains two entries for the character \\u" + Integer.toHexString(65536 + code).substring(1), "SEPM0018")
        }
        characterMap = new CharacterMap(NameOfNode.makeName(node).getStructuredQName, map)
      }
      else {
        SerializationParamsHandler.restrictAttributes(child, "value")
        val value = SerializationParamsHandler.getAttribute(child, "value")
        try ResultDocument.setSerializationProperty(properties, uri, lname, value, child.getAllNamespaces, false, node.getConfiguration)
        catch {
          case err: XPathException =>
            if ("XQST0109" == err.getErrorCodeLocalPart || "SEPM0016" == err.getErrorCodeLocalPart) {
              if ("" == uri) {
                val e2 = new XPathException("Unknown serialization parameter " + Err.depict(child), "SEPM0017")
                e2.setLocator(locator)
                throw e2
              }
              // Unknown serialization parameter - no action, ignore the error
            }
            else throw err
        }
      }
    }
  }

  /**
   * Get the output properties represented by this serialization parameter document
   *
   * @return the output properties obtained by parsing and validating this serialization
   *         parameter document
   */
  def getSerializationProperties = {
    val index = new CharacterMapIndex
    if (characterMap != null) {
      index.putCharacterMap(new StructuredQName("", "", "charMap"), characterMap)
      properties.put(SaxonOutputKeys.USE_CHARACTER_MAPS, "charMap")
    }
    new SerializationProperties(properties, index)
  }

  def getCharacterMap = characterMap
}