////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.AttributeSet
import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.expr.instruct.UseAttributeSet
import net.sf.saxon.expr.parser.Optimizer
import net.sf.saxon.om._
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.trans.SymbolicName
import net.sf.saxon.trans.Visibility
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.value.Whitespace
import java.util

/**
 * An xsl:attribute-set element in the stylesheet. <br>
 */
class XSLAttributeSet extends StyleElement with StylesheetComponent {
  private var nameAtt = null
  /*@Nullable*/ private var useAtt = null
  private var visibilityAtt = null
  private var stackFrameMap = null
  private val attributeSetElements = new util.ArrayList[ComponentDeclaration]
  private var useAttributeSetNames = null
  private val containedInstructions = new util.ArrayList[Expression]
  private var validated = false
  private var visibility = null
  private var streamable = false

  /**
   * Get the corresponding Procedure object that results from the compilation of this
   * StylesheetProcedure
   */
  override def getActor = getPrincipalStylesheetModule.getStylesheetPackage.getComponent(new SymbolicName(StandardNames.XSL_ATTRIBUTE_SET, getObjectName)).getActor.asInstanceOf[AttributeSet]

  override def getSymbolicName = new SymbolicName(StandardNames.XSL_ATTRIBUTE_SET, getObjectName)

  /**
   * Check the compatibility of this component with another component that it is overriding
   *
   * @param component the overridden component
   * @throws XPathException if the components are not compatible (differing signatures)
   */
  @throws[XPathException]
  override def checkCompatibility(component: Component) = if (component.getActor.asInstanceOf[AttributeSet].isDeclaredStreamable && !isDeclaredStreamable) compileError("The overridden attribute set is declared streamable, " + "so the overriding attribute set must also be declared streamable")

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  /**
   * Get the name of this attribute set
   *
   * @return the name of the attribute set, as a QName
   */
  def getAttributeSetName = getObjectName

  /**
   * Ask whether the attribute set is declared streamable
   *
   * @return true if the attribute streamable="yes" is present
   */
  def isDeclaredStreamable = streamable

  override def prepareAttributes(): Unit = {
    useAtt = null
    var streamableAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "name" =>
          nameAtt = Whitespace.trim(value)
        case "use-attribute-sets" =>
          useAtt = value
        case "streamable" =>
          streamableAtt = value
        case "visibility" =>
          visibilityAtt = Whitespace.trim(value)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (nameAtt == null) {
      reportAbsence("name")
      setObjectName(new StructuredQName("", "", "attribute-set-error-name"))
      return
    }
    if (visibilityAtt == null) visibility = Visibility.PRIVATE
    else visibility = interpretVisibilityValue(visibilityAtt, "")
    if (streamableAtt != null) streamable = processStreamableAtt(streamableAtt)
    setObjectName(makeQName(nameAtt, null, "name"))
  }

  /**
   * Get a name identifying the object of the expression, for example a function name, template name,
   * variable name, key name, element name, etc. This is used only where the name is known statically.
   * If there is no name, the value will be null.
   *
   * @return the name of the object declared in this element, if any
   */
  override def getObjectName = {
    var o = super.getObjectName
    if (o == null) {
      prepareAttributes()
      o = getObjectName
    }
    o
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration): Unit = {
    if (validated) return
    checkTopLevel("XTSE0010", true)
    stackFrameMap = getConfiguration.makeSlotManager
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLAttribute]) if (visibility eq Visibility.ABSTRACT) compileError("An abstract attribute-set must contain no xsl:attribute instructions")
      else compileError("Only xsl:attribute is allowed within xsl:attribute-set", "XTSE0010")
    }
    if (useAtt != null) {
      if (visibility eq Visibility.ABSTRACT) compileError("An abstract attribute-set must have no @use-attribute-sets attribute")
      // identify any attribute sets that this one refers to
      useAttributeSetNames = getUsedAttributeSets(useAtt)
    }
    validated = true
  }

  def getUseAttributeSetNames = useAttributeSetNames

  @throws[XPathException]
  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = top.indexAttributeSet(decl)

  /**
   * Check for circularity: specifically, check that this attribute set does not contain
   * a direct or indirect reference to the one supplied as a parameter
   *
   * @param origin the place from which the search started
   * @throws net.sf.saxon.trans.XPathException
   * if an error is found
   */
  @throws[XPathException]
  def checkCircularity(origin: XSLAttributeSet): Unit = if (this eq origin) compileError("The definition of the attribute set is circular", "XTSE0720")
  else {
    if (!validated) { // if this attribute set isn't validated yet, we don't check it.
      // The circularity will be detected when the last attribute set in the cycle
      // gets validated
      return
    }
    if (attributeSetElements != null) {
      import scala.collection.JavaConversions._
      for (attributeSetElement <- attributeSetElements) {
        val element = attributeSetElement.getSourceElement.asInstanceOf[XSLAttributeSet]
        element.checkCircularity(origin)
        if (streamable && !element.streamable) compileError("Attribute-set is declared streamable but references a non-streamable attribute set " + element.getAttributeSetName.getDisplayName, "XTSE3430")
      }
    }
  }

  /**
   * Get the contained xsl:attribute instructions, in compiled form
   *
   * @return the list of contained instructions. This does not include any xsl:use-attribute-set references.
   */
  def getContainedInstructions = containedInstructions

  /**
   * Get details of stack frame
   */
  override def getSlotManager = stackFrameMap

  /**
   * Compile the attribute set
   *
   * @param compilation the current compilation episode
   * @param decl        this attribute set declaration
   * @throws XPathException if a failure is detected
   */
  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration): Unit = {
    if (isActionCompleted(ACTION_COMPILE)) return
    if (useAtt != null) {
      val invocations = UseAttributeSet.makeUseAttributeSetInstructions(useAttributeSetNames, this)
      if (!invocations.isEmpty) containedInstructions.add(UseAttributeSet.makeCompositeExpression(invocations))
      // check for circularity, to the extent possible within a single package
      for (name <- useAttributeSetNames) {
        getPrincipalStylesheetModule.getAttributeSets(name, attributeSetElements)
      }
      import scala.collection.JavaConversions._
      for (attributeSetElement <- attributeSetElements) {
        attributeSetElement.getSourceElement.asInstanceOf[XSLAttributeSet].checkCircularity(this)
      }
      // check for consistency of streamability attribute
      if (streamable) {
        import scala.collection.JavaConversions._
        for (attributeSetElement <- attributeSetElements) {
          if (!(attributeSetElement.getSourceElement.asInstanceOf[XSLAttributeSet]).streamable) compileError("Attribute set is declared streamable, " + "but references an attribute set that is not declared streamable", "XTSE0730")
        }
      }
    }
    var node = null
    val iter = iterateAxis(AxisInfo.CHILD, NodeKindTest.ELEMENT)
    while ( {
      (node = iter.next.asInstanceOf[XSLAttribute]) != null
    }) {
      var inst = node.compile(compilation, decl)
      inst.setRetainedStaticContext(makeRetainedStaticContext)
      inst = inst.simplify
      if (compilation.getCompilerInfo.isCompileWithTracing) inst = makeTraceInstruction(this, inst)
      containedInstructions.add(inst)
    }
    setActionCompleted(ACTION_COMPILE)
  }

  /**
   * Optimize the stylesheet construct
   *
   * @param declaration this attribute set declaration
   */
  @throws[XPathException]
  override def optimize(declaration: ComponentDeclaration) = {
    // Already done earlier
  }

  /**
   * Generate byte code if appropriate
   *
   * @param opt the optimizer
   */
  override def generateByteCode(opt: Optimizer) = {
  }

  //    private void checkStreamability() throws XPathException {
  ////#ifdefined STREAM
  //         if (streamable) {
  //             ContextItemStaticInfo info = new ContextItemStaticInfo(AnyItemType.getInstance(), false, true);
  //             procedure.getBody().getStreamability(false, info, null);
  //             if (procedure.getBody().getSweep() != Sweep.MOTIONLESS) {
  //                 compileError("The attribute set is declared streamable but it is not motionless", "XTSE3430");
  //             }
  //         }
  ////#endif
  //     }
}