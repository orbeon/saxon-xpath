////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.trans.XPathException

/**
 * An xsl:on-completion element in the stylesheet (XSLT 3.0). <br>
 */
class XSLOnCompletion extends StyleElement {
  private var select = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    val parent = getParent.asInstanceOf[StyleElement]
    if (!parent.isInstanceOf[XSLIterate]) compileError("xsl:on-completion is not allowed as a child of " + parent.getDisplayName, "XTSE0010")
    // See W3C bug 24179, which changes the position of xsl:on-completion within xsl:iterate
    // For the time being we allow it anywhere, and give a warning if it is in the wrong place
    iterateAxis(AxisInfo.PRECEDING_SIBLING, NodeKindTest.ELEMENT).forEach((sib: Item) => {
      def foo(sib: Item) = {
        if (!(sib.isInstanceOf[XSLFallback] || sib.isInstanceOf[XSLLocalParam])) compileWarning("The rules for xsl:iterate have changed (see W3C bug 24179): " + "xsl:on-completion must now be the first child of xsl:iterate after the xsl:param elements", "XTSE0010")
      }

      foo(sib)
    })
    if (select != null && iterateAxis(AxisInfo.CHILD).next != null) compileError("An xsl:on-completion element with a select attribute must be empty", "XTSE3125")
    select = typeCheck("select", select)
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = if (select == null) compileSequenceConstructor(exec, decl, true)
  else select
}