////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser._
import net.sf.saxon.expr.sort.GlobalOrderComparer
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.UType
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.BooleanValue
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.SequenceType

/**
 * IdentityComparison: a boolean expression that compares two nodes
 * for equals, not-equals, greater-than or less-than based on identity and
 * document ordering
 */
object IdentityComparison {
  @throws[XPathException]
  private def getNode(exp: Expression, c: XPathContext) = exp.evaluateItem(c).asInstanceOf[NodeInfo]
}

final class IdentityComparison(val p1: Expression, val op: Int, val p2: Expression)

/**
 * Create an identity comparison identifying the two operands and the operator
 *
 * @param p1 the left-hand operand
 * @param op the operator, as a token returned by the Tokenizer (e.g. Token.LT)
 * @param p2 the right-hand operand
 */
  extends BinaryExpression(p1, op, p2) {
  private var generateIdEmulation = false

  /**
   * Set flag to indicate different empty-sequence behavior when emulating
   * comparison of two generate-id's. This is relevant when operands evaluate
   * to an empty sequence; if both are empty, the "is" operator returns (), while the
   * generate-id() comparison compares two empty strings, which returns true; if one is
   * empty, the "is" operator returns (), while the generate-id() comparison returns false.
   *
   * @param flag true if this function is being used to compare generate-id() output
   */
  def setGenerateIdEmulation(flag: Boolean) = generateIdEmulation = flag

  /**
   * Test the flag that indicates different empty-sequence behavior when emulating
   * comparison of two generate-id's
   *
   * @return true if this function is being used to compare generate-id() output
   */
  def isGenerateIdEmulation = generateIdEmulation

  /**
   * Type-check the expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    getLhs.typeCheck(visitor, contextInfo)
    getRhs.typeCheck(visitor, contextInfo)
    if (!generateIdEmulation) if (Literal.isEmptySequence(getLhsExpression) || Literal.isEmptySequence(getRhsExpression)) return Literal.makeEmptySequence
    val role0 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 0)
    val tc = visitor.getConfiguration.getTypeChecker(false)
    //role0.setSourceLocator(this);
    setLhsExpression(tc.staticTypeCheck(getLhsExpression, SequenceType.OPTIONAL_NODE, role0, visitor))
    val role1 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 1)
    //role1.setSourceLocator(this);
    setRhsExpression(tc.staticTypeCheck(getRhsExpression, SequenceType.OPTIONAL_NODE, role1, visitor))
    if (!Cardinality.allowsZero(getLhsExpression.getCardinality) && !Cardinality.allowsZero(getRhsExpression.getCardinality)) {
      generateIdEmulation = false
      // because the flag only makes a difference if one of the operands evaluates to ()
    }
    this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    val r = super.optimize(visitor, contextItemType)
    if (r ne this) if (!generateIdEmulation) if (Literal.isEmptySequence(getLhsExpression) || Literal.isEmptySequence(getRhsExpression)) return Literal.makeEmptySequence
    r
  }

  override protected def getOperandRole(arg: Int) = OperandRole.INSPECT

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings
   */
  override def copy(rebindings: RebindingMap) = {
    val ic = new IdentityComparison(getLhsExpression.copy(rebindings), operator, getRhsExpression.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, ic)
    ic.generateIdEmulation = generateIdEmulation
    ic
  }

  /**
   * Get the element name used to identify this expression in exported expression format
   *
   * @return the element name used to identify this expression
   */
  override protected def tag = operator match {
    case Token.IS =>
      "is"
    case Token.PRECEDES =>
      "precedes"
    case Token.FOLLOWS =>
      "follows"
    case _ =>
      "?"
  }

  /**
   * Evaluate the expression
   */
  /*@Nullable*/ @throws[XPathException]
  override def evaluateItem(context: XPathContext): BooleanValue = {
    val node0 = IdentityComparison.getNode(getLhsExpression, context)
    if (node0 == null) {
      if (generateIdEmulation) return BooleanValue.get(IdentityComparison.getNode(getRhsExpression, context) == null)
      return null
    }
    val node1 = IdentityComparison.getNode(getRhsExpression, context)
    if (node1 == null) {
      if (generateIdEmulation) return BooleanValue.FALSE
      return null
    }
    BooleanValue.get(compareIdentity(node0, node1))
  }

  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext): Boolean = {
    val node0 = IdentityComparison.getNode(getLhsExpression, context)
    if (node0 == null) return generateIdEmulation && IdentityComparison.getNode(getRhsExpression, context) == null
    val node1 = IdentityComparison.getNode(getRhsExpression, context)
    node1 != null && compareIdentity(node0, node1)
  }

  private def compareIdentity(node0: NodeInfo, node1: NodeInfo) = operator match {
    case Token.IS =>
      node0 == node1
    case Token.PRECEDES =>
      GlobalOrderComparer.getInstance.compare(node0, node1) < 0
    case Token.FOLLOWS =>
      GlobalOrderComparer.getInstance.compare(node0, node1) > 0
    case _ =>
      throw new UnsupportedOperationException("Unknown node identity test")
  }

  /**
   * Determine the data type of the expression
   *
   * @return Type.BOOLEAN
   */
  override def getItemType = BuiltInAtomicType.BOOLEAN

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType
   */
  override def getStaticUType(contextItemType: UType) = UType.BOOLEAN

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in export() output displaying the expression.
   */
  override def getExpressionName = "nodeComparison"
}