////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.Token
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.Converter
import net.sf.saxon.model.Type
import net.sf.saxon.om.StandardNames
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value._
import net.sf.saxon.z.IntHashMap
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode

/**
 * This class evaluates arithmetic expressions; it acts as a helper class to the ArithmeticExpression
 * class. There are many subclasses for the different kinds of arithmetic expression, and static methods
 * that allow the right subclass to be selected, either at compile time or at run time.
 */
object Calculator {
  val PLUS = 0
  val MINUS = 1
  val TIMES = 2
  val DIV = 3
  val MOD = 4
  val IDIV = 5

  /**
   * Get the token number corresponding to the operator number
   *
   * @param operator the Calculator operator code
   * @return the corresponding token
   */
  def getTokenFromOperator(operator: Int) = tokens(operator)

  private val tokens = Array[Int](Token.PLUS, Token.MINUS, Token.MULT, Token.DIV, Token.MOD, Token.IDIV)
  /**
   * Calculators used for the six operators when the static type information does not allow
   * a more specific calculator to be chosen
   */
  val ANY_ANY = Array(new Calculator.AnyPlusAny, new Calculator.AnyMinusAny, new Calculator.AnyTimesAny, new Calculator.AnyDivAny, new Calculator.AnyModAny, new Calculator.AnyIdivAny)
  /**
   * Calculators used when the first operand is a double
   */
  val DOUBLE_DOUBLE = Array(new Calculator.DoublePlusDouble, new Calculator.DoubleMinusDouble, new Calculator.DoubleTimesDouble, new Calculator.DoubleDivDouble, new Calculator.DoubleModDouble, new Calculator.DoubleIdivDouble)
  val DOUBLE_FLOAT = DOUBLE_DOUBLE
  val DOUBLE_DECIMAL = DOUBLE_DOUBLE
  val DOUBLE_INTEGER = DOUBLE_DOUBLE
  /**
   * Calculators used when the first operand is a float
   */
  val FLOAT_DOUBLE = DOUBLE_DOUBLE
  val FLOAT_FLOAT = Array(new Calculator.FloatPlusFloat, new Calculator.FloatMinusFloat, new Calculator.FloatTimesFloat, new Calculator.FloatDivFloat, new Calculator.FloatModFloat, new Calculator.FloatIdivFloat)
  val FLOAT_DECIMAL = FLOAT_FLOAT
  //public final static Calculator[] FLOAT_PDECIMAL = FLOAT_FLOAT;
  val FLOAT_INTEGER = FLOAT_FLOAT
  /**
   * Calculators used when the first operand is a decimal
   */
  val DECIMAL_DOUBLE = DOUBLE_DOUBLE
  val DECIMAL_FLOAT = FLOAT_FLOAT
  val DECIMAL_DECIMAL = Array(new Calculator.DecimalPlusDecimal, new Calculator.DecimalMinusDecimal, new Calculator.DecimalTimesDecimal, new Calculator.DecimalDivDecimal, new Calculator.DecimalModDecimal, new Calculator.DecimalIdivDecimal)
  val DECIMAL_INTEGER = DECIMAL_DECIMAL
  /**
   * Calculators used when the first operand is an integer
   */
  val INTEGER_DOUBLE = DOUBLE_DOUBLE
  val INTEGER_FLOAT = FLOAT_FLOAT
  val INTEGER_DECIMAL = DECIMAL_DECIMAL
  val INTEGER_INTEGER = Array(new Calculator.IntegerPlusInteger, new Calculator.IntegerMinusInteger, new Calculator.IntegerTimesInteger, new Calculator.IntegerDivInteger, new Calculator.IntegerModInteger, new Calculator.IntegerIdivInteger)
  /**
   * Calculators used when both operands are xs:dateTime, xs:date, or xs:time
   */
  /*@Nullable*/ val DATETIME_DATETIME = Array(null, new Calculator.DateTimeMinusDateTime, null, null, null, null)
  /**
   * Calculators used when the first operand is xs:dateTime, xs:date, or xs:time,
   * and the second is a duration
   */
  val DATETIME_DURATION = Array(new Calculator.DateTimePlusDuration, new Calculator.DateTimeMinusDuration, null, null, null, null)
  /**
   * Calculators used when the second operand is xs:dateTime, xs:date, or xs:time,
   * and the first is a duration
   */
  val DURATION_DATETIME = Array(new Calculator.DurationPlusDateTime, null, null, null, null, null)
  /**
   * Calculators used when the both operands are durations
   */
  val DURATION_DURATION = Array(new Calculator.DurationPlusDuration, new Calculator.DurationMinusDuration, null, new Calculator.DurationDivDuration, null, null)
  /**
   * Calculators used when the first operand is a duration and the second is numeric
   */
  val DURATION_NUMERIC = Array(null, null, new Calculator.DurationTimesNumeric, new Calculator.DurationDivNumeric, null, null)
  /**
   * Calculators used when the second operand is a duration and the first is numeric
   */
  val NUMERIC_DURATION = Array(null, null, new Calculator.NumericTimesDuration, null, null, null)
  /**
   * Table mapping argument types to the Calculator class used to implement them
   */
  private val table = new IntHashMap[Array[Calculator]](100)
  private val nameTable = new IntHashMap[String](100)

  private def `def`(typeA: Int, typeB: Int, calculatorSet: Array[Calculator], setName: String) = {
    val key = (typeA & 0xffff) << 16 | (typeB & 0xffff)
    table.put(key, calculatorSet)
    nameTable.put(key, setName)
    // As well as the entries added directly, we also add derived entries for other types
    // considered primitive
    if (typeA == StandardNames.XS_DURATION) {
      `def`(StandardNames.XS_DAY_TIME_DURATION, typeB, calculatorSet, setName)
      `def`(StandardNames.XS_YEAR_MONTH_DURATION, typeB, calculatorSet, setName)
    }
    if (typeB == StandardNames.XS_DURATION) {
      `def`(typeA, StandardNames.XS_DAY_TIME_DURATION, calculatorSet, setName)
      `def`(typeA, StandardNames.XS_YEAR_MONTH_DURATION, calculatorSet, setName)
    }
    if (typeA == StandardNames.XS_DATE_TIME) {
      `def`(StandardNames.XS_DATE, typeB, calculatorSet, setName)
      `def`(StandardNames.XS_TIME, typeB, calculatorSet, setName)
    }
    if (typeB == StandardNames.XS_DATE_TIME) {
      `def`(typeA, StandardNames.XS_DATE, calculatorSet, setName)
      `def`(typeA, StandardNames.XS_TIME, calculatorSet, setName)
    }
    if (typeA == StandardNames.XS_DOUBLE) `def`(StandardNames.XS_UNTYPED_ATOMIC, typeB, calculatorSet, setName)
    if (typeB == StandardNames.XS_DOUBLE) `def`(typeA, StandardNames.XS_UNTYPED_ATOMIC, calculatorSet, setName)
  }

  /**
   * Factory method to get a calculator for a given combination of types
   *
   * @param typeA       fingerprint of the primitive type of the first operand
   * @param typeB       fingerprint of the primitive type of the second operand
   * @param operator    the arithmetic operator in use
   * @param mustResolve indicates that a concrete Calculator is required (rather than
   *                    an ANY_ANY calculator which needs to be further resolved at run-time)
   * @return null if no suitable Calculator can be found.
   */
  def getCalculator(typeA: Int, typeB: Int, operator: Int, mustResolve: Boolean) = {
    val key = (typeA & 0xffff) << 16 | (typeB & 0xffff)
    val set = table.get(key)
    if (set == null) if (mustResolve) null
    else ANY_ANY(operator)
    else set(operator)
  }

  /**
   * Get a calculator given the short code used in the exported expression tree
   *
   * @param code the short code, e.g. i+i for IntegerPlusInteger
   * @return the appropriate Calculator
   */
  def reconstructCalculator(code: String) = {
    val typeA = typeFromCode(code.charAt(0))
    val typeB = typeFromCode(code.charAt(2))
    val operator = operatorFromCode(code.charAt(1))
    getCalculator(typeA, typeB, operator, false)
  }

  private def typeFromCode(code: Char) = code match {
    case 'a' =>
      StandardNames.XS_ANY_ATOMIC_TYPE
    case 'd' =>
      StandardNames.XS_DOUBLE
    case 'i' =>
      StandardNames.XS_INTEGER
    case 'f' =>
      StandardNames.XS_FLOAT
    case 'c' =>
      StandardNames.XS_DECIMAL
    case 'n' =>
      StandardNames.XS_NUMERIC
    case 't' =>
      StandardNames.XS_DATE_TIME
    case 'u' =>
      StandardNames.XS_DURATION
    case _ =>
      throw new AssertionError
  }

  def operatorFromCode(code: Char) = code match {
    case '+' =>
      PLUS
    case '-' =>
      MINUS
    case '*' =>
      TIMES
    case '/' =>
      DIV
    case '~' =>
      IDIV
    case '%' =>
      MOD
    case _ =>
      throw new AssertionError
  }

  /**
   * Get the name of the calculator set for a given combination of types
   *
   * @param typeA the fingerprint of the primitive type of the first operand
   * @param typeB the fingerprint of the primitive type of the second operand
   * @return null if no suitable Calculator can be found.
   */
  def getCalculatorSetName(typeA: Int, typeB: Int) = {
    val key = (typeA & 0xffff) << 16 | (typeB & 0xffff)
    nameTable.get(key)
  }

  /**
   * Arithmetic: anyAtomicType + AnyAtomicType
   */
  class AnyPlusAny extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val calc = getCalculator(a.getItemType.getPrimitiveType, b.getItemType.getPrimitiveType, PLUS, true)
      if (calc == null) throw new XPathException("Unsuitable types for + operation (" + Type.displayTypeName(a) + ", " + Type.displayTypeName(b) + ")", "XPTY0004", c)
      else calc.compute(a, b, c)
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.ANY_ATOMIC
  }

  /**
   * Arithmetic: anyAtomicType - AnyAtomicType
   */
  class AnyMinusAny extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val calc = getCalculator(a.getItemType.getPrimitiveType, b.getItemType.getPrimitiveType, MINUS, true)
      if (calc == null) throw new XPathException("Unsuitable types for - operation (" + Type.displayTypeName(a) + ", " + Type.displayTypeName(b) + ")", "XPTY0004", c)
      else calc.compute(a, b, c)
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.ANY_ATOMIC
  }

  /**
   * Arithmetic: anyAtomicType * AnyAtomicType
   */
  class AnyTimesAny extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val calc = getCalculator(a.getItemType.getPrimitiveType, b.getItemType.getPrimitiveType, TIMES, true)
      if (calc == null) throw new XPathException("Unsuitable types for * operation (" + Type.displayTypeName(a) + ", " + Type.displayTypeName(b) + ")", "XPTY0004", c)
      else calc.compute(a, b, c)
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.ANY_ATOMIC
  }

  /**
   * Arithmetic: anyAtomicType div AnyAtomicType
   */
  class AnyDivAny extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val calc = getCalculator(a.getItemType.getPrimitiveType, b.getItemType.getPrimitiveType, DIV, true)
      if (calc == null) throw new XPathException("Unsuitable types for div operation (" + Type.displayTypeName(a) + ", " + Type.displayTypeName(b) + ")", "XPTY0004", c)
      else calc.compute(a, b, c)
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.ANY_ATOMIC
  }

  /**
   * Arithmetic: anyAtomicType mod AnyAtomicType
   */
  class AnyModAny extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val calc = getCalculator(a.getItemType.getPrimitiveType, b.getItemType.getPrimitiveType, MOD, true)
      if (calc == null) throw new XPathException("Unsuitable types for mod operation (" + Type.displayTypeName(a) + ", " + Type.displayTypeName(b) + ")", "XPTY0004", c)
      else calc.compute(a, b, c)
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.ANY_ATOMIC
  }

  /**
   * Arithmetic: anyAtomicType idiv AnyAtomicType
   */
  class AnyIdivAny extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val calc = getCalculator(a.getItemType.getPrimitiveType, b.getItemType.getPrimitiveType, IDIV, true)
      if (calc == null) throw new XPathException("Unsuitable types for idiv operation (" + Type.displayTypeName(a) + ", " + Type.displayTypeName(b) + ")", "XPTY0004", c)
      else calc.compute(a, b, c)
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.ANY_ATOMIC
  }

  /**
   * Arithmetic: double + double (including types that promote to double)
   */
  class DoublePlusDouble extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new DoubleValue(a.asInstanceOf[NumericValue].getDoubleValue + b.asInstanceOf[NumericValue].getDoubleValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DOUBLE
  }

  /**
   * Arithmetic: double - double (including types that promote to double)
   */
  class DoubleMinusDouble extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new DoubleValue(a.asInstanceOf[NumericValue].getDoubleValue - b.asInstanceOf[NumericValue].getDoubleValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DOUBLE
  }

  /**
   * Arithmetic: double * double (including types that promote to double)
   */
  class DoubleTimesDouble extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new DoubleValue(a.asInstanceOf[NumericValue].getDoubleValue * b.asInstanceOf[NumericValue].getDoubleValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DOUBLE
  }

  /**
   * Arithmetic: double div double (including types that promote to double)
   */
  class DoubleDivDouble extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new DoubleValue(a.asInstanceOf[NumericValue].getDoubleValue / b.asInstanceOf[NumericValue].getDoubleValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DOUBLE
  }

  /**
   * Arithmetic: double mod double (including types that promote to double)
   */
  class DoubleModDouble extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new DoubleValue(a.asInstanceOf[NumericValue].getDoubleValue % b.asInstanceOf[NumericValue].getDoubleValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DOUBLE
  }

  /**
   * Arithmetic: double idiv double (including types that promote to double)
   */
  private class DoubleIdivDouble extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val A = a.asInstanceOf[NumericValue].getDoubleValue
      val B = b.asInstanceOf[NumericValue].getDoubleValue
      if (B == 0.0) throw new XPathException("Integer division by zero", "FOAR0001", c)
      if (Double.isNaN(A) || Double.isInfinite(A)) throw new XPathException("First operand of idiv is NaN or infinity", "FOAR0002", c)
      if (Double.isNaN(B)) throw new XPathException("Second operand of idiv is NaN", "FOAR0002", c)
      IntegerValue.makeIntegerValue(new DoubleValue(A / B)).asAtomic
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.INTEGER
  }

  /**
   * Arithmetic: float + float (including types that promote to float)
   */
  class FloatPlusFloat extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new FloatValue(a.asInstanceOf[NumericValue].getFloatValue + b.asInstanceOf[NumericValue].getFloatValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.FLOAT
  }

  /**
   * Arithmetic: float - float (including types that promote to float)
   */
  class FloatMinusFloat extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new FloatValue(a.asInstanceOf[NumericValue].getFloatValue - b.asInstanceOf[NumericValue].getFloatValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.FLOAT
  }

  /**
   * Arithmetic: float * float (including types that promote to float)
   */
  class FloatTimesFloat extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new FloatValue(a.asInstanceOf[NumericValue].getFloatValue * b.asInstanceOf[NumericValue].getFloatValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.FLOAT
  }

  /**
   * Arithmetic: float div float (including types that promote to float)
   */
  class FloatDivFloat extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new FloatValue(a.asInstanceOf[NumericValue].getFloatValue / b.asInstanceOf[NumericValue].getFloatValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.FLOAT
  }

  /**
   * Arithmetic: float mod float (including types that promote to float)
   */
  class FloatModFloat extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = new FloatValue(a.asInstanceOf[NumericValue].getFloatValue % b.asInstanceOf[NumericValue].getFloatValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.FLOAT
  }

  /**
   * Arithmetic: float idiv float (including types that promote to float)
   */
  class FloatIdivFloat extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val A = a.asInstanceOf[NumericValue].getFloatValue
      val B = b.asInstanceOf[NumericValue].getFloatValue
      if (B == 0.0) throw new XPathException("Integer division by zero", "FOAR0001", c)
      if (Float.isNaN(A) || Float.isInfinite(A)) throw new XPathException("First operand of idiv is NaN or infinity", "FOAR0002", c)
      if (Float.isNaN(B)) throw new XPathException("Second operand of idiv is NaN", "FOAR0002", c)
      val quotient = A / B
      if (Float.isInfinite(quotient)) { // bug 29171, test cbcl-numeric-idivide-008
        new Calculator.DecimalIdivDecimal().compute(new BigDecimalValue(a.asInstanceOf[NumericValue].getDecimalValue), new BigDecimalValue(b.asInstanceOf[NumericValue].getDecimalValue), c)
      }
      else Converter.FloatToInteger.INSTANCE.convert(new FloatValue(quotient)).asAtomic.asInstanceOf[IntegerValue]
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.INTEGER
  }

  /**
   * Arithmetic: decimal + decimal (including types that promote to decimal, that is, integer)
   */
  class DecimalPlusDecimal extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = if (a.isInstanceOf[IntegerValue] && b.isInstanceOf[IntegerValue]) a.asInstanceOf[IntegerValue].plus(b.asInstanceOf[IntegerValue])
    else new BigDecimalValue(a.asInstanceOf[NumericValue].getDecimalValue.add(b.asInstanceOf[NumericValue].getDecimalValue))

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DECIMAL
  }

  /**
   * Arithmetic: decimal - decimal (including types that promote to decimal, that is, integer)
   */
  class DecimalMinusDecimal extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = if (a.isInstanceOf[IntegerValue] && b.isInstanceOf[IntegerValue]) a.asInstanceOf[IntegerValue].minus(b.asInstanceOf[IntegerValue])
    else new BigDecimalValue(a.asInstanceOf[NumericValue].getDecimalValue.subtract(b.asInstanceOf[NumericValue].getDecimalValue))

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DECIMAL
  }

  /**
   * Arithmetic: decimal * decimal (including types that promote to decimal, that is, integer)
   */
  class DecimalTimesDecimal extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = if (a.isInstanceOf[IntegerValue] && b.isInstanceOf[IntegerValue]) a.asInstanceOf[IntegerValue].times(b.asInstanceOf[IntegerValue])
    else new BigDecimalValue(a.asInstanceOf[NumericValue].getDecimalValue.multiply(b.asInstanceOf[NumericValue].getDecimalValue))

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DECIMAL
  }

  /**
   * Arithmetic: decimal div decimal (including types that promote to decimal, that is, integer)
   */
  class DecimalDivDecimal extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = decimalDivide(a.asInstanceOf[NumericValue], b.asInstanceOf[NumericValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DECIMAL
  }

  @throws[XPathException]
  def decimalDivide(a: NumericValue, b: NumericValue) = {
    val A = a.getDecimalValue
    val B = b.getDecimalValue
    //        int scale = Math.max(DecimalValue.DIVIDE_PRECISION,
    //                Math.max(A.scale(), B.scale()));
    val scale = Math.max(BigDecimalValue.DIVIDE_PRECISION, A.scale - B.scale + BigDecimalValue.DIVIDE_PRECISION)
    try {
      val result = A.divide(B, scale, RoundingMode.HALF_DOWN)
      new BigDecimalValue(result)
    } catch {
      case err: ArithmeticException =>
        if (b.compareTo(0) == 0) throw new XPathException("Decimal divide by zero", "FOAR0001")
        else throw err
    }
  }

  /**
   * Arithmetic: decimal mod decimal (including types that promote to decimal, that is, integer)
   */
  class DecimalModDecimal extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext): AtomicValue = {
      if (a.isInstanceOf[IntegerValue] && b.isInstanceOf[IntegerValue]) return a.asInstanceOf[IntegerValue].mod(b.asInstanceOf[IntegerValue])
      val A = a.asInstanceOf[NumericValue].getDecimalValue
      val B = b.asInstanceOf[NumericValue].getDecimalValue
      try //BigDecimal quotient = A.divide(B, 0, BigDecimal.ROUND_DOWN);
        //BigDecimal remainder = A.subtract(quotient.multiply(B));
        new BigDecimalValue(A.remainder(B))
      catch {
        case err: ArithmeticException =>
          if (b.asInstanceOf[NumericValue].compareTo(0) == 0) throw new XPathException("Decimal modulo zero", "FOAR0001", c)
          else throw err
      }
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DECIMAL
  }

  /**
   * Arithmetic: decimal idiv decimal (including types that promote to decimal, that is, integer)
   */
  class DecimalIdivDecimal extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext): IntegerValue = {
      if (a.isInstanceOf[IntegerValue] && b.isInstanceOf[IntegerValue]) return a.asInstanceOf[IntegerValue].idiv(b.asInstanceOf[IntegerValue])
      val A = a.asInstanceOf[NumericValue].getDecimalValue
      val B = b.asInstanceOf[NumericValue].getDecimalValue
      if (B.signum == 0) throw new XPathException("Integer division by zero", "FOAR0001", c)
      //BigInteger quot = A.divide(B, 0, BigDecimal.ROUND_DOWN).toBigInteger();
      val quot = A.divideToIntegralValue(B).toBigInteger
      BigIntegerValue.makeIntegerValue(quot)
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.INTEGER
  }

  /**
   * Arithmetic: integer + integer
   */
  class IntegerPlusInteger extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[IntegerValue].plus(b.asInstanceOf[IntegerValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.INTEGER
  }

  /**
   * Arithmetic: integer - integer
   */
  class IntegerMinusInteger extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[IntegerValue].minus(b.asInstanceOf[IntegerValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.INTEGER
  }

  /**
   * Arithmetic: integer * integer
   */
  class IntegerTimesInteger extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[IntegerValue].times(b.asInstanceOf[IntegerValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.INTEGER
  }

  /**
   * Arithmetic: integer div integer
   */
  class IntegerDivInteger extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[IntegerValue].div(b.asInstanceOf[IntegerValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DECIMAL
  }

  /**
   * Arithmetic: integer mod integer
   */
  class IntegerModInteger extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[IntegerValue].mod(b.asInstanceOf[IntegerValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.INTEGER
  }

  /**
   * Arithmetic: integer idiv integer
   */
  class IntegerIdivInteger extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[IntegerValue].idiv(b.asInstanceOf[IntegerValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.INTEGER
  }

  /**
   * Arithmetic: date/time/dateTime - date/time/dateTime
   */
  private class DateTimeMinusDateTime extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[CalendarValue].subtract(b.asInstanceOf[CalendarValue], c)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DAY_TIME_DURATION
  }

  /**
   * Arithmetic: date/time/dateTime + duration
   */
  private class DateTimePlusDuration extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[CalendarValue].add(b.asInstanceOf[DurationValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = typeA
  }

  /**
   * Arithmetic: date/time/dateTime - duration
   */
  private class DateTimeMinusDuration extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[CalendarValue].add(b.asInstanceOf[DurationValue].negate)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = typeA
  }

  /**
   * Arithmetic: duration + date/time/dateTime
   */
  private class DurationPlusDateTime extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = b.asInstanceOf[CalendarValue].add(a.asInstanceOf[DurationValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = typeB
  }

  /**
   * Arithmetic: duration + duration
   */
  private class DurationPlusDuration extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[DurationValue].add(b.asInstanceOf[DurationValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = typeA
  }

  /**
   * Arithmetic: duration - duration
   */
  private class DurationMinusDuration extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[DurationValue].subtract(b.asInstanceOf[DurationValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = typeA
  }

  /**
   * Arithmetic: duration div duration
   */
  private class DurationDivDuration extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = a.asInstanceOf[DurationValue].divide(b.asInstanceOf[DurationValue])

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = BuiltInAtomicType.DECIMAL
  }

  /**
   * Arithmetic: duration * number
   */
  private class DurationTimesNumeric extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = if (b.isInstanceOf[Int64Value]) a.asInstanceOf[DurationValue].multiply(b.asInstanceOf[Int64Value].longValue)
    else a.asInstanceOf[DurationValue].multiply(b.asInstanceOf[NumericValue].getDoubleValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = typeA
  }

  /**
   * Arithmetic: number * duration
   */
  private class NumericTimesDuration extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = if (a.isInstanceOf[Int64Value]) b.asInstanceOf[DurationValue].multiply(a.asInstanceOf[Int64Value].longValue)
    else b.asInstanceOf[DurationValue].multiply(a.asInstanceOf[NumericValue].getDoubleValue)

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = typeB
  }

  /**
   * Arithmetic: duration div number
   */
  private class DurationDivNumeric extends Calculator {
    @throws[XPathException]
    override def compute(a: AtomicValue, b: AtomicValue, c: XPathContext) = {
      val d = 1.0 / b.asInstanceOf[NumericValue].getDoubleValue
      a.asInstanceOf[DurationValue].multiply(d)
    }

    override def getResultType(typeA: AtomicType, typeB: AtomicType) = typeA
  }

  try `def`(StandardNames.XS_DOUBLE, StandardNames.XS_DOUBLE, DOUBLE_DOUBLE, "DOUBLE_DOUBLE")
  `def`(StandardNames.XS_DOUBLE, StandardNames.XS_FLOAT, DOUBLE_FLOAT, "DOUBLE_FLOAT")
  `def`(StandardNames.XS_DOUBLE, StandardNames.XS_DECIMAL, DOUBLE_DECIMAL, "DOUBLE_DECIMAL")
  `def`(StandardNames.XS_DOUBLE, StandardNames.XS_INTEGER, DOUBLE_INTEGER, "DOUBLE_INTEGER")
  `def`(StandardNames.XS_FLOAT, StandardNames.XS_DOUBLE, FLOAT_DOUBLE, "FLOAT_DOUBLE")
  `def`(StandardNames.XS_FLOAT, StandardNames.XS_FLOAT, FLOAT_FLOAT, "FLOAT_FLOAT")
  `def`(StandardNames.XS_FLOAT, StandardNames.XS_DECIMAL, FLOAT_DECIMAL, "FLOAT_DECIMAL")
  `def`(StandardNames.XS_FLOAT, StandardNames.XS_INTEGER, FLOAT_INTEGER, "FLOAT_INTEGER")
  `def`(StandardNames.XS_DECIMAL, StandardNames.XS_DOUBLE, DECIMAL_DOUBLE, "DECIMAL_DOUBLE")
  `def`(StandardNames.XS_DECIMAL, StandardNames.XS_FLOAT, DECIMAL_FLOAT, "DECIMAL_FLOAT")
  `def`(StandardNames.XS_DECIMAL, StandardNames.XS_DECIMAL, DECIMAL_DECIMAL, "DECIMAL_DECIMAL")
  `def`(StandardNames.XS_DECIMAL, StandardNames.XS_INTEGER, DECIMAL_INTEGER, "DECIMAL_INTEGER")
  `def`(StandardNames.XS_INTEGER, StandardNames.XS_DOUBLE, INTEGER_DOUBLE, "INTEGER_DOUBLE")
  `def`(StandardNames.XS_INTEGER, StandardNames.XS_FLOAT, INTEGER_FLOAT, "INTEGER_FLOAT")
  `def`(StandardNames.XS_INTEGER, StandardNames.XS_DECIMAL, INTEGER_DECIMAL, "INTEGER_DECIMAL")
  `def`(StandardNames.XS_INTEGER, StandardNames.XS_INTEGER, INTEGER_INTEGER, "INTEGER_INTEGER")
  `def`(StandardNames.XS_DATE_TIME, StandardNames.XS_DATE_TIME, DATETIME_DATETIME, "DATETIME_DATETIME")
  `def`(StandardNames.XS_DATE_TIME, StandardNames.XS_DURATION, DATETIME_DURATION, "DATETIME_DURATION")
  `def`(StandardNames.XS_DURATION, StandardNames.XS_DATE_TIME, DURATION_DATETIME, "DURATION_DATETIME")
  `def`(StandardNames.XS_DURATION, StandardNames.XS_DURATION, DURATION_DURATION, "DURATION_DURATION")
  `def`(StandardNames.XS_DURATION, StandardNames.XS_DOUBLE, DURATION_NUMERIC, "DURATION_NUMERIC")
  `def`(StandardNames.XS_DURATION, StandardNames.XS_FLOAT, DURATION_NUMERIC, "DURATION_NUMERIC")
  `def`(StandardNames.XS_DURATION, StandardNames.XS_DECIMAL, DURATION_NUMERIC, "DURATION_NUMERIC")
  `def`(StandardNames.XS_DURATION, StandardNames.XS_INTEGER, DURATION_NUMERIC, "DURATION_NUMERIC")
  `def`(StandardNames.XS_DOUBLE, StandardNames.XS_DURATION, NUMERIC_DURATION, "NUMERIC_DURATION")
  `def`(StandardNames.XS_FLOAT, StandardNames.XS_DURATION, NUMERIC_DURATION, "NUMERIC_DURATION")
  `def`(StandardNames.XS_DECIMAL, StandardNames.XS_DURATION, NUMERIC_DURATION, "NUMERIC_DURATION")
  `def`(StandardNames.XS_INTEGER, StandardNames.XS_DURATION, NUMERIC_DURATION, "NUMERIC_DURATION")
}

abstract class Calculator {
  /**
   * Get a short code to identify the calculator in expression export files
   *
   * @return a short identifying code that can be used to reconstruct the calculator
   */
    def code = {
      val name = getClass.getSimpleName
      name.replaceAll("Any", "a").replaceAll("Double", "d").replaceAll("Float", "f").replaceAll("Decimal", "c").replaceAll("Integer", "i").replaceAll("Numeric", "n").replaceAll("DateTime", "t").replaceAll("Duration", "u").replaceAll("Plus", "+").replaceAll("Minus", "-").replaceAll("Times", "*").replaceAll("Div", "/").replaceAll("Idiv", "~").replaceAll("Mod", "%")
    }

  /**
   * Perform an arithmetic operation
   *
   * @param a the first operand. Must not be null, and must be an instance of the type implied by the
   *          class name.
   * @param b the second operand. Must not be null, and must be an instance of the type implied by the
   *          class name.
   * @param c the XPath dynamic evaluation context
   * @return the result of the computation, as a value of the correct primitive type
   * @throws XPathException in the event of an arithmetic error
   */
  @throws[XPathException]
  def compute(a: AtomicValue, b: AtomicValue, c: XPathContext)

  /**
   * Get the type of the result of the calculator, given arguments types typeA and typeB
   *
   * @param typeA the type of the first operand
   * @param typeB the type of the second operand
   * @return the type of the result
   */
  def getResultType(typeA: AtomicType, typeB: AtomicType)
}