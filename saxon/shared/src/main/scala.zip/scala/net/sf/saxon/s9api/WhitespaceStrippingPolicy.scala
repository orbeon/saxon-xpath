////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.event.FilterFactory
import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.Stripper
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om._
import net.sf.saxon.style.StylesheetPackage
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace
import java.util.function.Predicate

/**
 * WhitespaceStrippingPolicy is class defining the possible policies for handling
 * whitespace text nodes in a source document.
 */
object WhitespaceStrippingPolicy {
  /**
   * The value NONE indicates that all whitespace text nodes are retained. This is the default
   * when documents are processed without validation.
   */
    val NONE = new WhitespaceStrippingPolicy(Whitespace.NONE)
  /**
   * The value IGNORABLE indicates that whitespace text nodes in element-only content are
   * discarded. Content is element-only if it is defined by a schema or DTD definition that
   * does not allow mixed or PCDATA content. This option is in effect documentary only, since
   * this policy is always used when DTD or schema validation is selected for a {@link DocumentBuilder},
   * and is equivalent to {@link #NONE} otherwise.
   */
  val IGNORABLE = new WhitespaceStrippingPolicy(Whitespace.IGNORABLE)
  /**
   * The value ALL indicates that all whitespace-only text nodes are discarded.
   */
  val ALL = new WhitespaceStrippingPolicy(Whitespace.ALL)
  /**
   * UNSPECIFIED means that no other value has been specifically requested.
   */
  val UNSPECIFIED = new WhitespaceStrippingPolicy(Whitespace.UNSPECIFIED)

  /**
   * Create a custom whitespace stripping policy.
   * <p>Changed in 9.9 to use the standard Java 8 Predicate class in place of Saxon's version.</p>
   *
   * @param elementTest a predicate applied to element names, which should return true if whitespace-only
   *                    text node children of the element are to be stripped, false if they are to be retained.
   */
  def makeCustomPolicy(elementTest: Predicate[QName]) = {
    val rule = new SpaceStrippingRule() {
      override def isSpacePreserving(nodeName: NodeName, schemaType: SchemaType) = if (elementTest.test(new QName(nodeName.getStructuredQName))) Stripper.ALWAYS_STRIP
      else Stripper.ALWAYS_PRESERVE

      override

      def makeStripper(next: Receiver) = new Stripper(this, next)

      @throws[XPathException]
      override def `export`(presenter: ExpressionPresenter) = throw new UnsupportedOperationException
    }
    val wsp = new WhitespaceStrippingPolicy(Whitespace.XSLT)
    wsp.stripperRules = rule
    wsp
  }
}

class WhitespaceStrippingPolicy {
  private var policy = 0
  private var stripperRules = null

  def this(policy: Int) {
    this()
    this.policy = policy
    policy match {
      case Whitespace.ALL =>
        stripperRules = AllElementsSpaceStrippingRule.getInstance
      case Whitespace.NONE =>
        stripperRules = NoElementsSpaceStrippingRule.getInstance
      case Whitespace.IGNORABLE =>
        stripperRules = IgnorableSpaceStrippingRule.getInstance
      case _ =>
    }
  }

  /**
   * Create a WhitespaceStrippingPolicy based on the xsl:strip-space and xsl:preserve-space declarations
   * in a given XSLT stylesheet package
   *
   * @param pack the stylesheet package containing the xsl:strip-space and xsl:preserve-space declarations
   */
  def this(pack: StylesheetPackage) {
    this()
    policy = Whitespace.XSLT
    stripperRules = pack.getStripperRules
  }

  protected def ordinal = policy

  protected def getSpaceStrippingRule = stripperRules

  /*@NotNull*/ protected def makeStripper = new FilterFactory() {
    override def makeFilter(next: Receiver): ProxyReceiver = return new Stripper(stripperRules, next)
  }
}