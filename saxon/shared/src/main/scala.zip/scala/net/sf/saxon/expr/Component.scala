////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.instruct.Actor
import net.sf.saxon.expr.instruct.AttributeSet
import net.sf.saxon.expr.instruct.GlobalVariable
import net.sf.saxon.expr.instruct.NamedTemplate
import net.sf.saxon.om.Function
import net.sf.saxon.om.StandardNames
import net.sf.saxon.style.StylesheetPackage
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.Mode
import net.sf.saxon.trans.Visibility
import net.sf.saxon.trans.VisibilityProvenance
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.util

/**
 * Represents a component as defined in the XSLT 3.0 specification: for example a function, a named template,
 * an attribute set, a global variable.
 */
object Component {
  /**
   * Create a component
   *
   * @param actor             the compiled code that implements the component, for example a Template or Function
   * @param visibility        the visibility of the component
   * @param provenance        where the visibility property came from
   * @param containingPackage the package to which this component belongs
   * @param declaringPackage  the package in which the original declaration of the component appears
   */
    def makeComponent(actor: Actor, visibility: Visibility, provenance: VisibilityProvenance, containingPackage: StylesheetPackage, declaringPackage: StylesheetPackage) = {
      var c = null
      if (actor.isInstanceOf[Mode]) c = new Component.M
      else c = new Component
      c.actor = actor
      c.visibility = visibility
      c.provenance = provenance
      c.containingPackage = containingPackage
      c.declaringPackage = declaringPackage
      c
    }

  class M extends Component {
    /**
     * Get the actor (in this case a Mode) that is executed
     * when this component is called
     *
     * @return the code forming the implementation of this component
     */
      override def getActor = super.getActor.asInstanceOf[Mode]

    def setActor(m: Mode) = this.actor = m
  }

}

class Component private() {
  protected var actor = null
  private var visibility = null
  private var bindings = new util.ArrayList[ComponentBinding]
  private var containingPackage = null
  private var declaringPackage = null
  private var provenance = null
  private var baseComponent = null

  /**
   * Get the component's binding vector; that is the list of external references to other components
   *
   * @return the binding vector, a list of component bindings. These are identified by a binding
   *         slot number held with the individual instruction (such as a call-template instruction or a global
   *         variable reference) that contains the external component reference.
   */
  def getComponentBindings = bindings

  /**
   * Set the component's binding vector; that is the list of external references to other components
   *
   * @param bindings the binding vector, a list of component bindings. These are identified by a binding
   *                 slot number held with the individual instruction (such as a call-template instruction or a global
   *                 variable reference) that contains the external component reference.
   */
  def setComponentBindings(bindings: util.List[ComponentBinding]) = this.bindings = bindings

  /**
   * Set the visibility of the component, and say whether it is explicit or defaulted
   *
   * @param visibility the visibility of the component
   * @param provenance where the visibility property came from
   */
  def setVisibility(visibility: Visibility, provenance: VisibilityProvenance) = {
    this.visibility = visibility
    this.provenance = provenance
  }

  /**
   * Get the visibility of the component
   *
   * @return the component's visibility. In the declaring package this will be the original
   *         declared or exposed visibility; in a using package, it will be the visibility of the component
   *         within that package.
   */
  def getVisibility = visibility

  /**
   * Determine whether the visibility of the component is due to an explicit visibility attribute on the component
   * declaration
   *
   * @return the origin of the visibility information
   */
  def getVisibilityProvenance = provenance

  /**
   * Ask whether this is a hidden component derived from an abstract component with no
   * implementation
   *
   * @return true if this component is hidden, and its base component is abstract
   */
  def isHiddenAbstractComponent = (visibility eq Visibility.HIDDEN) && baseComponent != null && (baseComponent.getVisibility eq Visibility.ABSTRACT)

  /**
   * Get the actor (for example a compiled template, function, or variable) that is executed
   * when this component is called
   *
   * @return the code forming the implementation of this component
   */
  def getActor = actor

  /**
   * Get the declaring package of this component
   *
   * @return the package in which the code of the component was originally declared
   */
  def getDeclaringPackage = declaringPackage

  /**
   * Get the containing package of this component
   *
   * @return the package that contains this (version of the) component
   */
  def getContainingPackage = containingPackage

  /**
   * Get the component from which this one is derived
   *
   * @return the component from which this one is derived. This is set when the component appears in the
   *         package as a result of xsl:use-package; a component C in the used package is modified to create a
   *         component D in the using package, and D.getBaseComponent() returns C. The value will be null
   *         in the case of a component whose declaring package is the same as its containing package, that is,
   *         an "original" component (including an overriding component)
   */
  def getBaseComponent = baseComponent

  /**
   * Set the component from which this one is derived
   *
   * @param original the component from which this one is derived. This is set when the component appears in the
   *                 package as a result of xsl:use-package; a component C in the used package is modified to create a
   *                 component D in the using package, and D.getBaseComponent() returns C. The value will be null
   *                 in the case of a component whose declaring package is the same as its containing package, that is,
   *                 an "original" component (including an overriding component)
   */
  def setBaseComponent(original: Component) = baseComponent = original

  @throws[XPathException]
  def `export`(out: ExpressionPresenter, componentIdMap: util.Map[Component, Integer], packageIdMap: util.Map[StylesheetPackage, Integer]) = {
    out.startElement("co")
    val id = obtainComponentId(this, componentIdMap)
    out.emitAttribute("id", "" + id)
    if (provenance ne VisibilityProvenance.DEFAULTED) out.emitAttribute("vis", getVisibility.toString)
    val refs = listComponentReferences(componentIdMap)
    out.emitAttribute("binds", refs)
    if (baseComponent != null && (getActor eq baseComponent.getActor)) {
      val baseId = obtainComponentId(baseComponent, componentIdMap)
      out.emitAttribute("base", "" + baseId)
      out.emitAttribute("dpack", packageIdMap.get(declaringPackage) + "")
    }
    else actor.`export`(out)
    out.endElement
  }

  def listComponentReferences(componentIdMap: util.Map[Component, Integer]) = {
    val fsb = new FastStringBuffer(128)
    import scala.collection.JavaConversions._
    for (ref <- getComponentBindings) {
      val target = ref.getTarget
      val targetId = obtainComponentId(target, componentIdMap)
      if (fsb.length != 0) fsb.append(" ")
      fsb.append("" + targetId)
    }
    fsb.toString
  }

  private def obtainComponentId(component: Component, componentIdMap: util.Map[Component, Integer]) = {
    var id = componentIdMap.get(component)
    if (id == null) {
      id = componentIdMap.size
      componentIdMap.put(component, id)
    }
    id
  }

  def getComponentKind = if (actor.isInstanceOf[NamedTemplate]) StandardNames.XSL_TEMPLATE
  else if (actor.isInstanceOf[GlobalVariable]) StandardNames.XSL_VARIABLE
  else if (actor.isInstanceOf[Function]) StandardNames.XSL_FUNCTION
  else if (actor.isInstanceOf[AttributeSet]) StandardNames.XSL_ATTRIBUTE_SET
  else if (actor.isInstanceOf[Mode]) StandardNames.XSL_MODE
  else -1
}