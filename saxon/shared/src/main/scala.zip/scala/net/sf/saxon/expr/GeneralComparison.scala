////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser._
import net.sf.saxon.expr.sort.AtomicComparer
import net.sf.saxon.expr.sort.CodepointCollator
import net.sf.saxon.expr.sort.GenericAtomicComparer
import net.sf.saxon.expr.sort.UntypedNumericComparer
import net.sf.saxon.functions.Minimax
import net.sf.saxon.functions.SystemFunction
import net.sf.saxon.lib.ConversionRules
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model._
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.NamespaceResolver
import net.sf.saxon.om.Sequence
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value._
import java.util

/**
 * GeneralComparison: a boolean expression that compares two expressions
 * for equals, not-equals, greater-than or less-than. This implements the operators
 * =, !=, &lt;, &gt;, etc. This implementation is not used when in backwards-compatible mode
 */
object GeneralComparison {

  object ComparisonCardinality extends Enumeration {
    type ComparisonCardinality = Value
    val ONE_TO_ONE, MANY_TO_ONE, MANY_TO_MANY = Value
  }

  private def makeMinOrMax(exp: Expression, function: String) = if (Cardinality.allowsMany(exp.getCardinality)) {
    val fn = SystemFunction.makeCall(function, exp.getRetainedStaticContext, exp)
    assert(fn != null)
    (fn.asInstanceOf[SystemFunctionCall]).getTargetFunction.asInstanceOf[Minimax].setIgnoreNaN(true)
    fn
  }
  else exp

  /**
   * Compare two atomic values
   *
   * @param a0       the first value
   * @param operator the singleton version of the comparison operator,
   *                 for example { @link net.sf.saxon.expr.parser.Token#FEQ}
   * @param a1         the second value
   * @param comparer   the comparer to be used to perform the comparison. If the comparer is context-sensitive
   *                   then the context must already have been bound using comparer.provideContext().
   * @param checkTypes set to true if the operand types need to be checked for comparability at runtime
   * @param context    the XPath evaluation context
   * @param nsResolver namespace resolver
   * @return true if the comparison succeeds
   * @throws XPathException if a dynamic error occurs during the comparison
   */
  @throws[XPathException]
  def compare(a0: AtomicValue, operator: Int, a1: AtomicValue, comparer: AtomicComparer, checkTypes: Boolean, context: XPathContext, nsResolver: NamespaceResolver): Boolean = {
    val u0 = a0.isInstanceOf[UntypedAtomicValue]
    val u1 = a1.isInstanceOf[UntypedAtomicValue]
    if (u0 != u1) { // one value untyped, the other not
      val rules = context.getConfiguration.getConversionRules
      if (u0) { // a0 is untyped atomic
        if (a1.isInstanceOf[NumericValue]) return UntypedNumericComparer.quickCompare(a0.asInstanceOf[UntypedAtomicValue], a1.asInstanceOf[NumericValue], operator, rules)
        else if (a1.isInstanceOf[StringValue]) {
          // no conversion needed
        }
        else {
          var sc = a1.getItemType.getPrimitiveItemType.getStringConverter(rules)
          if (a1.isInstanceOf[QualifiedNameValue]) sc = sc.setNamespaceResolver(nsResolver).asInstanceOf[StringConverter]
          a0 = sc.convertString(a0.getStringValueCS).asAtomic
        }
      }
      else { // a1 is untyped atomic
        if (a0.isInstanceOf[NumericValue]) return UntypedNumericComparer.quickCompare(a1.asInstanceOf[UntypedAtomicValue], a0.asInstanceOf[NumericValue], Token.inverse(operator), rules)
        else if (a0.isInstanceOf[StringValue]) {
        }
        else {
          var sc = a0.getItemType.getPrimitiveItemType.getStringConverter(rules)
          if (a0.isInstanceOf[QualifiedNameValue]) sc = sc.setNamespaceResolver(nsResolver).asInstanceOf[StringConverter]
          a1 = sc.convertString(a1.getStringValueCS).asAtomic
        }
      }
      checkTypes = false // No further checking needed if conversion succeeded
    }
    ValueComparison.compare(a0, operator, a1, comparer, checkTypes)
  }

  /**
   * Return the singleton form of the comparison operator, e.g. FEQ for EQUALS, FGT for GT
   *
   * @param op the many-to-many form of the operator, for example { @link Token#LE}
   * @return the corresponding singleton operator, for example { @link Token#FLE}
   */
  def getCorrespondingSingletonOperator(op: Int) = op match {
    case Token.EQUALS =>
      Token.FEQ
    case Token.GE =>
      Token.FGE
    case Token.NE =>
      Token.FNE
    case Token.LT =>
      Token.FLT
    case Token.GT =>
      Token.FGT
    case Token.LE =>
      Token.FLE
    case _ =>
      op
  }
}

abstract class GeneralComparison(val p0: Expression, val op: Int, val p1: Expression)

/**
 * Create a relational expression identifying the two operands and the operator
 *
 * @param p0 the left-hand operand
 * @param op the operator, as a token returned by the Tokenizer (e.g. Token.LT)
 * @param p1 the right-hand operand
 */
  extends BinaryExpression(p0, op, p1) with ComparisonExpression with Callable {
  singletonOperator = GeneralComparison.getCorrespondingSingletonOperator(op)
  protected var singletonOperator = 0
  protected var comparer = null
  protected var needsRuntimeCheck = true
  protected var comparisonCardinality = GeneralComparison.ComparisonCardinality.MANY_TO_MANY
  protected var doneWarnings = false

  /**
   * Ask whether a runtime check of the types of the operands is needed
   *
   * @return true if the types of the operands need to be checked at run-time
   */
  def needsRuntimeCheck = needsRuntimeCheck

  /**
   * Say whether a runtime check of the types of the operands is needed
   *
   * @param needsCheck true if the types of the operands need to be checked at run-time
   */
  def setNeedsRuntimeCheck(needsCheck: Boolean) = needsRuntimeCheck = needsCheck

  /**
   * Ask whether the comparison is known to be many-to-one, one-to-one, or many-to-many.
   * (Note, an expression that is one-to-many will be converted to one that is many-to-one).
   *
   * @return the Cardinality of the comparison as one of the values { @link ComparisonCardinality#ONE_TO_ONE},
   *                                                                        { @link ComparisonCardinality#MANY_TO_MANY}, { @link ComparisonCardinality#MANY_TO_ONE}
   */
  def getComparisonCardinality = comparisonCardinality

  /**
   * Say whether the comparison is known to be many-to-one, one-to-one, or many-to-many.
   *
   * @param card the Cardinality of the comparison as one of the values { @link ComparisonCardinality#ONE_TO_ONE},
   *                                                                            { @link ComparisonCardinality#MANY_TO_MANY}, { @link ComparisonCardinality#MANY_TO_ONE}
   */
  def setComparisonCardinality(card: GeneralComparison.ComparisonCardinality) = comparisonCardinality = card

  /**
   * Set the comparer to be used
   *
   * @param comparer the comparer to be used
   */
  def setAtomicComparer(comparer: AtomicComparer) = this.comparer = comparer

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "GeneralComparison"

  /**
   * Get the namespace context for this expression, needed in the event that one operand contains untyped
   * atomic values and the other contains QNames
   */
  def getNamespaceResolver = getRetainedStaticContext

  /**
   * Get the AtomicComparer used to compare atomic values. This encapsulates any collation that is used
   */
  override def getAtomicComparer = comparer

  /**
   * Get the primitive (singleton) operator used: one of Token.FEQ, Token.FNE, Token.FLT, Token.FGT,
   * Token.FLE, Token.FGE
   */
  override def getSingletonOperator = singletonOperator

  /**
   * Determine whether untyped atomic values should be converted to the type of the other operand
   *
   * @return true if untyped values should be converted to the type of the other operand, false if they
   *         should be converted to strings.
   */
  override def convertsUntypedToOther = true

  /**
   * Determine the static cardinality. Returns [1..1]
   */
  override def computeCardinality = StaticProperty.EXACTLY_ONE

  /**
   * Type-check the expression
   *
   * @return the checked expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    val oldOp0 = getLhsExpression
    val oldOp1 = getRhsExpression
    getLhs.typeCheck(visitor, contextInfo)
    getRhs.typeCheck(visitor, contextInfo)
    // If either operand is statically empty, return false
    if (Literal.isEmptySequence(getLhsExpression) || Literal.isEmptySequence(getRhsExpression)) return Literal.makeLiteral(BooleanValue.FALSE, this)
    // Neither operand needs to be sorted
    setLhsExpression(getLhsExpression.unordered(false, false))
    setRhsExpression(getRhsExpression.unordered(false, false))
    val atomicType = SequenceType.ATOMIC_SEQUENCE
    val tc = config.getTypeChecker(false)
    val role0 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 0)
    //role0.setSourceLocator(this);
    setLhsExpression(tc.staticTypeCheck(getLhsExpression, atomicType, role0, visitor))
    val role1 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 1)
    //role1.setSourceLocator(this);
    setRhsExpression(tc.staticTypeCheck(getRhsExpression, atomicType, role1, visitor))
    if (getLhsExpression ne oldOp0) adoptChildExpression(getLhsExpression)
    if (getRhsExpression ne oldOp1) adoptChildExpression(getRhsExpression)
    val t0 = getLhsExpression.getItemType // this is always an atomic type or union type or xs:error
    val t1 = getRhsExpression.getItemType
    if (t0.isInstanceOf[ErrorType] || t1.isInstanceOf[ErrorType]) return Literal.makeLiteral(BooleanValue.FALSE, this)
    if (t0.getUType.union(t1.getUType).overlaps(UType.EXTENSION)) {
      val err = new XPathException("Cannot perform comparisons involving external objects")
      err.setIsTypeError(true)
      err.setErrorCode("XPTY0004")
      err.setLocator(getLocation)
      throw err
    }
    val pt0 = t0.getPrimitiveItemType.asInstanceOf[BuiltInAtomicType]
    val pt1 = t1.getPrimitiveItemType.asInstanceOf[BuiltInAtomicType]
    val c0 = getLhsExpression.getCardinality
    val c1 = getRhsExpression.getCardinality
    if (c0 == StaticProperty.EMPTY || c1 == StaticProperty.EMPTY) return Literal.makeLiteral(BooleanValue.FALSE, this)
    if (t0 == BuiltInAtomicType.ANY_ATOMIC || t0 == BuiltInAtomicType.UNTYPED_ATOMIC || t1 == BuiltInAtomicType.ANY_ATOMIC || t1 == BuiltInAtomicType.UNTYPED_ATOMIC) {
      // then no static type checking is possible
    }
    else if (!Type.isPossiblyComparable(pt0, pt1, Token.isOrderedOperator(singletonOperator))) {
      val message = "In {" + toShortString + "}: cannot compare " + t0 + " to " + t1
      if (Cardinality.allowsZero(c0) || Cardinality.allowsZero(c1)) if (!doneWarnings) { // avoid duplicate warnings
        doneWarnings = true
        var which = "one"
        if (Cardinality.allowsZero(c0) && !Cardinality.allowsZero(c1)) which = "the first"
        else if (Cardinality.allowsZero(c1) && !Cardinality.allowsZero(c0)) which = "the second"
        visitor.getStaticContext.issueWarning(message + ". The comparison can succeed only if " + which + " operand is empty, and in that case will always be false", getLocation)
      }
      else {
        val err = new XPathException(message)
        err.setErrorCode("XPTY0004")
        err.setIsTypeError(true)
        err.setLocator(getLocation)
        throw err
      }
    }
    needsRuntimeCheck = !Type.isGuaranteedGenerallyComparable(pt0, pt1, Token.isOrderedOperator(singletonOperator))
    if (!Cardinality.allowsMany(c0) /*c0 == StaticProperty.EXACTLY_ONE*/ && !Cardinality.allowsMany(c1) /*c1 == StaticProperty.EXACTLY_ONE */ && !(t0 == BuiltInAtomicType.ANY_ATOMIC) && !(t1 == BuiltInAtomicType.ANY_ATOMIC)) { // Use a value comparison if both arguments are singletons, and if the comparison operator to
      // be used can be determined.
      var e0 = getLhsExpression
      var e1 = getRhsExpression
      if (t0 == BuiltInAtomicType.UNTYPED_ATOMIC) if (t1 == BuiltInAtomicType.UNTYPED_ATOMIC) {
        e0 = new CastExpression(getLhsExpression, BuiltInAtomicType.STRING, Cardinality.allowsZero(c0))
        adoptChildExpression(e0)
        e1 = new CastExpression(getRhsExpression, BuiltInAtomicType.STRING, Cardinality.allowsZero(c1))
        adoptChildExpression(e1)
      }
      else if (NumericType.isNumericType(t1)) {
        val vun = makeCompareUntypedToNumeric(getLhsExpression, getRhsExpression, singletonOperator)
        return vun.typeCheck(visitor, contextInfo)
      }
      else {
        e0 = new CastExpression(getLhsExpression, pt1, Cardinality.allowsZero(c0))
        adoptChildExpression(e0)
      }
      else if (t1 == BuiltInAtomicType.UNTYPED_ATOMIC) if (NumericType.isNumericType(t0)) { //                    e1 = new CastExpression(getRhsExpression(), BuiltInAtomicType.DOUBLE, false);
        //                    adoptChildExpression(e1);
        val vun = makeCompareUntypedToNumeric(getRhsExpression, getLhsExpression, Token.inverse(singletonOperator))
        return vun.typeCheck(visitor, contextInfo)
      }
      else {
        e1 = new CastExpression(getRhsExpression, pt0, Cardinality.allowsZero(c1))
        adoptChildExpression(e1)
      }
      val vc = new ValueComparison(e0, singletonOperator, e1)
      vc.setAtomicComparer(comparer)
      vc.setResultWhenEmpty(BooleanValue.FALSE)
      ExpressionTool.copyLocationInfo(this, vc)
      Optimizer.trace(config, "Replaced general comparison by value comparison", vc)
      return vc.typeCheck(visitor, contextInfo)
    }
    val env = visitor.getStaticContext
    if (comparer == null) { // In XSLT, only do this the first time through, otherwise default-collation may be missed
      val defaultCollationName = env.getDefaultCollationName
      var collation = config.getCollation(defaultCollationName)
      if (collation == null) collation = CodepointCollator.getInstance
      comparer = GenericAtomicComparer.makeAtomicComparer(pt0, pt1, collation, config.getConversionContext)
    }
    // evaluate the expression now if both arguments are constant
    if (getLhsExpression.isInstanceOf[Literal] && getRhsExpression.isInstanceOf[Literal]) return Literal.makeLiteral(evaluateItem(env.makeEarlyEvaluationContext), this)
    this
  }

  private def makeCompareUntypedToNumeric(lhs: Expression, rhs: Expression, operator: Int) = {
    val vc = new ValueComparison(lhs, operator, rhs)
    vc.setAtomicComparer(new UntypedNumericComparer)
    ExpressionTool.copyLocationInfo(this, vc)
    Optimizer.trace(getConfiguration, "Replaced general comparison by untyped-numeric value comparison", vc)
    vc
  }

  override def getIntrinsicDependencies = { // The expression is dependent on the static namespace context if one operand might deliver
    // untypedAtomic and the other might deliver a QName
    val th = getConfiguration.getTypeHierarchy
    if (mayInvolveCastToQName(th, getLhsExpression, getRhsExpression) || mayInvolveCastToQName(th, getRhsExpression, getLhsExpression)) StaticProperty.DEPENDS_ON_STATIC_CONTEXT
    else 0
  }

  private def mayInvolveCastToQName(th: TypeHierarchy, e1: Expression, e2: Expression) = {
    val s1 = e1.getItemType.getAtomizedItemType.asInstanceOf[SimpleType]
    ((s1 eq BuiltInAtomicType.ANY_ATOMIC) || s1.isNamespaceSensitive) && (th.relationship(e2.getItemType.getAtomizedItemType, BuiltInAtomicType.UNTYPED_ATOMIC) ne Affinity.DISJOINT) && (e2.getSpecialProperties & StaticProperty.NOT_UNTYPED_ATOMIC) == 0
  }

  override def equals(other: Any) = other.isInstanceOf[GeneralComparison] && super.equals(other) && comparer == other.asInstanceOf[GeneralComparison].comparer

  /**
   * Optimize the expression
   *
   * @return the checked expression
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val th = visitor.getConfiguration.getTypeHierarchy
    val env = visitor.getStaticContext
    getLhs.optimize(visitor, contextInfo)
    getRhs.optimize(visitor, contextInfo)
    if (Literal.isEmptySequence(getLhsExpression) || Literal.isEmptySequence(getRhsExpression)) return Literal.makeLiteral(BooleanValue.FALSE, this)
    setLhsExpression(getLhsExpression.unordered(false, false))
    setRhsExpression(getRhsExpression.unordered(false, false))
    if (getLhsExpression.isInstanceOf[Literal] && getRhsExpression.isInstanceOf[Literal]) return Literal.makeLiteral(evaluateItem(visitor.getStaticContext.makeEarlyEvaluationContext).materialize, this)
    val t0 = getLhsExpression.getItemType
    val t1 = getRhsExpression.getItemType
    val c0 = getLhsExpression.getCardinality
    val c1 = getRhsExpression.getCardinality
    // Check if neither argument allows a sequence of >1
    val many0 = Cardinality.allowsMany(c0)
    val many1 = Cardinality.allowsMany(c1)
    if (many0) if (many1) comparisonCardinality = GeneralComparison.ComparisonCardinality.MANY_TO_MANY
    else comparisonCardinality = GeneralComparison.ComparisonCardinality.MANY_TO_ONE
    else if (many1) {
      val mc = getInverseComparison
      mc.comparisonCardinality = GeneralComparison.ComparisonCardinality.MANY_TO_ONE
      ExpressionTool.copyLocationInfo(this, mc)
      mc.comparer = comparer
      mc.needsRuntimeCheck = needsRuntimeCheck
      return mc.optimize(visitor, contextInfo)
    }
    else comparisonCardinality = GeneralComparison.ComparisonCardinality.ONE_TO_ONE
    // look for (N to M = I)
    if (operator == Token.EQUALS) { // First a variable range...
      if (getLhsExpression.isInstanceOf[RangeExpression]) {
        val min = getLhsExpression.asInstanceOf[RangeExpression].getLhsExpression
        val max = getLhsExpression.asInstanceOf[RangeExpression].getRhsExpression
        val ir = new IntegerRangeTest(getRhsExpression, min, max)
        ExpressionTool.copyLocationInfo(this, ir)
        return ir
      }
      if (getRhsExpression.isInstanceOf[RangeExpression]) {
        val min = getRhsExpression.asInstanceOf[RangeExpression].getLhsExpression
        val max = getRhsExpression.asInstanceOf[RangeExpression].getRhsExpression
        val ir = new IntegerRangeTest(getLhsExpression, min, max)
        ExpressionTool.copyLocationInfo(this, ir)
        return ir
      }
      // Now a fixed range...
      if (getLhsExpression.isInstanceOf[Literal]) {
        val value0 = getLhsExpression.asInstanceOf[Literal].getValue
        if (value0.isInstanceOf[IntegerRange]) {
          val min = value0.asInstanceOf[IntegerRange].getStart
          val max = value0.asInstanceOf[IntegerRange].getEnd
          val ir = new IntegerRangeTest(getRhsExpression, Literal.makeLiteral(Int64Value.makeIntegerValue(min), this), Literal.makeLiteral(Int64Value.makeIntegerValue(max), this))
          ExpressionTool.copyLocationInfo(this, ir)
          return ir
        }
      }
      if (getRhsExpression.isInstanceOf[Literal]) {
        val value1 = getRhsExpression.asInstanceOf[Literal].getValue
        if (value1.isInstanceOf[IntegerRange]) {
          val min = value1.asInstanceOf[IntegerRange].getStart
          val max = value1.asInstanceOf[IntegerRange].getEnd
          val ir = new IntegerRangeTest(getLhsExpression, Literal.makeLiteral(Int64Value.makeIntegerValue(min), this), Literal.makeLiteral(Int64Value.makeIntegerValue(max), this))
          ExpressionTool.copyLocationInfo(this, ir)
          return ir
        }
      }
    }
    // If the operator is gt, ge, lt, le then replace X < Y by min(X) < max(Y)
    // This optimization is done only in the case where at least one of the
    // sequences is known to be purely numeric. It isn't safe if both sequences
    // contain untyped atomic values, because in that case, the type of the
    // comparison isn't known in advance. For example [(1, U1) < ("fred", U2)]
    // involves both string and numeric comparisons.
    // Generally, do this optimization for a many-to-many comparison, because it prevents
    // early exit on a many-to-one comparison. But with a many-to-one comparison, do it
    // if the "many" branch can be lifted up the expression tree.
    if (operator != Token.EQUALS && operator != Token.NE && ((comparisonCardinality eq GeneralComparison.ComparisonCardinality.MANY_TO_MANY) || (comparisonCardinality eq GeneralComparison.ComparisonCardinality.MANY_TO_ONE) && manyOperandIsLiftable) && (NumericType.isNumericType(t0) || NumericType.isNumericType(t1))) { // System.err.println("** using minimax optimization **");
      var vc = null
      operator match {
        case Token.LT =>
        case Token.LE =>
          vc = new ValueComparison(GeneralComparison.makeMinOrMax(getLhsExpression, "min"), singletonOperator, GeneralComparison.makeMinOrMax(getRhsExpression, "max"))
          vc.setResultWhenEmpty(BooleanValue.FALSE)
          vc.setAtomicComparer(comparer)
        case Token.GT =>
        case Token.GE =>
          vc = new ValueComparison(GeneralComparison.makeMinOrMax(getLhsExpression, "max"), singletonOperator, GeneralComparison.makeMinOrMax(getRhsExpression, "min"))
          vc.setResultWhenEmpty(BooleanValue.FALSE)
          vc.setAtomicComparer(comparer)
        case _ =>
          throw new UnsupportedOperationException("Unknown operator " + operator)
      }
      ExpressionTool.copyLocationInfo(this, vc)
      vc.setRetainedStaticContext(getRetainedStaticContext)
      return vc.typeCheck(visitor, contextInfo)
    }
    if (getLhsExpression.isInstanceOf[Literal] && getRhsExpression.isInstanceOf[Literal]) return Literal.makeLiteral(evaluateItem(env.makeEarlyEvaluationContext), this)
    // Finally, convert to use the GeneralComparisonEE algorithm if in Saxon-EE
    visitor.obtainOptimizer.optimizeGeneralComparison(visitor, this, false, contextInfo)
  }

  private def manyOperandIsLiftable: Boolean = {
    if (getParentExpression.isInstanceOf[ContextSwitchingExpression] && (getParentExpression.asInstanceOf[ContextSwitchingExpression].getActionExpression eq this)) {
      import scala.collection.JavaConversions._
      for (o <- operands) {
        if (Cardinality.allowsMany(o.getChildExpression.getCardinality)) if (ExpressionTool.dependsOnFocus(o.getChildExpression)) return false
      }
      return true
    }
    false
  }

  /**
   * Evaluate the expression in a given context
   *
   * @param context the given context for evaluation
   * @return a BooleanValue representing the result of the numeric comparison of the two operands
   */
  /*@Nullable*/ @throws[XPathException]
  override def evaluateItem(context: XPathContext): BooleanValue = {
    comparisonCardinality match {
      case ONE_TO_ONE =>
        val value0 = getLhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
        val value1 = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
        return BooleanValue.get(evaluateOneToOne(value0, value1, context))
      case MANY_TO_ONE =>
        val iter0 = getLhsExpression.iterate(context)
        val value1 = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
        return BooleanValue.get(evaluateManyToOne(iter0, value1, context))
      case MANY_TO_MANY =>
        val iter1 = getLhsExpression.iterate(context)
        val iter2 = getRhsExpression.iterate(context)
        return BooleanValue.get(evaluateManyToMany(iter1, iter2, context))
    }
    null
  }

  /**
   * Evaluate the expression
   *
   * @param context   the dynamic evaluation context
   * @param arguments the values of the arguments, supplied as SequenceIterators
   * @return the result of the evaluation, in the form of a SequenceIterator
   * @throws XPathException if a dynamic error occurs during the evaluation of the expression
   */
  @throws[XPathException]
  override def call(context: XPathContext, arguments: Array[Sequence]): BooleanValue = {
    comparisonCardinality match {
      case ONE_TO_ONE =>
        val value0 = arguments(0).head.asInstanceOf[AtomicValue]
        val value1 = arguments(1).head.asInstanceOf[AtomicValue]
        return BooleanValue.get(evaluateOneToOne(value0, value1, context))
      case MANY_TO_ONE =>
        val iter0 = arguments(0).iterate
        val value1 = arguments(1).head.asInstanceOf[AtomicValue]
        return BooleanValue.get(evaluateManyToOne(iter0, value1, context))
      case MANY_TO_MANY =>
        val iter1 = arguments(0).iterate
        val iter2 = arguments(1).iterate
        return BooleanValue.get(evaluateManyToMany(iter1, iter2, context))
    }
    null
  }

  /**
   * Evaluate the expression in a boolean context
   *
   * @param context the given context for evaluation
   * @return a boolean representing the result of the numeric comparison of the two operands
   */
  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext): Boolean = {
    comparisonCardinality match {
      case ONE_TO_ONE =>
        val value0 = getLhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
        val value1 = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
        return evaluateOneToOne(value0, value1, context)
      case MANY_TO_ONE =>
        val iter0 = getLhsExpression.iterate(context)
        val value1 = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
        return evaluateManyToOne(iter0, value1, context)
      case MANY_TO_MANY =>
        val iter1 = getLhsExpression.iterate(context)
        val iter2 = getRhsExpression.iterate(context)
        return evaluateManyToMany(iter1, iter2, context)
    }
    false
  }

  /**
   * Evaluate a (zero-or-one)-to-(zero-or-one) comparison
   *
   * @param value0  the first value, or null if empty
   * @param value1  the second value, or null if empty
   * @param context dynamic evaluation context
   * @return the comparison result
   * @throws XPathException if a dynamic error occurs
   */
  @throws[XPathException]
  private def evaluateOneToOne(value0: AtomicValue, value1: AtomicValue, context: XPathContext) = try !(value0 == null || value1 == null) && GeneralComparison.compare(value0, singletonOperator, value1, comparer.provideContext(context), needsRuntimeCheck, context, getRetainedStaticContext)
  catch {
    case e: XPathException =>
      // re-throw the exception with location information added
      e.maybeSetLocation(getLocation)
      e.maybeSetContext(context)
      throw e
  }

  /**
   * Evaluate a (zero-to-many)-to-(zero-or-one) comparison
   *
   * @param iter0   iterator over the first value
   * @param value1  the second value, or null if empty
   * @param context dynamic evaluation context
   * @return the comparison result
   * @throws XPathException if a dynamic error occurs
   */
  @throws[XPathException]
  private def evaluateManyToOne(iter0: SequenceIterator, value1: AtomicValue, context: XPathContext): Boolean = try {
    if (value1 == null) return false
    var item0 = null
    val boundComparer = comparer.provideContext(context)
    while ( {
      (item0 = iter0.next.asInstanceOf[AtomicValue]) != null
    }) if (GeneralComparison.compare(item0, singletonOperator, value1, boundComparer, needsRuntimeCheck, context, getRetainedStaticContext)) {
      iter0.close()
      return true
    }
    false
  } catch {
    case e: XPathException =>
      e.maybeSetLocation(getLocation)
      e.maybeSetContext(context)
      throw e
  }

  /**
   * Evaluate a (zero-or-one)-to-(zero-or-one) comparison
   *
   * @param iter0   iterator over the first value
   * @param iter1   iterator the second value
   * @param context dynamic evaluation context
   * @return the comparison result
   * @throws XPathException if a dynamic error occurs
   */
  @throws[XPathException]
  def evaluateManyToMany(iter0: SequenceIterator, iter1: SequenceIterator, context: XPathContext): Boolean = try {
    var exhausted0 = false
    var exhausted1 = false
    val value0 = new util.ArrayList[AtomicValue]
    val value1 = new util.ArrayList[AtomicValue]
    val boundComparer = comparer.provideContext(context)
    // Read items from the two sequences alternately, in each case comparing the item to
    // all items that have previously been read from the other sequence. In the worst case
    // the number of comparisons is N*M, and the memory usage is (max(N,M)*2) where N and M
    // are the number of items in the two sequences. In practice, either M or N is often 1,
    // meaning that in this case neither list will ever hold more than one item.
    while ( {
      true
    }) {
      if (!exhausted0) {
        val item0 = iter0.next.asInstanceOf[AtomicValue]
        if (item0 == null) {
          if (exhausted1) return false
          exhausted0 = true
        }
        else {
          import scala.collection.JavaConversions._
          for (item1 <- value1) {
            if (GeneralComparison.compare(item0, singletonOperator, item1, boundComparer, needsRuntimeCheck, context, getRetainedStaticContext)) {
              iter0.close()
              iter1.close()
              return true
            }
          }
          if (!exhausted1) value0.add(item0)
        }
      }
      if (!exhausted1) {
        val item1 = iter1.next.asInstanceOf[AtomicValue]
        if (item1 == null) {
          if (exhausted0) return false
          exhausted1 = true
        }
        else {
          import scala.collection.JavaConversions._
          for (item0 <- value0) {
            if (GeneralComparison.compare(item0, singletonOperator, item1, boundComparer, needsRuntimeCheck, context, getRetainedStaticContext)) {
              iter0.close()
              iter1.close()
              return true
            }
          }
          if (!exhausted0) value1.add(item1)
        }
      }
    }
  } catch {
    case e: XPathException =>
      e.maybeSetLocation(getLocation)
      e.maybeSetContext(context)
      throw e
  }

  /**
   * Determine the data type of the expression
   *
   * @return the value BuiltInAtomicType.BOOLEAN
   */
  override def getItemType = BuiltInAtomicType.BOOLEAN

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType static information about the context item
   */
  override def getStaticUType(contextItemType: UType) = UType.BOOLEAN

  protected def getInverseComparison = {
    val gc2 = new GeneralComparison20(getRhsExpression, Token.inverse(operator), getLhsExpression)
    gc2.setRetainedStaticContext(getRetainedStaticContext)
    gc2
  }

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "GeneralComparison"

  /**
   * Get the element name used to identify this expression in exported expression format
   *
   * @return the element name used to identify this expression
   */
  override def tag = "gc"

  override protected def explainExtraAttributes(out: ExpressionPresenter) = {
    var cc = ""
    comparisonCardinality match {
      case ONE_TO_ONE =>
        cc = "1:1"
      case MANY_TO_ONE =>
        cc = "N:1"
      case MANY_TO_MANY =>
        cc = "M:N"
    }
    out.emitAttribute("card", cc)
    out.emitAttribute("comp", comparer.save)
  }
}