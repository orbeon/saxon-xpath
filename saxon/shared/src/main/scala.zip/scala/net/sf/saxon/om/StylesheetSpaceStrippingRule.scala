////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.Stripper
import net.sf.saxon.model.SchemaType
import net.sf.saxon.trace.ExpressionPresenter
import java.util

/**
 * A whitespace stripping rule that strips whitespace according to the rules defined for XSLT stylesheets
 */
object StylesheetSpaceStrippingRule {
  private val specials = Array(StandardNames.XSL_ANALYZE_STRING, StandardNames.XSL_APPLY_IMPORTS, StandardNames.XSL_APPLY_TEMPLATES, StandardNames.XSL_ATTRIBUTE_SET, StandardNames.XSL_CALL_TEMPLATE, StandardNames.XSL_CHARACTER_MAP, StandardNames.XSL_CHOOSE, StandardNames.XSL_EVALUATE, StandardNames.XSL_MERGE, StandardNames.XSL_MERGE_SOURCE, StandardNames.XSL_NEXT_ITERATION, StandardNames.XSL_NEXT_MATCH, StandardNames.XSL_STYLESHEET, StandardNames.XSL_TRANSFORM)
}

class StylesheetSpaceStrippingRule(var namePool: NamePool) extends SpaceStrippingRule {
  /**
   * Decide whether an element is in the set of white-space preserving element types
   *
   * @param elementName identifies the element being tested
   * @param schemaType  not used
   */
  override def isSpacePreserving(/*@NotNull*/ elementName: NodeName, schemaType: SchemaType): Int = {
    val fingerprint = elementName.obtainFingerprint(namePool)
    if (fingerprint == (StandardNames.XSL_TEXT & NamePool.FP_MASK)) return Stripper.ALWAYS_PRESERVE
    if (util.Arrays.binarySearch(StylesheetSpaceStrippingRule.specials, fingerprint) >= 0) return Stripper.ALWAYS_STRIP
    Stripper.STRIP_DEFAULT
  }

  /**
   * Make a filter to implement these space-stripping rules, or null if no filtering
   * is necessary
   *
   * @return a filter in the form of a ProxyReceiver, or null
   * @param next
   */
  override def makeStripper(next: Receiver) = new Stripper(this, next)

  /**
   * Export this rule as part of an exported stylesheet
   *
   * @param presenter the output handler
   */
  override def `export`(presenter: ExpressionPresenter) = {
    // no action
  }
}