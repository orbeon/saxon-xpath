////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.sort.AtomicMatchKey
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ConversionResult
import net.sf.saxon.model.ValidationFailure
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.math.BigDecimal
import java.math.RoundingMode

/**
 * A value of type xs:yearMonthDuration.
 * <p>The state retained by this class is essentially a signed 32-bit integer representing the number
 * of months: that is, {@code year*12 + month}; plus a type label allowing subtypes of {@code xs:yearMonthDuration}
 * to be represented.</p>
 */
object YearMonthDurationValue {
  /**
   * Static factory: create a year-month duration value from a supplied string, in
   * ISO 8601 format [+|-]PnYnM
   *
   * @param s a string in the lexical space of xs:yearMonthDuration.
   * @return either a YearMonthDurationValue, or a ValidationFailure if the string was
   *         not in the lexical space of xs:yearMonthDuration.
   */
    def makeYearMonthDurationValue(s: CharSequence): ConversionResult = {
      val d = DurationValue.makeDuration(s, true, false)
      if (d.isInstanceOf[ValidationFailure]) return d
      val dv = d.asInstanceOf[DurationValue]
      YearMonthDurationValue.fromMonths((dv.getYears * 12 + dv.getMonths) * dv.signum)
    }

  /**
   * Construct a duration value as a number of months.
   *
   * @param months the number of months (may be negative)
   * @return the corresponding xs:yearMonthDuration value
   */
  def fromMonths(months: Int) = {
    val mdv = new YearMonthDurationValue
    mdv.negative = months < 0
    mdv.months = if (months < 0) -months
    else months
    mdv.seconds = 0
    mdv.nanoseconds = 0
    mdv
  }
}

final class YearMonthDurationValue private()

/**
 * Private constructor for internal use
 */
  extends DurationValue with Comparable[YearMonthDurationValue] {
  typeLabel = BuiltInAtomicType.YEAR_MONTH_DURATION

  /**
   * Create a copy of this atomic value, with a different type label
   *
   * @param typeLabel the type label of the new copy. The caller is responsible for checking that
   *                  the value actually conforms to this type.
   */
  /*@NotNull*/ override def copyAsSubType(typeLabel: AtomicType) = {
    val v = YearMonthDurationValue.fromMonths(getLengthInMonths)
    v.typeLabel = typeLabel
    v
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.YEAR_MONTH_DURATION

  /**
   * Convert to string
   *
   * @return ISO 8601 representation.
   */
  override def getPrimitiveStringValue = { // The canonical representation has months in the range 0-11
    val y = getYears
    val m = getMonths
    val sb = new FastStringBuffer(32)
    if (negative) sb.cat('-')
    sb.cat('P')
    if (y != 0) sb.append(y + "Y")
    if (m != 0 || y == 0) sb.append(m + "M")
    sb
  }

  /**
   * Get the number of months in the duration
   *
   * @return the number of months in the duration
   */
  def getLengthInMonths = months * (if (negative) -1
  else +1)

  /**
   * Multiply a duration by an integer
   *
   * @param factor the number to multiply by
   * @return the result of the multiplication
   */
  @throws[XPathException]
  override def multiply(factor: Long) = { // Fast path for simple cases
    if (Math.abs(factor) < 30000 && Math.abs(months) < 30000) YearMonthDurationValue.fromMonths(factor.toInt * getLengthInMonths)
    else multiply(factor.toDouble)
  }

  /**
   * Multiply duration by a number.
   */
  @throws[XPathException]
  override def multiply(n: Double) = {
    if (Double.isNaN(n)) {
      val err = new XPathException("Cannot multiply a duration by NaN")
      err.setErrorCode("FOCA0005")
      throw err
    }
    val m = getLengthInMonths.toDouble
    val product = n * m
    if (Double.isInfinite(product) || product > Integer.MAX_VALUE || product < Integer.MIN_VALUE) {
      val err = new XPathException("Overflow when multiplying a duration by a number")
      err.setErrorCode("FODT0002")
      throw err
    }
    YearMonthDurationValue.fromMonths(product.round.toInt)
  }

  /**
   * Divide duration by a number.
   */
  @throws[XPathException]
  override def divide(n: Double) = {
    if (Double.isNaN(n)) {
      val err = new XPathException("Cannot divide a duration by NaN")
      err.setErrorCode("FOCA0005")
      throw err
    }
    val m = getLengthInMonths.toDouble
    val product = m / n
    if (Double.isInfinite(product) || product > Integer.MAX_VALUE || product < Integer.MIN_VALUE) {
      val err = new XPathException("Overflow when dividing a duration by a number")
      err.setErrorCode("FODT0002")
      throw err
    }
    YearMonthDurationValue.fromMonths(product.round.toInt)
  }

  /**
   * Find the ratio between two durations
   *
   * @param other the dividend
   * @return the ratio, as a decimal
   * @throws XPathException if an error occurs, for example division by zero or dividing durations of different type
   */
  @throws[XPathException]
  override def divide(other: DurationValue) = if (other.isInstanceOf[YearMonthDurationValue]) {
    val v1 = BigDecimal.valueOf(getLengthInMonths)
    val v2 = BigDecimal.valueOf(other.asInstanceOf[YearMonthDurationValue].getLengthInMonths)
    if (v2.signum == 0) {
      val err = new XPathException("Divide by zero (durations)")
      err.setErrorCode("FOAR0001")
      throw err
    }
    new BigDecimalValue(v1.divide(v2, 20, RoundingMode.HALF_EVEN))
  }
  else {
    val err = new XPathException("Cannot divide two durations of different type")
    err.setErrorCode("XPTY0004")
    throw err
  }

  /**
   * Add two year-month-durations
   */
  @throws[XPathException]
  override def add(other: DurationValue) = if (other.isInstanceOf[YearMonthDurationValue]) YearMonthDurationValue.fromMonths(getLengthInMonths + other.asInstanceOf[YearMonthDurationValue].getLengthInMonths)
  else {
    val err = new XPathException("Cannot add two durations of different type")
    err.setErrorCode("XPTY0004")
    throw err
  }

  /**
   * Subtract two year-month-durations
   */
  @throws[XPathException]
  override def subtract(other: DurationValue) = if (other.isInstanceOf[YearMonthDurationValue]) YearMonthDurationValue.fromMonths(getLengthInMonths - other.asInstanceOf[YearMonthDurationValue].getLengthInMonths)
  else {
    val err = new XPathException("Cannot subtract two durations of different type")
    err.setErrorCode("XPTY0004")
    throw err
  }

  /**
   * Negate a duration (same as subtracting from zero, but it preserves the type of the original duration)
   */
  override def negate = YearMonthDurationValue.fromMonths(-getLengthInMonths)

  /**
   * Compare the value to another duration value
   *
   * @param other The other dateTime value
   * @return negative value if this one is the earler, 0 if they are chronologically equal,
   *         positive value if this one is the later. For this purpose, dateTime values with an unknown
   *         timezone are considered to be UTC values (the Comparable interface requires
   *         a total ordering).
   * @throws ClassCastException if the other value is not a DateTimeValue (the parameter
   *                            is declared as Object to satisfy the Comparable interface)
   */
  override def compareTo(other: YearMonthDurationValue) = Integer.compare(getLengthInMonths, other.getLengthInMonths)

  /**
   * Get a Comparable value that implements the XPath ordering comparison semantics for this value.
   * Returns null if the value is not comparable according to XPath rules. The default implementation
   * returns the value itself. This is modified for types such as
   * xs:duration which allow ordering comparisons in XML Schema, but not in XPath.
   *
   * @param ordered          true if ordered comparisons need to be supported
   * @param collator         for comparing strings - not used
   * @param implicitTimezone implicit timezone in the dynamic context - not used
   */
  override def getXPathComparable(ordered: Boolean, collator: StringCollator, implicitTimezone: Int) = this
}