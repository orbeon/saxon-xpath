////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType

/**
 * An Untyped Atomic value. This inherits from StringValue for implementation convenience, even
 * though an untypedAtomic value is not a String in the data model type hierarchy.
 */
object UntypedAtomicValue {
  val ZERO_LENGTH_UNTYPED = new UntypedAtomicValue("")
}

class UntypedAtomicValue(val value: CharSequence)

/**
 * Constructor
 *
 * @param value the String value.  Must not be null.  The caller must ensure that the
 *              value will not subsequently change, even though it may be a mutable
 *              object such as a FastStringBuffer.
 */
  extends StringValue {
  this.uValue = uValue
  typeLabel = BuiltInAtomicType.UNTYPED_ATOMIC

  /**
   * Create a copy of this atomic value, with a different type label
   *
   * @param typeLabel the type label of the new copy. The caller is responsible for checking that
   *                  the value actually conforms to this type.
   */
  /*@NotNull*/ override def copyAsSubType(typeLabel: AtomicType) = {
    if (!(typeLabel == BuiltInAtomicType.UNTYPED_ATOMIC)) throw new UnsupportedOperationException
    this
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.UNTYPED_ATOMIC

  /**
   * Get the value of the item as a CharSequence. This is in some cases more efficient than
   * the version of the method that returns a String.
   */
  override final def getStringValueCS = value

  /**
   * For displaying the value in error messages, prefix with "u" to highlight that it's
   * untyped atomic
   *
   * @return a short depiction of the string for use in error messages
   */
  override def toShortString = "u" + super.toShortString
}