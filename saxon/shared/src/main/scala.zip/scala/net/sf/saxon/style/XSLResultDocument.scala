////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.ErrorExpression
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.ResultDocument
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om._
import net.sf.saxon.trans.SaxonErrorCode
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.value.EmptySequence
import net.sf.saxon.value.Whitespace
import java.util
import java.util.Properties

/**
 * An xsl:result-document element in the stylesheet.
 * <p>
 * The xsl:result-document element takes an attribute href="filename". The filename will
 * often contain parameters, e.g. {position()} to ensure that a different file is produced
 * for each element instance.
 * <p>
 * There is a further attribute "format" which determines the format of the
 * output file, it identifies the name of an xsl:output element containing the output
 * format details.
 */
object XSLResultDocument {
  val fans = new util.HashSet[String](40) // formatting attribute names
  var METHOD = new StructuredQName("", "", "method")
  var BUILD_TREE = new StructuredQName("", "", "build-tree")
  try fans.add("allow-duplicate-names")
  fans.add("build-tree")
  fans.add("byte-order-mark")
  fans.add("cdata-section-elements")
  fans.add("doctype-public")
  fans.add("doctype-system")
  fans.add("encoding")
  fans.add("escape-uri-attributes")
  fans.add("html-version")
  fans.add("include-content-type")
  fans.add("indent")
  fans.add("item-separator")
  fans.add("json-node-output-method")
  fans.add("media-type")
  fans.add("method")
  fans.add("normalization-form")
  fans.add("omit-xml-declaration")
  fans.add("output-version")
  fans.add("parameter-document")
  fans.add("standalone")
  fans.add("suppress-indentation")
  fans.add("undeclare-prefixes")
  fans.add(SaxonOutputKeys.ATTRIBUTE_ORDER)
  fans.add(SaxonOutputKeys.CANONICAL)
  fans.add(SaxonOutputKeys.CHARACTER_REPRESENTATION)
  fans.add(SaxonOutputKeys.DOUBLE_SPACE)
  fans.add(SaxonOutputKeys.INDENT_SPACES)
  fans.add(SaxonOutputKeys.LINE_LENGTH)
  fans.add(SaxonOutputKeys.NEWLINE)
  fans.add(SaxonOutputKeys.NEXT_IN_CHAIN)
  fans.add(SaxonOutputKeys.RECOGNIZE_BINARY)
  fans.add(SaxonOutputKeys.REQUIRE_WELL_FORMED)
  fans.add(SaxonOutputKeys.PROPERTY_ORDER)
  fans.add(SaxonOutputKeys.SINGLE_QUOTES)
  fans.add(SaxonOutputKeys.SUPPLY_SOURCE_LOCATOR)
}

class XSLResultDocument extends StyleElement {
  private var href = null
  private var formatQName = null // used when format is a literal string
  private var formatExpression = null // used when format is an AVT
  private var validationAction = Validation.STRIP
  private var schemaType = null
  private val serializationAttributes = new util.HashMap[StructuredQName, Expression](10)
  private var async = true

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var formatAttribute = null
    var hrefAttribute = null
    var validationAtt = null
    var typeAtt = null
    var useCharacterMapsAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val name = attName.getStructuredQName
      val value = att.getValue
      val f = name.getClarkName
      if (f == "format") {
        formatAttribute = Whitespace.trim(value)
        formatExpression = makeAttributeValueTemplate(formatAttribute, att)
      }
      else if (f == "href") {
        hrefAttribute = Whitespace.trim(value)
        href = makeAttributeValueTemplate(hrefAttribute, att)
      }
      else if (f == "validation") validationAtt = Whitespace.trim(value)
      else if (f == "type") typeAtt = Whitespace.trim(value)
      else if (f == "use-character-maps") useCharacterMapsAtt = Whitespace.trim(value)
      else if (XSLResultDocument.fans.contains(f) || (f.startsWith("{") && !(StandardNames.SAXON_ASYCHRONOUS == f))) { // this is a serialization attribute
        var `val` = value
        if (!(f == SaxonOutputKeys.ITEM_SEPARATOR) && !(f == SaxonOutputKeys.NEWLINE)) `val` = Whitespace.trim(value)
        val exp = makeAttributeValueTemplate(`val`, att)
        serializationAttributes.put(name, exp)
      }
      else if (name.getLocalPart == "asynchronous" && name.hasURI(NamespaceConstant.SAXON)) {
        async = processBooleanAttribute("saxon:asynchronous", value)
        if (getCompilation.getCompilerInfo.isCompileWithTracing) async = false
        else if (!("EE" == getConfiguration.getEditionCode)) {
          compileWarning("saxon:asynchronous - ignored when not running Saxon-EE", SaxonErrorCode.SXWN9013)
          async = false
        }
      }
      else checkUnknownAttribute(attName)
    }
    if (formatAttribute != null) if (formatExpression.isInstanceOf[StringLiteral]) {
      formatQName = makeQName(formatExpression.asInstanceOf[StringLiteral].getStringValue, "XTDE1460", "format")
      formatExpression = null
    }
    else getPrincipalStylesheetModule.setNeedsDynamicOutputProperties(true)
    if (validationAtt == null) validationAction = getDefaultValidation
    else validationAction = validateValidationAttribute(validationAtt)
    if (typeAtt != null) {
      if (!isSchemaAware) compileError("The @type attribute is available only with a schema-aware XSLT processor", "XTSE1660")
      schemaType = getSchemaType(typeAtt)
      validationAction = Validation.BY_TYPE
    }
    if (typeAtt != null && validationAtt != null) compileError("The @validation and @type attributes are mutually exclusive", "XTSE1505")
    if (useCharacterMapsAtt != null) {
      val s = XSLOutput.prepareCharacterMaps(this, useCharacterMapsAtt, new Properties)
      serializationAttributes.put(new StructuredQName("", "", "use-character-maps"), new StringLiteral(s))
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    if (href != null && !getConfiguration.getBooleanProperty(Feature.ALLOW_EXTERNAL_FUNCTIONS)) compileError("xsl:result-document is disabled when extension functions are disabled")
    href = typeCheck("href", href)
    formatExpression = typeCheck("format", formatExpression)
    import scala.collection.JavaConversions._
    for (prop <- serializationAttributes.keySet) {
      val exp1 = serializationAttributes.get(prop)
      val exp2 = typeCheck(prop.getDisplayName, exp1)
      if (exp1 ne exp2) serializationAttributes.put(prop, exp2)
    }
    getContainingPackage.setCreatesSecondaryResultDocuments(true)
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = { // Check that the call is not within xsl:variable or xsl:function.
    // This is a dynamic error, but worth detecting statically.
    // In fact this is a bit of a fudge. If a function or variable is inlined, we sometimes don't detect
    // XTDE1480 at run-time. Doing this static check improves our chances, though it won't catch all cases.
    val ai = iterateAxis(AxisInfo.ANCESTOR)
    var node = null
    while ( {
      (node = ai.next) != null
    }) if (node.isInstanceOf[XSLGeneralVariable] || node.isInstanceOf[XSLFunction]) {
      issueWarning("An xsl:result-document instruction inside " + node.getDisplayName + " will always fail at run-time", this)
      return new ErrorExpression("Call to xsl:result-document while in temporary output state", "XTDE1480", false)
    }
    var globalProps = null
    if (formatExpression == null) try globalProps = getPrincipalStylesheetModule.gatherOutputProperties(formatQName)
    catch {
      case err: XPathException =>
        compileError("Named output format has not been defined", "XTDE1460")
        return null
    }
    else {
      globalProps = new Properties
      getPrincipalStylesheetModule.setNeedsDynamicOutputProperties(true)
    }
    // If no serialization method was specified, we can work it out statically if the
    // first contained instruction is a literal result element. This saves effort at run-time.
    var method = null
    if (formatExpression == null && globalProps.getProperty("method") == null && serializationAttributes.get(XSLResultDocument.METHOD) == null) {
      val kids = iterateAxis(AxisInfo.CHILD)
      val first = kids.next
      if (first.isInstanceOf[LiteralResultElement]) {
        if (first.getURI == NamespaceConstant.XHTML && first.getLocalPart == "html") method = if (getEffectiveVersion == 10) "xml"
        else "xhtml"
        else if (first.getLocalPart.equalsIgnoreCase("html") && first.getURI.isEmpty) method = "html"
        else method = "xml"
        globalProps.setProperty("method", method)
      }
    }
    val localProps = new Properties
    val fixed = new util.HashSet[StructuredQName](10)
    val namespaceResolver = getStaticContext.getNamespaceResolver
    import scala.collection.JavaConversions._
    for (property <- serializationAttributes.keySet) {
      val exp = serializationAttributes.get(property)
      if (exp.isInstanceOf[StringLiteral]) {
        val s = exp.asInstanceOf[StringLiteral].getStringValue
        val lname = property.getLocalPart
        val uri = property.getURI
        try {
          ResultDocument.setSerializationProperty(localProps, uri, lname, s, namespaceResolver, false, exec.getConfiguration)
          fixed.add(property)
          if (property == XSLResultDocument.METHOD) method = s
        } catch {
          case e: XPathException =>
            if (NamespaceConstant.SAXON == e.getErrorCodeNamespace) compileWarning(e.getMessage, e.getErrorCodeQName)
            else {
              e.setErrorCode("XTSE0020")
              compileError(e)
            }
        }
      }
    }
    import scala.collection.JavaConversions._
    for (p <- fixed) {
      serializationAttributes.remove(p)
    }
    val inst = new ResultDocument(globalProps, localProps, href, formatExpression, validationAction, schemaType, serializationAttributes, getContainingPackage.getCharacterMapIndex)
    var content = compileSequenceConstructor(exec, decl, true)
    if (content == null) content = Literal.makeLiteral(EmptySequence.getInstance)
    inst.setContentExpression(content)
    inst.setAsynchronous(async)
    inst
  }
}