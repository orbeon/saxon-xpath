////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.ConstrainedIterator
import net.sf.saxon.value.EmptySequence

/**
 * A value that is a sequence containing zero or one items.
 */
object ZeroOrOne {
  @SuppressWarnings(Array("rawtypes")) private val EMPTY = new ZeroOrOne[Item](null)

  /**
   * Return the instance of ZeroOrOne that represents the empty sequence
   *
   * @return a representation of the empty sequence that satisfies the type ZeroOrOne
   */
  @SuppressWarnings(Array("unchecked")) def empty[T <: Item] = EMPTY
}

class ZeroOrOne[T <: Item](var item: T // may be null, to represent an empty sequence
                          )

/**
 * Create a sequence containing zero or one items
 *
 * @param item The item to be contained in the sequence, or null if the sequence
 *             is to be empty
 */
  extends GroundedValue {
  /**
   * Get the string value of this sequence. The string value of an item is the result of applying the string()
   * function. The string value of an empty sequence is the zero-length string.
   *
   * @return the string value of the sequence.
   */
  override def getStringValueCS = if (item == null) ""
  else item.getStringValueCS

  /**
   * Convert the value to a string, using the serialization rules.
   * For atomic values this is the same as a cast; for sequence values
   * it gives a space-separated list. For QNames and NOTATIONS, or lists
   * containing them, it fails.
   */
  /*@NotNull*/ override def getStringValue = if (item == null) ""
  else item.getStringValue

  /**
   * Get the first item in the sequence.
   *
   * @return the first item in the sequence if there is one, or null if the sequence
   *         is empty
   */
  override def head = item

  /**
   * Get the length of the sequence
   */
  override def getLength = if (item == null) 0
  else 1

  /**
   * Get the n'th item in the sequence (starting from 0). This is defined for all
   * SequenceValues, but its real benefits come for a SequenceValue stored extensionally
   * (or for a MemoClosure, once all the values have been read)
   *
   * @param n the index of the required item, with 0 representing the first item in the sequence
   * @return the n'th item if it exists, or null otherwise
   */
  /*@Nullable*/ override def itemAt(n: Int) = if (n == 0 && item != null) item
  else null

  /**
   * Get a subsequence of the value
   *
   * @param start  the index of the first item to be included in the result, counting from zero.
   *               A negative value is taken as zero. If the value is beyond the end of the sequence, an empty
   *               sequence is returned
   * @param length the number of items to be included in the result. Specify Integer.MAX_VALUE to
   *               get the subsequence up to the end of the base sequence. If the value is negative, an empty sequence
   *               is returned. If the value goes off the end of the sequence, the result returns items up to the end
   *               of the sequence
   * @return the required subsequence. If min is
   */
  override def subsequence(start: Int, length: Int) = if (item != null && start <= 0 && start + length > 0) this
  else EmptySequence.getInstance

  /**
   * Return an iterator over this value.
   */
  override def iterate = new ConstrainedIterator[T]() {
    private[om] var gone = false
    override

    def hasNext: Boolean = return item != null && !gone

    override

    def next: T = if (gone) return null
    else {
      gone = true
      return item
    }

    override

    def getLength: Int = return if (item == null) 0
    else 1

    override

    def materialize: GroundedValue = return if (item == null) EmptySequence.getInstance
    else item

    override

    def getResidue: GroundedValue = return if (gone) EmptySequence.getInstance
    else item

    override

    def getReverseIterator: SequenceIterator = return iterate
  }

  /**
   * Get the effective boolean value
   */
  @throws[XPathException]
  override def effectiveBooleanValue = ExpressionTool.effectiveBooleanValue(item)

  /**
   * Returns a string representation of the object (used only for diagnostics).
   *
   * @return a string representation of the object.
   */
  override def toString = if (item == null) "null"
  else item.toString

  /**
   * Reduce the sequence to its simplest form. If the value is an empty sequence, the result will be
   * EmptySequence.getInstance(). If the value is a single atomic value, the result will be an instance
   * of AtomicValue. If the value is a single item of any other kind, the result will be an instance
   * of SingletonItem. Otherwise, the result will typically be unchanged.
   *
   * @return the simplified sequence
   */
  override def reduce = if (item == null) EmptySequence.getInstance
  else item
}