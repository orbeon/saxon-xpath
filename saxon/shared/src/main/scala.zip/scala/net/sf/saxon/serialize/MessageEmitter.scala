////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import javax.xml.transform.OutputKeys
import java.util.Properties

/**
 * MessageEmitter is the default Receiver for xsl:message output.
 * It is the same as XMLEmitter except that (a) it adds an extra newline at the end of the message, and
 * (b) it recognizes a processing-instruction with name "error-code" specially; this is assumed to contain
 * the error-code requested on the {@code xsl:message} instruction. These changes can be overridden
 * in a user-supplied subclass.
 */
class MessageEmitter() extends XMLEmitter {
  override def setPipelineConfiguration(pipelineConfiguration: PipelineConfiguration) = {
    super.setPipelineConfiguration(pipelineConfiguration)
    if (writer == null && outputStream == null) try setOutputStream(getConfiguration.getStandardErrorOutput)
    catch {
      case e: XPathException =>
        throw new AssertionError(e)
    }
    try {
      val props = new Properties
      props.setProperty(OutputKeys.METHOD, "xml")
      props.setProperty(OutputKeys.INDENT, "yes")
      props.setProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
      setOutputProperties(props)
    } catch {
      case e: XPathException =>
        throw new IllegalStateException(e)
    }
  }

  @throws[XPathException]
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = if (!suppressProcessingInstruction(target, data, locationId, properties)) super.processingInstruction(target, data, locationId, properties)

  /**
   * Method to decide whether a processing instruction in the message should be suppressed. The default
   * implementation suppresses a processing instruction whose target is "error-code"; this processing
   * instruction is inserted into the message; its data part is an EQName containing the error code.
   *
   * @param target     the processing instruction target (that is, name)
   * @param data       the data part of the processing instruction
   * @param locationId the location, which in the case of the error-code processing instruction, holds
   *                   the location of the originating xsl:message instruction
   * @param properties currently 0.
   * @return true if the processing instruction is to be suppressed from the displayed message.
   */
  protected def suppressProcessingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = target == "error-code"

  @throws[XPathException]
  override def endDocument() = {
    try if (writer != null) {
      writer.write('\n')
      writer.flush()
    }
    catch {
      case err: IOException =>
        throw new XPathException(err)
    }
    super.endDocument()
  }

  @throws[XPathException]
  override def close() = {
    try if (writer != null) writer.flush()
    catch {
      case err: IOException =>
        throw new XPathException(err)
    }
    super.close()
  }
}