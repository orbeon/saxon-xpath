////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.functions.ResolveQName
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.lib.SerializerFactory
import net.sf.saxon.om._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace
import javax.xml.transform.OutputKeys
import java.util
import java.util.Properties
import java.util.StringTokenizer

/**
 * An xsl:output element in the stylesheet.
 */
object XSLOutput {
  private def isListOfNames(property: String) = property == OutputKeys.CDATA_SECTION_ELEMENTS || property == SaxonOutputKeys.SUPPRESS_INDENTATION || property == SaxonOutputKeys.ATTRIBUTE_ORDER || property == SaxonOutputKeys.DOUBLE_SPACE

  private def isQName(property: String) = property == OutputKeys.METHOD || property == SaxonOutputKeys.JSON_NODE_OUTPUT_METHOD

  /**
   * Process the use-character-maps attribute
   *
   * @param element          the stylesheet element on which the use-character-maps attribute appears
   * @param useCharacterMaps the value of the use-character-maps attribute
   * @param details          The existing output properties
   * @return the augmented value of the use-character-maps attribute in Clark notation
   */
  def prepareCharacterMaps(element: StyleElement, useCharacterMaps: String, details: Properties) = {
    val psm = element.getPrincipalStylesheetModule
    var existing = details.getProperty(SaxonOutputKeys.USE_CHARACTER_MAPS)
    if (existing == null) existing = ""
    val s = new StringBuilder
    val st = new StringTokenizer(useCharacterMaps, " \t\n\r", false)
    while ( {
      st.hasMoreTokens
    }) {
      val displayname = st.nextToken
      val qName = element.makeQName(displayname, null, "use-character-maps")
      val decl = psm.getCharacterMap(qName)
      if (decl == null) element.compileErrorInAttribute("No character-map named '" + displayname + "' has been defined", "XTSE1590", "use-character-maps")
      s.append(" ").append(qName.getClarkName)
    }
    existing = s + existing
    existing
  }
}

class XSLOutput extends StyleElement {
  private var outputFormatName = null
  /*@Nullable*/ private val method = null
  private val outputVersion = null
  private var useCharacterMaps = null
  private val serializationAttributes = new util.HashMap[String, String](10)
  private var userAttributes = null

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  override def prepareAttributes() = {
    var nameAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getStructuredQName.getClarkName
      if (f == "name") nameAtt = Whitespace.trim(value)
      else if (f == "version") {
        val outputVersion = Whitespace.trim(value)
        serializationAttributes.put(f, outputVersion)
      }
      else if (f == "use-character-maps") useCharacterMaps = value
      else if (f == "parameter-document") {
        val `val` = Whitespace.trim(value)
        serializationAttributes.put(f, `val`)
        serializationAttributes.put(SaxonOutputKeys.PARAMETER_DOCUMENT_BASE_URI, getBaseURI)
      }
      else if (XSLResultDocument.fans.contains(f) && !(f == "output-version")) {
        var `val` = value
        if (!(f == SaxonOutputKeys.ITEM_SEPARATOR) && !(f == SaxonOutputKeys.NEWLINE)) `val` = Whitespace.trim(`val`)
        serializationAttributes.put(f, `val`)
      }
      else {
        val attributeURI = attName.getURI
        if ("" == attributeURI || NamespaceConstant.XSLT == attributeURI || NamespaceConstant.SAXON == attributeURI) checkUnknownAttribute(attName)
        else {
          val name = '{' + attributeURI + '}' + attName.getLocalPart
          if (userAttributes == null) userAttributes = new util.HashMap[String, String](5)
          userAttributes.put(name, value)
        }
      }
    }
    if (nameAtt != null) outputFormatName = makeQName(nameAtt, "XTSE1570", "name")
  }

  /**
   * Get the name of the xsl:output declaration
   *
   * @return the name, as a structured QName; or null for an unnamed output declaration
   */
  def getFormatQName = outputFormatName

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    checkTopLevel("XTSE0010", false)
    checkEmpty()
  }

  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = {
    // no action
  }

  /**
   * Process the [xsl:]version attribute if there is one
   *
   * @param ns the namespace URI of the attribute required, either the XSLT namespace or ""
   */
  override protected def processVersionAttribute(ns: String) = version = getParent.asInstanceOf[StyleElement].getEffectiveVersion

  /**
   * Validate the properties,
   * and return the values as additions to a supplied Properties object.
   *
   * @param details        the Properties object to be populated with property values
   * @param precedences    a HashMap to be populated with information about the precedence
   *                       of the property values: the key is the property name as a Clark name, the value
   *                       is a boxed integer giving the property's import precedence
   * @param thisPrecedence the precedence of thi instruction
   * @throws net.sf.saxon.trans.XPathException
   * if an error is found
   */
  @throws[XPathException]
  protected def gatherOutputProperties(details: Properties, precedences: util.HashMap[String, Integer], thisPrecedence: Int) = {
    val sf = getConfiguration.getSerializerFactory
    if (method != null) if ("xml" == method || "html" == method || "text" == method || "xhtml" == method || "json" == method || "adaptive" == method) {
      checkAndPut(sf, OutputKeys.METHOD, method, details, precedences, thisPrecedence)
      //details.put(OutputKeys.METHOD, method);
    }
    else {
      var parts = null
      try {
        parts = NameChecker.getQNameParts(method)
        val prefix = parts(0)
        if (prefix.isEmpty) compileError("method must be xml, html, xhtml, text, json, adaptive, or a prefixed name", "XTSE1570")
        else {
          val uri = getURIForPrefix(prefix, false)
          if (uri == null) undeclaredNamespaceError(prefix, "XTSE0280", "method")
          checkAndPut(sf, OutputKeys.METHOD, '{' + uri + '}' + parts(1), details, precedences, thisPrecedence)
          //details.put(OutputKeys.METHOD, '{' + uri + '}' + parts[1] );
        }
      } catch {
        case e: QNameException =>
          compileError("Invalid method name. " + e.getMessage, "XTSE1570")
      }
    }
    import scala.collection.JavaConversions._
    for (entry <- serializationAttributes.entrySet) {
      checkAndPut(sf, entry.getKey, entry.getValue, details, precedences, thisPrecedence)
    }
    if (serializationAttributes.containsKey(SaxonOutputKeys.NEXT_IN_CHAIN)) checkAndPut(sf, SaxonOutputKeys.NEXT_IN_CHAIN_BASE_URI, getSystemId, details, precedences, thisPrecedence)
    if (useCharacterMaps != null) {
      val s = XSLOutput.prepareCharacterMaps(this, useCharacterMaps, details)
      details.setProperty(SaxonOutputKeys.USE_CHARACTER_MAPS, s)
    }
    // deal with user-defined attributes
    if (userAttributes != null) {
      import scala.collection.JavaConversions._
      for (e <- userAttributes.entrySet) {
        details.setProperty(e.getKey, e.getValue)
      }
    }
  }

  /**
   * Add an output property to the list of properties after checking that it is consistent
   * with other properties
   *
   * @param property       the name of the property in Clark format
   * @param value          the value of the property
   * @param props          the list of properties to be updated
   * @param precedences    the import precedence of each property
   * @param thisPrecedence the import precedence of the declaration containing this value
   * @throws net.sf.saxon.trans.XPathException
   * if an error occurs
   */
  private def checkAndPut(sf: SerializerFactory, property: String, value: String, props: Properties, precedences: util.HashMap[String, Integer], thisPrecedence: Int): Unit = {
    try {
      if (XSLOutput.isListOfNames(property)) {
        val useDefaultNS = !(property == SaxonOutputKeys.ATTRIBUTE_ORDER)
        val allowStar = property == SaxonOutputKeys.ATTRIBUTE_ORDER
        value = SaxonOutputKeys.parseListOfNodeNames(value, this, useDefaultNS, false, allowStar, "XTSE0280")
      }
      if (XSLOutput.isQName(property) && value.contains(":")) value = ResolveQName.resolveQName(value, this).getEQName
      value = sf.checkOutputProperty(property, value)
    } catch {
      case err: XPathException =>
        val code = if (property == "method") "XTSE1570"
        else "XTSE0020"
        if (property.contains("{")) compileError(err.getMessage, code)
        else compileErrorInAttribute(err.getMessage, code, property)
        return
    }
    val old = props.getProperty(property)
    if (old == null) {
      props.setProperty(property, value)
      precedences.put(property, thisPrecedence)
    }
    else if (old == value) {
      // do nothing
    }
    else if (XSLOutput.isListOfNames(property)) {
      props.setProperty(property, old + " " + value)
      precedences.put(property, thisPrecedence)
    }
    else {
      val oldPrec = precedences.get(property)
      if (oldPrec == null) return // shouldn't happen but ignore it
      if (oldPrec > thisPrecedence) {
        // ignore this value, the other has higher precedence
      }
      else if (oldPrec eq thisPrecedence) compileError("Conflicting values for output property " + property, "XTSE1560")
      else { // this has higher precedence: can't happen
        throw new IllegalStateException("Output properties must be processed in decreasing precedence order")
      }
    }
  }
}