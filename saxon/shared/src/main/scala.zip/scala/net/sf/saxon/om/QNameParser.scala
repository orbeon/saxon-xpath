////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2013-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.query.XQueryParser
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * Parser to handle QNames in either lexical QName or EQName syntax, including resolving any prefix against
 * a URIResolver. The parser can be instantiated with various options to control the returned error code,
 * the handling of defaults, etc.
 *
 * The QNameParser is immutable; its properties are set using the <code>withProperty()</code> fluent API style.
 */
class QNameParser(var resolver: NamespaceResolver) {
  private var acceptEQName = false
  private var errorOnBadSyntax = "XPST0003"
  private var errorOnUnresolvedPrefix = "XPST0081"
  private var unescaper = null

  /**
   * Set the namespace resolver to be used
   *
   * @param resolver the namespace resolver
   * @return a new QNameParser using the specified NamespaceResolver
   */
  def withNamespaceResolver(resolver: NamespaceResolver) = {
    val qp2 = copy
    qp2.resolver = resolver
    qp2
  }

  /**
   * Say whether URI-qualified names in <code>Q{uri}local</code> format should be accepted
   *
   * @param acceptEQName true if extended QName syntax is accepted
   * @return a new QNameParser with the requested properties
   */
  def withAcceptEQName(acceptEQName: Boolean): QNameParser = {
    if (acceptEQName == this.acceptEQName) return this
    val qp2 = copy
    qp2.acceptEQName = acceptEQName
    qp2
  }

  /**
   * Say what error code should be thrown when the QName syntax is invalid
   *
   * @param code the error code to be thrown
   * @return a new QNameParser with the requested properties
   */
  def withErrorOnBadSyntax(code: String): QNameParser = {
    if (code == errorOnBadSyntax) return this
    val qp2 = copy
    qp2.errorOnBadSyntax = code
    qp2
  }

  /**
   * Say what error code should be thrown when the prefix is undeclared
   *
   * @param code the error code to be thrown
   * @return a new QNameParser with the requested properties
   */
  def withErrorOnUnresolvedPrefix(code: String): QNameParser = {
    if (code == errorOnUnresolvedPrefix) return this
    val qp2 = copy
    qp2.errorOnUnresolvedPrefix = code
    qp2
  }

  /**
   * Supply a callback used to unescape special characters appearing in the URI part of an EQName
   *
   * @param unescaper the callback to be used
   * @return a new QNameParser with the requested properties
   */
  def withUnescaper(unescaper: XQueryParser.Unescaper) = {
    val qp2 = copy
    qp2.unescaper = unescaper
    qp2
  }

  private def copy = {
    val qp2 = new QNameParser(resolver)
    qp2.acceptEQName = acceptEQName
    qp2.errorOnBadSyntax = errorOnBadSyntax
    qp2.errorOnUnresolvedPrefix = errorOnUnresolvedPrefix
    qp2.unescaper = unescaper
    qp2
  }

  /**
   * Make a structured QName from a lexical QName, using a supplied NamespaceResolver to
   * resolve the prefix. The local part of the QName is checked for validity; the prefix is
   * not checked, on the grounds that an invalid prefix will fail to resolve to a URI.
   *
   * @param lexicalName the QName as a lexical name (prefix:local)
   * @param defaultNS   the default namespace to use if there is no prefix
   * @return the StructuredQName object corresponding to this lexical QName
   * @throws net.sf.saxon.trans.XPathException if the namespace prefix is not in scope or if the value is lexically
   *                        invalid. Error code FONS0004 is set if the namespace prefix has not been declared; error
   *                                           code FOCA0002 is set if the name is lexically invalid. These may need to be
   *                                           changed on return depending on the caller's requirements.
   */
  @throws[XPathException]
  def parse(lexicalName: CharSequence, defaultNS: String): StructuredQName = {
    lexicalName = Whitespace.trimWhitespace(lexicalName)
    if (acceptEQName && lexicalName.length >= 4 && lexicalName.charAt(0) == 'Q' && lexicalName.charAt(1) == '{') {
      val name = lexicalName.toString
      val endBrace = name.indexOf('}')
      if (endBrace < 0) throw new XPathException("Invalid EQName: closing brace not found", errorOnBadSyntax)
      else if (endBrace == name.length - 1) throw new XPathException("Invalid EQName: local part is missing", errorOnBadSyntax)
      var uri = name.substring(2, endBrace).toString
      //String uri = Whitespace.collapseWhitespace(name.substring(2, endBrace)).toString();
      if (unescaper != null && uri.contains("&")) uri = unescaper.unescape(uri).toString
      if (uri == NamespaceConstant.XMLNS) throw new XPathException("The string '" + NamespaceConstant.XMLNS + "' cannot be used as a namespace URI", "XQST0070")
      val local = name.substring(endBrace + 1)
      checkLocalName(local)
      return new StructuredQName("", uri, local)
    }
    try {
      val parts = NameChecker.getQNameParts(lexicalName)
      checkLocalName(parts(1))
      if (parts(0).isEmpty) return new StructuredQName("", defaultNS, parts(1))
      val uri = resolver.getURIForPrefix(parts(0), false)
      if (uri == null) throw new XPathException("Namespace prefix '" + parts(0) + "' has not been declared", errorOnUnresolvedPrefix)
      new StructuredQName(parts(0), uri, parts(1))
    } catch {
      case e: QNameException =>
        throw new XPathException(e.getMessage, errorOnBadSyntax)
    }
  }

  @throws[XPathException]
  private def checkLocalName(local: String) = if (!NameChecker.isValidNCName(local)) throw new XPathException("Invalid EQName: local part is not a valid NCName", errorOnBadSyntax)
}