////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.expr.LastPositionFinder
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.ArrayIterator
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.tree.iter.GroundedIterator
import net.sf.saxon.tree.iter.SingletonIterator
import net.sf.saxon.value.EmptySequence
import net.sf.saxon.value.SequenceExtent
import java.util

/**
 * A Sequence implementation that represents a lazy evaluation of a supplied iterator. Items
 * are read from the base iterator only when they are first required, and are then remembered
 * within the local storage of the MemoSequence, which eventually (if the sequence is read
 * to the end) contains the entire value.
 */
object MemoSequence {

  private object State extends Enumeration {
    type State = Value
    val // State in which no items have yet been read
    UNREAD, // State in which zero or more items are in the reservoir and it is not known
    // whether more items exist
    MAYBE_MORE, // State in which all the items are in the reservoir
    ALL_READ, // State in which we are getting the base iterator. If the closure is called in this state,
    // it indicates a recursive entry, which is only possible on an error path
    BUSY, // State in which we know that the value is an empty sequence
    EMPTY = Value
  }

}

class MemoSequence(var inputIterator: SequenceIterator) extends Sequence {
  private var reservoir = null
  private var used = 0
  protected var state = MemoSequence.State.UNREAD

  @throws[XPathException]
  override def head = iterate.next

  @throws[XPathException]
  override def iterate: SequenceIterator = state match {
    case UNREAD =>
      state = MemoSequence.State.BUSY
      if (inputIterator.isInstanceOf[EmptyIterator]) {
        state = MemoSequence.State.EMPTY
        return inputIterator
      }
      reservoir = new Array[Item](50)
      used = 0
      state = MemoSequence.State.MAYBE_MORE
      new MemoSequence#ProgressiveIterator
    case MAYBE_MORE =>
      new MemoSequence#ProgressiveIterator
    case ALL_READ =>
      used match {
        case 0 =>
          state = MemoSequence.State.EMPTY
          EmptyIterator.emptyIterator
        case 1 =>
          assert(reservoir != null)
          SingletonIterator.makeIterator(reservoir(0))
        case _ =>
          new ArrayIterator[Item](reservoir, 0, used)
      }
    case BUSY =>
      // recursive entry: can happen if there is a circularity involving variable and function definitions
      // Can also happen if variable evaluation is attempted in a debugger, hence the cautious message
      val de = new XPathException("Attempt to access a variable while it is being evaluated")
      de.setErrorCode("XTDE0640")
      //de.setXPathContext(context);
      throw de
    case EMPTY =>
      EmptyIterator.emptyIterator
    case _ =>
      throw new IllegalStateException("Unknown iterator state")
  }

  /**
   * Get the Nth item in the sequence (0-based), reading new items into the internal reservoir if necessary
   *
   * @param n the index of the required item
   * @return the Nth item if it exists, or null otherwise
   * @throws XPathException if the input sequence cannot be read
   */
  @throws[XPathException]
  def itemAt(n: Int): Item = {
    if (n < 0) return null
    if (reservoir != null && n < used) return reservoir(n)
    if ((state eq MemoSequence.State.ALL_READ) || (state eq MemoSequence.State.EMPTY)) return null
    if (state eq MemoSequence.State.UNREAD) {
      val item = inputIterator.next
      if (item == null) {
        state = MemoSequence.State.EMPTY
        return null
      }
      else {
        state = MemoSequence.State.MAYBE_MORE
        reservoir = new Array[Item](50)
        append(item)
        if (n == 0) return item
      }
    }
    // We have read some items from the input sequence but not enough. Read as many more as are needed.
    var diff = n - used + 1
    while ( {
      {
        diff -= 1;
        diff + 1
      } > 0
    }) {
      val i = inputIterator.next
      if (i == null) {
        state = MemoSequence.State.ALL_READ
        condense()
        return null
      }
      append(i)
      state = MemoSequence.State.MAYBE_MORE
    }
    //noinspection ConstantConditions
    reservoir(n)
  }

  /**
   * Append an item to the reservoir
   *
   * @param item the item to be added
   */
  private def append(item: Item) = {
    assert(reservoir != null)
    if (used >= reservoir.length) reservoir = util.Arrays.copyOf(reservoir, used * 2)
    reservoir({
      used += 1;
      used - 1
    }) = item
  }

  /**
   * Release unused space in the reservoir (provided the amount of unused space is worth reclaiming)
   */
  private def condense() = if (reservoir != null && reservoir.length - used > 30) reservoir = util.Arrays.copyOf(reservoir, used)

  /**
   * A ProgressiveIterator starts by reading any items already held in the reservoir;
   * when the reservoir is exhausted, it reads further items from the inputIterator,
   * copying them into the reservoir as they are read.
   */
  final class ProgressiveIterator()

  /**
   * Create a ProgressiveIterator
   */
    extends SequenceIterator with LastPositionFinder with GroundedIterator {
    private[om] var position = -1 // zero-based position in the reservoir of the
    /**
     * Get the containing MemoSequence
     *
     */
    def getMemoSequence = this

    /*@Nullable*/ @throws[XPathException]
    override def next: Item = {
      this synchronized { // synchronized for the case where a multi-threaded xsl:for-each is reading the variable
        if (position == -2) { // means we've already returned null once, keep doing so if called again.
          return null
        }
        position += 1
        if ( position < used) {
          assert(reservoir != null)
          reservoir(position)
        }
        else if (state eq MemoSequence.State.ALL_READ) { // someone else has read the input to completion in the meantime
          position = -2
          null
        }
        else {
          assert(inputIterator != null)
          val i = inputIterator.next
          if (i == null) {
            state = MemoSequence.State.ALL_READ
            condense()
            position = -2
            return null
          }
          position = used
          append(i)
          state = MemoSequence.State.MAYBE_MORE
          i
        }
      }
    }

    override def close() = {
    }

    /**
     * Get the last position (that is, the number of items in the sequence)
     */
    @throws[XPathException]
    override def getLength = if (state eq MemoSequence.State.ALL_READ) used
    else if (state eq MemoSequence.State.EMPTY) 0
    else { // save the current position
      val savePos = position
      // fill the reservoir
      while ( {
        next != null
      }) {
      }
      // reset the current position
      position = savePos
      // return the total number of items
      used
    }

    /**
     * Return a value containing all the items in the sequence returned by this
     * SequenceIterator
     *
     * @return the corresponding value
     */
    @throws[XPathException]
    override def materialize = if (state eq MemoSequence.State.ALL_READ) makeExtent
    else if (state eq MemoSequence.State.EMPTY) EmptySequence.getInstance
    else {
      val savePos = position
      while ( {
        next != null
      }) {
      }
      position = savePos
      // return all the items
      makeExtent
    }

    private def makeExtent = if (used == reservoir.length) if (used == 0) EmptySequence.getInstance
    else if (used == 1) reservoir(0)
    else new SequenceExtent(reservoir)
    else SequenceExtent.makeSequenceExtent(util.Arrays.asList(reservoir).subList(0, used))

    @throws[XPathException]
    override def getResidue = if ((state eq MemoSequence.State.EMPTY) || position >= used || position == -2) EmptySequence.getInstance
    else if (state eq MemoSequence.State.ALL_READ) SequenceExtent.makeSequenceExtent(util.Arrays.asList(reservoir).subList(position + 1, used))
    else {
      val savePos = position
      while ( {
        next != null
      }) {
      }
      position = savePos
      SequenceExtent.makeSequenceExtent(util.Arrays.asList(reservoir).subList(position + 1, used))
    }

    /**
     * Get properties of this iterator, as a bit-significant integer.
     *
     * @return the properties of this iterator. This will be some combination of
     *         properties such as { @link net.sf.saxon.om.SequenceIterator.Property#GROUNDED} and { @link net.sf.saxon.om.SequenceIterator.Property#LAST_POSITION_FINDER}. It is always
     *         acceptable to return the value zero, indicating that there are no known special properties.
     */
    override def getProperties = { // bug 1740 shows that it is better to report the iterator as grounded even though this
      // may trigger eager evaluation of the underlying sequence.
      util.EnumSet.of(Property.GROUNDED, Property.LAST_POSITION_FINDER)
    }
  }

}