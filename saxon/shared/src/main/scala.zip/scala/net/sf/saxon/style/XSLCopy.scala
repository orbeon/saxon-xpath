////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr._
import net.sf.saxon.expr.instruct._
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace

/**
 * Handler for xsl:copy elements in stylesheet. <br>
 */
class XSLCopy extends StyleElement {
  private var use = null // value of use-attribute-sets attribute
  private var attributeSets = null
  private var copyNamespaces = true
  private var inheritNamespaces = true
  private var validationAction = Validation.PRESERVE
  private var schemaType = null
  private var select = null
  private var selectSpecified = false

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var copyNamespacesAtt = null
    var validationAtt = null
    var typeAtt = null
    var inheritAtt = null
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "use-attribute-sets" =>
          use = value
        case "copy-namespaces" =>
          copyNamespacesAtt = Whitespace.trim(value)
        case "select" =>
          selectAtt = att
        case "type" =>
          typeAtt = Whitespace.trim(value)
        case "validation" =>
          validationAtt = Whitespace.trim(value)
        case "inherit-namespaces" =>
          inheritAtt = Whitespace.trim(value)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (copyNamespacesAtt != null) copyNamespaces = processBooleanAttribute("copy-namespaces", copyNamespacesAtt)
    if (typeAtt != null && validationAtt != null) compileError("The type and validation attributes must not both be specified", "XTSE1505")
    if (validationAtt != null) validationAction = validateValidationAttribute(validationAtt)
    else validationAction = getDefaultValidation
    if (typeAtt != null) {
      schemaType = getSchemaType(typeAtt)
      if (!isSchemaAware) compileError("The @type attribute is available only with a schema-aware XSLT processor", "XTSE1660")
      validationAction = Validation.BY_TYPE
    }
    if (inheritAtt != null) inheritNamespaces = processBooleanAttribute("inherit-namespaces", inheritAtt)
    if (selectAtt != null) {
      select = makeExpression(selectAtt.getValue, selectAtt)
      selectSpecified = true
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    if (use != null) { // get the names of referenced attribute sets
      attributeSets = getUsedAttributeSets(use)
    }
    if (select == null) {
      select = new ContextItemExpression
      select.setLocation(allocateLocation)
    }
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    select = typeCheck("select", select)
    try {
      val role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:copy/select", 0)
      role.setErrorCode("XTTE3180")
      select = getConfiguration.getTypeChecker(false).staticTypeCheck(select, SequenceType.OPTIONAL_ITEM, role, makeExpressionVisitor)
    } catch {
      case err: XPathException =>
        compileError(err)
    }
    var content = compileSequenceConstructor(exec, decl, true)
    if (attributeSets != null) {
      val use = UseAttributeSet.makeUseAttributeSets(attributeSets, this)
      // The use-attribute-sets is ignored unless the context item is an element node. So we
      // wrap the UseAttributeSet instructions in a conditional to perform a run-time test
      val condition = new InstanceOfExpression(new ContextItemExpression, SequenceType.makeSequenceType(NodeKindTest.ELEMENT, StaticProperty.EXACTLY_ONE))
      val choice = Choose.makeConditional(condition, use)
      if (content == null) content = choice
      else {
        content = Block.makeBlock(choice, content)
        content.setLocation(allocateLocation)
      }
    }
    if (content == null) content = Literal.makeEmptySequence
    val inst = new Copy( //select,
      //selectSpecified,
      copyNamespaces, inheritNamespaces, schemaType, validationAction)
    inst.setContentExpression(content)
    if (selectSpecified) new ForEach(select, inst)
    else inst
  }
}