////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import org.jetbrains.annotations.NotNull
import java.util.Collections
import java.util

/**
 * An implementation of AttributeMap representing an empty AttributeMap
 */
object EmptyAttributeMap {
  private val THE_INSTANCE = new EmptyAttributeMap

  def getInstance = THE_INSTANCE
}

class EmptyAttributeMap private() extends AttributeMap {
  /**
   * Return the number of attributes in the map.
   *
   * @return The number of attributes in the map.
   */
  override def size = 0

  override def get(name: NodeName) = null

  override def get(uri: String, local: String) = null

  override def getByFingerprint(fingerprint: Int, namePool: NamePool) = null

  override def put(att: AttributeInfo) = SingletonAttributeMap.of(att)

  override def remove(name: NodeName) = this

  override def iterator = Collections.emptyIterator

  override def apply(mapper: Function[AttributeInfo, AttributeInfo]) = this
}