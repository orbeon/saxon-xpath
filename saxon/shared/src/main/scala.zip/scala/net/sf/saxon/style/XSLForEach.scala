////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.ForEach
import net.sf.saxon.expr.sort.SortExpression
import net.sf.saxon.expr.sort.SortKeyDefinitionList
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.SaxonErrorCode
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.Whitespace

/**
 * Handler for xsl:for-each elements in stylesheet. <br>
 */
class XSLForEach extends StyleElement {
  /*@Nullable*/ private var select = null
  private var containsTailCall = false
  private var threads = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Specify that xsl:sort is a permitted child
   */
  override protected def isPermittedChild(child: StyleElement) = child.isInstanceOf[XSLSort]

  override protected def markTailCalls = {
    assert(select != null)
    if (Cardinality.allowsMany(select.getCardinality)) false
    else {
      val last = getLastChildInstruction
      containsTailCall = last != null && last.markTailCalls
      containsTailCall
    }
  }

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else if (attName.getLocalPart == "threads" && attName.hasURI(NamespaceConstant.SAXON)) {
        val threadsAtt = Whitespace.trim(value)
        threads = makeAttributeValueTemplate(threadsAtt, att)
        if (getCompilation.getCompilerInfo.isCompileWithTracing) {
          compileWarning("saxon:threads - no multithreading takes place when compiling with trace enabled", SaxonErrorCode.SXWN9012)
          threads = new StringLiteral("0")
        }
        else if (!("EE" == getConfiguration.getEditionCode)) {
          compileWarning("saxon:threads - ignored when not running Saxon-EE", SaxonErrorCode.SXWN9013)
          threads = new StringLiteral("0")
        }
      }
      else checkUnknownAttribute(attName)
    }
    if (selectAtt == null) {
      reportAbsence("select")
      select = Literal.makeEmptySequence
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    checkSortComesFirst(false)
    select = typeCheck("select", select)
    if (!hasChildNodes) compileWarning("An empty xsl:for-each instruction has no effect", SaxonErrorCode.SXWN9009)
  }

  @throws[XPathException]
  override def compile(compilation: Compilation, decl: ComponentDeclaration): Expression = {
    val sortKeys = makeSortKeys(compilation, decl)
    var sortedSequence = select
    if (sortKeys != null) sortedSequence = new SortExpression(select, sortKeys)
    val block = compileSequenceConstructor(compilation, decl, true)
    if (block == null) { // body of for-each is empty: it's a no-op.
      return Literal.makeEmptySequence
    }
    try {
      val result = new ForEach(sortedSequence, block.simplify, containsTailCall, threads)
      result.setInstruction(true)
      result.setLocation(allocateLocation)
      result
    } catch {
      case err: XPathException =>
        compileError(err)
        null
    }
  }
}