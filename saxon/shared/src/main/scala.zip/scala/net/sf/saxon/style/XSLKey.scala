////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.Version
import net.sf.saxon.expr._
import net.sf.saxon.expr.instruct.Actor
import net.sf.saxon.expr.instruct.ApplyTemplates
import net.sf.saxon.expr.instruct.CallTemplate
import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.expr.parser._
import net.sf.saxon.expr.sort.CodepointCollator
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ErrorType
import net.sf.saxon.model.ItemType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.om.StandardNames
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.pattern.NodeTestPattern
import net.sf.saxon.pattern.Pattern
import net.sf.saxon.trans._
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace
import java.net.URI
import java.net.URISyntaxException
import java.util.function.Predicate

/**
 * Handler for xsl:key elements in stylesheet. <br>
 */
object XSLKey {

  private class ContainsGlobalVariable extends Predicate[Expression] {
    override def test(e: Expression) = e.isInstanceOf[GlobalVariableReference] || e.isInstanceOf[UserFunctionCall] || e.isInstanceOf[CallTemplate] || e.isInstanceOf[ApplyTemplates]
  }

  private val containsGlobalVariable = new XSLKey.ContainsGlobalVariable
}

class XSLKey extends StyleElement with StylesheetComponent {
  private var `match` = null
  private var use = null
  private var collationName = null
  private var keyName = null
  private var stackFrameMap = null
  private var rangeKey = false
  private var composite = false
  private var keyDefinition = null

  /**
   * Get the corresponding Actor object that results from the compilation of this
   * StylesheetComponent
   *
   * @return the compiled ComponentCode
   * @throws UnsupportedOperationException for second-class components such as keys that support outwards references
   *                                       but not inwards references
   */
  override def getActor = throw new UnsupportedOperationException

  override def getSymbolicName = null

  override def checkCompatibility(component: Component) = {
    // no action: keys cannot be overridden
  }

  override def isDeclaration = true

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  /**
   * Get the Procedure object that looks after any local variables declared in the content constructor
   */
  override def getSlotManager = stackFrameMap

  override def prepareAttributes() = {
    var nameAtt = null
    var matchAtt = null
    var useAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val uri = attName.getURI
      val local = attName.getLocalPart
      if ("" == uri) local match {
        case "name" =>
          nameAtt = Whitespace.trim(value)
        case "use" =>
          useAtt = value
          use = makeExpression(useAtt, att)
        case "match" =>
          matchAtt = value
        case "collation" =>
          collationName = Whitespace.trim(value)
        case "composite" =>
          composite = processBooleanAttribute("composite", value)
        case _ =>
          checkUnknownAttribute(attName)
      }
      else if (local == "range-key" && uri == NamespaceConstant.SAXON) rangeKey = processBooleanAttribute("range-key", value)
      else checkUnknownAttribute(attName)
    }
    if (nameAtt == null) {
      reportAbsence("name")
      nameAtt = "_dummy_key_name"
    }
    keyName = makeQName(nameAtt, null, "name")
    setObjectName(keyName)
    if (matchAtt == null) {
      reportAbsence("match")
      matchAtt = "*"
    }
    `match` = makePattern(matchAtt, "match")
    if (`match` == null) { // error has been reported
      `match` = new NodeTestPattern(ErrorType.getInstance)
    }
  }

  def getKeyName = { //We use null to mean "not yet evaluated"
    if (getObjectName == null) { // allow for forwards references
      val nameAtt = getAttributeValue("", "name")
      if (nameAtt != null) setObjectName(makeQName(nameAtt, null, "name"))
    }
    getObjectName
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    val config = getConfiguration
    stackFrameMap = config.makeSlotManager
    checkTopLevel("XTSE0010", false)
    if (use != null) { // the value can be supplied as a content constructor in place of a use expression
      if (hasChildNodes) compileError("An xsl:key element with a @use attribute must be empty", "XTSE1205")
      try {
        val role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:key/use", 0)
        //role.setSourceLocator(new ExpressionLocation(this));
        use = config.getTypeChecker(false).staticTypeCheck(use, SequenceType.ATOMIC_SEQUENCE, role, makeExpressionVisitor)
      } catch {
        case err: XPathException =>
          compileError(err)
      }
    }
    else if (!hasChildNodes) compileError("An xsl:key element must either have a @use attribute or have content", "XTSE1205")
    use = typeCheck("use", use)
    `match` = typeCheck("match", `match`)
    // Do a further check that the use expression makes sense in the context of the match pattern
    if (use != null) use = use.typeCheck(makeExpressionVisitor, config.makeContextItemStaticInfo(`match`.getItemType, false))
    if (collationName != null) {
      var collationURI = null
      try {
        collationURI = new URI(collationName)
        if (!collationURI.isAbsolute) {
          val base = new URI(getBaseURI)
          collationURI = base.resolve(collationURI)
          collationName = collationURI.toString
        }
      } catch {
        case err: URISyntaxException =>
          compileError("Collation name '" + collationName + "' is not a valid URI")
        //collationName = NamespaceConstant.CODEPOINT_COLLATION_URI;
      }
    }
    else collationName = getDefaultCollationName
  }

  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = {
    val keyName = getKeyName
    if (keyName != null) top.getKeyManager.preRegisterKeyDefinition(keyName)
  }

  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = {
    val env = getStaticContext
    val config = env.getConfiguration
    var collator = null
    if (collationName != null) {
      collator = findCollation(collationName, getBaseURI)
      if (collator == null) {
        compileError("The collation name " + Err.wrap(collationName, Err.URI) + " is not recognized", "XTSE1210")
        collator = CodepointCollator.getInstance
      }
      if (collator.isInstanceOf[CodepointCollator]) { // if the user explicitly asks for the codepoint collation, treat it as if they hadn't asked
        collator = null
        collationName = null
      }
      else if (!Version.platform.canReturnCollationKeys(collator)) compileError("The collation used for xsl:key must be capable of generating collation keys", "XTSE1210")
    }
    if (use == null) {
      val body = compileSequenceConstructor(compilation, decl, true)
      try {
        use = Atomizer.makeAtomizer(body, null)
        use = use.simplify
      } catch {
        case e: XPathException =>
          compileError(e)
      }
      try {
        val role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, "xsl:key/use", 0)
        use = config.getTypeChecker(false).staticTypeCheck(use, SequenceType.ATOMIC_SEQUENCE, role, makeExpressionVisitor)
        assert(`match` != null)
        use = use.typeCheck(makeExpressionVisitor, config.makeContextItemStaticInfo(`match`.getItemType, false))
      } catch {
        case err: XPathException =>
          compileError(err)
      }
    }
    var useItemType = use.getItemType
    if (useItemType eq ErrorType.getInstance) useItemType = BuiltInAtomicType.STRING // corner case, prevents crashing
    var useType = useItemType.getPrimitiveItemType.asInstanceOf[BuiltInAtomicType]
    if (xPath10ModeIsEnabled) if (!(useType == BuiltInAtomicType.STRING) && !(useType == BuiltInAtomicType.UNTYPED_ATOMIC)) {
      use = new AtomicSequenceConverter(use, BuiltInAtomicType.STRING)
      use.asInstanceOf[AtomicSequenceConverter].allocateConverter(config, false)
      useType = BuiltInAtomicType.STRING
    }
    // first slot in pattern is reserved for current()
    var nextFree = 0
    if ((`match`.getDependencies & StaticProperty.DEPENDS_ON_CURRENT_ITEM) != 0) nextFree = 1
    `match`.allocateSlots(stackFrameMap, nextFree)
    // If either the match pattern or the use expression references a global variable or parameter,
    // or a call on a function or template that might reference one, then
    // the key indexes cannot be reused across multiple transformations. See Saxon bug 1968.
    val sensitive = ExpressionTool.contains(use, false, XSLKey.containsGlobalVariable) || ExpressionTool.contains(`match`, false, XSLKey.containsGlobalVariable)
    val km = getCompilation.getPrincipalStylesheetModule.getKeyManager
    val symbolicName = new SymbolicName(StandardNames.XSL_KEY, keyName)
    val keydef = new KeyDefinition(symbolicName, `match`, use, collationName, collator)
    keydef.setPackageData(getCompilation.getPackageData)
    keydef.setRangeKey(rangeKey)
    keydef.setIndexedItemType(useType)
    keydef.setStackFrameMap(stackFrameMap)
    keydef.setLocation(getSystemId, getLineNumber)
    keydef.setBackwardsCompatible(xPath10ModeIsEnabled)
    keydef.setComposite(composite)
    keydef.obtainDeclaringComponent(this)
    try km.addKeyDefinition(keyName, keydef, !sensitive, compilation.getConfiguration)
    catch {
      case err: XPathException =>
        compileError(err)
    }
    keyDefinition = keydef
  }

  /**
   * Optimize the stylesheet construct
   *
   * @param declaration this xsl:key declaration
   */
  @throws[XPathException]
  override def optimize(declaration: ComponentDeclaration) = {
    val visitor = makeExpressionVisitor
    val contextItemType = getConfiguration.makeContextItemStaticInfo(`match`.getItemType, false)
    var useExp = keyDefinition.getUse
    useExp = useExp.optimize(visitor, contextItemType)
    allocateLocalSlots(useExp)
    keyDefinition.setBody(useExp)
  }

  /**
   * Generate byte code if appropriate
   *
   * @param opt the optimizer
   */
  override def generateByteCode(opt: Optimizer) = {
  }
}