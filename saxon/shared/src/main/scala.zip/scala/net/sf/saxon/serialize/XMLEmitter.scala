////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.Configuration
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.serialize.charcode.UTF16CharacterSet
import net.sf.saxon.serialize.charcode.UTF8CharacterSet
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.tiny.CharSlice
import net.sf.saxon.tree.tiny.CompressedWhitespace
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.Whitespace
import javax.xml.transform.OutputKeys
import java.util
import java.util.Properties

/**
 * XMLEmitter is an Emitter that generates XML output
 * to a specified destination.
 */
object XMLEmitter {
  private[serialize] var specialInText = null // lookup table for special characters in text
  private[serialize] var specialInAtt = null // lookup table for special characters in attributes
  private[serialize] var specialInAttSingle = null // lookup table for special characters in attributes with single-quote delimiter
  try specialInText = new Array[Boolean](128)
  for (i <- 0 to 31) {
    specialInText(i) = true // allowed in XML 1.1 as character references
  }
  for (i <- 32 to 127) {
    specialInText(i) = false
  }
  //    note, 0 is used to switch escaping on and off for mapped characters
  specialInText('\n') = false
  specialInText('\t') = false
  specialInText('\r') = true
  specialInText('<') = true
  specialInText('>') = true
  specialInText('&') = true
  specialInAtt = new Array[Boolean](128)
  for (i <- 0 to 31) {
    specialInAtt(i) = true
  }
  for (i <- 32 to 127) {
    specialInAtt(i) = false
  }
  specialInAtt(0.toChar) = true
  // used to switch escaping on and off for mapped characters
  specialInAtt('\r') = true
  specialInAtt('\n') = true
  specialInAtt('\t') = true
  specialInAtt('<') = true
  specialInAtt('>') = true
  specialInAtt('&') = true
  specialInAtt('\"') = true
  specialInAttSingle = util.Arrays.copyOf(specialInAtt, 128)
  specialInAttSingle('\"') = false
  specialInAttSingle('\'') = true
}

class XMLEmitter extends Emitter {
  protected var canonical = false
  protected var started = false
  protected var startedElement = false
  protected var openStartTag = false
  protected var declarationIsWritten = false
  protected var elementCode = null
  protected var indentForNextAttribute = -1
  protected var undeclareNamespaces = false
  protected var unfailing = false
  protected var delimiter = '"'
  protected var attSpecials = XMLEmitter.specialInAtt
  protected var elementStack = new util.Stack[String]
  private var indenting = false
  private var indentChars = "\n                                                          "
  private var requireWellFormed = false
  protected var characterReferenceGenerator = HexCharacterReferenceGenerator.THE_INSTANCE

  /**
   * Set the character reference generator to be used for generating hexadecimal or decimal
   * character references
   *
   * @param generator the character reference generator to be used
   */
  def setCharacterReferenceGenerator(generator: CharacterReferenceGenerator) = this.characterReferenceGenerator = generator

  /**
   * Say that all non-ASCII characters should be escaped, regardless of the character encoding
   *
   * @param escape true if all non ASCII characters should be escaped
   */
  def setEscapeNonAscii(escape: Boolean) = {
    // no action (not currently supported for this output method
  }

  /**
   * Start of the event stream. Nothing is done at this stage: the opening of the output
   * file is deferred until some content is written to it.
   */
  @throws[XPathException]
  override def open() = {
  }

  /**
   * Start of a document node. Nothing is done at this stage: the opening of the output
   * file is deferred until some content is written to it.
   *
   * @param properties
   */
  @throws[XPathException]
  override def startDocument(properties: Int) = {
  }

  /**
   * Notify the end of a document node
   */
  @throws[XPathException]
  override def endDocument() = {
    // Following code removed as a result of bug 2323. If a failure occurs during xsl:result-document processing,
    // and the output is being written to a SAXResult, then the ContentHandler.endDocument() method is called in order
    // to close any open files; and this calls Emitter.endDocument() at a point where the output is incomplete.
    //        if (!elementStack.isEmpty()) {
    //            throw new IllegalStateException("Attempt to end document in serializer when elements are unclosed");
    //        }
  }

  /**
   * Do the real work of starting the document. This happens when the first
   * content is written.
   *
   * @throws XPathException if an error occurs opening the output file
   */
  @throws[XPathException]
  protected def openDocument() = {
    if (writer == null) makeWriter()
    if (characterSet == null) characterSet = UTF8CharacterSet.getInstance
    if (outputProperties == null) outputProperties = new Properties
    undeclareNamespaces = "yes" == outputProperties.getProperty(SaxonOutputKeys.UNDECLARE_PREFIXES)
    canonical = "yes" == outputProperties.getProperty(SaxonOutputKeys.CANONICAL)
    unfailing = "yes" == outputProperties.getProperty(SaxonOutputKeys.UNFAILING)
    if ("yes" == outputProperties.getProperty(SaxonOutputKeys.SINGLE_QUOTES)) {
      delimiter = '\''
      attSpecials = XMLEmitter.specialInAttSingle
    }
    writeDeclaration()
  }

  /**
   * Output the XML declaration
   */
  @throws[XPathException]
  def writeDeclaration(): Unit = {
    if (declarationIsWritten) return
    declarationIsWritten = true
    try {
      indenting = "yes" == outputProperties.getProperty(OutputKeys.INDENT)
      val byteOrderMark = outputProperties.getProperty(SaxonOutputKeys.BYTE_ORDER_MARK)
      var encoding = outputProperties.getProperty(OutputKeys.ENCODING)
      if (encoding == null || encoding.equalsIgnoreCase("utf8") || canonical) encoding = "UTF-8"
      if ("yes" == byteOrderMark && !canonical && ("UTF-8".equalsIgnoreCase(encoding) || "UTF-16LE".equalsIgnoreCase(encoding) || "UTF-16BE".equalsIgnoreCase(encoding))) writer.write('\uFEFF')
      var omitXMLDeclaration = outputProperties.getProperty(OutputKeys.OMIT_XML_DECLARATION)
      if (omitXMLDeclaration == null) omitXMLDeclaration = "no"
      if (canonical) omitXMLDeclaration = "yes"
      var version = outputProperties.getProperty(OutputKeys.VERSION)
      if (version == null) version = if (getConfiguration.getXMLVersion == Configuration.XML10) "1.0"
      else "1.1"
      else {
        if (!(version == "1.0") && !(version == "1.1")) if (unfailing) version = "1.0"
        else {
          val err = new XPathException("XML version must be 1.0 or 1.1")
          err.setErrorCode("SESU0013")
          throw err
        }
        if (!(version == "1.0") && omitXMLDeclaration == "yes" && outputProperties.getProperty(OutputKeys.DOCTYPE_SYSTEM) != null) if (!unfailing) {
          val err = new XPathException("Values of 'version', 'omit-xml-declaration', and 'doctype-system' conflict")
          err.setErrorCode("SEPM0009")
          throw err
        }
      }
      val undeclare = outputProperties.getProperty(SaxonOutputKeys.UNDECLARE_PREFIXES)
      if ("yes" == undeclare) undeclareNamespaces = true
      if (version == "1.0" && undeclareNamespaces) if (unfailing) undeclareNamespaces = false
      else {
        val err = new XPathException("Cannot undeclare namespaces with XML version 1.0")
        err.setErrorCode("SEPM0010")
        throw err
      }
      var standalone = outputProperties.getProperty(OutputKeys.STANDALONE)
      if ("omit" == standalone) standalone = null
      if (standalone != null) {
        requireWellFormed = true
        if (omitXMLDeclaration == "yes" && !unfailing) {
          val err = new XPathException("Values of 'standalone' and 'omit-xml-declaration' conflict")
          err.setErrorCode("SEPM0009")
          throw err
        }
      }
      val systemId = outputProperties.getProperty(OutputKeys.DOCTYPE_SYSTEM)
      if (systemId != null && !("" == systemId)) requireWellFormed = true
      if (omitXMLDeclaration == "no") {
        writer.write("<?xml version=\"" + version + "\" " + "encoding=\"" + encoding + '\"' + (if (standalone != null) " standalone=\"" + standalone + '\"'
        else "") + "?>")
        // don't write a newline character: it's wrong if the output is an
        // external general parsed entity
      }
    } catch {
      case err: IOException =>
        throw new XPathException("Failure writing to " + getSystemId, err)
    }
  }

  /**
   * Output the document type declaration
   *
   * @param name        the qualified name of the element
   * @param displayName The element name as displayed
   * @param systemId    The DOCTYPE system identifier
   * @param publicId    The DOCTYPE public identifier
   * @throws net.sf.saxon.trans.XPathException if an error occurs writing to the output
   */
  @throws[XPathException]
  protected def writeDocType(name: NodeName, displayName: String, systemId: String, publicId: String) = try if (!canonical) {
    if (declarationIsWritten && !indenting) { // don't add a newline if indenting, because the indenter will already have done so
      writer.write("\n")
    }
    writer.write("<!DOCTYPE " + displayName + '\n')
    var quotedSystemId = null
    if (systemId != null) if (systemId.contains("\"")) quotedSystemId = "'" + systemId + "'"
    else quotedSystemId = '"' + systemId + '"'
    if (systemId != null && publicId == null) writer.write("  SYSTEM " + quotedSystemId + ">\n")
    else if (systemId == null && publicId != null) { // handles the HTML case
      writer.write("  PUBLIC \"" + publicId + "\">\n")
    }
    else writer.write("  PUBLIC \"" + publicId + "\" " + quotedSystemId + ">\n")
  }
  catch {
    case err: IOException =>
      throw new XPathException("Failure writing to " + getSystemId, err)
  }

  /**
   * End of the document.
   */
  @throws[XPathException]
  override def close() = { // if nothing has been written, we should still create the file and write an XML declaration
    if (!started) openDocument()
    try if (writer != null) writer.flush()
    catch {
      case err: IOException =>
        throw new XPathException("Failure writing to " + getSystemId, err)
    }
    super.close()
  }

  /**
   * Start of an element. Output the start tag, escaping special characters.
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    previousAtomic = false
    if (!started) openDocument()
    else if (requireWellFormed && elementStack.isEmpty && startedElement && !unfailing) {
      val err = new XPathException("When 'standalone' or 'doctype-system' is specified, " + "the document must be well-formed; but this document contains more than one top-level element")
      err.setErrorCode("SEPM0004")
      throw err
    }
    startedElement = true
    val displayName = elemName.getDisplayName
    if (!allCharactersEncodable) {
      val badchar = testCharacters(displayName)
      if (badchar != 0) {
        val err = new XPathException("Element name contains a character (decimal + " + badchar + ") not available in the selected encoding")
        err.setErrorCode("SERE0008")
        throw err
      }
    }
    elementStack.push(displayName)
    elementCode = elemName
    try {
      if (!started) {
        var systemId = outputProperties.getProperty(OutputKeys.DOCTYPE_SYSTEM)
        var publicId = outputProperties.getProperty(OutputKeys.DOCTYPE_PUBLIC)
        // Treat "" as equivalent to absent. This goes beyond what the spec strictly allows.
        if ("" == systemId) systemId = null
        if ("" == publicId) publicId = null
        if (systemId != null) {
          requireWellFormed = true
          writeDocType(elemName, displayName, systemId, publicId)
        }
        else if (writeDocTypeWithNullSystemId) writeDocType(elemName, displayName, null, publicId)
        started = true
      }
      if (openStartTag) closeStartTag()
      writer.write('<')
      writer.write(displayName)
      if (indentForNextAttribute >= 0) indentForNextAttribute += displayName.length
      var isFirst = true
      import scala.collection.JavaConversions._
      for (ns <- namespaces) {
        namespace(ns.getPrefix, ns.getURI, isFirst)
        isFirst = false
      }
      import scala.collection.JavaConversions._
      for (att <- attributes) {
        attribute(att.getNodeName, att.getValue, att.getProperties, isFirst)
        isFirst = false
      }
      openStartTag = true
      indentForNextAttribute = -1
    } catch {
      case err: IOException =>
        throw new XPathException("Failure writing to " + getSystemId, err)
    }
  }

  protected def writeDocTypeWithNullSystemId = false

  @throws[XPathException]
  def namespace(nsprefix: String, nsuri: String, isFirst: Boolean) = try {
    val sep = if (isFirst) " "
    else getAttributeIndentString
    if (nsprefix.isEmpty) {
      writer.write(sep)
      writeAttribute(elementCode, "xmlns", nsuri, ReceiverOption.NONE)
    }
    else if (nsprefix == "xml") {
      //return;
    }
    else {
      val badchar = testCharacters(nsprefix)
      if (badchar != 0) {
        val err = new XPathException("Namespace prefix contains a character (decimal + " + badchar + ") not available in the selected encoding")
        err.setErrorCode("SERE0008")
        throw err
      }
      if (undeclareNamespaces || !nsuri.isEmpty) {
        writer.write(sep)
        writeAttribute(elementCode, "xmlns:" + nsprefix, nsuri, ReceiverOption.NONE)
      }
    }
  } catch {
    case err: IOException =>
      throw new XPathException("Failure writing to " + getSystemId, err)
  }

  /**
   * Set the indentation to be used for attributes (this excludes the length of the
   * element name itself)
   *
   * @param indent the number of spaces to be output before each attribute (on a new line)
   */
  def setIndentForNextAttribute(indent: Int) = indentForNextAttribute = indent

  @throws[XPathException]
  private def attribute(nameCode: NodeName, value: CharSequence, properties: Int, isFirst: Boolean) = {
    var displayName = nameCode.getDisplayName
    if (!allCharactersEncodable) {
      val badchar = testCharacters(displayName)
      if (badchar != 0) if (unfailing) displayName = convertToAscii(displayName)
      else {
        val err = new XPathException("Attribute name contains a character (decimal + " + badchar + ") not available in the selected encoding")
        err.setErrorCode("SERE0008")
        throw err
      }
    }
    try writer.write(if (isFirst) " "
    else getAttributeIndentString)
    catch {
      case err: IOException =>
        throw new XPathException("Failure writing to " + getSystemId, err)
    }
    writeAttribute(elementCode, displayName, value, properties)
  }

  protected def getAttributeIndentString = if (indentForNextAttribute < 0) " "
  else {
    val indent = indentForNextAttribute
    while ( {
      indent >= indentChars.length
    }) { //noinspection StringConcatenationInLoop
      indentChars += "                     "
    }
    indentChars.substring(0, indent)
  }

  /**
   * Mark the end of the start tag
   *
   * @throws XPathException if an IO exception occurs
   */
  @throws[XPathException]
  def closeStartTag() = try if (openStartTag) {
    writer.write('>')
    openStartTag = false
  }
  catch {
    case err: IOException =>
      throw new XPathException("Failure writing to " + getSystemId, err)
  }

  /**
   * Close an empty element tag. (This is overridden in XHTMLEmitter).
   *
   * @param displayName the name of the empty element
   * @param nameCode    the fingerprint of the name of the empty element
   * @return the string used to close an empty element tag.
   */
  protected def emptyElementTagCloser(displayName: String, nameCode: NodeName) = if (canonical) "></" + displayName + ">"
  else "/>"

  /**
   * Write attribute name=value pair.
   *
   * @param elCode     The element name is not used in this version of the
   *                   method, but is used in the HTML subclass.
   * @param attname    The attribute name, which has already been validated to ensure
   *                   it can be written in this encoding
   * @param value      The value of the attribute
   * @param properties Any special properties of the attribute
   * @throws net.sf.saxon.trans.XPathException if an error occurs
   */
  @throws[XPathException]
  protected def writeAttribute(elCode: NodeName, attname: String, value: CharSequence, properties: Int) = try {
    val `val` = value.toString
    writer.write(attname)
    if (ReceiverOption.contains(properties, ReceiverOption.NO_SPECIAL_CHARS)) {
      writer.write('=')
      writer.write(delimiter)
      writer.write(`val`)
      writer.write(delimiter)
    }
    else if (ReceiverOption.contains(properties, ReceiverOption.USE_NULL_MARKERS)) { // null (0) characters will be used before and after any section of
      // the value generated from a character map
      writer.write('=')
      val delim = if (`val`.indexOf('"') >= 0 && `val`.indexOf('\'') < 0) '\''
      else delimiter
      writer.write(delim)
      writeEscape(value, true)
      writer.write(delim)
    }
    else {
      writer.write("=")
      writer.write(delimiter)
      writeEscape(value, true)
      writer.write(delimiter)
    }
  } catch {
    case err: IOException =>
      throw new XPathException("Failure writing to " + getSystemId, err)
  }

  /**
   * Test that all characters in a name (for example) are supported in the target encoding.
   *
   * @param chars the characters to be tested
   * @return zero if all the characters are available, or the value of the
   *         first offending character if not
   */
  protected def testCharacters(chars: CharSequence): Int = {
    var i = 0
    while ( {
      i < chars.length
    }) {
      val c = chars.charAt(i)
      if (c > 127) if (UTF16CharacterSet.isHighSurrogate(c)) {
        val cc = UTF16CharacterSet.combinePair(c, chars.charAt({
          i += 1; i
        }))
        if (!characterSet.inCharset(cc)) return cc
      }
      else if (!characterSet.inCharset(c)) return c
      i += 1
    }
    0
  }

  /**
   * Where characters are not available in the selected encoding, substitute them
   */
  protected def convertToAscii(chars: CharSequence) = {
    val buff = new FastStringBuffer(chars.length)
    for (i <- 0 until chars.length) {
      val c = chars.charAt(i)
      if (c >= 20 && c < 127) buff.cat(c)
      else buff.append("_" + c.toInt + "_")
    }
    buff.toString
  }

  /**
   * End of an element.
   */
  @throws[XPathException]
  override def endElement() = {
    val displayName = elementStack.pop
    try if (openStartTag) {
      writer.write(emptyElementTagCloser(displayName, elementCode))
      openStartTag = false
    }
    else {
      writer.write("</")
      writer.write(displayName)
      writer.write('>')
    }
    catch {
      case err: IOException =>
        throw new XPathException("Failure writing to " + getSystemId, err)
    }
  }

  /**
   * Character data.
   */
  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = {
    if (!started) openDocument()
    if (requireWellFormed && elementStack.isEmpty && !Whitespace.isWhite(chars) && !unfailing) {
      val err = new XPathException("When 'standalone' or 'doctype-system' is specified, " + "the document must be well-formed; but this document contains a top-level text node")
      err.setErrorCode("SEPM0004")
      throw err
    }
    try {
      if (openStartTag) closeStartTag()
      if (ReceiverOption.contains(properties, ReceiverOption.NO_SPECIAL_CHARS)) writeCharSequence(chars)
      else if (!ReceiverOption.contains(properties, ReceiverOption.DISABLE_ESCAPING)) writeEscape(chars, false)
      else { // disable-output-escaping="yes"
        if (testCharacters(chars) == 0) if (!ReceiverOption.contains(properties, ReceiverOption.USE_NULL_MARKERS)) writeCharSequence(chars)
        else { // Need to strip out any null markers. See test output-html109
          val len = chars.length
          for (i <- 0 until len) {
            val c = chars.charAt(i)
            if (c != 0) writer.write(c)
          }
        }
        else { // Using disable output escaping with characters
          // that are not available in the target encoding
          // The required action is to ignore d-o-e in respect of those characters that are
          // not available in the encoding. This is slow...
          val len = chars.length
          var i = 0
          while ( {
            i < len
          }) {
            val c = chars.charAt(i)
            if (c != 0) if (c > 127 && UTF16CharacterSet.isHighSurrogate(c)) {
              val pair = new Array[Char](2)
              pair(0) = c
              pair(1) = chars.charAt({
                i += 1; i
              })
              val cc = UTF16CharacterSet.combinePair(c, pair(1))
              if (!characterSet.inCharset(cc)) writeEscape(new CharSlice(pair), false)
              else writeCharSequence(new CharSlice(pair))
            }
            else {
              val ca = Array(c)
              if (!characterSet.inCharset(c)) writeEscape(new CharSlice(ca), false)
              else writeCharSequence(new CharSlice(ca))
            }
            i += 1
          }
        }
      }
    } catch {
      case err: IOException =>
        throw new XPathException("Failure writing to " + getSystemId, err)
    }
  }

  /**
   * Write a CharSequence (without any escaping of special characters): various implementations
   *
   * @param s the character sequence to be written
   * @throws java.io.IOException in the event of a failure to write to the output file
   */
  @throws[java.io.IOException]
  def writeCharSequence(s: CharSequence) = if (s.isInstanceOf[String]) writer.write(s.asInstanceOf[String])
  else if (s.isInstanceOf[CharSlice]) s.asInstanceOf[CharSlice].write(writer)
  else if (s.isInstanceOf[FastStringBuffer]) s.asInstanceOf[FastStringBuffer].write(writer)
  else if (s.isInstanceOf[CompressedWhitespace]) s.asInstanceOf[CompressedWhitespace].write(writer)
  else writer.write(s.toString)

  /**
   * Handle a processing instruction.
   */
  @throws[XPathException]
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = {
    if (!started) openDocument()
    var x = testCharacters(target)
    if (x != 0) if (unfailing) target = convertToAscii(target)
    else {
      val err = new XPathException("Character in processing instruction name cannot be represented " + "in the selected encoding (code " + x + ')')
      err.setErrorCode("SERE0008")
      throw err
    }
    x = testCharacters(data)
    if (x != 0) if (unfailing) data = convertToAscii(data)
    else {
      val err = new XPathException("Character in processing instruction data cannot be represented " + "in the selected encoding (code " + x + ')')
      err.setErrorCode("SERE0008")
      throw err
    }
    try {
      if (openStartTag) closeStartTag()
      writer.write("<?" + target + (if (data.length > 0) ' ' + data.toString
      else "") + "?>")
    } catch {
      case err: IOException =>
        throw new XPathException("Failure writing to " + getSystemId, err)
    }
  }

  /**
   * Write contents of array to current writer, after escaping special characters.
   * This method converts the XML special characters (such as &lt; and &amp;) into their
   * predefined entities.
   *
   * @param chars       The character sequence containing the string
   * @param inAttribute Set to true if the text is in an attribute value
   */
  @throws[java.io.IOException]
  @throws[XPathException]
  protected def writeEscape(chars: CharSequence, inAttribute: Boolean): Unit = {
    var segstart = 0
    var disabled = false
    val specialChars = if (inAttribute) attSpecials
    else XMLEmitter.specialInText
    if (chars.isInstanceOf[CompressedWhitespace]) {
      chars.asInstanceOf[CompressedWhitespace].writeEscape(specialChars, writer)
      return
    }
    val clength = chars.length
    while ( {
      segstart < clength
    }) {
      var i = segstart
      // find a maximal sequence of "ordinary" characters
      while ( {
        i < clength
      }) {
        val c = chars.charAt(i)
        if (c < 127) if (specialChars(c)) break //todo: break is not supported
        else i += 1
        else if (c < 160) break //todo: break is not supported
        else if (c == 0x2028) break //todo: break is not supported
        else if (UTF16CharacterSet.isHighSurrogate(c)) break //todo: break is not supported
        else if (!characterSet.inCharset(c)) break //todo: break is not supported
        else i += 1
      }
      // if this was the whole string write it out and exit
      if (i >= clength) {
        if (segstart == 0) writeCharSequence(chars)
        else writeCharSequence(chars.subSequence(segstart, i))
        return
      }
      // otherwise write out this sequence
      if (i > segstart) writeCharSequence(chars.subSequence(segstart, i))
      // examine the special character that interrupted the scan
      val c = chars.charAt(i)
      if (c == 0) { // used to switch escaping on and off
        disabled = !disabled
      }
      else if (disabled) {
        if (c > 127) if (UTF16CharacterSet.isHighSurrogate(c)) {
          val cc = UTF16CharacterSet.combinePair(c, chars.charAt(i + 1))
          if (!characterSet.inCharset(cc)) {
            val de = new XPathException("Character x" + Integer.toHexString(cc) + " is not available in the chosen encoding")
            de.setErrorCode("SERE0008")
            throw de
          }
        }
        else if (!characterSet.inCharset(c)) {
          val de = new XPathException("Character " + c + " (x" + Integer.toHexString(c.toInt) + ") is not available in the chosen encoding")
          de.setErrorCode("SERE0008")
          throw de
        }
        writer.write(c)
      }
      else if (c < 127) { // process special ASCII characters
        c match {
          case '<' =>
            writer.write("&lt;")
          case '>' =>
            writer.write("&gt;")
          case '&' =>
            writer.write("&amp;")
          case '\"' =>
            writer.write("&#34;")
          case '\'' =>
            writer.write("&#39;")
          case '\n' =>
            writer.write("&#xA;")
          case '\r' =>
            writer.write("&#xD;")
          case '\t' =>
            writer.write("&#x9;")
          case _ =>
            // C0 control characters
            characterReferenceGenerator.outputCharacterReference(c, writer)
        }
      }
      else if (c < 160 || c == 0x2028) { // XML 1.1 requires these characters to be written as character references
        characterReferenceGenerator.outputCharacterReference(c, writer)
      }
      else if (UTF16CharacterSet.isHighSurrogate(c)) {
        val d = chars.charAt({
          i += 1; i
        })
        val charval = UTF16CharacterSet.combinePair(c, d)
        if (characterSet.inCharset(charval)) {
          writer.write(c)
          writer.write(d)
        }
        else characterReferenceGenerator.outputCharacterReference(charval, writer)
      }
      else { // process characters not available in the current encoding
        characterReferenceGenerator.outputCharacterReference(c, writer)
      }
      segstart = {
        i += 1; i
      }
    }
  }

  /**
   * Handle a comment.
   */
  @throws[XPathException]
  override def comment(chars: CharSequence, locationId: Location, properties: Int) = {
    if (!started) openDocument()
    val x = testCharacters(chars)
    if (x != 0) if (unfailing) chars = convertToAscii(chars)
    else {
      val err = new XPathException("Character in comment cannot be represented " + "in the selected encoding (code " + x + ')')
      err.setErrorCode("SERE0008")
      throw err
    }
    try {
      if (openStartTag) closeStartTag()
      writer.write("<!--")
      writer.write(chars.toString)
      writer.write("-->")
    } catch {
      case err: IOException =>
        throw new XPathException("Failure writing to " + getSystemId, err)
    }
  }

  /**
   * Ask whether this Receiver (or the downstream pipeline) makes any use of the type annotations
   * supplied on element and attribute events
   *
   * @return true if the Receiver makes any use of this information. If false, the caller
   *         may supply untyped nodes instead of supplying the type annotation
   */
  override def usesTypeAnnotations = false

  /**
   * Ask whether anything has yet been written
   *
   * @return true if content has been output
   */
  def isStarted = started
}