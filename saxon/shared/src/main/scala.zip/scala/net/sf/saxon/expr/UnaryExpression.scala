////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.model.ItemType
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.jiter.MonoIterator

/**
 * Unary Expression: an expression taking a single operand expression
 */
abstract class UnaryExpression(val p0: Expression) extends Expression {
  operand = new Operand(this, p0, getOperandRole)
  //        if (p0.getRetainedStaticContext() != null) {
  //            setRetainedStaticContext(p0.getRetainedStaticContext());
  //        }
  ExpressionTool.copyLocationInfo(p0, this)
  private var operand = null

  /*@NotNull*/ def getBaseExpression = operand.getChildExpression

  def setBaseExpression(child: Expression) = operand.setChildExpression(child)

  def getOperand = operand

  override def operands = () => new MonoIterator[Operand](operand)

  /**
   * Get the usage (in terms of streamability analysis) of the single operand
   *
   * @return the operand usage
   */
  protected def getOperandRole

  /**
   * Type-check the expression. Default implementation for unary operators that accept
   * any kind of operand
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    operand.typeCheck(visitor, contextInfo)
    // if the operand value is known, pre-evaluate the expression
    try if (getBaseExpression.isInstanceOf[Literal]) {
      val e2 = Literal.makeLiteral(iterate(visitor.getStaticContext.makeEarlyEvaluationContext).materialize, this)
      ExpressionTool.copyLocationInfo(this, e2)
      return e2
    }
    catch {
      case err: Exception =>

      // if early evaluation fails, suppress the error: the value might
      // not be needed at run-time
    }
    this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor     an expression visitor
   * @param contextInfo the static type of "." at the point where this expression is invoked.
   *                    The parameter is set to null if it is known statically that the context item will be undefined.
   *                    If the type of the context item is not known statically, the argument is set to
   *                    { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    operand.optimize(visitor, contextInfo)
    val base = getBaseExpression
    try if (base.isInstanceOf[Literal]) return Literal.makeLiteral(iterate(visitor.getStaticContext.makeEarlyEvaluationContext).materialize, this)
    catch {
      case err: XPathException =>
    }
    this
  }

  /**
   * Get the static properties of this expression (other than its type). The result is
   * bit-signficant. These properties are used for optimizations. In general, if
   * property bit is set, it is true, but if it is unset, the value is unknown.
   */
  override def computeSpecialProperties = getBaseExpression.getSpecialProperties

  /**
   * Determine the static cardinality. Default implementation returns the cardinality of the operand
   */
  override def computeCardinality = getBaseExpression.getCardinality

  /**
   * Determine the data type of the expression, if possible. The default
   * implementation for unary expressions returns the item type of the operand
   *
   * @return the item type of the items in the result sequence, insofar as this
   *         is known statically.
   */
  override def getItemType = getBaseExpression.getItemType

  /**
   * Is this expression the same as another expression?
   */
  override def equals(/*@Nullable*/ other: Any) = other != null && this.getClass == other.getClass && this.getBaseExpression.isEqual(other.asInstanceOf[UnaryExpression].getBaseExpression)

  /**
   * get HashCode for comparing two expressions. Note that this hashcode gives the same
   * result for (A op B) and for (B op A), whether or not the operator is commutative.
   */
  override def computeHashCode = ("UnaryExpression " + getClass).hashCode ^ getBaseExpression.hashCode

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   */
  override def toString = getExpressionName + "(" + getBaseExpression + ")"

  override def toShortString = getExpressionName + "(" + getBaseExpression.toShortString + ")"

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    val name = getExpressionName
    if (name == null) {
      out.startElement("unaryOperator", this)
      val op = displayOperator(out.getConfiguration)
      if (op != null) out.emitAttribute("op", op)
    }
    else out.startElement(name, this)
    emitExtraAttributes(out)
    getBaseExpression.`export`(out)
    out.endElement
  }

  protected def emitExtraAttributes(out: ExpressionPresenter) = {
    // default: no action
  }

  /**
   * Give a string representation of the operator for use in diagnostics
   *
   * @param config the Saxon configuration
   * @return the operator, as a string
   */
  protected def displayOperator(config: Configuration) = null
}