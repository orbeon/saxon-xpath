////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.lib.ConversionRules
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ConversionResult
import net.sf.saxon.model.ValidationFailure
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.util.regex.Matcher
import java.util.regex.Pattern

/**
 * Implementation of the xs:gYearMonth data type
 */
object GYearMonthValue {
  private val regex = Pattern.compile("(-?[0-9]+-[0-9][0-9])(Z|[+-][0-9][0-9]:[0-9][0-9])?")

  def makeGYearMonthValue(value: CharSequence, rules: ConversionRules): ConversionResult = {
    val m = regex.matcher(Whitespace.trimWhitespace(value))
    if (!m.matches) return new ValidationFailure("Cannot convert '" + value + "' to a gYearMonth")
    val g = new GYearMonthValue
    val base = m.group(1)
    val tz = m.group(2)
    val date = base + "-01" + (if (tz == null) ""
    else tz)
    g.typeLabel = BuiltInAtomicType.G_YEAR_MONTH
    setLexicalValue(g, date, rules.isAllowYearZero)
  }
}

class GYearMonthValue private() extends GDateValue {
  def this(year: Int, month: Byte, tz: Int, `type`: AtomicType) {
    this()
    this.year = year
    this.month = month
    day = 1
    setTimezoneInMinutes(tz)
    typeLabel = `type`
  }

  def this(year: Int, month: Byte, tz: Int, xsd10: Boolean) {
    this(year, month, tz, BuiltInAtomicType.G_YEAR_MONTH)
    this.hasNoYearZero = xsd10
  }

  /**
   * Make a copy of this date, time, or dateTime value
   *
   * @param typeLabel
   */
  override def copyAsSubType(typeLabel: AtomicType) = {
    val v = new GYearMonthValue(year, month, getTimezoneInMinutes, hasNoYearZero)
    v.typeLabel = typeLabel
    v
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.G_YEAR_MONTH

  /*@NotNull*/ override def getPrimitiveStringValue = {
    val sb = new FastStringBuffer(FastStringBuffer.C16)
    var yr = year
    if (year <= 0) {
      yr = -yr + (if (hasNoYearZero) 1
      else 0) // no year zero in lexical space for XSD 1.0
      if (yr != 0) sb.cat('-')
    }
    appendString(sb, yr, if (yr > 9999) (yr + "").length
    else 4)
    sb.cat('-')
    appendTwoDigits(sb, month)
    if (hasTimezone) appendTimezone(sb)
    sb
  }

  /**
   * Add a duration to this date/time value
   *
   * @param duration the duration to be added (which might be negative)
   * @return a new date/time value representing the result of adding the duration. The original
   *         object is not modified.
   * @throws net.sf.saxon.trans.XPathException
   *
   */
  @throws[XPathException]
  override def add(duration: DurationValue) = {
    val err = new XPathException("Cannot add a duration to an xs:gYearMonth")
    err.setErrorCode("XPTY0004")
    throw err
  }

  /**
   * Return a new date, time, or dateTime with the same normalized value, but
   * in a different timezone
   *
   * @param tz the new timezone, in minutes
   * @return the date/time in the new timezone
   */
  override def adjustTimezone(tz: Int) = {
    val dt = toDateTime.adjustTimezone(tz).asInstanceOf[DateTimeValue]
    new GYearMonthValue(dt.getYear, dt.getMonth, dt.getTimezoneInMinutes, hasNoYearZero)
  }
}