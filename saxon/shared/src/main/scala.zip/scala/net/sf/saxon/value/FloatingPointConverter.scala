////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.tree.util.FastStringBuffer
import java.math.BigInteger

/**
 * This is a utility class that handles formatting of numbers as strings.
 * <p>The algorithm for converting a floating point number to a string is taken from Guy L. Steele and
 * Jon L. White, <i>How to Print Floating-Point Numbers Accurately</i>, ACM SIGPLAN 1990. It is algorithm
 * (FPP)<sup>2</sup> from that paper. There are three separate implementations of the algorithm:</p>
 * <ul>
 * <li>One using long arithmetic and generating non-exponential output representations</li>
 * <li>One using BigInteger arithmetic and generating non-exponential output representation</li>
 * <li>One using BigInteger arithmetic and generating exponential output representations</li>
 * </ul>
 * <p>The choice of method depends on the value of the number being formatted.</p>
 * <p>The module contains some residual code (mainly the routine for formatting integers) from the class
 * AppenderHelper by Jack Shirazi in the O'Reilly book <i>Java Performance Tuning</i>. The floating point routines
 * in that module were found to be unsuitable, since they used floating point arithmetic which introduces
 * rounding errors.</p>
 * <p>There are several reasons for doing this conversion within Saxon, rather than leaving it all to Java.
 * Firstly, there are differences in the required output format, notably the absence of ".0" when formatting
 * whole numbers, and the different rules for the range of numbers where exponential notation is used.
 * Secondly, there are bugs in some Java implementations, for example JDK outputs 0.001 as 0.0010, and
 * IKVM/GNU gets things very wrong sometimes. Finally, this implementation is faster for "everyday" numbers,
 * though it is slower for more extreme numbers. It would probably be reasonable to hand over formatting
 * to the Java platform (at least when running the Sun JDK) for exponents outside the range -7 to +7.</p>
 */
object FloatingPointConverter {
  var THE_INSTANCE = new FloatingPointConverter
  /**
   * char array holding the characters for the string "-Infinity".
   */
  private val NEGATIVE_INFINITY = Array('-', 'I', 'N', 'F')
  /**
   * char array holding the characters for the string "Infinity".
   */
  private val POSITIVE_INFINITY = Array('I', 'N', 'F')
  /**
   * char array holding the characters for the string "NaN".
   */
  private val NaN = Array('N', 'a', 'N')
  private val charForDigit = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
  val DOUBLE_SIGN_MASK = 0x8000000000000000L
  private val doubleExpMask = 0x7ff0000000000000L
  private val doubleExpShift = 52
  private val doubleExpBias = 1023
  private val doubleFractMask = 0xfffffffffffffL
  val FLOAT_SIGN_MASK = 0x80000000
  private val floatExpMask = 0x7f800000
  private val floatExpShift = 23
  private val floatExpBias = 127
  private val floatFractMask = 0x7fffff
  private val TEN = BigInteger.valueOf(10)
  private val NINE = BigInteger.valueOf(9)

  /**
   * Format an integer, appending the string representation of the integer to a string buffer
   *
   * @param s the string buffer
   * @param i the integer to be formatted
   * @return the supplied string buffer, containing the appended integer
   */
  def appendInt(s: FastStringBuffer, i: Int): FastStringBuffer = {
    if (i < 0) {
      if (i == Integer.MIN_VALUE) { //cannot make this positive due to integer overflow
        s.append("-2147483648")
        return s
      }
      s.cat('-')
      i = -i
    }
    var c = 0
    if (i < 10) { //one digit
      s.cat(charForDigit(i))
      s
    }
    else if (i < 100) { //two digits
      s.cat(charForDigit(i / 10))
      s.cat(charForDigit(i % 10))
      s
    }
    else if (i < 1000) { //three digits
      s.cat(charForDigit(i / 100))
      s.cat(charForDigit((c = i % 100) / 10))
      s.cat(charForDigit(c % 10))
      s
    }
    else if (i < 10000) { //four digits
      s.cat(charForDigit(i / 1000))
      s.cat(charForDigit((c = i % 1000) / 100))
      s.cat(charForDigit((c %= 100) / 10))
      s.cat(charForDigit(c % 10))
      s
    }
    else if (i < 100000) { //five digits
      s.cat(charForDigit(i / 10000))
      s.cat(charForDigit((c = i % 10000) / 1000))
      s.cat(charForDigit((c %= 1000) / 100))
      s.cat(charForDigit((c %= 100) / 10))
      s.cat(charForDigit(c % 10))
      s
    }
    else if (i < 1000000) { //six digits
      s.cat(charForDigit(i / 100000))
      s.cat(charForDigit((c = i % 100000) / 10000))
      s.cat(charForDigit((c %= 10000) / 1000))
      s.cat(charForDigit((c %= 1000) / 100))
      s.cat(charForDigit((c %= 100) / 10))
      s.cat(charForDigit(c % 10))
      s
    }
    else if (i < 10000000) { //seven digits
      s.cat(charForDigit(i / 1000000))
      s.cat(charForDigit((c = i % 1000000) / 100000))
      s.cat(charForDigit((c %= 100000) / 10000))
      s.cat(charForDigit((c %= 10000) / 1000))
      s.cat(charForDigit((c %= 1000) / 100))
      s.cat(charForDigit((c %= 100) / 10))
      s.cat(charForDigit(c % 10))
      s
    }
    else if (i < 100000000) { //eight digits
      s.cat(charForDigit(i / 10000000))
      s.cat(charForDigit((c = i % 10000000) / 1000000))
      s.cat(charForDigit((c %= 1000000) / 100000))
      s.cat(charForDigit((c %= 100000) / 10000))
      s.cat(charForDigit((c %= 10000) / 1000))
      s.cat(charForDigit((c %= 1000) / 100))
      s.cat(charForDigit((c %= 100) / 10))
      s.cat(charForDigit(c % 10))
      s
    }
    else if (i < 1000000000) { //nine digits
      s.cat(charForDigit(i / 100000000))
      s.cat(charForDigit((c = i % 100000000) / 10000000))
      s.cat(charForDigit((c %= 10000000) / 1000000))
      s.cat(charForDigit((c %= 1000000) / 100000))
      s.cat(charForDigit((c %= 100000) / 10000))
      s.cat(charForDigit((c %= 10000) / 1000))
      s.cat(charForDigit((c %= 1000) / 100))
      s.cat(charForDigit((c %= 100) / 10))
      s.cat(charForDigit(c % 10))
      s
    }
    else { //ten digits
      s.cat(charForDigit(i / 1000000000))
      s.cat(charForDigit((c = i % 1000000000) / 100000000))
      s.cat(charForDigit((c %= 100000000) / 10000000))
      s.cat(charForDigit((c %= 10000000) / 1000000))
      s.cat(charForDigit((c %= 1000000) / 100000))
      s.cat(charForDigit((c %= 100000) / 10000))
      s.cat(charForDigit((c %= 10000) / 1000))
      s.cat(charForDigit((c %= 1000) / 100))
      s.cat(charForDigit((c %= 100) / 10))
      s.cat(charForDigit(c % 10))
      s
    }
  }

  /**
   * Implementation of the (FPP)2 algorithm from Steele and White, for doubles in the range
   * 0.01 to 1000000, and floats in the range 0.000001 to 1000000.
   * In this range (a) XPath requires that the output should not be in exponential
   * notation, and (b) the arithmetic can be handled using longs rather than BigIntegers
   *
   * @param sb the string buffer to which the formatted result is to be appended
   * @param e  the exponent of the floating point number
   * @param f  the fraction part of the floating point number, such that the "real" value of the
   *           number is f * 2^(e-p), with p&gt;=0 and 0 lt f lt 2^p
   * @param p  the precision
   */
  private def fppfpp(sb: FastStringBuffer, e: Int, f: Long, p: Int) = {
    var R = f << Math.max(e - p, 0)
    var S = 1L << Math.max(0, -(e - p))
    var Mminus = 1L << Math.max(e - p, 0)
    var Mplus = Mminus
    var initial = true
    // simpleFixup
    if (f == 1L << (p - 1)) {
      Mplus = Mplus << 1
      R = R << 1
      S = S << 1
    }
    var k = 0
    while ( {
      R < (S + 9) / 10
    }) { // (S+9)/10 == ceiling(S/10)
      k -= 1
      R = R * 10
      Mminus = Mminus * 10
      Mplus = Mplus * 10
    }
    while ( {
      2 * R + Mplus >= 2 * S
    }) {
      S = S * 10
      k += 1
    }
    for (z <- k until 0) {
      if (initial) sb.append("0.")
      initial = false
      sb.cat('0')
    }
    // end simpleFixup
    //int H = k-1;
    var low = false
    var high = false
    var U = 0
    while ( {
      true
    }) {
      k -= 1
      val R10 = R * 10
      U = (R10 / S).toInt
      R = R10 - (U * S) // = R*10 % S, but faster - saves a division
      Mminus = Mminus * 10
      Mplus = Mplus * 10
      low = 2 * R < Mminus
      high = 2 * R > 2 * S - Mplus
      if (low || high) break //todo: break is not supported
      if (k == -1) {
        if (initial) sb.cat('0')
        sb.cat('.')
      }
      sb.cat(charForDigit(U))
      initial = false
    }
    if (high && (!low || 2 * R > S)) U += 1
    if (k == -1) {
      if (initial) sb.cat('0')
      sb.cat('.')
    }
    sb.cat(charForDigit(U))
    for (z <- 0 until k) {
      sb.cat('0')
    }
  }

  /**
   * Implementation of the (FPP)2 algorithm from Steele and White, for doubles in the range
   * 0.000001 to 0.01. In this range XPath requires that the output should not be in exponential
   * notation, but the scale factors are large enough to exceed the capacity of long arithmetic.
   *
   * @param sb the string buffer to which the formatted result is to be appended
   * @param e  the exponent of the floating point number
   * @param f  the fraction part of the floating point number, such that the "real" value of the
   *           number is f * 2^(e-p), with p&gt;=0 and 0 lt f lt 2^p
   * @param p  the precision
   */
  private def fppfppBig(sb: FastStringBuffer, e: Int, f: Long, p: Int) = { //long R = f << Math.max(e-p, 0);
    var R = BigInteger.valueOf(f).shiftLeft(Math.max(e - p, 0))
    //long S = 1L << Math.max(0, -(e-p));
    var S = BigInteger.ONE.shiftLeft(Math.max(0, -(e - p)))
    //long Mminus = 1 << Math.max(e-p, 0);
    var Mminus = BigInteger.ONE.shiftLeft(Math.max(e - p, 0))
    //long Mplus = Mminus;
    var Mplus = Mminus
    var initial = true
    if (f == 1L << (p - 1)) {
      Mplus = Mplus.shiftLeft(1)
      R = R.shiftLeft(1)
      S = S.shiftLeft(1)
    }
    var k = 0
    while ( {
      R.compareTo(S.add(NINE).divide(TEN)) < 0
    }) {
      k -= 1
      R = R.multiply(TEN)
      Mminus = Mminus.multiply(TEN)
      Mplus = Mplus.multiply(TEN)
    }
    while ( {
      R.shiftLeft(1).add(Mplus).compareTo(S.shiftLeft(1)) >= 0
    }) {
      S = S.multiply(TEN)
      k += 1
    }
    for (z <- k until 0) {
      if (initial) sb.append("0.")
      initial = false
      sb.cat('0')
    }
    var low = false
    var high = false
    var U = 0
    while ( {
      true
    }) {
      k -= 1
      val R10 = R.multiply(TEN)
      U = R10.divide(S).intValue
      R = R10.mod(S)
      Mminus = Mminus.multiply(TEN)
      Mplus = Mplus.multiply(TEN)
      val R2 = R.shiftLeft(1)
      low = R2.compareTo(Mminus) < 0
      high = R2.compareTo(S.shiftLeft(1).subtract(Mplus)) > 0
      if (low || high) break //todo: break is not supported
      if (k == -1) {
        if (initial) sb.cat('0')
        sb.cat('.')
      }
      sb.cat(charForDigit(U))
      initial = false
    }
    if (high && (!low || R.shiftLeft(1).compareTo(S) > 0)) U += 1
    if (k == -1) {
      if (initial) sb.cat('0')
      sb.cat('.')
    }
    sb.cat(charForDigit(U))
    for (z <- 0 until k) {
      sb.cat('0')
    }
  }

  /**
   * Implementation of the (FPP)2 algorithm from Steele and White, for numbers outside the range
   * 0.000001 to 1000000. In this range XPath requires that the output should be in exponential
   * notation
   *
   * @param sb the string buffer to which the formatted result is to be appended
   * @param e  the exponent of the floating point number
   * @param f  the fraction part of the floating point number, such that the "real" value of the
   *           number is f * 2^(e-p), with p&gt;=0 and 0 lt f lt 2^p
   * @param p  the precision
   */
  private def fppfppExponential(sb: FastStringBuffer, e: Int, f: Long, p: Int) = {
    var R = BigInteger.valueOf(f).shiftLeft(Math.max(e - p, 0))
    var S = BigInteger.ONE.shiftLeft(Math.max(0, -(e - p)))
    var Mminus = BigInteger.ONE.shiftLeft(Math.max(e - p, 0))
    var Mplus = Mminus
    var initial = true
    var doneDot = false
    if (f == 1L << (p - 1)) {
      Mplus = Mplus.shiftLeft(1)
      R = R.shiftLeft(1)
      S = S.shiftLeft(1)
    }
    var k = 0
    while ( {
      R.compareTo(S.add(NINE).divide(TEN)) < 0
    }) {
      k -= 1
      R = R.multiply(TEN)
      Mminus = Mminus.multiply(TEN)
      Mplus = Mplus.multiply(TEN)
    }
    while ( {
      R.shiftLeft(1).add(Mplus).compareTo(S.shiftLeft(1)) >= 0
    }) {
      S = S.multiply(TEN)
      k += 1
    }
    val H = k - 1
    var low = false
    var high = false
    var U = 0
    while ( {
      true
    }) {
      k -= 1
      val R10 = R.multiply(TEN)
      U = R10.divide(S).intValue
      R = R10.mod(S)
      Mminus = Mminus.multiply(TEN)
      Mplus = Mplus.multiply(TEN)
      val R2 = R.shiftLeft(1)
      low = R2.compareTo(Mminus) < 0
      high = R2.compareTo(S.shiftLeft(1).subtract(Mplus)) > 0
      if (low || high) break //todo: break is not supported
      sb.cat(charForDigit(U))
      if (initial) {
        sb.cat('.')
        doneDot = true
      }
      initial = false
    }
    if (high && (!low || R.shiftLeft(1).compareTo(S) > 0)) U += 1
    sb.cat(charForDigit(U))
    if (!doneDot) sb.append(".0")
    sb.cat('E')
    appendInt(sb, H)
  }

  /**
   * Append a string representation of a double value to a string buffer
   *
   * @param s the string buffer to which the result will be appended
   * @param d the double to be formatted
   * @return the original string buffer, now containing the string representation of the supplied double
   */
  def appendDouble(s: FastStringBuffer, d: Double, forceExponential: Boolean): FastStringBuffer = {
    if (d == Double.NEGATIVE_INFINITY) s.append(NEGATIVE_INFINITY)
    else if (d == Double.POSITIVE_INFINITY) s.append(POSITIVE_INFINITY)
    else if (d != d) s.append(NaN)
    else if (d == 0.0) {
      if ((Double.doubleToLongBits(d) & DOUBLE_SIGN_MASK) != 0) s.cat('-')
      s.cat('0')
      if (forceExponential) s.append(".0E0")
    }
    else if (d == Double.MAX_VALUE) s.append("1.7976931348623157E308")
    else if (d == -Double.MAX_VALUE) s.append("-1.7976931348623157E308")
    else if (d == Double.MIN_VALUE) s.append("4.9E-324")
    else if (d == -Double.MIN_VALUE) s.append("-4.9E-324")
    else {
      if (d < 0) {
        s.cat('-')
        d = -d
      }
      val bits = Double.doubleToLongBits(d)
      val fraction = (1L << 52) | (bits & doubleFractMask)
      val rawExp = (bits & doubleExpMask) >> doubleExpShift
      val exp = rawExp.toInt - doubleExpBias
      if (rawExp == 0) { // don't know how to handle this currently: hand it over to Java to deal with
        s.append(Double.toString(d))
        return s
      }
      if (forceExponential || (d >= 1000000 || d < 0.000001)) fppfppExponential(s, exp, fraction, 52)
      else if (d <= 0.01) fppfppBig(s, exp, fraction, 52)
      else fppfpp(s, exp, fraction, 52)
      // test code
      //            try {
      //                if (Double.parseDouble(s.toString()) != value) {
      //                    System.err.println("*** Round-trip failed: input " + value +
      //                            '(' + Double.doubleToLongBits(value) + ')' +
      //                            " != output " + s.toString() +
      //                            '(' + Double.doubleToLongBits(Double.parseDouble(s.toString())) + ')' );
      //                }
      //            } catch (NumberFormatException e) {
      //                System.err.println("*** Bad float " + s.toString() + " for input " + value);
      //            }
    }
    s
  }

  /**
   * Append a string representation of a float value to a string buffer
   *
   * @param s                the string buffer to which the result will be appended
   * @param f                the float to be formatted
   * @param forceExponential forces exponential notation if set (if not set, exponential notation
   *                         is used only for values outside the range 1e-6 to 1e+6)
   * @return the original string buffer, now containing the string representation of the supplied float
   */
  /*@NotNull*/ def appendFloat(s: FastStringBuffer, f: Float, forceExponential: Boolean): FastStringBuffer = {
    if (f == Float.NEGATIVE_INFINITY) s.append(NEGATIVE_INFINITY)
    else if (f == Float.POSITIVE_INFINITY) s.append(POSITIVE_INFINITY)
    else if (f != f) s.append(NaN)
    else if (f == 0.0) {
      if ((Float.floatToIntBits(f) & FLOAT_SIGN_MASK) != 0) s.cat('-')
      s.cat('0')
    }
    else if (f == Float.MAX_VALUE) s.append("3.4028235E38")
    else if (f == -Float.MAX_VALUE) s.append("-3.4028235E38")
    else if (f == Float.MIN_VALUE) s.append("1.4E-45")
    else if (f == -Float.MIN_VALUE) s.append("-1.4E-45")
    else {
      if (f < 0) {
        s.cat('-')
        f = -f
      }
      val bits = Float.floatToIntBits(f)
      val fraction = (1 << 23) | (bits & floatFractMask)
      val rawExp = (bits & floatExpMask) >> floatExpShift
      val exp = rawExp - floatExpBias
      val precision = 23
      if (rawExp == 0) {
        s.append(Float.toString(f))
        return s
      }
      if (forceExponential || (f >= 1000000 || f < 0.000001F)) fppfppExponential(s, exp, fraction, precision)
      else fppfpp(s, exp, fraction, precision)
    }
    s
  }
}

class FloatingPointConverter private() {
  //    public static void main(String[] args) {
  //        if (args.length > 0 && args[0].equals("F")) {
  //            if (args.length == 2) {
  //                StringTokenizer tok = new StringTokenizer(args[1], ",");
  //                while (tok.hasMoreElements()) {
  //                    String input = tok.nextToken();
  //                    float f = Float.parseFloat(input);
  //                    FastStringBuffer sb = new FastStringBuffer(20);
  //                    appendFloat(sb, f);
  //                    System.err.println("input: " + input + " output: " + sb.toString() + " java: " + f);
  //            } else {
  //                Random gen = new Random();
  //                for (int i=1; i<1000; i++) {
  //                    int p=gen.nextInt(999*i*i);
  //                    int q=gen.nextInt(999*i*i);
  //                    String input = (p + "." + q);
  //        } else {
  //                    double f = Double.parseDouble(input);
  //                    appendDouble(sb, f);
  //                long start = System.currentTimeMillis();
  //                for (int i=1; i<100000; i++) {
  //                    //int p=gen.nextInt(999*i*i);
  //                    int q=gen.nextInt(999*i);
  //                    //String input = (p + "." + q);
  //                    String input = "0.000" + q;
  //                    //System.err.println("input: " + input + " output: " + sb.toString() + " java: " + f);
  //                System.err.println("** elapsed time " + (System.currentTimeMillis() - start));
  //        }
  //    }
}