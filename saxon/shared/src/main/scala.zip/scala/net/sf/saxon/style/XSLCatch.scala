////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.pattern._
import net.sf.saxon.trans.XPathException
import java.util
import java.util.StringTokenizer

/**
 * Handler for xsl:catch elements in stylesheet.
 * The xsl:catch element has a mandatory attribute errors, a space-separated list of NameTests defining
 * which errors are caught. If an error is caught, the value to be returned may be defined either by a select
 * attribute or by the content of the saxon:catch element.
 */
class XSLCatch extends StyleElement {
  private var select = null
  private var nameTest = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = false

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  /**
   * Ask whether variables declared in an "uncle" element are visible.
   *
   * @return true for all elements except xsl:fallback and saxon:catch
   */
  override protected def seesAvuncularVariables = false

  override def prepareAttributes() = {
    var selectAtt = null
    var errorAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else if (f == "errors") errorAtt = value
      else checkUnknownAttribute(attName)
    }
    if (errorAtt == null) { // default is "catch all errors"
      nameTest = AnyNodeTest.getInstance // for error recovery
    }
    else {
      val tests = parseNameTests(errorAtt)
      if (tests.size == 0) compileError("xsl:catch/@errors must not be empty")
      if (tests.size == 1) nameTest = tests.get(0)
      else nameTest = new UnionQNameTest(tests)
    }
  }

  /**
   * Parse an attribute consisting of a space-separated sequence of NameTests
   *
   * @param elements the value of the attribute
   * @return the sequence of NameTests
   */
  private def parseNameTests(elements: String) = {
    val result = new util.ArrayList[QNameTest]
    val st = new StringTokenizer(elements, " \t\n\r", false)
    while ( {
      st.hasMoreTokens
    }) {
      val s = st.nextToken
      var nt = null
      if (s == "*") {
        nt = AnyNodeTest.getInstance
        result.add(nt)
      }
      else if (s.endsWith(":*")) {
        if (s.length == 2) {
          compileError("No prefix before ':*'")
          result.add(AnyNodeTest.getInstance)
        }
        val prefix = s.substring(0, s.length - 2)
        val uri = getURIForPrefix(prefix, false)
        nt = new NamespaceTest(getNamePool, Type.ELEMENT, uri)
        result.add(nt)
      }
      else if (s.startsWith("*:")) {
        if (s.length == 2) {
          compileErrorInAttribute("No local name after '*:'", "XTSE0010", "errors")
          result.add(AnyNodeTest.getInstance)
        }
        val localname = s.substring(2)
        nt = new LocalNameTest(getNamePool, Type.ELEMENT, localname)
        result.add(nt)
      }
      else {
        var prefix = null
        var localName = null
        var uri = null
        try {
          val parts = NameChecker.getQNameParts(s)
          prefix = parts(0)
          if (parts(0) == "") uri = ""
          else {
            uri = getURIForPrefix(prefix, false)
            if (uri == null) {
              undeclaredNamespaceError(prefix, "XTSE0280", "errors")
              result.add(AnyNodeTest.getInstance)
              break //todo: break is not supported
            }
          }
          localName = parts(1)
        } catch {
          case err: QNameException =>
            compileErrorInAttribute("Error code " + s + " is not a valid QName", "XTSE0280", "errors")
            result.add(AnyNodeTest.getInstance)
            break //todo: break is not supported
        }
        val target = getNamePool
        val nameCode = target.allocateFingerprint(uri, localName)
        nt = new NameTest(Type.ELEMENT, nameCode, getNamePool)
        result.add(nt)
      }
    }
    result
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    select = typeCheck("select", select)
    if (select != null && hasChildNodes) compileError("An xsl:catch element with a select attribute must be empty", "XTSE3150")
    if (!getParent.isInstanceOf[XSLTry]) compileError("xsl:catch may appear only as a child of xsl:try")
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    if (select == null) select = compileSequenceConstructor(exec, decl, true)
    getParent.asInstanceOf[XSLTry].addCatchClause(nameTest, select)
    null
  }
}