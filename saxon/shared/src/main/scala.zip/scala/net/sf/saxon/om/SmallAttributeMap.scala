////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import java.util

/**
 * An implementation of AttributeMap suitable for small collections of attributes (typically, up to five).
 * Searching for a particular attribute involves a sequential search, and adding a new attribute constructs
 * a full copy.
 *
 * <p>A {@code SmallAttributeMap} retains attribute order, so there may be situations in which it is appropriate
 * to use this structure even for larger attribute sets.</p>
 */
object SmallAttributeMap {
  private[om] val LIMIT = 8
}

class SmallAttributeMap(val attributes: List[AttributeInfo]) extends AttributeMap { // TODO: check uniqueness of names?
  this.attributes = new ArrayList[AttributeInfo](attributes)
  private var attributes = null

  /**
   * Return the number of attributes in the map.
   *
   * @return The number of attributes in the map.
   */
  override def size = attributes.size

  override def get(name: NodeName): AttributeInfo = {
    import scala.collection.JavaConversions._
    for (info <- attributes) {
      if (info.getNodeName == name) return info
    }
    null
  }

  override def get(uri: String, local: String): AttributeInfo = {
    import scala.collection.JavaConversions._
    for (info <- attributes) {
      val name = info.getNodeName
      if (name.getLocalPart == local && name.hasURI(uri)) return info
    }
    null
  }

  override def getByFingerprint(fingerprint: Int, namePool: NamePool): AttributeInfo = {
    import scala.collection.JavaConversions._
    for (info <- attributes) {
      val name = info.getNodeName
      if (name.obtainFingerprint(namePool) == fingerprint) return info
    }
    null
  }

  override def iterator = attributes.iterator

  override def asList = new util.ArrayList[AttributeInfo](attributes)

  override def itemAt(index: Int) = attributes.get(index)
}