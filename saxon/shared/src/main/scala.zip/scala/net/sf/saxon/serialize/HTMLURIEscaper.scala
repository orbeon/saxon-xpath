////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.Configuration
import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.serialize.charcode.UTF8CharacterSet
import net.sf.saxon.serialize.codenorm.Normalizer
import net.sf.saxon.trans.UncheckedXPathException
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer

/**
 * This class is used as a filter on the serialization pipeline; it performs the function
 * of escaping URI-valued attributes in HTML
 *
 * @author Michael H. Kay
 */
object HTMLURIEscaper {
  /**
   * Table of attributes whose value is a URL
   */
    // we use two HashMaps to avoid unnecessary string concatenations
    private val urlAttributes = new HTMLTagHashSet(47)
  private val urlCombinations = new HTMLTagHashSet(101)

  private def setUrlAttribute(element: String, attribute: String) = {
    urlAttributes.add(attribute)
    urlCombinations.add(element + '+' + attribute)
  }

  /**
   * Escape a URI according to the HTML rules: that is, a non-ASCII character (specifically,
   * a character outside the range 32 - 126) is replaced by the %HH encoding of the octets in
   * its UTF-8 representation
   *
   * @param url the URI to be escaped
   * @param normalize
   * @return the URI after escaping non-ASCII characters
   */
  /*@NotNull*/ @throws[XPathException]
  def escapeURL(url: CharSequence, normalize: Boolean, config: Configuration): CharSequence = { // optimize for the common case where the string is all ASCII characters
    for (i <- url.length - 1 to 0 by -1) {
      val ch = url.charAt(i)
      if (ch < 32 || ch > 126) if (normalize) {
        val normalized = Normalizer.make(Normalizer.C, config).normalize(url)
        return reallyEscapeURL(normalized)
      }
      else return reallyEscapeURL(url)
    }
    url
  }

  private def reallyEscapeURL(url: CharSequence) = {
    val sb = new FastStringBuffer(url.length + 20)
    val hex = "0123456789ABCDEF"
    val array = new Array[Byte](4)
    for (i <- 0 until url.length) {
      val ch = url.charAt(i)
      if (ch < 32 || ch > 126) {
        val used = UTF8CharacterSet.getUTF8Encoding(ch, if (i + 1 < url.length) url.charAt(i + 1)
        else ' ', array)
        for (b <- 0 until used) { //int v = (array[b]>=0 ? array[b] : 256 + array[b]);
          val v = array(b).toInt & 0xff
          sb.cat('%')
          sb.cat(hex.charAt(v / 16))
          sb.cat(hex.charAt(v % 16))
        }
      }
      else sb.cat(ch)
    }
    sb
  }

  try setUrlAttribute("form", "action")
  setUrlAttribute("object", "archive")
  setUrlAttribute("body", "background")
  setUrlAttribute("q", "cite")
  setUrlAttribute("blockquote", "cite")
  setUrlAttribute("del", "cite")
  setUrlAttribute("ins", "cite")
  setUrlAttribute("object", "classid")
  setUrlAttribute("object", "codebase")
  setUrlAttribute("applet", "codebase")
  setUrlAttribute("object", "data")
  setUrlAttribute("button", "datasrc")
  setUrlAttribute("div", "datasrc")
  setUrlAttribute("input", "datasrc")
  setUrlAttribute("object", "datasrc")
  setUrlAttribute("select", "datasrc")
  setUrlAttribute("span", "datasrc")
  setUrlAttribute("table", "datasrc")
  setUrlAttribute("textarea", "datasrc")
  setUrlAttribute("script", "for")
  setUrlAttribute("a", "href")
  setUrlAttribute("a", "name") // see second note in section B.2.1 of HTML 4 specification
  setUrlAttribute("area", "href")
  setUrlAttribute("link", "href")
  setUrlAttribute("base", "href")
  setUrlAttribute("img", "longdesc")
  setUrlAttribute("frame", "longdesc")
  setUrlAttribute("iframe", "longdesc")
  setUrlAttribute("head", "profile")
  setUrlAttribute("script", "src")
  setUrlAttribute("input", "src")
  setUrlAttribute("frame", "src")
  setUrlAttribute("iframe", "src")
  setUrlAttribute("img", "src")
  setUrlAttribute("img", "usemap")
  setUrlAttribute("input", "usemap")
  setUrlAttribute("object", "usemap")
}

class HTMLURIEscaper(val nextReceiver: Receiver) extends ProxyReceiver(nextReceiver) {
  def isUrlAttribute(element: NodeName, attribute: NodeName): Boolean = {
    if (pool == null) pool = getNamePool
    val attributeName = attribute.getDisplayName
    if (!HTMLURIEscaper.urlAttributes.contains(attributeName)) return false
    val elementName = element.getDisplayName
    HTMLURIEscaper.urlCombinations.contains(elementName + '+' + attributeName)
  }

  protected var currentElement = null
  protected var escapeURIAttributes = true
  protected var pool = null

  /**
   * Start of a document node.
   *
   * @param properties
   */
  @throws[XPathException]
  override def startDocument(properties: Int) = {
    nextReceiver.startDocument(properties)
    pool = getPipelineConfiguration.getConfiguration.getNamePool
  }

  /**
   * Notify the start of an element
   */
  @throws[XPathException]
  override def startElement(nameCode: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    currentElement = nameCode
    var atts2 = attributes
    if (escapeURIAttributes) try atts2 = attributes.apply((att: AttributeInfo) => {
      def foo(att: AttributeInfo) =
        if (!ReceiverOption.contains(att.getProperties, ReceiverOption.DISABLE_ESCAPING)) {
          val attName = att.getNodeName
          if (isUrlAttribute(nameCode, attName)) {
            val value = att.getValue
            try new AttributeInfo(att.getNodeName, att.getType, HTMLURIEscaper.escapeURL(value, true, getConfiguration).toString, att.getLocation, att.getProperties | ReceiverOption.DISABLE_CHARACTER_MAPS)
            catch {
              case e: XPathException =>
                throw new UncheckedXPathException(e)
            }
          }
          else att
        }
        else att

      foo(att)
    })
    catch {
      case e: UncheckedXPathException =>
        throw e.getXPathException
    }
    nextReceiver.startElement(nameCode, `type`, atts2, namespaces, location, properties)
  }
}