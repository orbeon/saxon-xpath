////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Cardinality

/**
 * A SingleItemFilter is an expression that selects zero or one items from a supplied sequence
 */
abstract class SingleItemFilter(val base: Expression) extends UnaryExpression(base) {
  override protected def getOperandRole = OperandRole.SAME_FOCUS_ACTION

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor     an expresion visitor
   * @param contextInfo the static type of "." at the point where this expression is invoked.
   *                    The parameter is set to null if it is known statically that the context item will be undefined.
   *                    If the type of the context item is not known statically, the argument is set to
   *                    { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws net.sf.saxon.trans.XPathException
   * if an error is discovered during this phase
   * (typically a type error)
   */
  /*@NotNull*/ @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    getOperand.optimize(visitor, contextInfo)
    val base = getBaseExpression
    if (!Cardinality.allowsMany(base.getCardinality)) return base
    super.optimize(visitor, contextInfo)
  }

  /**
   * Get the static cardinality: this implementation is appropriate for [1] and [last()] which will always
   * return something if the input is non-empty
   */
  override def computeCardinality = StaticProperty.ALLOWS_ZERO_OR_ONE
}