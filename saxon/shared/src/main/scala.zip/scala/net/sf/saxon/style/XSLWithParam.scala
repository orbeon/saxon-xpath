////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.WithParam
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.Item
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.value.SequenceType
import java.util

/**
 * An xsl:with-param element in the stylesheet. <br>
 * The xsl:with-param element has mandatory attribute name and optional attribute select
 */
class XSLWithParam extends XSLGeneralVariable {
  private val allowedAttributes = util.EnumSet.of(SourceBinding.BindingProperty.SELECT, SourceBinding.BindingProperty.AS, SourceBinding.BindingProperty.TUNNEL)

  override protected def prepareAttributes() = sourceBinding.prepareAttributes(allowedAttributes)

  def isTunnelParam = sourceBinding.hasProperty(SourceBinding.BindingProperty.TUNNEL)

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    super.validate(decl)
    // Check for duplicate parameter names
    val iter = iterateAxis(AxisInfo.PRECEDING_SIBLING)
    var prev = null
    while ( {
      (prev = iter.next) != null
    }) if (prev.isInstanceOf[XSLWithParam]) if (sourceBinding.getVariableQName == prev.asInstanceOf[XSLWithParam].sourceBinding.getVariableQName) compileError("Duplicate parameter name", "XTSE0670")
  }

  @throws[XPathException]
  def checkAgainstRequiredType(required: SequenceType) = sourceBinding.checkAgainstRequiredType(required)

  /*@NotNull*/ @throws[XPathException]
  def compileWithParam(parent: Expression, exec: Compilation, decl: ComponentDeclaration) = {
    sourceBinding.handleSequenceConstructor(exec, decl)
    val inst = new WithParam
    inst.setSelectExpression(parent, sourceBinding.getSelectExpression)
    inst.setVariableQName(sourceBinding.getVariableQName)
    inst.setRequiredType(sourceBinding.getInferredType(true))
    inst
  }
}