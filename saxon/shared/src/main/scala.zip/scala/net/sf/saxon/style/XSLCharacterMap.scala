////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.om._
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace
import net.sf.saxon.z.IntHashMap
import java.util
import java.util.StringTokenizer

/**
 * An xsl:character-map declaration in the stylesheet. <br>
 */
class XSLCharacterMap extends StyleElement {
  /*@Nullable*/ private[style] var use = null
  private[style] var characterMapElements = null
  private[style] var validated = false
  private[style] var redundant = false

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  /**
   * Get the fingerprint of the name of this character map
   *
   * @return the fingerprint value
   */
  def getCharacterMapName: StructuredQName = {
    val name = getObjectName
    if (name == null) return makeQName(getAttributeValue("", "name"), null, "name")
    name
  }

  /**
   * Test whether this character map is redundant (because another with the
   * same name has higher import precedence). Note that a character map is not
   * considered redundant simply because it is not referenced in an xsl:output
   * declaration; we allow character-maps to be selected at run-time using the
   * setOutputProperty() API.
   *
   * @return true if this character map is redundant
   */
  def isRedundant = redundant

  /**
   * Validate the attributes on this instruction
   */
  override def prepareAttributes() = {
    var name = null
    use = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      if (f == "name") name = Whitespace.trim(value)
      else if (f == "use-character-maps") use = value
      else checkUnknownAttribute(attName)
    }
    if (name == null) {
      reportAbsence("name")
      name = "unnamedCharacterMap_" + hashCode
    }
    setObjectName(makeQName(name, null, "name"))
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration): Unit = {
    if (validated) return
    // check that this is a top-level declaration
    checkTopLevel("XTSE0010", false)
    // check that the only children are xsl:output-character elements
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (!child.isInstanceOf[XSLOutputCharacter]) compileError("Only xsl:output-character is allowed within xsl:character-map", "XTSE0010")
    }
    // check that there isn't another character-map with the same name and import
    // precedence
    val psm = getPrincipalStylesheetModule
    val other = psm.getCharacterMap(getObjectName)
    if (other != null /* error path: see character-map-027 */ && (other.getSourceElement ne this)) if (decl.getPrecedence == other.getPrecedence) compileError("There are two character-maps with the same name and import precedence", "XTSE1580")
    else if (decl.getPrecedence < other.getPrecedence) redundant = true
    // validate the use-character-maps attribute
    if (use != null) { // identify any character maps that this one refers to
      characterMapElements = new util.ArrayList[XSLCharacterMap](5)
      val st = new StringTokenizer(use, " \t\n\r", false)
      while ( {
        st.hasMoreTokens
      }) {
        val displayname = st.nextToken
        try {
          val parts = NameChecker.getQNameParts(displayname)
          val uri = getURIForPrefix(parts(0), false)
          if (uri == null) compileError("Undeclared namespace prefix " + Err.wrap(parts(0)) + " in character map name", "XTSE0280")
          val qn = new StructuredQName(parts(0), uri, parts(1))
          val charMapDecl = psm.getCharacterMap(qn)
          if (charMapDecl == null) compileError("No character-map named '" + displayname + "' has been defined", "XTSE1590")
          else {
            val ref = charMapDecl.getSourceElement.asInstanceOf[XSLCharacterMap]
            characterMapElements.add(ref)
          }
        } catch {
          case err: QNameException =>
            compileError("Invalid character-map name. " + err.getMessage, "XTSE1590")
        }
      }
      // check for circularity
      import scala.collection.JavaConversions._
      for (characterMapElement <- characterMapElements) {
        characterMapElement.asInstanceOf[XSLCharacterMap].checkCircularity(this)
      }
    }
    validated = true
  }

  /**
   * Check for circularity: specifically, check that this attribute set does not contain
   * a direct or indirect reference to the one supplied as a parameter
   *
   * @param origin the start point of the search
   * @throws net.sf.saxon.trans.XPathException
   * if an error is detected
   */
  @throws[XPathException]
  private def checkCircularity(origin: XSLCharacterMap): Unit = if (this eq origin) {
    compileError("The definition of the character map is circular", "XTSE1600")
    characterMapElements = null // for error recovery
  }
  else {
    if (!validated) { // if this attribute set isn't validated yet, we don't check it.
      // The circularity will be detected when the last attribute set in the cycle
      // gets validated
      return
    }
    if (characterMapElements != null) {
      import scala.collection.JavaConversions._
      for (characterMapElement <- characterMapElements) {
        characterMapElement.asInstanceOf[XSLCharacterMap].checkCircularity(origin)
      }
    }
  }

  /**
   * Assemble all the mappings defined by this character map, adding them to a
   * HashMap that maps integer codepoints to strings
   *
   * @param map an IntHash map populated with the character mappings
   */
  def assemble(map: IntHashMap[String]) = {
    if (characterMapElements != null) {
      import scala.collection.JavaConversions._
      for (charmap <- characterMapElements) {
        charmap.assemble(map)
      }
    }
    import scala.collection.JavaConversions._
    for (child <- children) {
      val oc = child.asInstanceOf[XSLOutputCharacter]
      map.put(oc.getCodePoint, oc.getReplacementString)
    }
  }

  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = {
    // no action
  }
}