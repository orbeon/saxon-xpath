////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * Handler for xsl:otherwise elements in stylesheet.
 */
class XSLOtherwise extends StyleElement {
  private var select = null

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      if (f == "select") { // Saxon extension
        requireSyntaxExtensions("select")
        select = makeExpression(att.getValue, att)
      }
      else checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    if (!getParent.isInstanceOf[XSLChoose]) compileError("xsl:otherwise must be immediately within xsl:choose", "XTSE0010")
    if (select != null && hasChildNodes) compileError("xsl:otherwise element must be empty if @select is present", "XTSE0010")
  }

  /**
   * Mark tail-recursive calls on stylesheet functions. For most instructions, this does nothing.
   */
  override def markTailCalls = {
    val last = getLastChildInstruction
    last != null && last.markTailCalls
  }

  /*@NotNull*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = throw new UnsupportedOperationException("XSLOtherwise#compile() should not be called")

  @throws[XPathException]
  override def compileSequenceConstructor(compilation: Compilation, decl: ComponentDeclaration, includeParams: Boolean) = if (select == null) super.compileSequenceConstructor(compilation, decl, includeParams)
  else select
}