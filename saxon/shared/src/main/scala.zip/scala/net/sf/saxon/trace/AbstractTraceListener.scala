////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.Controller
import net.sf.saxon.Version
import net.sf.saxon.expr.XPathContext
import net.sf.saxon.expr.instruct.Instruction
import net.sf.saxon.expr.parser.CodeInjector
import net.sf.saxon.lib.Logger
import net.sf.saxon.lib.StandardDiagnostics
import net.sf.saxon.lib.StandardLogger
import net.sf.saxon.lib.TraceListener
import net.sf.saxon.om.Item
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.Mode
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.tree.util.Navigator
import net.sf.saxon.value.StringValue
import net.sf.saxon.value.Whitespace
import java.util

/**
 * This is the standard trace listener used when the -T option is specified on the command line.
 * There are two variants, represented by subclasses: one for XSLT, and one for XQuery. The two variants
 * differ in that they present the trace output in terms of constructs used in the relevant host language.
 */
object AbstractTraceListener {
  /*@NotNull*/ private val spaceBuffer = new StringBuffer("                ")

  /**
   * Get n spaces
   */
  protected def spaces(n: Int) = {
    while ( {
      spaceBuffer.length < n
    }) spaceBuffer.append(AbstractTraceListener.spaceBuffer)
    spaceBuffer.substring(0, n)
  }
}

abstract class AbstractTraceListener extends StandardDiagnostics with TraceListener {
  protected var indent = 0
  private var detail = 2 // none=0; low=1; normal=2; high=3
  protected var out = new StandardLogger

  /**
   * Get the associated CodeInjector to be used at compile time to generate the tracing calls
   */
  def getCodeInjector = new TraceCodeInjector

  /**
   * Set the level of detail required
   *
   * @param level 0=none, 1=low (function and template calls), 2=normal (instructions), 3=high (expressions)
   */
  def setLevelOfDetail(level: Int) = this.detail = level

  /**
   * Called at start
   */
  override def open(controller: Controller) = {
    out.info("<trace " + "saxon-version=\"" + Version.getProductVersion + "\" " + getOpeningAttributes + '>')
    indent += 1
  }

  protected def getOpeningAttributes

  /**
   * Called at end
   */
  override def close() = {
    indent -= 1
    out.info("</trace>")
  }

  /**
   * Called when an instruction in the stylesheet gets processed
   */
  override def enter(info: Traceable, properties: util.Map[String, AnyRef], context: XPathContext) = if (isApplicable(info)) {
    val loc = info.getLocation
    val tag = tag(info)
    val file = abbreviateLocationURI(loc.getSystemId)
    val msg = new StringBuilder(AbstractTraceListener.spaces(indent) + '<' + tag)
    import scala.collection.JavaConversions._
    for (entry <- properties.entrySet) {
      var `val` = entry.getValue
      if (`val`.isInstanceOf[StructuredQName]) `val` = `val`.asInstanceOf[StructuredQName].getDisplayName
      else if (`val`.isInstanceOf[StringValue]) `val` = `val`.asInstanceOf[StringValue].getStringValue
      if (`val` != null) msg.append(' ').append(entry.getKey).append("=\"").append(escape(`val`.toString)).append('"')
    }
    msg.append(" line=\"").append(loc.getLineNumber).append('"')
    val col = loc.getColumnNumber
    if (col >= 0) msg.append(" column=\"").append(loc.getColumnNumber).append('"')
    msg.append(" module=\"").append(escape(file)).append('"')
    msg.append(">")
    out.info(msg.toString)
    indent += 1
  }

  /**
   * Escape a string for XML output (in an attribute delimited by double quotes).
   * This method also collapses whitespace (since the value may be an XPath expression that
   * was originally written over several lines).
   */
  def escape(/*@Nullable*/ in: String): String = {
    if (in == null) return ""
    val collapsed = Whitespace.collapseWhitespace(in)
    val sb = new FastStringBuffer(collapsed.length + 10)
    for (i <- 0 until collapsed.length) {
      val c = collapsed.charAt(i)
      if (c == '<') sb.append("&lt;")
      else if (c == '>') sb.append("&gt;")
      else if (c == '&') sb.append("&amp;")
      else if (c == '\"') sb.append("&#34;")
      else if (c == '\n') sb.append("&#xA;")
      else if (c == '\r') sb.append("&#xD;")
      else if (c == '\t') sb.append("&#x9;")
      else sb.cat(c)
    }
    sb.toString
  }

  /**
   * Called after an instruction of the stylesheet got processed
   *
   * @param info
   */
  override def leave(info: Traceable) = if (isApplicable(info)) {
    val tag = tag(info)
    indent -= 1
    out.info(AbstractTraceListener.spaces(indent) + "</" + tag + '>')
  }

  protected def isApplicable(info: Traceable) = level(info) <= detail

  protected def tag(info: Traceable)

  protected def level(info: Traceable): Int = {
    if (info.isInstanceOf[TraceableComponent]) return 1
    if (info.isInstanceOf[Instruction]) 2
    else 3
  }

  /**
   * Called when an item becomes the context item
   */
  override def startCurrentItem(item: Item) = {
    if (item.isInstanceOf[NodeInfo] && detail > 0) {
      val curr = item.asInstanceOf[NodeInfo]
      out.info(AbstractTraceListener.spaces(indent) + "<source node=\"" + Navigator.getPath(curr) + "\" line=\"" + curr.getLineNumber + "\" file=\"" + abbreviateLocationURI(curr.getSystemId) + "\">")
    }
    indent += 1
  }

  /**
   * Called after a node of the source tree got processed
   */
  override def endCurrentItem(item: Item) = {
    indent -= 1
    if (item.isInstanceOf[NodeInfo] && detail > 0) {
      val curr = item.asInstanceOf[NodeInfo]
      out.info(AbstractTraceListener.spaces(indent) + "</source><!-- " + Navigator.getPath(curr) + " -->")
    }
  }

  /**
   * Set the output destination (default is System.err)
   *
   * @param stream the output destination for tracing output
   */
  override def setOutputDestination(stream: Logger) = out = stream

  /**
   * Get the output destination
   */
  def getOutputDestination = out

  /**
   * Method called when a rule search has completed.
   *
   * @param rule the rule (or possible built-in ruleset) that has been selected
   * @param mode the mode in operation
   * @param item the item that was checked against
   */
  override def endRuleSearch(rule: Any, mode: Mode, item: Item) = {
    // do nothing
  }

  /**
   * Method called when a search for a template rule is about to start
   */
  override def startRuleSearch() = {
  }
}