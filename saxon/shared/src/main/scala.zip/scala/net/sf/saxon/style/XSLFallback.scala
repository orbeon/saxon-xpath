////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * xsl:fallback element in stylesheet. <br>
 */
class XSLFallback extends StyleElement {
  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
    override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  /**
   * Ask whether variables declared in an "uncle" element are visible.
   *
   * @return true for all elements except xsl:fallback and saxon:catch
   */
  override protected def seesAvuncularVariables = false

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    // Parent elements are now responsible for validating their children
    //        StyleElement parent = (StyleElement)getParent();
    //        if (!parent.mayContainFallback()) {
    //            compileError("xsl:fallback is not allowed as a child of " + parent.getDisplayName(), "XT0010");
    //        }
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = { // if we get here, then the parent instruction is OK, so the fallback is not activated
    null
  }
}