////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.compat.ArithmeticExpression10
import net.sf.saxon.expr.parser._
import net.sf.saxon.model._
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.StandardNames
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value._

/**
 * Arithmetic Expression: an expression using one of the operators
 * plus, minus, multiply, div, idiv, mod. Note that this code does not handle backwards
 * compatibility mode: see {@link ArithmeticExpression10}
 */
object ArithmeticExpression {
  /**
   * Static method to apply arithmetic to two values
   *
   * @param value0   the first value
   * @param operator the operator as denoted in the Calculator class, for example { @link Calculator#PLUS}
   * @param value1  the second value
   * @param context the XPath dynamic evaluation context
   * @return the result of the arithmetic operation
   * @throws XPathException if a dynamic error occurs during evaluation
   */
    @throws[XPathException]
    def compute(value0: AtomicValue, operator: Int, value1: AtomicValue, context: XPathContext) = {
      val p0 = value0.getPrimitiveType.getFingerprint
      val p1 = value1.getPrimitiveType.getFingerprint
      val calculator = Calculator.getCalculator(p0, p1, operator, false)
      calculator.compute(value0, value1, context)
    }

  /**
   * Map operator codes from those in the Token class to those in the Calculator class
   *
   * @param op an operator denoted by a constant in the { @link Token} class, for example { @link Token#PLUS}
   * @return an operator denoted by a constant defined in the { @link Calculator} class, for example
   *                                                                  { @link Calculator#PLUS}
   */
  def mapOpCode(op: Int) = op match {
    case Token.PLUS =>
      Calculator.PLUS
    case Token.MINUS =>
    case Token.NEGATE =>
      Calculator.MINUS
    case Token.MULT =>
      Calculator.TIMES
    case Token.DIV =>
      Calculator.DIV
    case Token.IDIV =>
      Calculator.IDIV
    case Token.MOD =>
      Calculator.MOD
    case _ =>
      throw new IllegalArgumentException
  }
}

class ArithmeticExpression(val p0: Expression, val operator: Int, val p1: Expression)

/**
 * Create an arithmetic expression
 *
 * @param p0       the first operand
 * @param operator the operator, for example { @link Token#PLUS}
 * @param p1 the second operand
 */
  extends BinaryExpression(p0, operator, p1) {
  protected var calculator = null
  private var itemType = null

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "arithmetic"

  /**
   * Determine the special properties of this expression
   *
   * @return { @link StaticProperty#NO_NODES_NEWLY_CREATED}. This is overridden
   *                 for some subclasses.
   */
  override def computeSpecialProperties = {
    val p = super.computeSpecialProperties
    p | StaticProperty.NOT_UNTYPED_ATOMIC
  }

  /**
   * Set the calculator allocated to evaluate this expression
   *
   * @param calculator the calculator to be used
   */
  def setCalculator(calculator: Calculator) = this.calculator = calculator

  /**
   * Get the calculator allocated to evaluate this expression
   *
   * @return the calculator, a helper object that does the actual calculation
   */
  def getCalculator = calculator

  /**
   * Type-check the expression statically. We try to work out which particular
   * arithmetic function to use if the types of operands are known an compile time.
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    resetLocalStaticProperties()
    getLhs.typeCheck(visitor, contextInfo)
    getRhs.typeCheck(visitor, contextInfo)
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    val tc = config.getTypeChecker(false)
    val oldOp0 = getLhsExpression
    val oldOp1 = getRhsExpression
    val atomicType = SequenceType.OPTIONAL_ATOMIC
    val role0 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 0)
    //role0.setSourceLocator(this);
    setLhsExpression(tc.staticTypeCheck(getLhsExpression, atomicType, role0, visitor))
    val itemType0 = getLhsExpression.getItemType
    if (itemType0.isInstanceOf[ErrorType]) return Literal.makeEmptySequence
    var type0 = itemType0.getPrimitiveItemType.asInstanceOf[AtomicType]
    if (type0.getFingerprint == StandardNames.XS_UNTYPED_ATOMIC) {
      setLhsExpression(UntypedSequenceConverter.makeUntypedSequenceConverter(config, getLhsExpression, BuiltInAtomicType.DOUBLE))
      type0 = BuiltInAtomicType.DOUBLE
    }
    else if ( /*!(operand0 instanceof UntypedAtomicConverter)*/ (getLhsExpression.getSpecialProperties & StaticProperty.NOT_UNTYPED_ATOMIC) == 0 && (th.relationship(type0, BuiltInAtomicType.UNTYPED_ATOMIC) ne Affinity.DISJOINT) ) {
      setLhsExpression(UntypedSequenceConverter.makeUntypedSequenceConverter(config, getLhsExpression, BuiltInAtomicType.DOUBLE))
      type0 = getLhsExpression.getItemType.getPrimitiveItemType.asInstanceOf[AtomicType]
    }
    // System.err.println("First operand"); operand0.display(10);
    val role1 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 1)
    //role1.setSourceLocator(this);
    setRhsExpression(tc.staticTypeCheck(getRhsExpression, atomicType, role1, visitor))
    val itemType1 = getRhsExpression.getItemType
    if (itemType1.isInstanceOf[ErrorType]) return Literal.makeEmptySequence
    var type1 = itemType1.getPrimitiveItemType.asInstanceOf[AtomicType]
    if (type1.getFingerprint == StandardNames.XS_UNTYPED_ATOMIC) {
      setRhsExpression(UntypedSequenceConverter.makeUntypedSequenceConverter(config, getRhsExpression, BuiltInAtomicType.DOUBLE))
      type1 = BuiltInAtomicType.DOUBLE
    }
    else if ( /*!(operand1 instanceof UntypedAtomicConverter) &&*/ (getRhsExpression.getSpecialProperties & StaticProperty.NOT_UNTYPED_ATOMIC) == 0 && (th.relationship(type1, BuiltInAtomicType.UNTYPED_ATOMIC) ne Affinity.DISJOINT) ) {
      setRhsExpression(UntypedSequenceConverter.makeUntypedSequenceConverter(config, getRhsExpression, BuiltInAtomicType.DOUBLE))
      type1 = getRhsExpression.getItemType.getPrimitiveItemType.asInstanceOf[AtomicType]
    }
    if (itemType0.getUType.union(itemType1.getUType).overlaps(UType.EXTENSION)) {
      val de = new XPathException("Arithmetic operators are not defined for external objects")
      de.setLocation(getLocation)
      de.setErrorCode("XPTY0004")
      throw de
    }
    if (getLhsExpression ne oldOp0) adoptChildExpression(getLhsExpression)
    if (getRhsExpression ne oldOp1) adoptChildExpression(getRhsExpression)
    if (Literal.isEmptySequence(getLhsExpression) || Literal.isEmptySequence(getRhsExpression)) return Literal.makeEmptySequence
    if (operator == Token.NEGATE) if (getRhsExpression.isInstanceOf[Literal] && getRhsExpression.asInstanceOf[Literal].getValue.isInstanceOf[NumericValue]) {
      val nv = getRhsExpression.asInstanceOf[Literal].getValue.asInstanceOf[NumericValue]
      return Literal.makeLiteral(nv.negate, this)
    }
    else {
      val ne = new NegateExpression(getRhsExpression)
      ne.setBackwardsCompatible(false)
      return ne.typeCheck(visitor, contextInfo)
    }
    // Get a calculator to implement the arithmetic operation. If the types are not yet specifically known,
    // we allow this to return an "ANY" calculator which defers the decision. However, we only allow this if
    // at least one of the operand types is AnyAtomicType or (otherwise unspecified) numeric.
    val mustResolve = !(type0 == BuiltInAtomicType.ANY_ATOMIC || type1 == BuiltInAtomicType.ANY_ATOMIC || type0 == NumericType.getInstance || type1 == NumericType.getInstance)
    calculator = Calculator.getCalculator(type0.getFingerprint, type1.getFingerprint, ArithmeticExpression.mapOpCode(operator), mustResolve)
    if (calculator == null) {
      val de = new XPathException("Arithmetic operator is not defined for arguments of types (" + type0.getDescription + ", " + type1.getDescription + ")")
      de.setLocation(getLocation)
      de.setIsTypeError(true)
      de.setErrorCode("XPTY0004")
      throw de
    }
    // If the calculator is going to promote arguments to xs:double, then promote any literal arguments now.
    // (Could generalize this, but this is the common case)
    if (calculator.code.matches("d.d")) {
      if (getLhsExpression.isInstanceOf[Literal] && !(type0 == BuiltInAtomicType.DOUBLE)) {
        val value = getLhsExpression.asInstanceOf[Literal].getValue
        if (value.isInstanceOf[NumericValue]) setLhsExpression(Literal.makeLiteral(new DoubleValue(value.asInstanceOf[NumericValue].getDoubleValue), this))
      }
      if (getRhsExpression.isInstanceOf[Literal] && !(type1 == BuiltInAtomicType.DOUBLE)) {
        val value = getRhsExpression.asInstanceOf[Literal].getValue
        if (value.isInstanceOf[NumericValue]) setRhsExpression(Literal.makeLiteral(new DoubleValue(value.asInstanceOf[NumericValue].getDoubleValue), this))
      }
    }
    try if (getLhsExpression.isInstanceOf[Literal] && getRhsExpression.isInstanceOf[Literal]) return Literal.makeLiteral(evaluateItem(visitor.getStaticContext.makeEarlyEvaluationContext).materialize, this)
    catch {
      case err: XPathException =>

      // if early evaluation fails, suppress the error: the value might
      // not be needed at run-time, or it might be due to context such as the implicit timezone
      // not being available yet
    }
    this
  }

  /**
   * For an expression that returns an integer or a sequence of integers, get
   * a lower and upper bound on the values of the integers that may be returned, from
   * static analysis. The default implementation returns null, meaning "unknown" or
   * "not applicable". Other implementations return an array of two IntegerValue objects,
   * representing the lower and upper bounds respectively. The values
   * UNBOUNDED_LOWER and UNBOUNDED_UPPER are used by convention to indicate that
   * the value may be arbitrarily large. The values MAX_STRING_LENGTH and MAX_SEQUENCE_LENGTH
   * are used to indicate values limited by the size of a string or the size of a sequence.
   *
   * @return the lower and upper bounds of integer values in the result, or null to indicate
   *         unknown or not applicable.
   */
  /*@Nullable*/ override def getIntegerBounds: Array[IntegerValue] = {
    val bounds0 = getLhsExpression.getIntegerBounds
    val bounds1 = getRhsExpression.getIntegerBounds
    if (bounds0 == null || bounds1 == null) null
    else operator match {
      case Token.PLUS =>
        Array[IntegerValue](bounds0(0).plus(bounds1(0)), bounds0(1).plus(bounds1(1)))
      case Token.MINUS =>
        Array[IntegerValue](bounds0(0).minus(bounds1(1)), bounds0(1).minus(bounds1(0)))
      case Token.MULT =>
        if (getRhsExpression.isInstanceOf[Literal]) {
          val val1 = bounds1(0)
          if (val1.signum > 0) Array[IntegerValue](bounds0(0).times(val1), bounds0(1).times(val1))
          else null
        }
        else if (getLhsExpression.isInstanceOf[Literal]) {
          val val0 = bounds1(0)
          if (val0.signum > 0) return Array[IntegerValue](bounds1(0).times(val0), bounds1(1).times(val0))
          else return null
        }
      case Token.DIV =>
      case Token.IDIV =>
        if (getRhsExpression.isInstanceOf[Literal]) {
          val val1 = bounds1(0)
          if (val1.signum > 0) try return Array[IntegerValue](bounds0(0).idiv(val1), bounds0(1).idiv(val1))
          catch {
            case e: XPathException =>
              return null
          }
        }
        null
      case _ =>
        null
    }
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be rebound
   */
  override def copy(rebindings: RebindingMap) = {
    val ae = new ArithmeticExpression(getLhsExpression.copy(rebindings), operator, getRhsExpression.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, ae)
    ae.calculator = calculator
    ae
  }

  /**
   * Determine the data type of the expression, insofar as this is known statically
   *
   * @return the atomic type of the result of this arithmetic expression
   */
  override def getItemType: PlainType = {
    if (itemType != null) return itemType
    if (calculator == null) BuiltInAtomicType.ANY_ATOMIC // type is not known statically
    else {
      var t1 = getLhsExpression.getItemType
      if (!t1.isInstanceOf[AtomicType]) t1 = t1.getAtomizedItemType
      var t2 = getRhsExpression.getItemType
      if (!t2.isInstanceOf[AtomicType]) t2 = t2.getAtomizedItemType
      var resultType = calculator.getResultType(t1.getPrimitiveItemType.asInstanceOf[AtomicType], t2.getPrimitiveItemType.asInstanceOf[AtomicType])
      if (resultType == BuiltInAtomicType.ANY_ATOMIC) { // there are a few special cases where we can do better. For example, given X+1, where the type of X
        // is unknown, we can still infer that the result is numeric. (Not so for X*2, however, where it could
        // be a duration)
        val th = getConfiguration.getTypeHierarchy
        if ((operator == Token.PLUS || operator == Token.MINUS) && (NumericType.isNumericType(t2) || NumericType.isNumericType(t1))) resultType = NumericType.getInstance
      }
      itemType = resultType
    }
  }

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType static information about the context item
   */
  override def getStaticUType(contextItemType: UType) = { // The rationale for this is in the XSLT 3.0 spec
    if (getParentExpression.isInstanceOf[FilterExpression] && (getParentExpression.asInstanceOf[FilterExpression].getRhsExpression eq this)) UType.NUMERIC
    else if (operator == Token.NEGATE) UType.NUMERIC
    else UType.ANY_ATOMIC
  }

  /**
   * Reset the static properties of the expression to -1, so that they have to be recomputed
   * next time they are used.
   */
  override def resetLocalStaticProperties() = {
    super.resetLocalStaticProperties()
    itemType = null
  }

  /**
   * Evaluate the expression.
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext): AtomicValue = {
    val v0 = getLhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
    if (v0 == null) return null
    val v1 = getRhsExpression.evaluateItem(context).asInstanceOf[AtomicValue]
    if (v1 == null) return null
    try calculator.compute(v0, v1, context)
    catch {
      case e: XPathException =>
        e.maybeSetLocation(getLocation)
        e.maybeSetFailingExpression(this)
        e.maybeSetContext(context)
        throw e
    }
  }

  override protected def tag = "arith"

  override protected def explainExtraAttributes(out: ExpressionPresenter) = if (calculator != null) { // May be null during optimizer tracing
    out.emitAttribute("calc", calculator.code)
  }
}