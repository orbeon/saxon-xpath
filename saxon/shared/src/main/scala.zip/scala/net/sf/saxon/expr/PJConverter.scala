////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.lib.ExternalObjectModel
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.ma.map.MapType
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.pattern.NodeTest
import net.sf.saxon.trans.SaxonErrorCode
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.wrapper.VirtualNode
import net.sf.saxon.value._
import java.lang.reflect.Array
import java.lang.reflect.Constructor
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.ParameterizedType
import java.math.BigDecimal
import java.math.BigInteger
import java.net.MalformedURLException
import java.net.URI
import java.net.URISyntaxException
import java.net.URL
import java.time._
import java.util

/**
 * This class together with its embedded subclasses handles conversion from XPath values
 * to Java values
 */
object PJConverter {
  private val jpmap = new util.HashMap[Class[_], SequenceType]

  /**
   * Get the nearest XPath equivalent to a Java class. A function call will
   * be type-checked against an XPath function signature in which the Java classes
   * are replaced by their nearest equivalent XPath types
   *
   * @param javaClass a Java class
   * @return the nearest equivalent XPath SequenceType
   */
  def getEquivalentSequenceType(javaClass: Class[_]): SequenceType = {
    if (javaClass.isArray) {
      val memberClass = javaClass.getComponentType
      if (memberClass eq classOf[Byte]) { // special-case byte[] which maps to xs:unsignedByte* - see bugs 3525, 3818
        return SequenceType.makeSequenceType(BuiltInAtomicType.UNSIGNED_BYTE, StaticProperty.ALLOWS_ZERO_OR_MORE)
      }
      else {
        val memberType = getEquivalentSequenceType(memberClass)
        if (memberType != null) return SequenceType.makeSequenceType(memberType.getPrimaryType, StaticProperty.ALLOWS_ZERO_OR_MORE)
      }
    }
    jpmap.get(javaClass)
  }

  /**
   * Get the nearest XPath equivalent to a Java parameterized type. The only parameterized
   * types we recognize are those like Sequence&lt;StringValue&gt; which correspond
   * exactly to an XPath SequenceType.
   *
   * @param javaType a parameterized Java class
   * @return the nearest equivalent XPath SequenceType
   */
  def getParameterizedSequenceType(javaType: Type): SequenceType = {
    if (javaType.isInstanceOf[ParameterizedType]) {
      val aType = javaType.asInstanceOf[ParameterizedType]
      val parameterArgTypes = aType.getActualTypeArguments
      if (parameterArgTypes.length == 1 && parameterArgTypes(0).isInstanceOf[Class[_]] && classOf[Item].isAssignableFrom(parameterArgTypes(0).asInstanceOf[Class[_]])) {
        val memberType = getEquivalentSequenceType(parameterArgTypes(0).asInstanceOf[Class[_]])
        val itemType = if (memberType == null) null
        else memberType.getPrimaryType
        val collectionType = aType.getRawType
        var cardinality = -1
        if (collectionType == classOf[ZeroOrOne[_ <: Item]]) cardinality = StaticProperty.ALLOWS_ZERO_OR_ONE
        else if (collectionType == classOf[One[_ <: Item]]) cardinality = StaticProperty.ALLOWS_ONE
        else if (collectionType == classOf[OneOrMore[_ <: Item]]) cardinality = StaticProperty.ALLOWS_ONE_OR_MORE
        else if (collectionType == classOf[ZeroOrMore[_ <: Item]]) cardinality = StaticProperty.ALLOWS_ZERO_OR_MORE
        if (itemType != null && cardinality != -1) return SequenceType.makeSequenceType(itemType, cardinality)
      }
    }
    null
  }

  /**
   * Factory method to instantiate a converter from a given XPath type to a given Java class
   *
   * @param config      the Saxon Configuration
   * @param itemType    the item type of the XPath value to be converted
   * @param cardinality the cardinality of the XPath value to be converted
   * @param targetClass the Java class required for the conversion result
   * @return a suitable converter
   * @throws net.sf.saxon.trans.XPathException
   * if no conversion is possible
   */
  @throws[XPathException]
  def allocate(config: Configuration, itemType: ItemType, cardinality: Int, targetClass: Class[_]): PJConverter = {
    val th = config.getTypeHierarchy
    if (targetClass eq classOf[SequenceIterator]) return ToSequenceIterator.INSTANCE
    if ((targetClass eq classOf[Sequence]) || (targetClass eq classOf[Item])) return Identity.INSTANCE
    if (targetClass eq classOf[One[_ <: Item]]) return ToOne.INSTANCE
    if (targetClass eq classOf[ZeroOrOne[_ <: Item]]) return ToZeroOrOne.INSTANCE
    if (targetClass eq classOf[OneOrMore[_ <: Item]]) return ToOneOrMore.INSTANCE
    if (targetClass eq classOf[ZeroOrMore[_ <: Item]]) return ToZeroOrMore.INSTANCE
    if ((targetClass eq classOf[GroundedValue]) | (targetClass eq classOf[SequenceExtent])) return ToSequenceExtent.INSTANCE
    if (!itemType.isPlainType) {
      val externalObjectModels = config.getExternalObjectModels
      import scala.collection.JavaConversions._
      for (model <- externalObjectModels) {
        val converter = model.getPJConverter(targetClass)
        if (converter != null) return converter
      }
      if (classOf[NodeInfo].isAssignableFrom(targetClass)) return Identity.INSTANCE
    }
    if (classOf[util.Collection[_]].isAssignableFrom(targetClass)) return ToCollection.INSTANCE
    if (targetClass.isArray) {
      val itemConverter = allocate(config, itemType, StaticProperty.EXACTLY_ONE, targetClass.getComponentType)
      return new PJConverter.ToArray(itemConverter)
    }
    if (!Cardinality.allowsMany(cardinality)) if (itemType.isPlainType) if (itemType eq ErrorType.getInstance) { // supplied value is (); we need to convert it to null; this converter does the job.
      StringValueToString.INSTANCE
    }
    else if (th.isSubType(itemType, BuiltInAtomicType.STRING)) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[String]) || (targetClass eq classOf[CharSequence])) StringValueToString.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[StringValue])) Identity.INSTANCE
    else if ((targetClass eq classOf[Char]) || (targetClass eq classOf[Character])) StringValueToChar.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (itemType eq BuiltInAtomicType.UNTYPED_ATOMIC) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[String]) || (targetClass eq classOf[CharSequence])) StringValueToString.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[UntypedAtomicValue])) Identity.INSTANCE
    else try {
      val constructor = targetClass.getConstructor(classOf[String])
      new PJConverter() {
        @throws[XPathException]
        override def convert(value: Sequence, targetClass: Class[_], context: XPathContext): Any = try return constructor.newInstance(value.head.getStringValue)
        catch {
          case e@(_: InstantiationException | _: IllegalAccessException) =>
            throw new XPathException(e)
          case e: InvocationTargetException =>
            throw new XPathException("Cannot convert untypedAtomic to " + targetClass.getName + ": " + e.getMessage, "FORG0001")
        }
      }
    } catch {
      case e: NoSuchMethodException =>
        throw cannotConvert(itemType, targetClass, config)
    }
    else if (th.isSubType(itemType, BuiltInAtomicType.BOOLEAN)) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[Boolean]) || (targetClass eq classOf[Boolean])) BooleanValueToBoolean.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[BooleanValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.INTEGER)) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[BigInteger])) IntegerValueToBigInteger.INSTANCE
    else if ((targetClass eq classOf[Long]) || (targetClass eq classOf[Long])) IntegerValueToLong.INSTANCE
    else if ((targetClass eq classOf[Int]) || (targetClass eq classOf[Integer])) IntegerValueToInt.INSTANCE
    else if ((targetClass eq classOf[Short]) || (targetClass eq classOf[Short])) IntegerValueToShort.INSTANCE
    else if ((targetClass eq classOf[Byte]) || (targetClass eq classOf[Byte])) IntegerValueToByte.INSTANCE
    else if ((targetClass eq classOf[Char]) || (targetClass eq classOf[Character])) IntegerValueToChar.INSTANCE
    else if ((targetClass eq classOf[Double]) || (targetClass eq classOf[Double])) NumericValueToDouble.INSTANCE
    else if ((targetClass eq classOf[Float]) || (targetClass eq classOf[Float])) NumericValueToFloat.INSTANCE
    else if (targetClass eq classOf[BigDecimal]) NumericValueToBigDecimal.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[IntegerValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.DECIMAL)) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[BigDecimal])) NumericValueToBigDecimal.INSTANCE
    else if ((targetClass eq classOf[Double]) || (targetClass eq classOf[Double])) NumericValueToDouble.INSTANCE
    else if ((targetClass eq classOf[Float]) || (targetClass eq classOf[Float])) NumericValueToFloat.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[BigDecimalValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.FLOAT)) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[Float]) || (targetClass eq classOf[Float])) NumericValueToFloat.INSTANCE
    else if ((targetClass eq classOf[Double]) || (targetClass eq classOf[Double])) NumericValueToDouble.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[FloatValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.DOUBLE)) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[Double]) || (targetClass eq classOf[Double])) NumericValueToDouble.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[DoubleValue])) Identity.INSTANCE
    else Atomic.INSTANCE
    else if (th.isSubType(itemType, BuiltInAtomicType.ANY_URI)) if ((targetClass eq classOf[Any]) || classOf[URI].isAssignableFrom(targetClass)) AnyURIValueToURI.INSTANCE
    else if (classOf[URL].isAssignableFrom(targetClass)) AnyURIValueToURL.INSTANCE
    else if ((targetClass eq classOf[String]) || (targetClass eq classOf[CharSequence])) StringValueToString.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[AnyURIValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.QNAME)) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[QName])) QualifiedNameValueToQName.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[QNameValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.NOTATION)) if ((targetClass eq classOf[Any]) || (targetClass eq classOf[QName])) QualifiedNameValueToQName.INSTANCE
    else if (targetClass.isAssignableFrom(classOf[NotationValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.DURATION)) if (targetClass.isAssignableFrom(classOf[DurationValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.DATE_TIME)) if (targetClass.isAssignableFrom(classOf[DateTimeValue])) Identity.INSTANCE
    else if (targetClass eq classOf[Date]) CalendarValueToDate.INSTANCE
    else if (targetClass eq classOf[Calendar]) CalendarValueToCalendar.INSTANCE
    else if (targetClass eq classOf[Instant]) CalendarValueToInstant.INSTANCE
    else if (targetClass eq classOf[ZonedDateTime]) CalendarValueToZonedDateTime.INSTANCE
    else if (targetClass eq classOf[LocalDateTime]) CalendarValueToLocalDateTime.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.DATE)) if (targetClass.isAssignableFrom(classOf[DateValue])) Identity.INSTANCE
    else if (targetClass eq classOf[Date]) CalendarValueToDate.INSTANCE
    else if (targetClass eq classOf[Calendar]) CalendarValueToCalendar.INSTANCE
    else if (targetClass eq classOf[Instant]) CalendarValueToInstant.INSTANCE
    else if (targetClass eq classOf[ZonedDateTime]) CalendarValueToZonedDateTime.INSTANCE
    else if (targetClass eq classOf[OffsetDateTime]) CalendarValueToOffsetDateTime.INSTANCE
    else if (targetClass eq classOf[LocalDateTime]) CalendarValueToLocalDateTime.INSTANCE
    else if (targetClass eq classOf[LocalDate]) DateValueToLocalDate.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.TIME)) if (targetClass.isAssignableFrom(classOf[TimeValue])) Identity.INSTANCE
    else if (targetClass eq classOf[Date]) CalendarValueToDate.INSTANCE
    else if (targetClass eq classOf[Calendar]) CalendarValueToCalendar.INSTANCE
    else if (targetClass eq classOf[Instant]) CalendarValueToInstant.INSTANCE
    else if (targetClass eq classOf[ZonedDateTime]) CalendarValueToZonedDateTime.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.G_YEAR)) if (targetClass.isAssignableFrom(classOf[GYearValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.G_YEAR_MONTH)) if (targetClass.isAssignableFrom(classOf[GYearMonthValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.G_MONTH)) if (targetClass.isAssignableFrom(classOf[GMonthValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.G_MONTH_DAY)) if (targetClass.isAssignableFrom(classOf[GMonthDayValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.G_DAY)) if (targetClass.isAssignableFrom(classOf[GDayValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.BASE64_BINARY)) if (targetClass.isAssignableFrom(classOf[Base64BinaryValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else if (th.isSubType(itemType, BuiltInAtomicType.HEX_BINARY)) if (targetClass.isAssignableFrom(classOf[HexBinaryValue])) Identity.INSTANCE
    else throw cannotConvert(itemType, targetClass, config)
    else Atomic.INSTANCE
    else if (itemType.isInstanceOf[JavaExternalObjectType]) UnwrapExternalObject.INSTANCE
    else if (itemType.isInstanceOf[ErrorType]) ToNull.INSTANCE
    else if (itemType.isInstanceOf[NodeTest]) if (classOf[NodeInfo].isAssignableFrom(targetClass)) Identity.INSTANCE
    else General.INSTANCE
    else { // ItemType is item()
      General.INSTANCE
    }
    else { // Cardinality allows many (but target type is not a collection)
      General.INSTANCE
    }
  }

  private def cannotConvert(source: ItemType, target: Class[_], config: Configuration) = new XPathException("Cannot convert from " + source + " to " + target.getName)

  /**
   * Static method to get a converter from an XPath sequence of nodes to the representation of a NodeList
   * in an external object model (this is really a special for DOM, which uses NodeList rather than general
   * purpose Java collection classes)
   *
   * @param config the Saxon configuration
   * @param node   an object representing a node in an external model
   * @return the Java object representing the external node
   */
  def allocateNodeListCreator(config: Configuration, node: Any): PJConverter = {
    val externalObjectModels = config.getExternalObjectModels
    import scala.collection.JavaConversions._
    for (model <- externalObjectModels) {
      val converter = model.getNodeListCreator(node)
      if (converter != null) return converter
    }
    ToCollection.INSTANCE
  }

  object ToSequenceIterator {
    val INSTANCE = new PJConverter.ToSequenceIterator
  }

  class ToSequenceIterator extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = value.iterate
  }

  object ToNull {
    val INSTANCE = new PJConverter.ToNull
  }

  class ToNull extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = null
  }

  object ToSequenceExtent {
    val INSTANCE = new PJConverter.ToSequenceExtent
  }

  class ToSequenceExtent extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = value.iterate.materialize
  }

  /**
   * Converter for use when the target class is a collection class. Also used when the target
   * class is Object
   */
  object ToCollection {
    val INSTANCE = new PJConverter.ToCollection
  }

  class ToCollection extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      var list = null
      if (targetClass.isAssignableFrom(classOf[util.ArrayList[_]])) list = new util.ArrayList[AnyRef](100)
      else try list = targetClass.newInstance.asInstanceOf[util.Collection[AnyRef]]
      catch {
        case e: InstantiationException =>
          val de = new XPathException("Cannot instantiate collection class " + targetClass)
          de.setXPathContext(context)
          throw de
        case e: IllegalAccessException =>
          val de = new XPathException("Cannot access collection class " + targetClass)
          de.setXPathContext(context)
          throw de
      }
      val config = context.getConfiguration
      val iter = value.iterate
      var it = null
      while ( {
        (it = iter.next) != null
      }) if (it.isInstanceOf[AtomicValue]) {
        val pj = allocate(config, it.asInstanceOf[AtomicValue].getItemType, StaticProperty.EXACTLY_ONE, classOf[Any])
        list.add(pj.convert(it, classOf[Any], context))
      }
      else if (it.isInstanceOf[VirtualNode]) list.add(it.asInstanceOf[VirtualNode].getRealNode)
      else list.add(it)
      list
    }
  }

  /**
   * Converter for use when the target class is an array
   */
  class ToArray(var itemConverter: PJConverter) extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext): Any = {
      if (value.isInstanceOf[ExternalObject[_]] && targetClass.isAssignableFrom(value.asInstanceOf[ExternalObject[_]].getObject.getClass)) return value.asInstanceOf[ExternalObject[_]].getObject
      val componentClass = targetClass.getComponentType
      val list = new util.ArrayList[AnyRef](20)
      val iter = value.iterate
      var item = null
      while ( {
        (item = iter.next) != null
      }) {
        val obj = itemConverter.convert(item, componentClass, context)
        if (obj != null) list.add(obj)
      }
      val array = Array.newInstance(componentClass, list.size)
      for (i <- 0 until list.size) {
        Array.set(array, i, list.get(i))
      }
      array
      //return list.toArray((Object[])array);
    }
  }

  /**
   * Converter for use when the target class is {@link One}, which constrains the value to be
   * a singleton
   */
  object ToOne {
    val INSTANCE = new PJConverter.ToOne
  }

  class ToOne extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = { // Assume all the type checking has already been done
      new One[_ <: Item](value.head)
    }
  }

  /**
   * Converter for use when the target class is {@link ZeroOrOne}, which constrains the value to be
   * a singleton or an empty sequence
   */
  object ToZeroOrOne {
    val INSTANCE = new PJConverter.ToZeroOrOne
  }

  class ToZeroOrOne extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = new ZeroOrOne[_ <: Item](value.head)
  }

  /**
   * Converter for use when the target class is {@link OneOrMore}, which constrains the value to be
   * a non-empty sequence
   */
  object ToOneOrMore {
    val INSTANCE = new PJConverter.ToOneOrMore
  }

  class ToOneOrMore extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = OneOrMore.makeOneOrMore(value)
  }

  /**
   * Converter for use when the target class is {@link ZeroOrMore}, which allows any sequence
   * but is a generic (parameterized) class so there is compile-time information about the type
   * of items
   */
  object ToZeroOrMore {
    val INSTANCE = new PJConverter.ToZeroOrMore
  }

  class ToZeroOrMore extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = new ZeroOrMore[Item](value.iterate)
  }

  object Identity {
    val INSTANCE = new PJConverter.Identity
  }

  class Identity extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext): Any = {
      if (value.isInstanceOf[Closure]) value = value.asInstanceOf[Closure].reduce
      if (value.isInstanceOf[ZeroOrOne[_ <: Item]]) value = value.asInstanceOf[ZeroOrOne[_]].head
      if (value.isInstanceOf[VirtualNode]) {
        val obj = value.asInstanceOf[VirtualNode].getRealNode
        if (targetClass.isAssignableFrom(obj.getClass)) return obj
      }
      if (targetClass.isAssignableFrom(value.getClass)) value
      else {
        var gv = value.materialize
        if (targetClass.isAssignableFrom(gv.getClass)) return gv
        gv = gv.reduce
        if (targetClass.isAssignableFrom(gv.getClass)) return gv
        if (gv.getLength == 0) null
        else throw new XPathException("Cannot convert value " + value.getClass + " of type " + SequenceTool.getItemType(value, context.getConfiguration.getTypeHierarchy) + " to class " + targetClass.getName)
      }
    }
  }

  object UnwrapExternalObject {
    val INSTANCE = new PJConverter.UnwrapExternalObject
  }

  class UnwrapExternalObject extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext): Any = {
      var head = value.head
      if (head == null) return null
      if (!head.isInstanceOf[ExternalObject[_]]) if (classOf[Sequence].isAssignableFrom(targetClass)) head = new ObjectValue[Sequence](value)
      else throw new XPathException("Expected external object of class " + targetClass.getName + ", got " + head.getClass)
      val obj = head.asInstanceOf[ExternalObject[_]].getObject
      if (!targetClass.isAssignableFrom(obj.getClass)) throw new XPathException("External object has wrong class (is " + obj.getClass.getName + ", expected " + targetClass.getName + ")")
      obj
    }
  }

  object StringValueToString {
    val INSTANCE = new PJConverter.StringValueToString
  }

  class StringValueToString extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val first = value.head
      if (first == null) null
      else first.getStringValue
    }
  }

  object StringValueToChar {
    val INSTANCE = new PJConverter.StringValueToChar
  }

  class StringValueToChar extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext): Any = {
      val first = value.head
      if (first == null) return null
      val str = first.getStringValue
      if (str.length == 1) str.charAt(0)
      else {
        val de = new XPathException("Cannot convert xs:string to Java char unless length is 1")
        de.setXPathContext(context)
        de.setErrorCode(SaxonErrorCode.SXJE0005)
        throw de
      }
    }
  }

  object BooleanValueToBoolean {
    val INSTANCE = new PJConverter.BooleanValueToBoolean
  }

  class BooleanValueToBoolean extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val bv = value.head.asInstanceOf[BooleanValue]
      assert(bv != null)
      bv.getBooleanValue
    }
  }

  object IntegerValueToBigInteger {
    val INSTANCE = new PJConverter.IntegerValueToBigInteger
  }

  class IntegerValueToBigInteger extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val `val` = value.head.asInstanceOf[IntegerValue]
      if (`val` == null) null
      else `val`.asBigInteger
    }
  }

  object IntegerValueToLong {
    val INSTANCE = new PJConverter.IntegerValueToLong
  }

  class IntegerValueToLong extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val iv = value.head.asInstanceOf[IntegerValue]
      assert(iv != null)
      iv.longValue
    }
  }

  object IntegerValueToInt {
    val INSTANCE = new PJConverter.IntegerValueToInt
  }

  class IntegerValueToInt extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val iv = value.head.asInstanceOf[IntegerValue]
      assert(iv != null)
      iv.longValue.toInt
    }
  }

  object IntegerValueToShort {
    val INSTANCE = new PJConverter.IntegerValueToShort
  }

  class IntegerValueToShort extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val iv = value.head.asInstanceOf[IntegerValue]
      assert(iv != null)
      iv.longValue.toShort
    }
  }

  object IntegerValueToByte {
    val INSTANCE = new PJConverter.IntegerValueToByte
  }

  class IntegerValueToByte extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val iv = value.head.asInstanceOf[IntegerValue]
      assert(iv != null)
      iv.longValue.toByte
    }
  }

  object IntegerValueToChar {
    val INSTANCE = new PJConverter.IntegerValueToChar
  }

  class IntegerValueToChar extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val iv = value.head.asInstanceOf[IntegerValue]
      assert(iv != null)
      iv.longValue.toChar
    }
  }

  object NumericValueToBigDecimal {
    val INSTANCE = new PJConverter.NumericValueToBigDecimal
  }

  class NumericValueToBigDecimal extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val nv = value.head.asInstanceOf[NumericValue]
      if (nv == null) null
      else nv.getDecimalValue
    }
  }

  object NumericValueToDouble {
    val INSTANCE = new PJConverter.NumericValueToDouble
  }

  class NumericValueToDouble extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val nv = value.head.asInstanceOf[NumericValue]
      assert(nv != null)
      nv.getDoubleValue
    }
  }

  object NumericValueToFloat {
    val INSTANCE = new PJConverter.NumericValueToFloat
  }

  class NumericValueToFloat extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val nv = value.head.asInstanceOf[NumericValue]
      assert(nv != null)
      nv.getFloatValue
    }
  }

  object AnyURIValueToURI {
    val INSTANCE = new PJConverter.AnyURIValueToURI
  }

  class AnyURIValueToURI extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val av = value.head.asInstanceOf[AnyURIValue]
      try if (av == null) null
      else new URI(value.asInstanceOf[AnyURIValue].getStringValue)
      catch {
        case err: URISyntaxException =>
          throw new XPathException("The anyURI value '" + value + "' is not an acceptable Java URI")
      }
    }
  }

  object AnyURIValueToURL {
    val INSTANCE = new PJConverter.AnyURIValueToURL
  }

  class AnyURIValueToURL extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val av = value.head.asInstanceOf[AnyURIValue]
      try if (av == null) null
      else new URL(value.asInstanceOf[AnyURIValue].getStringValue)
      catch {
        case err: MalformedURLException =>
          throw new XPathException("The anyURI value '" + value + "' is not an acceptable Java URL")
      }
    }
  }

  object QualifiedNameValueToQName {
    val INSTANCE = new PJConverter.QualifiedNameValueToQName
  }

  class QualifiedNameValueToQName extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val qv = value.head.asInstanceOf[QualifiedNameValue]
      if (qv == null) null
      else qv.toJaxpQName
    }
  }

  object CalendarValueToInstant {
    val INSTANCE = new PJConverter.CalendarValueToInstant
  }

  class CalendarValueToInstant extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val cv = value.head.asInstanceOf[CalendarValue]
      if (cv == null) null
      else cv.toDateTime.toJavaInstant
    }
  }

  object CalendarValueToZonedDateTime {
    val INSTANCE = new PJConverter.CalendarValueToZonedDateTime
  }

  class CalendarValueToZonedDateTime extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val cv = value.head.asInstanceOf[CalendarValue]
      if (cv == null) null
      else cv.toDateTime.toZonedDateTime
    }
  }

  object CalendarValueToOffsetDateTime {
    val INSTANCE = new PJConverter.CalendarValueToOffsetDateTime
  }

  class CalendarValueToOffsetDateTime extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val cv = value.head.asInstanceOf[CalendarValue]
      if (cv == null) null
      else cv.toDateTime.toOffsetDateTime
    }
  }

  object CalendarValueToLocalDateTime {
    val INSTANCE = new PJConverter.CalendarValueToLocalDateTime
  }

  class CalendarValueToLocalDateTime extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val cv = value.head.asInstanceOf[CalendarValue]
      if (cv == null) null
      else cv.toDateTime.toLocalDateTime
    }
  }

  object CalendarValueToDate {
    val INSTANCE = new PJConverter.CalendarValueToDate
  }

  class CalendarValueToDate extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val cv = value.head.asInstanceOf[CalendarValue]
      if (cv == null) null
      else cv.getCalendar.getTime
    }
  }

  object DateValueToLocalDate {
    val INSTANCE = new PJConverter.DateValueToLocalDate
  }

  class DateValueToLocalDate extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val cv = value.head.asInstanceOf[DateValue]
      if (cv == null) null
      else cv.toLocalDate
    }
  }

  object CalendarValueToCalendar {
    val INSTANCE = new PJConverter.CalendarValueToCalendar
  }

  class CalendarValueToCalendar extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val cv = value.head.asInstanceOf[CalendarValue]
      if (cv == null) null
      else cv.getCalendar
    }
  }

  /**
   * Converter for use when the source object is an atomic value, but nothing more is known
   * statically.
   */
  object Atomic {
    val INSTANCE = new PJConverter.Atomic
  }

  class Atomic extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext): Any = { // TODO: not really worth separating from General
      val item = value.head.asInstanceOf[AtomicValue]
      if (item == null) return null
      val config = context.getConfiguration
      val converter = allocate(config, item.getItemType, StaticProperty.EXACTLY_ONE, targetClass)
      converter.convert(item, targetClass, context)
    }
  }

  /**
   * General-purpose converter when nothing more specific is available.
   * (Provided largely as a transition aid)
   */
  object General {
    val INSTANCE = new PJConverter.General
  }

  class General extends PJConverter {
    @throws[XPathException]
    override def convert(value: Sequence, targetClass: Class[_], context: XPathContext) = {
      val config = context.getConfiguration
      val gv = value.materialize
      var converter = allocate(config, SequenceTool.getItemType(gv, config.getTypeHierarchy), SequenceTool.getCardinality(gv), targetClass)
      if (converter.isInstanceOf[PJConverter.General]) converter = Identity.INSTANCE
      converter.convert(gv, targetClass, context)
    }
  }

  try jpmap.put(classOf[Boolean], SequenceType.SINGLE_BOOLEAN)
  jpmap.put(classOf[Boolean], SequenceType.OPTIONAL_BOOLEAN)
  jpmap.put(classOf[String], SequenceType.OPTIONAL_STRING)
  jpmap.put(classOf[CharSequence], SequenceType.OPTIONAL_STRING)
  // Mappings for long and int are chosen to avoid static type errors when
  // a Java method expecting long or int is called with an integer literal
  jpmap.put(classOf[Long], SequenceType.SINGLE_INTEGER)
  jpmap.put(classOf[Long], SequenceType.OPTIONAL_INTEGER)
  jpmap.put(classOf[Int], SequenceType.SINGLE_INTEGER)
  jpmap.put(classOf[Integer], SequenceType.OPTIONAL_INTEGER)
  jpmap.put(classOf[Short], SequenceType.SINGLE_SHORT)
  jpmap.put(classOf[Short], SequenceType.OPTIONAL_SHORT)
  jpmap.put(classOf[Byte], SequenceType.SINGLE_BYTE)
  jpmap.put(classOf[Byte], SequenceType.OPTIONAL_BYTE)
  jpmap.put(classOf[Float], SequenceType.SINGLE_FLOAT)
  jpmap.put(classOf[Float], SequenceType.OPTIONAL_FLOAT)
  jpmap.put(classOf[Double], SequenceType.SINGLE_DOUBLE)
  jpmap.put(classOf[Double], SequenceType.OPTIONAL_DOUBLE)
  jpmap.put(classOf[URI], SequenceType.OPTIONAL_ANY_URI)
  jpmap.put(classOf[URL], SequenceType.OPTIONAL_ANY_URI)
  jpmap.put(classOf[BigInteger], SequenceType.OPTIONAL_INTEGER)
  jpmap.put(classOf[BigDecimal], SequenceType.OPTIONAL_DECIMAL)
  jpmap.put(classOf[StringValue], SequenceType.OPTIONAL_STRING)
  jpmap.put(classOf[BooleanValue], SequenceType.OPTIONAL_BOOLEAN)
  jpmap.put(classOf[DoubleValue], SequenceType.OPTIONAL_DOUBLE)
  jpmap.put(classOf[FloatValue], SequenceType.OPTIONAL_FLOAT)
  jpmap.put(classOf[DecimalValue], SequenceType.OPTIONAL_DECIMAL)
  jpmap.put(classOf[IntegerValue], SequenceType.OPTIONAL_INTEGER)
  jpmap.put(classOf[AnyURIValue], SequenceType.OPTIONAL_ANY_URI)
  jpmap.put(classOf[QNameValue], SequenceType.OPTIONAL_QNAME)
  jpmap.put(classOf[NotationValue], SequenceType.OPTIONAL_NOTATION)
  jpmap.put(classOf[DateValue], SequenceType.OPTIONAL_DATE)
  jpmap.put(classOf[DateTimeValue], SequenceType.OPTIONAL_DATE_TIME)
  jpmap.put(classOf[TimeValue], SequenceType.OPTIONAL_TIME)
  jpmap.put(classOf[DurationValue], SequenceType.OPTIONAL_DURATION)
  jpmap.put(classOf[DayTimeDurationValue], SequenceType.OPTIONAL_DAY_TIME_DURATION)
  jpmap.put(classOf[YearMonthDurationValue], SequenceType.OPTIONAL_YEAR_MONTH_DURATION)
  jpmap.put(classOf[GYearValue], SequenceType.OPTIONAL_G_YEAR)
  jpmap.put(classOf[GYearMonthValue], SequenceType.OPTIONAL_G_YEAR_MONTH)
  jpmap.put(classOf[GMonthValue], SequenceType.OPTIONAL_G_MONTH)
  jpmap.put(classOf[GMonthDayValue], SequenceType.OPTIONAL_G_MONTH_DAY)
  jpmap.put(classOf[GDayValue], SequenceType.OPTIONAL_G_DAY)
  jpmap.put(classOf[Base64BinaryValue], SequenceType.OPTIONAL_BASE64_BINARY)
  jpmap.put(classOf[HexBinaryValue], SequenceType.OPTIONAL_HEX_BINARY)
  jpmap.put(classOf[Function], SequenceType.OPTIONAL_FUNCTION_ITEM)
  jpmap.put(classOf[MapItem], MapType.OPTIONAL_MAP_ITEM)
  jpmap.put(classOf[NodeInfo], SequenceType.OPTIONAL_NODE)
  jpmap.put(classOf[TreeInfo], SequenceType.OPTIONAL_DOCUMENT_NODE)
}

abstract class PJConverter {
  /**
   * Convert an XPath value to a Java value of a specified class
   *
   * @param value       the supplied XPath value
   * @param targetClass the class of the required Java value
   * @param context     the XPath dynamic context
   * @return the corresponding Java value, which is guaranteed to be an instance of the
   *         target class (except that an empty sequence is converted to null)
   * @throws XPathException if the conversion is not possible or fails
   */
    /*@Nullable*/ @throws[XPathException]
    def convert(value: Sequence, targetClass: Class[_], context: XPathContext)
}