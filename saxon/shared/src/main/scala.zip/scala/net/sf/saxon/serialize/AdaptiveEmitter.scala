////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.event.ReceiverWithOutputProperties
import net.sf.saxon.event.SequenceWriter
import net.sf.saxon.functions.FormatNumber
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.ma.arrays.ArrayItem
import net.sf.saxon.ma.map.KeyValuePair
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.query.QueryResult
import net.sf.saxon.serialize.codenorm.Normalizer
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.DoubleValue
import net.sf.saxon.value.QualifiedNameValue
import javax.xml.transform.stream.StreamResult
import java.io.IOException
import java.io.StringWriter
import java.io.Writer
import java.util.Properties

/**
 * This class implements the Adaptive serialization method defined in XSLT+XQuery Serialization 3.1.
 */
class AdaptiveEmitter(val pipe: PipelineConfiguration, var writer: Writer) extends SequenceWriter(pipe) with ReceiverWithOutputProperties {
  private var characterMap = null
  private var outputProperties = null
  private var itemSeparator = "\n"
  private var started = false

  def setOutputProperties(props: Properties) = {
    outputProperties = props
    val sep = props.getProperty(SaxonOutputKeys.ITEM_SEPARATOR)
    if (sep != null && !("#absent" == sep)) itemSeparator = sep
  }

  /**
   * Set the Unicode normalizer to be used for normalizing strings.
   *
   * @param normalizer the normalizer to be used
   */
  def setNormalizer(normalizer: Normalizer) = {
  }

  /**
   * Set the CharacterMap to be used, if any
   *
   * @param map the character map
   */
  def setCharacterMap(map: CharacterMap) = this.characterMap = map

  override def getOutputProperties = outputProperties

  @throws[XPathException]
  private def emit(s: CharSequence) = try writer.append(s)
  catch {
    case e: IOException =>
      throw new XPathException(e)
  }

  /**
   * Abstract method to be supplied by subclasses: output one item in the sequence.
   *
   * @param item the item to be written to the sequence
   * @throws XPathException if any failure occurs while writing the item
   */
  @throws[XPathException]
  override def write(item: Item) = {
    if (started) emit(itemSeparator)
    else {
      if (writer == null) {
      }
      started = true
    }
    serializeItem(item)
  }

  @throws[XPathException]
  private def serializeItem(item: Item) = if (item.isInstanceOf[AtomicValue]) emit(serializeAtomicValue(item.asInstanceOf[AtomicValue]))
  else if (item.isInstanceOf[NodeInfo]) serializeNode(item.asInstanceOf[NodeInfo])
  else if (item.isInstanceOf[MapItem]) serializeMap(item.asInstanceOf[MapItem])
  else if (item.isInstanceOf[ArrayItem]) serializeArray(item.asInstanceOf[ArrayItem])
  else if (item.isInstanceOf[Function]) serializeFunction(item.asInstanceOf[Function])

  @throws[XPathException]
  private def serializeAtomicValue(value: AtomicValue) = value.getPrimitiveType.getFingerprint match {
    case StandardNames.XS_STRING =>
    case StandardNames.XS_ANY_URI =>
    case StandardNames.XS_UNTYPED_ATOMIC =>
      var s = value.getStringValue
      if (s.contains("\"")) s = s.replace("\"", "\"\"")
      if (characterMap != null) s = characterMap.map(s, false).toString
      "\"" + s + "\""
    case StandardNames.XS_BOOLEAN =>
      if (value.effectiveBooleanValue) "true()"
      else "false()"
    case StandardNames.XS_DECIMAL =>
    case StandardNames.XS_INTEGER =>
      value.getStringValue
    case StandardNames.XS_DOUBLE =>
      FormatNumber.formatExponential(value.asInstanceOf[DoubleValue])
    case StandardNames.XS_FLOAT =>
    case StandardNames.XS_DURATION =>
    case StandardNames.XS_DATE_TIME =>
    case StandardNames.XS_DATE =>
    case StandardNames.XS_TIME =>
    case StandardNames.XS_G_YEAR_MONTH =>
    case StandardNames.XS_G_MONTH =>
    case StandardNames.XS_G_MONTH_DAY =>
    case StandardNames.XS_G_YEAR =>
    case StandardNames.XS_G_DAY =>
    case StandardNames.XS_HEX_BINARY =>
    case StandardNames.XS_BASE64_BINARY =>
      value.getPrimitiveType.getDisplayName + "(\"" + value.getStringValue + "\")"
    case StandardNames.XS_DAY_TIME_DURATION =>
    case StandardNames.XS_YEAR_MONTH_DURATION =>
      "xs:duration(\"" + value.getStringValue + "\")"
    case StandardNames.XS_QNAME =>
    case StandardNames.XS_NOTATION =>
      value.asInstanceOf[QualifiedNameValue].getStructuredQName.getEQName
    case _ =>
      "***"
  }

  @throws[XPathException]
  private def serializeFunction(fn: Function) = {
    val fname = fn.getFunctionName
    if (fname == null || fname.hasURI(NamespaceConstant.ANONYMOUS)) emit("(anonymous-function)")
    else if (fname.hasURI(NamespaceConstant.FN)) emit("fn:" + fname.getLocalPart)
    else if (fname.hasURI(NamespaceConstant.MATH)) emit("math:" + fname.getLocalPart)
    else if (fname.hasURI(NamespaceConstant.MAP_FUNCTIONS)) emit("map:" + fname.getLocalPart)
    else if (fname.hasURI(NamespaceConstant.ARRAY_FUNCTIONS)) emit("array:" + fname.getLocalPart)
    else if (fname.hasURI(NamespaceConstant.SCHEMA)) emit("xs:" + fname.getLocalPart)
    else emit(fname.getEQName)
    emit("#" + fn.getArity)
  }

  @throws[XPathException]
  private def serializeNode(node: NodeInfo) = node.getNodeKind match {
    case Type.ATTRIBUTE =>
      emit(node.getDisplayName)
      emit("=\"")
      emit(node.getStringValueCS)
      emit("\"")
    case Type.NAMESPACE =>
      emit(if (node.getLocalPart.isEmpty) "xmlns"
      else "xmlns:" + node.getLocalPart)
      emit("=\"")
      emit(node.getStringValueCS)
      emit("\"")
    case _ =>
      val sw = new StringWriter
      val props = new Properties(outputProperties)
      var nodeMethod = outputProperties.getProperty(SaxonOutputKeys.JSON_NODE_OUTPUT_METHOD)
      if (nodeMethod == null) nodeMethod = "xml"
      props.setProperty("method", nodeMethod)
      props.setProperty("indent", "no")
      props.setProperty("omit-xml-declaration", "yes")
      props.setProperty(SaxonOutputKeys.UNFAILING, "yes")
      var cmi = null
      if (characterMap != null) {
        cmi = new CharacterMapIndex
        cmi.putCharacterMap(characterMap.getName, characterMap)
      }
      val sProps = new SerializationProperties(props, cmi)
      QueryResult.serialize(node, new StreamResult(sw), sProps)
      emit(sw.toString.trim)
  }

  @throws[XPathException]
  private def serializeArray(array: ArrayItem) = {
    emit("[")
    var first = true
    import scala.collection.JavaConversions._
    for (seq <- array.members) {
      if (first) first = false
      else emit(",")
      outputInternalSequence(seq)
    }
    emit("]")
  }

  @throws[XPathException]
  private def serializeMap(map: MapItem) = {
    emit("map{")
    var first = true
    import scala.collection.JavaConversions._
    for (pair <- map.keyValuePairs) {
      if (first) first = false
      else emit(",")
      serializeItem(pair.key)
      emit(":")
      val value = pair.value
      outputInternalSequence(value)
    }
    emit("}")
  }

  @throws[XPathException]
  private def outputInternalSequence(value: Sequence) = {
    var first = true
    var it = null
    val iter = value.iterate
    val omitParens = value.isInstanceOf[GroundedValue] && value.asInstanceOf[GroundedValue].getLength == 1
    if (!omitParens) emit("(")
    while ( {
      (it = iter.next) != null
    }) {
      if (!first) emit(",")
      first = false
      serializeItem(it)
    }
    if (!omitParens) emit(")")
  }

  @throws[XPathException]
  override def close() = {
    super.close()
    if (writer != null) try writer.close()
    catch {
      case e: IOException =>
        throw new XPathException(e)
    }
  }
}