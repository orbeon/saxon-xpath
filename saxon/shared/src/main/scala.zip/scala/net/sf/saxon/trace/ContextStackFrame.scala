////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.expr.XPathContext
import net.sf.saxon.expr.instruct._
import net.sf.saxon.lib.Logger
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.ma.arrays.ArrayItem
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.om.Function
import net.sf.saxon.om.Item
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.KeyDefinition
import net.sf.saxon.tree.util.Navigator
import net.sf.saxon.value.AtomicValue

/**
 * An entry on the context stack. A new entry is created every time the context changes. This is a
 * representation of the stack created on request; it does not hold live data.
 */
object ContextStackFrame {

  /**
   * Subclass of ContextStackFrame representing the outermost stack frame,
   * for the calling application
   */
  class CallingApplication extends ContextStackFrame {
    override def print(out: Logger) = {
      //out.println("  (called from external application)");
    }
  }

  /**
   * Subclass of ContextStackFrame representing a built-in template rule in XSLT
   */
  class BuiltInTemplateRule(var context: XPathContext) extends ContextStackFrame {
    override def print(out: Logger) = {
      val contextItem = context.getContextItem
      var diag = null
      if (contextItem.isInstanceOf[NodeInfo]) diag = Navigator.getPath(contextItem.asInstanceOf[NodeInfo])
      else if (contextItem.isInstanceOf[AtomicValue]) diag = "value " + contextItem.toString
      else if (contextItem.isInstanceOf[MapItem]) diag = "map"
      else if (contextItem.isInstanceOf[ArrayItem]) diag = "array"
      else if (contextItem.isInstanceOf[Function]) diag = "function"
      else diag = "item"
      out.error("  in built-in template rule for " + diag + " in " + context.getCurrentMode.getActor.getModeTitle.toLowerCase)
    }
  }

  /**
   * Subclass of ContextStackFrame representing a call to a user-defined function
   * either in XSLT or XQuery
   */
  class FunctionCall extends ContextStackFrame {
    private[trace] var functionName = null

    /**
     * Get the name of the function being called
     *
     * @return the name of the function being called
     */
    def getFunctionName = functionName

    /**
     * Set the name of the function being called
     *
     * @param functionName the name of the function being called
     */
    def setFunctionName(functionName: StructuredQName) = this.functionName = functionName

    /**
     * Display a representation of the stack frame on the specified output stream
     *
     * @param out the output stream
     */
    override def print(out: Logger) = out.error("  at " + (if (functionName == null) "(anonymous)"
    else functionName.getDisplayName) + "() " + showLocation)
  }

  /**
   * Subclass of ContextStackFrame representing an xsl:apply-templates call in XSLT
   */
  class ApplyTemplates extends ContextStackFrame {
    override def print(out: Logger) = {
      out.error("  at xsl:apply-templates " + showLocation)
      val node = getContextItem
      if (node.isInstanceOf[NodeInfo]) out.error("     processing " + Navigator.getPath(node.asInstanceOf[NodeInfo]))
    }
  }

  /**
   * Subclass of ContextStackFrame representing an xsl:call-template instruction in XSLT
   */
  class CallTemplate extends ContextStackFrame {
    /**
     * Get the name of the template being called
     *
     * @return the name of the template being called. Note this may be null in the case of the
     *         extension instruction saxon:call-template
     */
      def getTemplateName = templateName

    /**
     * Set the name of the template being called
     *
     * @param templateName the name of the template being called.
     */
    def setTemplateName(templateName: StructuredQName) = this.templateName = templateName

    private[trace] var templateName = null

    override def print(out: Logger) = {
      val name = if (templateName == null) "??"
      else templateName.getDisplayName
      out.error("  at xsl:call-template name=\"" + name + "\" " + showLocation)
    }
  }

  /**
   * Subclass of ContextStackFrame representing the evaluation of a variable (typically a global variable)
   */
  class VariableEvaluation extends ContextStackFrame {
    /**
     * Get the name of the variable
     *
     * @return the name of the variable
     */
      def getVariableName = variableName

    /**
     * Set the name of the variable
     *
     * @param variableName the name of the variable
     */
    def setVariableName(variableName: StructuredQName) = this.variableName = variableName

    private[trace] var variableName = null

    override def print(out: Logger) = out.error("  in " + displayContainer(getContainer) + " " + showLocation)
  }

  private def displayContainer(/*@NotNull*/ container: Any): String = {
    if (container.isInstanceOf[Actor]) {
      val name = container.asInstanceOf[Actor].getComponentName
      val objectName = if (name == null) ""
      else name.getDisplayName
      if (container.isInstanceOf[NamedTemplate]) return "template name=\"" + objectName + "\""
      else if (container.isInstanceOf[UserFunction]) return "function " + objectName + "()"
      else if (container.isInstanceOf[AttributeSet]) return "attribute-set " + objectName
      else if (container.isInstanceOf[KeyDefinition]) return "key " + objectName
      else if (container.isInstanceOf[GlobalVariable]) {
        val qName = container.asInstanceOf[GlobalVariable].getVariableQName
        if (qName.hasURI(NamespaceConstant.SAXON_GENERATED_VARIABLE)) return "optimizer-created global variable"
        else return "global variable $" + qName.getDisplayName
      }
    }
    else if (container.isInstanceOf[TemplateRule]) return "template match=\"" + container.asInstanceOf[TemplateRule].getMatchPattern.toString + "\""
    ""
  }
}

abstract class ContextStackFrame {
  private var context = null
  private var location = null
  private var contextItem = null
  private var container = null

  /**
   * Set the location of the instruction that caused this new context
   * to be created
   *
   * @param loc the location of the instruction
   */
  def setLocation(loc: Location) = this.location = loc

  /**
   * Get the system ID representing the location of the instruction that caused this new context
   * to be created
   *
   * @return the system ID (base URI/module URI) of the module containing the instruction
   */
  def getSystemId = location.getSystemId

  /**
   * Get the line number of the location of the instruction that caused this new context
   * to be created
   *
   * @return the line number of the instruction within its containing module
   */
  def getLineNumber = location.getLineNumber

  /**
   * Set the container of the instruction that caused this new context to be created. This will
   * generally be an object such as an XSLT Template or a user-defined function
   *
   * @param container the container of the instruction
   */
  def setComponent(container: Any) = this.container = container

  /**
   * Get the container of the instruction that caused this new context to be created. This will
   * generally be an object such as an XSLT Template or a user-defined function
   *
   * @return the container of the instruction in the expression tree
   */
  def getContainer = container

  /**
   * Set the value of the context at this level of the context stack
   *
   * @param context the context as it was when this new context was created
   */
  def setContext(context: XPathContext) = this.context = context

  /**
   * Get the value of the context at this level of the context stack
   *
   * @return the context as it was when this new context was created
   */
  def getContext = context

  /**
   * Set the value of the context item at this level of the context stack
   *
   * @param contextItem the context item as it was when this new context was created
   */
  def setContextItem(contextItem: Item) = this.contextItem = contextItem

  /**
   * Get the value of the context item at this level of the context stack
   *
   * @return the context item as it was when this new context was created
   */
  def getContextItem = contextItem

  /**
   * Display a representation of the stack frame on the specified output stream
   *
   * @param out the output stream
   */
  def print(out: Logger)

  /**
   * Show the location of a call (for use by subclasses)
   *
   * @return typically "(" + systemId() + "#" + lineNumber() + ")"
   */
  protected def showLocation: String = {
    if (getSystemId == null) return ""
    val line = getLineNumber
    if (line == -1 || line == 0xfffff) "(" + getSystemId + ")"
    else "(" + getSystemId + "#" + getLineNumber + ")"
  }
}