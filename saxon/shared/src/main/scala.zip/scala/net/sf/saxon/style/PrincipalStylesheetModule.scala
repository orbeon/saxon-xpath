////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.expr.Component
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.accum.Accumulator
import net.sf.saxon.expr.accum.AccumulatorRegistry
import net.sf.saxon.expr.instruct._
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.Optimizer
import net.sf.saxon.expr.parser.OptimizerOptions
import net.sf.saxon.functions.DocumentFn
import net.sf.saxon.functions.ExecutableFunctionLibrary
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.pattern.NameTest
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.query.XQueryFunction
import net.sf.saxon.query.XQueryFunctionLibrary
import net.sf.saxon.s9api.HostLanguage
import net.sf.saxon.serialize.CharacterMap
import net.sf.saxon.serialize.CharacterMapIndex
import net.sf.saxon.trans.Timer
import net.sf.saxon.trans._
import net.sf.saxon.trans.rules.RuleManager
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.tree.linked.DocumentImpl
import net.sf.saxon.value.Whitespace
import net.sf.saxon.z.IntHashMap
import javax.xml.transform.URIResolver
import java.util._

/**
 * Represents both the stylesheet module at the root of the import tree, that is, the module
 * that includes or imports all the others, and also the XSLT package that has this stylesheet
 * module as its root.
 * <p>This version of the StylesheetPackage class represents a trivial package that is constructed
 * by the system to wrap an ordinary (non-package) stylesheet, as available in XSLT 2.0. A subclass
 * is used for "real" packages, currently available only in Saxon-EE.</p>
 */
object PrincipalStylesheetModule {
  @throws[XPathException]
  private def gatherUsePackageDeclarations(compilation: Compilation, wrapper: StyleElement, declarations: util.List[XSLUsePackage]) = {
    import scala.collection.JavaConversions._
    for (use <- wrapper.children) {
      if (use.isInstanceOf[XSLUsePackage]) declarations.add(use.asInstanceOf[XSLUsePackage])
      else if (use.isInstanceOf[XSLInclude]) {
        val href = Whitespace.trim(use.getAttributeValue("", "href"))
        val resolver = compilation.getCompilerInfo.getURIResolver
        val key = DocumentFn.computeDocumentKey(href, use.getBaseURI, compilation.getPackageData, resolver, false)
        val includedTree = compilation.getStylesheetModules.get(key)
        val incWrapper = includedTree.getRootNode.asInstanceOf[DocumentImpl].getDocumentElement.asInstanceOf[StyleElement]
        gatherUsePackageDeclarations(compilation, incWrapper, declarations)
      }
    }
  }

  @throws[XPathException]
  private def setLocalParamDetails(source: XSLTemplate, nt: NamedTemplate) = {
    val kids = source.iterateAxis(AxisInfo.CHILD, NodeKindTest.ELEMENT)
    val details = new util.ArrayList[NamedTemplate.LocalParamInfo]
    kids.forEachOrFail((child: Item) => {
      def foo(child: Item) =
        if (child.isInstanceOf[XSLLocalParam]) {
          val lp = child.asInstanceOf[XSLLocalParam]
          lp.prepareTemplateSignatureAttributes()
          val info = new NamedTemplate.LocalParamInfo
          info.name = lp.getVariableQName
          info.requiredType = lp.getRequiredType
          info.isRequired = lp.isRequiredParam
          info.isTunnel = lp.isTunnelParam
          details.add(info)
        }

      foo(child)
    })
    nt.setLocalParamDetails(details)
  }
}

class PrincipalStylesheetModule @throws[XPathException]
(val sourceElement: XSLPackage)

/**
 * Create a PrincipalStylesheetModule
 *
 * @param sourceElement the xsl:package element at the root of the package manifest
 */
  extends StylesheetModule(sourceElement, 0) with GlobalVariableManager {
  declaredModes = sourceElement.isDeclaredModes
  stylesheetPackage = getConfiguration.makeStylesheetPackage
  val compilerInfo = sourceElement.getCompilation.getCompilerInfo
  stylesheetPackage.setTargetEdition(compilerInfo.getTargetEdition)
  stylesheetPackage.setRelocatable(compilerInfo.isRelocatable)
  stylesheetPackage.setJustInTimeCompilation(compilerInfo.isJustInTimeCompilation)
  stylesheetPackage.setImplicitPackage(!(sourceElement.getLocalPart == "package"))
  keyManager = stylesheetPackage.getKeyManager
  decimalFormatManager = stylesheetPackage.getDecimalFormatManager
  ruleManager = new RuleManager(stylesheetPackage, compilerInfo)
  ruleManager.getUnnamedMode.makeDeclaringComponent(Visibility.PRIVATE, stylesheetPackage)
  stylesheetPackage.setRuleManager(ruleManager)
  stylesheetPackage.setDeclaredModes(declaredModes)
  val defaultMode = sourceElement.getDefaultMode
  stylesheetPackage.setDefaultMode(sourceElement.getDefaultMode)
  if (defaultMode != null) ruleManager.obtainMode(defaultMode, !declaredModes)
  characterMapIndex = new CharacterMapIndex
  stylesheetPackage.setCharacterMapIndex(characterMapIndex)
  typeAliasManager = getConfiguration.makeTypeAliasManager
  stylesheetPackage.setTypeAliasManager(typeAliasManager)
  try setInputTypeAnnotations(sourceElement.getInputTypeAnnotationsAttribute)
  catch {
    case err: XPathException =>

    // it will be reported some other time
  }
  private var stylesheetPackage = null
  private var declaredModes = false
  // index of global variables and parameters, by StructuredQName
  // (overridden variables are excluded).
  private val globalVariableIndex = new util.HashMap[StructuredQName, ComponentDeclaration](20)
  // index of templates - only includes those actually declared within this package
  private val templateIndex = new util.HashMap[StructuredQName, ComponentDeclaration](20)
  // Table of named stylesheet functions.
  private val functionIndex = new util.HashMap[SymbolicName, ComponentDeclaration](8)
  // key manager for all the xsl:key definitions in this package
  private var keyManager = null
  // decimal format manager for all the xsl:decimal-format definitions in this package
  private var decimalFormatManager = null
  // rule manager for template rules
  private var ruleManager = null
  // manager class for accumulator rules (XSLT 3.0 only)
  private var accumulatorManager = null
  // namespace aliases. This information is needed at compile-time only
  private var numberOfAliases = 0
  private var namespaceAliasList = new util.ArrayList[ComponentDeclaration](5)
  private var namespaceAliasMap = null
  private var aliasResultUriSet = null
  // attribute sets. A package can contain several declarations attribute sets with the same name.
  // They are indexed in the order they will be applied, that is, highest precedence first
  private val attributeSetDeclarations = new util.HashMap[StructuredQName, util.List[ComponentDeclaration]]
  // cache of stylesheet documents. Note that multiple imports of the same URI
  // lead to the stylesheet tree being reused
  private val moduleCache = new util.HashMap[DocumentURI, XSLModuleRoot](4)
  private var typeAliasManager = null
  private var characterMapIndex = null
  private val fixupActions = new util.ArrayList[Action]
  private var needsDynamicOutputProperties = false

  /**
   * Search the package for a component with a given name
   *
   * @param name the symbolic name of the required component
   * @return the requested component if found, or null otherwise
   */
  def getComponent(name: SymbolicName) = stylesheetPackage.getComponentIndex.get(name)

  /**
   * Get the outermost stylesheet module in a package
   *
   * @return this module (this class represents both the package and its outermost module)
   */
  /*@NotNull*/ override def getPrincipalStylesheetModule = this

  /**
   * Get the stylesheet package
   *
   * @return the associated stylesheet package
   */
  def getStylesheetPackage = stylesheetPackage

  /**
   * Get the key manager used to manage xsl:key declarations in this package
   *
   * @return the key manager
   */
  def getKeyManager = keyManager

  /**
   * Get the decimal format manager used to manage xsl:decimal-format declarations in this package
   *
   * @return the decimal format manager
   */
  def getDecimalFormatManager = decimalFormatManager

  /**
   * Get the rule manager used to manage modes declared explicitly or implicitly in this package
   *
   * @return the rule manager
   */
  def getRuleManager = ruleManager

  /**
   * Ask whether it is required that modes be explicitly declared
   *
   * @return true if modes referenced within this package must be explicitly declared
   */
  def isDeclaredModes = declaredModes

  /**
   * Register a callback action to be performed during the fixup phase
   *
   * @param action the callback action
   */
  def addFixupAction(action: Action) = fixupActions.add(action)

  /**
   * Say that this stylesheet package needs dynamic output properties
   *
   * @param b true if this stylesheet needs dynamic output properties
   */
  def setNeedsDynamicOutputProperties(b: Boolean) = needsDynamicOutputProperties = b

  /**
   * Get an index of character maps declared using xsl:character-map entries in this package
   *
   * @return the character map index
   */
  def getCharacterMapIndex = characterMapIndex

  /**
   * Get the type alias manager (type aliases are a Saxon extension)
   *
   * @return the type alias manager
   */
  def getTypeAliasManager = typeAliasManager

  /**
   * Declare an imported XQuery function
   *
   * @param function the imported function
   * @throws net.sf.saxon.trans.XPathException if an error occurs
   */
  @throws[XPathException]
  def declareXQueryFunction(function: XQueryFunction) = {
    val lib = getStylesheetPackage.getXQueryFunctionLibrary
    if (getStylesheetPackage.getFunction(function.getUserFunction.getSymbolicName) != null) throw new XPathException("Duplication declaration of " + function.getUserFunction.getSymbolicName, "XQST0034")
    lib.declareFunction(function)
  }

  /**
   * Add a module to the cache of stylesheet modules
   *
   * @param key    the key to be used (based on the absolute URI)
   * @param module the stylesheet document tree corresponding to this absolute URI
   */
  def putStylesheetDocument(key: DocumentURI, module: XSLStylesheet) = moduleCache.put(key, module)

  /**
   * Get a module from the cache of stylesheet modules
   *
   * @param key the key to be used (based on the absolute URI)
   * @return the stylesheet document tree corresponding to this absolute URI
   */
  def getStylesheetDocument(key: DocumentURI) = {
    val sheet = moduleCache.get(key)
    if (sheet != null) {
      val warning = new XPathException("Stylesheet module " + key + " is included or imported more than once. " + "This is permitted, but may lead to errors or unexpected behavior")
      sheet.issueWarning(warning)
    }
    sheet
  }

  /**
   * Preprocess does all the processing possible before the source document is available.
   * It is done once per stylesheet, so the stylesheet can be reused for multiple source
   * documents. The method is called only on the XSLStylesheet element representing the
   * principal stylesheet module
   *
   * @throws net.sf.saxon.trans.XPathException if errors are found in the stylesheet
   */
  @throws[XPathException]
  def preprocess(compilation: Compilation) = {
    val timer = compilation.timer
    // process any xsl:use-package, xsl:include and xsl:import elements
    spliceUsePackages(getRootElement.asInstanceOf[XSLPackage], getRootElement.getCompilation)
    if (Compilation.TIMING) timer.report("spliceIncludes")
    // import schema documents
    importSchemata()
    if (Compilation.TIMING) timer.report("importSchemata")
    // process type aliases
    getTypeAliasManager.processAllDeclarations(topLevel)
    // build indexes for selected top-level elements
    buildIndexes()
    if (Compilation.TIMING) timer.report("buildIndexes")
    // check for use of schema-aware constructs
    checkForSchemaAwareness()
    if (Compilation.TIMING) timer.report("checkForSchemaAwareness")
    // process the attributes of every node in the tree
    processAllAttributes()
    if (Compilation.TIMING) timer.report("processAllAttributes")
    // collect any namespace aliases
    collectNamespaceAliases()
    if (Compilation.TIMING) timer.report("collectNamespaceAliases")
    // fix up references from XPath expressions to variables and functions, for static typing
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      val inst = decl.getSourceElement
      if (!inst.isActionCompleted(StyleElement.ACTION_FIXUP)) {
        inst.setActionCompleted(StyleElement.ACTION_FIXUP)
        inst.fixupReferences()
      }
    }
    if (Compilation.TIMING) timer.report("fixupReferences")
    // Validate the whole package (i.e. with included and imported stylesheet modules)
    val top = getStylesheetElement.asInstanceOf[XSLPackage]
    //setInputTypeAnnotations(top.getInputTypeAnnotationsAttribute());
    val decl = new ComponentDeclaration(this, top)
    if (!top.isActionCompleted(StyleElement.ACTION_VALIDATE)) {
      top.setActionCompleted(StyleElement.ACTION_VALIDATE)
      top.validate(null)
      import scala.collection.JavaConversions._
      for (d <- topLevel) {
        d.getSourceElement.validateSubtree(d, false)
      }
    }
    if (Compilation.TIMING) timer.report("validate")
    // Gather the output properties
    val props = gatherOutputProperties(null)
    props.setProperty(SaxonOutputKeys.STYLESHEET_VERSION, getStylesheetPackage.getVersion + "")
    getStylesheetPackage.setDefaultOutputProperties(props)
    // Handle named output formats for use at run-time
    val outputNames = new util.HashSet[StructuredQName](5)
    import scala.collection.JavaConversions._
    for (outputDecl <- topLevel) {
      if (outputDecl.getSourceElement.isInstanceOf[XSLOutput]) {
        val out = outputDecl.getSourceElement.asInstanceOf[XSLOutput]
        val qName = out.getFormatQName
        if (qName != null) outputNames.add(qName)
      }
    }
    if (outputNames.isEmpty) if (needsDynamicOutputProperties) throw new XPathException("The stylesheet contains xsl:result-document instructions that calculate the output " + "format name at run-time, but there are no named xsl:output declarations", "XTDE1460")
    else {
      import scala.collection.JavaConversions._
      for (qName <- outputNames) {
        val oprops = gatherOutputProperties(qName)
        //if (needsDynamicOutputProperties) {  // needed for saxon:serialize
        getStylesheetPackage.setNamedOutputProperties(qName, oprops)
        //}
      }
    }
    if (Compilation.TIMING) timer.report("Register output formats")
    // Index the character maps
    import scala.collection.JavaConversions._
    for (d <- topLevel) {
      val inst = d.getSourceElement
      if (inst.isInstanceOf[XSLCharacterMap]) {
        val xcm = inst.asInstanceOf[XSLCharacterMap]
        val qn = xcm.getCharacterMapName
        val map = new IntHashMap[String]
        xcm.assemble(map)
        characterMapIndex.putCharacterMap(xcm.getCharacterMapName, new CharacterMap(qn, map))
      }
    }
    if (Compilation.TIMING) timer.report("Index character maps")
  }

  /**
   * Incorporate declarations from used packages
   *
   * @param xslpackage  the used package
   * @param compilation this compilation
   * @throws XPathException if any error is detected in the used package
   */
  @throws[XPathException]
  protected def spliceUsePackages(xslpackage: XSLPackage, compilation: Compilation) = { //        CompilerInfo info = compilation.getCompilerInfo();
    // Warning message deleted by bug 3278
    //        if (info.isVersionWarning() &&
    //                xslpackage.getEffectiveVersion() != 30) {
    //            XPathException w = new XPathException(
    //                    "Running an XSLT " + xslpackage.getEffectiveVersionAsString() + " stylesheet with an XSLT 3.0 processor");
    //            w.setLocator(xslpackage);
    //            compilation.reportWarning(w);
    //        }
    val useDeclarations = new util.ArrayList[XSLUsePackage]
    PrincipalStylesheetModule.gatherUsePackageDeclarations(compilation, xslpackage, useDeclarations)
    // First pass: gather all the named overriding declarations and add them to the topLevel declaration list
    val overrides = new util.HashSet[SymbolicName]
    import scala.collection.JavaConversions._
    for (use <- useDeclarations) {
      gatherOverridingDeclarations(use, compilation, overrides)
    }
    //gatherOverridingDeclarations(compilation, xslpackage, overrides);
    // Second pass: make modified copies of the named components in the used packages
    val thisPackage = getStylesheetPackage
    import scala.collection.JavaConversions._
    for (use <- useDeclarations) {
      val acceptors = use.getAcceptors
      thisPackage.addComponentsFromUsedPackage(use.getUsedPackage, acceptors, overrides)
    }
    // Third pass: process the overriding template rules, creating new mode objects
    import scala.collection.JavaConversions._
    for (use <- useDeclarations) {
      use.gatherRuleOverrides(this, overrides)
    }
    // Now process the declarations contained within this package, both in the top-level module
    // and within its included and imported modules
    spliceIncludes()
  }

  @throws[XPathException]
  private def gatherOverridingDeclarations(use: XSLUsePackage, compilation: Compilation, overrides: util.Set[SymbolicName]) = {
    use.findUsedPackage(compilation.getCompilerInfo)
    use.gatherNamedOverrides(this, topLevel, overrides)
  }

  /**
   * Process import-schema declarations
   *
   * @throws net.sf.saxon.trans.XPathException if errors are detected
   */
  @throws[XPathException]
  protected def importSchemata() = { // Outside Saxon-EE, xsl:import-schemas are an error
    for (i <- topLevel.size - 1 to 0 by -1) {
      val decl = topLevel.get(i)
      if (decl.getSourceElement.isInstanceOf[XSLImportSchema]) {
        val xe = new XPathException("xsl:import-schema requires Saxon-EE")
        xe.setErrorCode("XTSE1650")
        xe.setLocator(decl.getSourceElement)
        throw xe
      }
    }
  }

  /**
   * Build indexes for selected top-level declarations
   *
   * @throws net.sf.saxon.trans.XPathException if errors are detected
   */
  @throws[XPathException]
  private def buildIndexes() = { // Scan the declarations in reverse order, that is, highest precedence first
    for (i <- topLevel.size - 1 to 0 by -1) {
      val decl = topLevel.get(i)
      decl.getSourceElement.index(decl, this)
    }
  }

  /**
   * Process the attributes of every node in the stylesheet
   *
   * @throws net.sf.saxon.trans.XPathException if static errors are found in the stylesheet
   */
  @throws[XPathException]
  def processAllAttributes() = {
    getRootElement.processDefaultCollationAttribute()
    getRootElement.processDefaultMode()
    getRootElement.prepareAttributes()
    import scala.collection.JavaConversions._
    for (xss <- moduleCache.values) {
      xss.prepareAttributes()
    }
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      val inst = decl.getSourceElement
      if (!inst.isActionCompleted(StyleElement.ACTION_PROCESS_ATTRIBUTES)) {
        inst.setActionCompleted(StyleElement.ACTION_PROCESS_ATTRIBUTES)
        try inst.processAllAttributes()
        catch {
          case err: XPathException =>
            decl.getSourceElement.compileError(err)
        }
      }
    }
  }

  /**
   * Add a stylesheet function to the index
   *
   * @param decl The declaration wrapping an XSLFunction object
   */
  protected def indexFunction(decl: ComponentDeclaration) = {
    val componentIndex = stylesheetPackage.getComponentIndex
    val sourceFunction = decl.getSourceElement.asInstanceOf[XSLFunction]
    val compiledFunction = sourceFunction.getCompiledFunction
    val declaringComponent = compiledFunction.obtainDeclaringComponent(sourceFunction)
    val sName = sourceFunction.getSymbolicName
    //StructuredQName qName = template.getTemplateName();
    if (sName != null) { // see if there is already a named function with this precedence
      val other = componentIndex.get(sName)
      if (other == null) { // this is the first
        componentIndex.put(sName, declaringComponent)
        functionIndex.put(sName, decl)
      }
      else if (other.getDeclaringPackage eq getStylesheetPackage) { // check the precedences
        val thisPrecedence = decl.getPrecedence
        val otherFunction = functionIndex.get(sName)
        val otherPrecedence = otherFunction.getPrecedence
        if (thisPrecedence == otherPrecedence) sourceFunction.compileError("Duplicate named function (see line " + otherFunction.getSourceElement.getLineNumber + " of " + otherFunction.getSourceElement.getSystemId + ')', "XTSE0770")
        else if (thisPrecedence < otherPrecedence) {
          //template.setRedundantNamedTemplate();
        }
        else { // can't happen, but we'll play safe
          //other.setRedundantNamedTemplate();
          componentIndex.put(sName, declaringComponent)
          functionIndex.put(sName, decl)
        }
      }
      else if (sourceFunction.findAncestorElement(StandardNames.XSL_OVERRIDE) != null) { // the new one wins
        componentIndex.put(sName, declaringComponent)
        functionIndex.put(sName, decl)
      }
      else sourceFunction.compileError("Function " + sName.getShortName + " conflicts with a public function in package " + other.getDeclaringPackage.getPackageName, "XTSE3050")
    }
  }

  /**
   * Index a global xsl:variable or xsl:param element
   *
   * @param decl The Declaration referencing the XSLVariable or XSLParam element
   * @throws XPathException if an error occurs
   */
  @throws[XPathException]
  protected def indexVariableDeclaration(decl: ComponentDeclaration) = {
    val varDecl = decl.getSourceElement.asInstanceOf[XSLGlobalVariable]
    val qName = varDecl.getSourceBinding.getVariableQName
    val compiledVariable = varDecl.getActor.asInstanceOf[GlobalVariable]
    val declaringComponent = compiledVariable.obtainDeclaringComponent(varDecl)
    val componentIndex = stylesheetPackage.getComponentIndex
    if (qName != null) { // see if there is already a global variable with this precedence
      val sName = varDecl.getSymbolicName
      val other = componentIndex.get(sName)
      if (other == null) {
        globalVariableIndex.put(qName, decl)
        componentIndex.put(new SymbolicName(StandardNames.XSL_VARIABLE, qName), varDecl.getActor.getDeclaringComponent)
      }
      else if (other.getDeclaringPackage eq getStylesheetPackage) {
        val thisPrecedence = decl.getPrecedence
        val otherVarDecl = globalVariableIndex.get(sName.getComponentName)
        val otherPrecedence = otherVarDecl.getPrecedence
        if (thisPrecedence == otherPrecedence) {
          val v2 = otherVarDecl.getSourceElement
          if (v2 eq varDecl) varDecl.compileError("Global variable or parameter $" + qName.getDisplayName + " is declared more than once " + "(caused by including the containing module more than once)", "XTSE0630")
          else varDecl.compileError("Duplicate global variable/parameter declaration (see line " + v2.getLineNumber + " of " + v2.getSystemId + ')', "XTSE0630")
        }
        else if (thisPrecedence < otherPrecedence && (varDecl ne otherVarDecl.getSourceElement)) varDecl.setRedundant(true)
        else if (varDecl ne otherVarDecl.getSourceElement) {
          otherVarDecl.getSourceElement.asInstanceOf[XSLGlobalVariable].setRedundant(true)
          globalVariableIndex.put(qName, decl)
          componentIndex.put(new SymbolicName(StandardNames.XSL_VARIABLE, qName), varDecl.getActor.getDeclaringComponent)
        }
      }
      else if (varDecl.findAncestorElement(StandardNames.XSL_OVERRIDE) != null) {
        componentIndex.put(sName, declaringComponent)
        globalVariableIndex.put(sName.getComponentName, decl)
      }
      else {
        val kind = if (varDecl.isInstanceOf[XSLGlobalParam]) "parameter"
        else "variable"
        varDecl.compileError("Global " + kind + " $" + sName.getComponentName.getDisplayName + " conflicts with a public variable/parameter in package " + other.getDeclaringPackage.getPackageName, "XTSE3050")
      }
    }
  }

  /**
   * Get the global variable or parameter with a given name (taking
   * precedence rules into account). This will only return global variables
   * declared in the same package where they are used.
   *
   * @param qName name of the global variable or parameter
   * @return the variable declaration, or null if it does not exist
   */
  def getGlobalVariableBinding(qName: StructuredQName) = {
    val decl = globalVariableIndex.get(qName)
    if (decl == null) null
    else decl.getSourceElement.asInstanceOf[XSLGlobalVariable].getSourceBinding
  }

  /**
   * Add a named template to the index
   *
   * @param decl the declaration of the Template object
   * @throws XPathException if an error occurs
   */
  @throws[XPathException]
  protected def indexNamedTemplate(decl: ComponentDeclaration) = {
    val componentIndex = stylesheetPackage.getComponentIndex
    val sourceTemplate = decl.getSourceElement.asInstanceOf[XSLTemplate]
    val sName = sourceTemplate.getSymbolicName
    if (sName != null) { // see if there is already a named template with this precedence
      val other = componentIndex.get(sName)
      if (other == null) { //NamedTemplate compiledTemplate = new NamedTemplate();
        val compiledTemplate = decl.getSourceElement.asInstanceOf[XSLTemplate].getCompiledNamedTemplate
        val declaringComponent = compiledTemplate.obtainDeclaringComponent(sourceTemplate)
        componentIndex.put(sName, declaringComponent)
        PrincipalStylesheetModule.setLocalParamDetails(sourceTemplate, compiledTemplate)
        templateIndex.put(sName.getComponentName, decl)
      }
      else if (other.getDeclaringPackage eq getStylesheetPackage) {
        val thisPrecedence = decl.getPrecedence
        val otherTemplate = templateIndex.get(sName.getComponentName)
        val otherPrecedence = otherTemplate.getPrecedence
        if (thisPrecedence == otherPrecedence) {
          val errorCode = if (sourceTemplate.getParent.isInstanceOf[XSLOverride]) "XTSE3055"
          else "XTSE0660"
          sourceTemplate.compileError("Duplicate named template (see line " + otherTemplate.getSourceElement.getLineNumber + " of " + otherTemplate.getSourceElement.getSystemId + ')', errorCode)
        }
        else if (thisPrecedence < otherPrecedence) {
          //return;
        }
        else {
          val compiledTemplate = new NamedTemplate(sName.getComponentName)
          val declaringComponent = compiledTemplate.obtainDeclaringComponent(sourceTemplate)
          componentIndex.put(sName, declaringComponent)
          templateIndex.put(sName.getComponentName, decl)
          PrincipalStylesheetModule.setLocalParamDetails(sourceTemplate, compiledTemplate)
        }
      }
      else if (sourceTemplate.findAncestorElement(StandardNames.XSL_OVERRIDE) != null) {
        val compiledTemplate = sourceTemplate.getCompiledNamedTemplate //new NamedTemplate();
        val declaringComponent = compiledTemplate.obtainDeclaringComponent(sourceTemplate)
        componentIndex.put(sName, declaringComponent)
        templateIndex.put(sName.getComponentName, decl)
      }
      else sourceTemplate.compileError("Named template " + sName.getComponentName.getDisplayName + " conflicts with a public named template in package " + other.getDeclaringPackage.getPackageName, "XTSE3050")
    }
  }

  /**
   * Get the named template with a given name
   *
   * @param name the name of the required template
   * @return the template with the given name, if there is one, or null otherwise. If there
   *         are several templates with the same name, the one with highest import precedence
   *         is returned. Note that this template may subsequently be overridden in another package,
   *         but only by another template with a compatible signature.
   */
  def getNamedTemplate(name: StructuredQName) = {
    val componentIndex = stylesheetPackage.getComponentIndex
    val component = componentIndex.get(new SymbolicName(StandardNames.XSL_TEMPLATE, name))
    if (component == null) null
    else component.getActor.asInstanceOf[NamedTemplate]
  }

  /**
   * Add an attribute set to the index
   *
   * @param decl the declaration of the attribute set object
   * @throws XPathException if an error occurs
   */
  @throws[XPathException]
  protected def indexAttributeSet(decl: ComponentDeclaration) = { //HashMap<SymbolicName, Component> componentIndex = stylesheetPackage.getComponentIndex();
    val sourceAttributeSet = decl.getSourceElement.asInstanceOf[XSLAttributeSet]
    val name = sourceAttributeSet.getAttributeSetName
    var entries = attributeSetDeclarations.get(name)
    if (entries == null) {
      entries = new util.ArrayList[ComponentDeclaration]
      attributeSetDeclarations.put(name, entries)
    }
    else {
      val thisVis = Whitespace.trim(sourceAttributeSet.getAttributeValue("", "visibility"))
      val firstVis = Whitespace.trim(entries.get(0).getSourceElement.getAttributeValue("", "visibility"))
      if (if (thisVis == null) firstVis != null
      else !(thisVis == firstVis)) throw new XPathException("Visibility attributes on attribute-sets sharing the same name must all be the same", "XTSE0010")
    }
    entries.add(0, decl)
  }

  /**
   * Return all the attribute set declarations in the package having a particular QName
   *
   * @param name the name of the required declarations
   * @return the set of declarations having this name, or null if there are none
   */
  def getAttributeSetDeclarations(name: StructuredQName) = attributeSetDeclarations.get(name)

  /**
   * Combine all like-named xsl:attribute-set declarations in this package into a single Component, whose body
   * is an AttributeSet object. The resulting attribute set Components are saved in the StylesheetPackage
   * object.
   *
   * @throws XPathException if a failure occurs
   */
  @throws[XPathException]
  def combineAttributeSets(compilation: Compilation) = {
    val index = new util.HashMap[StructuredQName, AttributeSet]
    import scala.collection.JavaConversions._
    for (entry <- attributeSetDeclarations.entrySet) {
      val as = new AttributeSet
      as.setName(entry.getKey)
      as.setPackageData(stylesheetPackage)
      val firstDecl = entry.getValue.get(0).getSourceElement
      as.setSystemId(firstDecl.getSystemId)
      as.setLineNumber(firstDecl.getLineNumber)
      index.put(entry.getKey, as)
      var declaringComponent = as.getDeclaringComponent
      if (declaringComponent == null) declaringComponent = as.makeDeclaringComponent(Visibility.PRIVATE, stylesheetPackage)
      stylesheetPackage.addComponent(declaringComponent)
    }
    import scala.collection.JavaConversions._
    for (entry <- attributeSetDeclarations.entrySet) {
      val content = new util.ArrayList[Expression]
      var vis = null
      var explicitVisibility = false
      var streamable = false
      // Bug 3195. If the same xsl:attribute-set element is present more than
      // once in the list, we need to remove all but the last occurrence, otherwise
      // the same expression will be present more than once in the tree. This can
      // happen when a stylesheet module is included/imported more than once.
      val entries = new util.ArrayList[ComponentDeclaration]
      val elements = new util.HashSet[XSLAttributeSet]
      for (i <- entry.getValue.size - 1 to 0 by -1) {
        val decl = entry.getValue.get(i)
        val src = decl.getSourceElement.asInstanceOf[XSLAttributeSet]
        if (!elements.contains(src)) {
          entries.add(0, decl)
          elements.add(src)
        }
      }
      import scala.collection.JavaConversions._
      for (decl <- entries) {
        val src = decl.getSourceElement.asInstanceOf[XSLAttributeSet]
        streamable |= src.isDeclaredStreamable
        src.compileDeclaration(compilation, decl)
        content.addAll(src.getContainedInstructions)
        vis = src.getVisibility
        explicitVisibility = explicitVisibility || src.getAttributeValue("", "visibility") != null
      }
      val aSet = index.get(entry.getKey)
      aSet.setDeclaredStreamable(streamable)
      val block = Block.makeBlock(content)
      aSet.setBody(block)
      val frame = getConfiguration.makeSlotManager
      ExpressionTool.allocateSlots(block, 0, frame)
      aSet.setStackFrameMap(frame)
      val provenance = if (explicitVisibility) VisibilityProvenance.EXPLICIT
      else VisibilityProvenance.DEFAULTED
      aSet.getDeclaringComponent.setVisibility(vis, provenance)
      if (streamable) checkStreamability(aSet)
    }
  }

  /**
   * Check the streamability of an attribute set declared within this stylesheet module.
   * (Null implementation for Saxon-HE).
   *
   * @param aSet the attribute set to be checked
   * @throws XPathException if the streamability rules are not satisifed
   */
  @throws[XPathException]
  protected def checkStreamability(aSet: AttributeSet) = {
  }

  /**
   * Get the list of attribute-set declarations associated with a given QName.
   * This is used for xsl:element, xsl:copy, xsl:attribute-set, and on literal
   * result elements
   *
   * @param name the name of the required attribute set
   * @param list a list to hold the list of XSLAttributeSet elements in the stylesheet tree.
   */
  protected def getAttributeSets(name: StructuredQName, list: util.List[ComponentDeclaration]) = { // search for the named attribute set, using all of them if there are several with the
    // same name
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      if (decl.getSourceElement.isInstanceOf[XSLAttributeSet]) {
        val t = decl.getSourceElement.asInstanceOf[XSLAttributeSet]
        if (t.getAttributeSetName == name) list.add(decl)
      }
    }
  }

  /**
   * Handle an explicitly-declared mode
   *
   * @param decl the declaration of the Mode object
   */
  def indexMode(decl: ComponentDeclaration): Unit = {
    val sourceMode = decl.getSourceElement.asInstanceOf[XSLMode]
    val modeName = sourceMode.getObjectName
    if (modeName == null) return // Not a named mode
    val sName = new SymbolicName(StandardNames.XSL_MODE, modeName)
    // see if there is already a named mode with this precedence
    val other = getStylesheetPackage.getRuleManager.obtainMode(modeName, false)
    if (other != null && (other.getDeclaringComponent.getDeclaringPackage ne getStylesheetPackage)) sourceMode.compileError("Mode " + sName.getComponentName.getDisplayName + " conflicts with a public mode declared in package " + other.getDeclaringComponent.getDeclaringPackage.getPackageName, "XTSE3050")
  }

  /**
   * Check that it is legitimate to add a given template rule to a given mode
   *
   * @param template the template rule
   * @param mode     the mode
   */
  def checkAcceptableModeForPackage(template: XSLTemplate, mode: Mode): Boolean = {
    val templatePack = template.getPackageData
    if (mode.getDeclaringComponent == null) return true
    val modePack = mode.getDeclaringComponent.getDeclaringPackage
    if (templatePack ne modePack) {
      val parent = template.getParent
      var bad = false
      if (!parent.isInstanceOf[XSLOverride]) bad = true
      else {
        val grandParent = parent.getParent
        if (!grandParent.isInstanceOf[XSLUsePackage]) bad = true
        else {
          val modeName = mode.getSymbolicName
          val usedMode = grandParent.asInstanceOf[XSLUsePackage].getUsedPackage.getComponent(modeName).asInstanceOf[Component.M]
          if (usedMode == null) bad = true
          else if (usedMode.getVisibility eq Visibility.FINAL) bad = true
        }
      }
      if (bad) {
        template.compileError("A template rule cannot be added to a mode declared in a used package " + "unless the xsl:template declaration appears within an xsl:override child of the appropriate xsl:use-package element", "XTSE3050")
        return false
      }
    }
    true
  }

  /**
   * Check for schema-awareness.
   * Typed input nodes are recognized if and only if the stylesheet contains an import-schema declaration.
   */
  private def checkForSchemaAwareness(): Unit = {
    val compilation = getRootElement.getCompilation
    if (!compilation.isSchemaAware && getConfiguration.isLicensedFeature(Configuration.LicenseFeature.ENTERPRISE_XSLT)) {
      import scala.collection.JavaConversions._
      for (decl <- topLevel) {
        val node = decl.getSourceElement
        if (node.isInstanceOf[XSLImportSchema]) {
          compilation.setSchemaAware(true)
          return
        }
      }
    }
  }

  /**
   * Get the class that manages accumulator functions
   *
   * @return the class that manages accumulators. Always null in Saxon-HE
   */
  def getAccumulatorManager = accumulatorManager

  /**
   * Set the class that manages accumulator functions
   *
   * @param accumulatorManager the manager of accumulator functions
   */
  def setAccumulatorManager(accumulatorManager: AccumulatorRegistry) = {
    this.accumulatorManager = accumulatorManager
    stylesheetPackage.setAccumulatorRegistry(accumulatorManager)
  }

  protected def addNamespaceAlias(node: ComponentDeclaration) = {
    namespaceAliasList.add(node)
    numberOfAliases += 1
  }

  /**
   * Get the declared namespace alias for a given namespace URI code if there is one.
   * If there is more than one, we get the last.
   *
   * @param uri The uri used in the stylesheet.
   * @return The namespace binding to be used (prefix and uri): return null
   *         if no alias is defined
   */
  protected def getNamespaceAlias(uri: String) = namespaceAliasMap.get(uri)

  /**
   * Determine if a namespace is included in the result-prefix of a namespace-alias
   *
   * @param uri the namespace URI
   * @return true if an xsl:namespace-alias has been defined for this namespace URI
   */
  protected def isAliasResultNamespace(uri: String) = aliasResultUriSet.contains(uri)

  /**
   * Collect any namespace aliases
   */
  private def collectNamespaceAliases() = {
    namespaceAliasMap = new util.HashMap[String, NamespaceBinding](numberOfAliases)
    aliasResultUriSet = new util.HashSet[String](numberOfAliases)
    val aliasesAtThisPrecedence = new util.HashSet[String]
    var currentPrecedence = -1
    // Note that we are processing the list in reverse stylesheet order,
    // that is, highest precedence first.
    for (i <- 0 until numberOfAliases) {
      val decl = namespaceAliasList.get(i)
      val xna = decl.getSourceElement.asInstanceOf[XSLNamespaceAlias]
      val scode = xna.getStylesheetURI
      val resultBinding = xna.getResultNamespaceBinding
      val prec = decl.getPrecedence
      // check that there isn't a conflict with another xsl:namespace-alias
      // at the same precedence
      if (currentPrecedence != prec) {
        currentPrecedence = prec
        aliasesAtThisPrecedence.clear()
        //precedenceBoundary = i;
      }
      if (aliasesAtThisPrecedence.contains(scode)) if (!(namespaceAliasMap.get(scode).getURI == resultBinding.getURI)) xna.compileError("More than one alias is defined for the same namespace", "XTSE0810")
      if (namespaceAliasMap.get(scode) == null) {
        namespaceAliasMap.put(scode, resultBinding)
        aliasResultUriSet.add(resultBinding.getURI)
      }
      aliasesAtThisPrecedence.add(scode)
    }
    namespaceAliasList = null // throw it in the garbage
  }

  protected def hasNamespaceAliases = numberOfAliases > 0

  /**
   * Create an output properties object representing the xsl:output elements in the stylesheet.
   *
   * @param formatQName The name of the output format required. If set to null, gathers
   *                    information for the unnamed output format
   * @return the Properties object containing the details of the specified output format
   * @throws XPathException if a named output format does not exist in
   *                        the stylesheet
   */
  @throws[XPathException]
  def gatherOutputProperties(/*@Nullable*/ formatQName: StructuredQName) = {
    var found = formatQName == null
    val config = getConfiguration
    val details = new Properties(config.getDefaultSerializationProperties)
    val precedences = new util.HashMap[String, Integer](10)
    for (i <- topLevel.size - 1 to 0 by -1) {
      val decl = topLevel.get(i)
      if (decl.getSourceElement.isInstanceOf[XSLOutput]) {
        val xo = decl.getSourceElement.asInstanceOf[XSLOutput]
        if (if (formatQName == null) xo.getFormatQName == null
        else formatQName == xo.getFormatQName) {
          found = true
          xo.gatherOutputProperties(details, precedences, decl.getPrecedence)
        }
      }
    }
    if (!found) compileError("Requested output format " + formatQName.getDisplayName + " has not been defined", "XTDE1460")
    details
  }

  /**
   * Compile the source XSLT stylesheet package
   *
   * @param compilation the compilation episode
   * @throws XPathException if compilation fails for any reason
   */
  @throws[XPathException]
  protected def compile(compilation: Compilation): Unit = try {
    val timer = compilation.timer
    //PreparedStylesheet pss = getPreparedStylesheet();
    val config = getConfiguration
    // If any XQuery functions were imported, fix up all function calls
    // registered against these functions.
    val queryFunctions = stylesheetPackage.getXQueryFunctionLibrary
    val qf = queryFunctions.getFunctionDefinitions
    while ( {
      qf.hasNext
    }) {
      val f = qf.next.asInstanceOf[XQueryFunction]
      f.fixupReferences()
    }
    if (Compilation.TIMING) timer.report("fixup Query functions")
    // Register all modes with the rule manager
    val allowImplicit = !getStylesheetPackage.isDeclaredModes
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      val snode = decl.getSourceElement
      if (snode.isInstanceOf[XSLMode]) getRuleManager.obtainMode(snode.getObjectName, true)
      if (allowImplicit) registerImplicitModes(snode, getRuleManager)
    }
    // Register template rules with the rule manager
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      val snode = decl.getSourceElement
      if (snode.isInstanceOf[XSLTemplate]) snode.asInstanceOf[XSLTemplate].register(decl)
    }
    if (Compilation.TIMING) timer.report("register templates")
    // Adjust the visibility of components based on xsl:expose declarations
    adjustExposedVisibility()
    if (Compilation.TIMING) timer.report("adjust exposed visibility")
    // Call compile method for each top-level object in the stylesheet
    // Note, some declarations (templates) need to be compiled repeatedly if the module
    // is imported repeatedly; others (variables, functions) do not
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      val snode = decl.getSourceElement
      if (!snode.isActionCompleted(StyleElement.ACTION_COMPILE)) {
        snode.setActionCompleted(StyleElement.ACTION_COMPILE)
        snode.compileDeclaration(compilation, decl)
      }
    }
    if (Compilation.TIMING) timer.report("compile top-level objects (" + topLevel.size + ")")
    // Call type-check method for each user-defined function in the stylesheet. This is no longer
    // done during the optimize step, to avoid functions being inlined before they are type-checked.
    import scala.collection.JavaConversions._
    for (decl <- functionIndex.values) {
      val node = decl.getSourceElement
      if (!node.isActionCompleted(StyleElement.ACTION_TYPECHECK)) {
        node.setActionCompleted(StyleElement.ACTION_TYPECHECK)
        if (node.getVisibility ne Visibility.ABSTRACT) node.asInstanceOf[XSLFunction].getCompiledFunction.typeCheck(node.makeExpressionVisitor)
      }
    }
    if (Compilation.TIMING) timer.report("typeCheck functions (" + functionIndex.size + ")")
    if (compilation.getErrorCount > 0) { // not much point carrying on
      return
    }
    // Call optimize() method for each top-level declaration
    optimizeTopLevel()
    if (Compilation.TIMING) timer.report("optimize top level")
    // optimize functions that aren't overridden
    import scala.collection.JavaConversions._
    for (decl <- functionIndex.values) {
      val node = decl.getSourceElement
      if (!node.isActionCompleted(StyleElement.ACTION_OPTIMIZE)) {
        node.setActionCompleted(StyleElement.ACTION_OPTIMIZE)
        node.asInstanceOf[StylesheetComponent].optimize(decl)
      }
    }
    if (Compilation.TIMING) timer.report("optimize functions")
    // Check consistency of decimal formats
    getDecimalFormatManager.checkConsistency()
    if (Compilation.TIMING) timer.report("check decimal formats")
    // Check consistency of modes
    val ruleManager = getRuleManager
    ruleManager.checkConsistency()
    ruleManager.computeRankings()
    if (!compilation.isFallbackToNonStreaming) ruleManager.invertStreamableTemplates()
    if (config.obtainOptimizer.isOptionSet(OptimizerOptions.RULE_SET)) ruleManager.optimizeRules()
    if (Compilation.TIMING) timer.report("build template rule tables")
    // Build a run-time function library. This supports the use of function-available()
    // with a dynamic argument, and extensions such as saxon:evaluate(). The run-time
    // function library differs from the compile-time function library in that both
    // the StylesheetFunctionLibrary's on the library list are replaced by equivalent
    // ExecutableFunctionLibrary's. This is to prevent the retaining of run-time links
    // to the stylesheet document tree.
    val overriding = new ExecutableFunctionLibrary(config)
    val underriding = new ExecutableFunctionLibrary(config)
    import scala.collection.JavaConversions._
    for (decl <- stylesheetPackage.getComponentIndex.values) {
      val vis = decl.getVisibility
      if ( /*(vis == Visibility.PUBLIC || vis == Visibility.FINAL) &&*/ decl.getActor.isInstanceOf[UserFunction] ) {
        val f = decl.getActor.asInstanceOf[UserFunction]
        if (f.isOverrideExtensionFunction) overriding.addFunction(f)
        else underriding.addFunction(f)
      }
    }
    getStylesheetPackage.setFunctionLibraryDetails(null, overriding, underriding)
    if (Compilation.TIMING) timer.report("build runtime function tables")
    // Allocate binding slots to named templates
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      val inst = decl.getSourceElement
      if (inst.isInstanceOf[XSLTemplate]) {
        val proc = inst.asInstanceOf[XSLTemplate].getActor
        if (proc != null && proc.getTemplateName == null) proc.allocateAllBindingSlots(stylesheetPackage)
      }
    }
    if (Compilation.TIMING) timer.report("allocate binding slots to named templates")
    // Allocate binding slots to component reference expressions
    val componentIndex = stylesheetPackage.getComponentIndex
    import scala.collection.JavaConversions._
    for (decl <- componentIndex.values) {
      val proc = decl.getActor
      if (proc != null) proc.allocateAllBindingSlots(stylesheetPackage)
    }
    if (Compilation.TIMING) timer.report("allocate binding slots to component references")
    // Allocate binding slots in key definitions
    val keyMan = getKeyManager
    import scala.collection.JavaConversions._
    for (keySet <- keyMan.getAllKeyDefinitionSets) {
      import scala.collection.JavaConversions._
      for (keyDef <- keySet.getKeyDefinitions) {
        keyDef.makeDeclaringComponent(Visibility.PRIVATE, getStylesheetPackage)
        keyDef.allocateAllBindingSlots(stylesheetPackage)
      }
    }
    if (Compilation.TIMING) timer.report("allocate binding slots to key definitions")
    // Allocate binding slots in accumulators
    val accMan = getAccumulatorManager
    if (accMan != null) {
      import scala.collection.JavaConversions._
      for (acc <- accMan.getAllAccumulators) {
        acc.allocateAllBindingSlots(stylesheetPackage)
      }
    }
    if (Compilation.TIMING) timer.report("allocate binding slots to accumulators")
    // Generate byte code where appropriate
    if (compilation.getCompilerInfo.isGenerateByteCode && !config.isDeferredByteCode(HostLanguage.XSLT)) {
      if (Compilation.TIMING) config.getStandardErrorOutput.println("Generating byte code...")
      val opt = config.obtainOptimizer
      import scala.collection.JavaConversions._
      for (decl <- topLevel) {
        val inst = decl.getSourceElement
        if (inst.isInstanceOf[StylesheetComponent]) inst.asInstanceOf[StylesheetComponent].generateByteCode(opt)
      }
    }
    if (Compilation.TIMING) {
      timer.report("inject byte code candidates")
      timer.reportCumulative("total compile time")
    }
  } catch {
    case err: RuntimeException =>
      // if syntax errors were reported earlier, then exceptions may occur during this phase
      // due to inconsistency of data structures. We can ignore these exceptions as they
      // will go away when the user corrects the stylesheet
      if (compilation.getErrorCount == 0) { // rethrow the exception
        throw err
      }
  }

  private def registerImplicitModes(element: StyleElement, manager: RuleManager) = {
    if (element.isInstanceOf[XSLApplyTemplates] || element.isInstanceOf[XSLTemplate]) {
      val modeAtt = element.getAttributeValue("mode")
      if (modeAtt != null) {
        val tokens = Whitespace.trim(modeAtt).split("[ \t\n\r]+")
        for (s <- tokens) {
          if (!s.startsWith("#")) {
            val modeName = element.makeQName(s, null, "mode")
            val sName = new SymbolicName(StandardNames.XSL_MODE, modeName)
            val componentIndex = getStylesheetPackage.getComponentIndex
            val existing = componentIndex.get(sName)
            if (existing != null && (existing.getDeclaringPackage ne getStylesheetPackage)) if (element.isInstanceOf[XSLTemplate] && !element.getParent.isInstanceOf[XSLOverride]) element.compileError("A template rule cannot be added to a mode declared in a used package " + "unless the xsl:template declaration appears within an xsl:override child of the appropriate xsl:use-package element", "XTSE3050")
            else manager.obtainMode(modeName, true)
          }
        }
      }
    }
    var child = null
    val kids = element.iterateAxis(AxisInfo.CHILD)
    while ( {
      (child = kids.next) != null
    }) if (child.isInstanceOf[StyleElement]) registerImplicitModes(child.asInstanceOf[StyleElement], manager)
  }

  @throws[XPathException]
  def optimizeTopLevel() = { // Call optimize method for each top-level object in the stylesheet
    // But for functions, do it only for those of highest precedence.
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      val node = decl.getSourceElement
      if (node.isInstanceOf[StylesheetComponent] && !node.isInstanceOf[XSLFunction] && !node.isActionCompleted(StyleElement.ACTION_OPTIMIZE)) {
        node.setActionCompleted(StyleElement.ACTION_OPTIMIZE)
        node.asInstanceOf[StylesheetComponent].optimize(decl)
      }
      if (node.isInstanceOf[XSLTemplate]) node.asInstanceOf[XSLTemplate].allocatePatternSlotNumbers
    }
  }

  /**
   * Get an imported schema with a given namespace
   *
   * @param targetNamespace The target namespace of the required schema.
   *                        Supply an empty string for the default namespace
   * @return the required Schema, or null if no such schema has been imported
   */
  protected def isImportedSchema(targetNamespace: String) = stylesheetPackage.getSchemaNamespaces.contains(targetNamespace)

  protected def addImportedSchema(targetNamespace: String) = stylesheetPackage.getSchemaNamespaces.add(targetNamespace)

  protected def getImportedSchemaTable = stylesheetPackage.getSchemaNamespaces

  /**
   * Get a character map, identified by the fingerprint of its name.
   * Search backwards through the stylesheet.
   *
   * @param name The character map name being sought
   * @return the identified character map, or null if not found
   */
  def getCharacterMap(name: StructuredQName): ComponentDeclaration = {
    for (i <- topLevel.size - 1 to 0 by -1) {
      val decl = topLevel.get(i)
      if (decl.getSourceElement.isInstanceOf[XSLCharacterMap]) {
        val t = decl.getSourceElement.asInstanceOf[XSLCharacterMap]
        if (t.getCharacterMapName == name) return decl
      }
    }
    null
  }

  /**
   * Adjust visibility of components by applying xsl:expose rules
   */
  @throws[XPathException]
  def adjustExposedVisibility(): Unit = {
    val exposeDeclarations = new util.ArrayList[XSLExpose] // xsl:expose declarations in reverse order
    import scala.collection.JavaConversions._
    for (decl <- topLevel) {
      if (decl.getSourceElement.isInstanceOf[XSLExpose]) exposeDeclarations.add(0, decl.getSourceElement.asInstanceOf[XSLExpose])
    }
    if (exposeDeclarations.isEmpty) return
    val pool = getConfiguration.getNamePool
    val componentIndex = stylesheetPackage.getComponentIndex
    import scala.collection.JavaConversions._
    for (component <- componentIndex.values) {
      val fp = component.getComponentKind
      val exactNameTest = new ComponentTest(fp, new NameTest(Type.ELEMENT, new FingerprintedQName(component.getActor.getComponentName, pool), pool), -1)
      var exactFunctionTest = null
      if (fp == StandardNames.XSL_FUNCTION) {
        val fn = component.getActor.asInstanceOf[Function]
        exactFunctionTest = new ComponentTest(fp, new NameTest(Type.ELEMENT, new FingerprintedQName(fn.getFunctionName, pool), pool), fn.getArity)
      }
      var matched = false
      import scala.collection.JavaConversions._
      for (exposure <- exposeDeclarations) {
        val explicitComponentTests = exposure.getExplicitComponentTests
        if (explicitComponentTests.contains(exactNameTest) || (exactFunctionTest != null && explicitComponentTests.contains(exactFunctionTest))) {
          component.setVisibility(exposure.getVisibility, VisibilityProvenance.EXPOSED)
          matched = true
          break //todo: break is not supported
        }
      }
      if (!matched && (component.getVisibilityProvenance eq VisibilityProvenance.DEFAULTED)) { // Look for a matching wildcard
        partialWildcardSearch //todo: labels are not supported
        import scala.collection.JavaConversions._
        for (exposure <- exposeDeclarations) {
          import scala.collection.JavaConversions._
          for (test <- exposure.getWildcardComponentTests) {
            if (test.isPartialWildcard && test.matches(component.getActor)) {
              component.setVisibility(exposure.getVisibility, VisibilityProvenance.EXPOSED)
              matched = true
              break partialWildcardSearch // todo: label break is not supported
            }
          }
        }
        if (!matched) {
          anyWildcardSearch //todo: labels are not supported
          import scala.collection.JavaConversions._
          for (exposure <- exposeDeclarations) {
            import scala.collection.JavaConversions._
            for (test <- exposure.getWildcardComponentTests) {
              if (test.matches(component.getActor)) {
                component.setVisibility(exposure.getVisibility, VisibilityProvenance.EXPOSED)
                break anyWildcardSearch // todo: label break is not supported
              }
            }
          }
        }
      }
    }
  }

  /**
   * Compile time error, specifying an error code
   *
   * @param message   the error message
   * @param errorCode the error code. May be null if not known or not defined
   * @throws XPathException unconditionally
   */
  @throws[XPathException]
  protected def compileError(message: String, errorCode: String) = {
    val tce = new XPathException(message, errorCode)
    compileError(tce)
  }

  /**
   * Report an error with diagnostic information
   *
   * @param error contains information about the error
   */
  protected def compileError(error: XPathException) = {
    error.setIsStaticError(true)
    getRootElement.compileError(error)
  }

  @throws[XPathException]
  protected def fixup() = { // Perform the fixup actions
    import scala.collection.JavaConversions._
    for (a <- fixupActions) {
      a.doAction()
    }
  }

  @throws[XPathException]
  protected def complete() = stylesheetPackage.complete()

  def getSlotManager = null

  override def getEquivalentVariable(select: Expression) = null // implemented in Saxon-EE
  override def addGlobalVariable(variable: GlobalVariable) = addGlobalVariable(variable, Visibility.PRIVATE)

  def addGlobalVariable(variable: GlobalVariable, visibility: Visibility) = {
    val component = variable.makeDeclaringComponent(visibility, getStylesheetPackage)
    if (variable.getPackageData == null) variable.setPackageData(stylesheetPackage)
    if (visibility eq Visibility.HIDDEN) stylesheetPackage.addHiddenComponent(component)
    else stylesheetPackage.getComponentIndex.put(new SymbolicName(StandardNames.XSL_VARIABLE, variable.getVariableQName), component)
  }
}