////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.TryCatch
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.pattern.QNameTest
import net.sf.saxon.trans.XPathException
import java.util

/**
 * Handler for xsl:try elements in stylesheet.
 * The xsl:try element contains a sequence constructor or a select expression,
 * which defines the expression to be evaluated, and it may contain one or more
 * xsl:catch elements, which define the value to be returned in the event of
 * dynamic errors.
 */
class XSLTry extends StyleElement {
  private var select = null
  private var rollbackOutput = true
  private val catchTests = new util.ArrayList[QNameTest]
  private val catchExprs = new util.ArrayList[Expression]

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var selectAtt = null
    var rollbackOutputAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "select" =>
          selectAtt = value
          select = makeExpression(selectAtt, att)
        case "rollback-output" =>
          rollbackOutputAtt = value
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (rollbackOutputAtt != null) rollbackOutput = processBooleanAttribute("rollback-output", rollbackOutputAtt)
  }

  override protected def isPermittedChild(child: StyleElement) = child.isInstanceOf[XSLCatch]

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    select = typeCheck("select", select)
    var foundCatch = false
    import scala.collection.JavaConversions._
    for (kid <- children) {
      if (kid.isInstanceOf[XSLCatch]) foundCatch = true
      else if (kid.isInstanceOf[XSLFallback]) {
        // no action;
      }
      else {
        if (foundCatch) compileError("xsl:catch elements must come after all other children of xsl:try (excepting xsl:fallback)", "XTSE0010")
        if (select != null) compileError("An " + getDisplayName + " element with a select attribute must be empty", "XTSE3140")
      }
    }
    if (!foundCatch) compileError("xsl:try must have at least one xsl:catch child element", "XTSE0010")
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val content = compileSequenceConstructor(exec, decl, true)
    if (select == null) select = content
    val expr = new TryCatch(select)
    for (i <- 0 until catchTests.size) {
      expr.addCatchExpression(catchTests.get(i), catchExprs.get(i))
    }
    expr.setRollbackOutput(rollbackOutput)
    expr
  }

  def addCatchClause(nameTest: QNameTest, catchExpr: Expression) = {
    catchTests.add(nameTest)
    catchExprs.add(catchExpr)
  }
}