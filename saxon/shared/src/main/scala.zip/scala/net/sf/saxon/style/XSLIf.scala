////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.instruct.Choose
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.BooleanValue

/**
 * Handler for xsl:if elements in stylesheet. <br>
 * The xsl:if element has a mandatory attribute test, a boolean expression.
 * The content is output if the test condition is true.
 */
object XSLIf {
  /**
   * Process all the attributes, for an element where the only permitted attribute is "test"
   *
   * @param se the containing element
   * @return the expression represented by the test attribute, or null if the attribute is absent
   */
    def prepareTestAttribute(se: StyleElement) = {
      var testAtt = null
      import scala.collection.JavaConversions._
      for (att <- se.attributes) {
        val attName = att.getNodeName
        val f = attName.getDisplayName
        if (f == "test") testAtt = att
        else se.checkUnknownAttribute(attName)
      }
      if (testAtt == null) null
      else se.makeExpression(testAtt.getValue, testAtt)
    }
}

class XSLIf extends StyleElement {
  private var test = null
  private var thenExp = null
  private var elseExp = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      f match {
        case "test" =>
          test = makeExpression(att.getValue, att)
        case "then" =>
          // Saxon extension
          requireSyntaxExtensions("then")
          thenExp = makeExpression(att.getValue, att)
        case "else" =>
          requireSyntaxExtensions("else")
          elseExp = makeExpression(att.getValue, att)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (test == null) reportAbsence("test")
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    test = typeCheck("test", test)
    if (thenExp != null && hasChildNodes) compileError("xsl:if element must be empty if @then is present", "XTSE0010")
  }

  /**
   * Mark tail-recursive calls on stylesheet functions. For most instructions, this does nothing.
   */
  override def markTailCalls = {
    val last = getLastChildInstruction
    last != null && last.markTailCalls
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = {
    if (test.isInstanceOf[Literal]) {
      val testVal = test.asInstanceOf[Literal].getValue
      // condition known statically, so we only need compile the code if true.
      // This can happen with expressions such as test="function-available('abc')".
      try if (testVal.effectiveBooleanValue) return compileSequenceConstructor(exec, decl, true)
      else return null
      catch {
        case err: XPathException =>

        // fall through to non-optimizing case
      }
    }
    val action = compileSequenceConstructor(exec, decl, true)
    if (action == null) return null
    var conditions = null
    var actions = null
    if (elseExp == null) {
      conditions = Array[Expression](test)
      actions = Array[Expression](action)
    }
    else {
      conditions = Array[Expression](test, Literal.makeLiteral(BooleanValue.TRUE))
      actions = Array[Expression](action, elseExp)
    }
    val choose = new Choose(conditions, actions)
    choose.setInstruction(true)
    choose
  }

  @throws[XPathException]
  override def compileSequenceConstructor(compilation: Compilation, decl: ComponentDeclaration, includeParams: Boolean) = if (thenExp == null) super.compileSequenceConstructor(compilation, decl, includeParams)
  else thenExp
}