////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Untyped
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace
import javax.xml.transform.OutputKeys
import java.util.Properties

/**
 * The MetaTagAdjuster adds a meta element to the content of the head element, indicating
 * the required content type and encoding; it also removes any existing meta element
 * containing this information
 */
class MetaTagAdjuster(val next: Receiver)

/**
 * Create a new MetaTagAdjuster
 *
 * @param next the next receiver in the pipeline
 */
  extends ProxyReceiver(next) {
  private var seekingHead = true
  private var droppingMetaTags = -1
  private var inMetaTag = false
  private[serialize] var encoding = null
  private var mediaType = null
  private var level = 0
  private var isXHTML = false
  private var htmlVersion = 4

  /**
   * Set output properties
   *
   * @param details the serialization properties
   */
  def setOutputProperties(details: Properties) = {
    encoding = details.getProperty(OutputKeys.ENCODING)
    if (encoding == null) encoding = "UTF-8"
    mediaType = details.getProperty(OutputKeys.MEDIA_TYPE)
    if (mediaType == null) mediaType = "text/html"
    var htmlVn = details.getProperty(SaxonOutputKeys.HTML_VERSION)
    if (htmlVn == null && !isXHTML) htmlVn = details.getProperty(OutputKeys.VERSION)
    if (htmlVn != null && htmlVn.startsWith("5")) htmlVersion = 5
  }

  /**
   * Indicate whether we're handling HTML or XHTML
   */
  def setIsXHTML(xhtml: Boolean) = isXHTML = xhtml

  /**
   * Compare a name: case-blindly in the case of HTML, case-sensitive for XHTML
   */
  private def comparesEqual(name1: String, name2: String) = if (isXHTML) name1 == name2
  else name1.equalsIgnoreCase(name2)

  private def matchesName(name: NodeName, local: String): Boolean = if (isXHTML) {
    if (!(name.getLocalPart == local)) return false
    if (htmlVersion == 5) name.hasURI("") || name.hasURI(NamespaceConstant.XHTML)
    else name.hasURI(NamespaceConstant.XHTML)
  }
  else name.getLocalPart.equalsIgnoreCase(local)

  /**
   * Notify the start of an element
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int): Unit = {
    if (droppingMetaTags == level) if (matchesName(elemName, "meta")) { // if there was an http-equiv="ContentType" attribute, discard the meta element entirely
      var found = false
      import scala.collection.JavaConversions._
      for (att <- attributes) {
        val name = att.getNodeName.getLocalPart
        if (comparesEqual(name, "http-equiv")) {
          val value = Whitespace.trim(att.getValue)
          if (value.equalsIgnoreCase("Content-Type")) { // case-blind comparison even for XHTML
            found = true
            break //todo: break is not supported
          }
        }
      }
      inMetaTag = found
      if (found) return
    }
    level += 1
    nextReceiver.startElement(elemName, `type`, attributes, namespaces, location, properties)
    if (seekingHead && matchesName(elemName, "head")) {
      val headPrefix = elemName.getPrefix
      val headURI = elemName.getURI
      val metaCode = new FingerprintedQName(headPrefix, headURI, "meta")
      var atts = EmptyAttributeMap.getInstance
      atts = atts.put(new AttributeInfo(new NoNamespaceName("http-equiv"), BuiltInAtomicType.UNTYPED_ATOMIC, "Content-Type", Loc.NONE, ReceiverOption.NONE))
      atts = atts.put(new AttributeInfo(new NoNamespaceName("content"), BuiltInAtomicType.UNTYPED_ATOMIC, mediaType + "; charset=" + encoding, Loc.NONE, ReceiverOption.NONE))
      nextReceiver.startElement(metaCode, Untyped.getInstance, atts, namespaces, location, ReceiverOption.NONE)
      droppingMetaTags = level
      seekingHead = false
      nextReceiver.endElement()
    }
  }

  /**
   * End of element
   */
  @throws[XPathException]
  override def endElement() = if (inMetaTag) inMetaTag = false
  else {
    level -= 1
    if (droppingMetaTags == level + 1) droppingMetaTags = -1
    nextReceiver.endElement()
  }
}