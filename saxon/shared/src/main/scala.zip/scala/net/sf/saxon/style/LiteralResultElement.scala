////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.FixedAttribute
import net.sf.saxon.expr.instruct.FixedElement
import net.sf.saxon.expr.instruct.UseAttributeSet
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Untyped
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.linked.DocumentImpl
import net.sf.saxon.tree.linked.LinkedTreeBuilder
import net.sf.saxon.z.IntHashSet
import net.sf.saxon.z.IntSet
import java.util

/**
 * This class represents a literal result element in the style sheet
 * (typically an HTML element to be output). <br>
 * It is also used to represent unknown top-level elements, which are ignored.
 */
object LiteralResultElement {
  private val STANDARD_ATTRIBUTES = IntHashSet.of(StandardNames.XSL_USE_ATTRIBUTE_SETS, StandardNames.XSL_DEFAULT_COLLATION, StandardNames.XSL_DEFAULT_MODE, StandardNames.XSL_DEFAULT_VALIDATION, StandardNames.XSL_EXTENSION_ELEMENT_PREFIXES, StandardNames.XSL_EXCLUDE_RESULT_PREFIXES, StandardNames.XSL_EXPAND_TEXT, StandardNames.XSL_VERSION, StandardNames.XSL_XPATH_DEFAULT_NAMESPACE, StandardNames.XSL_TYPE, StandardNames.XSL_USE_WHEN, StandardNames.XSL_VALIDATION)
}

class LiteralResultElement extends StyleElement {
  private var resultNodeName = null
  private var attributeNames = null
  private var attributeValues = null
  private var numberOfAttributes = 0
  private var toplevel = false
  private var retainedNamespaces = NamespaceMap.emptyMap
  private var attributeSets = null
  /*@Nullable*/ private var schemaType = null
  private var validation = Validation.STRIP
  private var inheritNamespaces = true

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  /**
   * Specify that this is an instruction
   */
  override def isInstruction = true

  /**
   * Process the attribute list
   */
  override def prepareAttributes() = { // Process the values of all attributes. At this stage we deal with attribute
    // values (especially AVTs), but we do not apply namespace aliasing to the
    // attribute names.
    val atts = attributes
    val num = atts.size
    if (num == 0) numberOfAttributes = 0
    else {
      attributeNames = new Array[NodeName](num)
      attributeValues = new Array[Expression](num)
      numberOfAttributes = 0
      import scala.collection.JavaConversions._
      for (att <- atts) {
        val name = att.getNodeName
        val fp = name.getFingerprint
        val attURI = name.getURI
        if (attURI == NamespaceConstant.XSLT) if (!LiteralResultElement.STANDARD_ATTRIBUTES.contains(fp)) { // Standard attributes have already been dealt with
          if (fp == StandardNames.XSL_INHERIT_NAMESPACES) inheritNamespaces = processBooleanAttribute("xsl:inherit-namespaces", att.getValue)
          else if (!forwardsCompatibleModeIsEnabled) compileError("Unknown XSLT attribute " + Err.wrap(name.getDisplayName, Err.ATTRIBUTE), "XTSE0805")
        }
        else {
          attributeNames(numberOfAttributes) = name
          val exp = makeAttributeValueTemplate(att.getValue, att)
          attributeValues(numberOfAttributes) = exp
          numberOfAttributes += 1
        }
      }
      // now shorten the arrays if necessary. This is necessary if there are [xsl:]-prefixed
      // attributes that weren't copied into the arrays.
      if (numberOfAttributes < attributeNames.length) {
        attributeNames = util.Arrays.copyOf(attributeNames, numberOfAttributes)
        attributeValues = util.Arrays.copyOf(attributeValues, numberOfAttributes)
      }
    }
    resultNodeName = getNodeName
  }

  /**
   * Validate that this node is OK
   *
   * @param decl
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    toplevel = getParent.isInstanceOf[XSLStylesheet]
    resultNodeName = getNodeName
    val elementURI = getURI
    if (toplevel) { // A top-level element can never be a "real" literal result element,
      // but this class gets used for unknown elements found at the top level
      if (elementURI.isEmpty) {
        compileError("Top level elements must have a non-null namespace URI", "XTSE0130")
        // Now gets caught earlier - such elements are built as DataElement instances
      }
    }
    else { // Build the list of output namespace nodes. Note we no longer optimize this list.
      // See comments in the 9.1 source code for some history of this decision.
      retainedNamespaces = getAllNamespaces
      // Spec bug 5857: if there is no other binding for the default namespace, add an undeclaration
      //            String defaultNamespace = getURIForPrefix("", true);
      //            if (defaultNamespace.length()==0) {
      //                namespaceCodes.add(NamespaceBinding.DEFAULT_UNDECLARATION);
      //            }
      // apply any aliases required to create the list of output namespaces
      val sheet = getPrincipalStylesheetModule
      if (sheet.hasNamespaceAliases) {
        var aliasedNamespaces = retainedNamespaces
        import scala.collection.JavaConversions._
        for (nb <- retainedNamespaces) {
          val suri = nb.getURI
          val ncode = sheet.getNamespaceAlias(suri)
          if (ncode != null && !(ncode.getURI == suri)) { // apply the namespace alias.
            aliasedNamespaces = aliasedNamespaces.remove(nb.getPrefix)
            if (!ncode.getURI.isEmpty) aliasedNamespaces = aliasedNamespaces.put(ncode.getPrefix, ncode.getURI)
          }
        }
        retainedNamespaces = aliasedNamespaces
        // determine if there is an alias for the namespace of the element name
        val elementAlias = sheet.getNamespaceAlias(elementURI)
        if (elementAlias != null && !(elementAlias.getURI == elementURI)) resultNodeName = new FingerprintedQName(elementAlias.getPrefix, elementAlias.getURI, getLocalPart)
      }
      // deal with special attributes
      val useAttSets = getAttributeValue(NamespaceConstant.XSLT, "use-attribute-sets")
      if (useAttSets != null) attributeSets = getUsedAttributeSets(useAttSets)
      validation = getDefaultValidation
      val `type` = getAttributeValue(NamespaceConstant.XSLT, "type")
      if (`type` != null) {
        if (!isSchemaAware) compileError("The xsl:type attribute is available only with a schema-aware XSLT processor", "XTSE1660")
        schemaType = getSchemaType(`type`)
        validation = Validation.BY_TYPE
      }
      val validate = getAttributeValue(NamespaceConstant.XSLT, "validation")
      if (validate != null) {
        validation = validateValidationAttribute(validate)
        if (schemaType != null) compileError("The attributes xsl:type and xsl:validation are mutually exclusive", "XTSE1505")
      }
      // establish the names to be used for all the output attributes;
      // also type-check the AVT expressions
      if (numberOfAttributes > 0) {
        var changed = false
        for (i <- 0 until numberOfAttributes) {
          val anameCode = attributeNames(i)
          var alias = anameCode
          val attURI = anameCode.getURI
          if (!attURI.isEmpty) { // attribute has a namespace prefix
            val newBinding = sheet.getNamespaceAlias(attURI)
            if (newBinding != null && !(newBinding.getURI == attURI)) {
              alias = new FingerprintedQName(newBinding.getPrefix, newBinding.getURI, anameCode.getLocalPart)
              changed = true
            }
          }
          attributeNames(i) = alias
          attributeValues(i) = typeCheck(alias.getDisplayName, attributeValues(i))
        }
        if (changed && numberOfAttributes > 1) { // spec bug 30400. Check that the attribute names are still distinct
          val names = new IntHashSet(numberOfAttributes)
          for (i <- 0 until numberOfAttributes) {
            val fp = attributeNames(i).obtainFingerprint(getNamePool)
            val absent = names.add(fp)
            if (!absent) compileError("As a result of namespace aliasing, two attributes have the same expanded name", "XTSE0813")
          }
        }
      }
      // remove any namespaces that are on the exclude-result-prefixes list.
      // The namespace is excluded even if it is the namespace of the element or an attribute,
      // though in that case namespace fixup will reinstate it.
      var afterExclusions = retainedNamespaces
      import scala.collection.JavaConversions._
      for (nb <- retainedNamespaces) {
        val uri = nb.getURI
        if (isExcludedNamespace(uri) && !sheet.isAliasResultNamespace(uri)) afterExclusions = afterExclusions.remove(nb.getPrefix)
      }
      retainedNamespaces = afterExclusions
    }
  }

  /**
   * Validate the children of this node, recursively. Overridden for top-level
   * data elements.
   *
   * @param decl
   * @param excludeStylesheet
   */
  @throws[XPathException]
  override protected def validateChildren(decl: ComponentDeclaration, excludeStylesheet: Boolean) = if (!toplevel) super.validateChildren(decl, excludeStylesheet)

  /**
   * Compile code to process the literal result element at runtime
   */
  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = { // top level elements in the stylesheet are ignored
    if (toplevel) return null
    val inst = new FixedElement(resultNodeName, retainedNamespaces, inheritNamespaces, true, schemaType, validation)
    var content = compileSequenceConstructor(exec, decl, true)
    if (numberOfAttributes > 0) for (i <- attributeNames.length - 1 to 0 by -1) {
      val att = new FixedAttribute(attributeNames(i), Validation.STRIP, null)
      att.setRetainedStaticContext(makeRetainedStaticContext)
      att.setSelect(attributeValues(i))
      att.setLocation(allocateLocation)
      val exp = att
      //                if (exec.getCompilerInfo().isCompileWithTracing()) {
      //                    TraceExpression trace = new TraceExpression(exp);
      //                    trace.setNamespaceResolver(getNamespaceResolver());
      //                    trace.setConstructType(LocationKind.LITERAL_RESULT_ATTRIBUTE);
      //                    trace.setLocation(allocateLocation());
      //                    trace.setObjectName(attributeNames[i].getStructuredQName());
      //                    exp = trace;
      //                }
      if (content == null) content = exp
      else {
        content = Block.makeBlock(exp, content)
        content.setLocation(allocateLocation)
      }
    }
    if (attributeSets != null) {
      val use = UseAttributeSet.makeUseAttributeSets(attributeSets, this)
      if (content == null) content = use
      else {
        content = Block.makeBlock(use, content)
        content.setLocation(allocateLocation)
      }
    }
    if (content == null) content = Literal.makeEmptySequence
    inst.setContentExpression(content)
    inst.setRetainedStaticContext(makeRetainedStaticContext)
    inst.setLocation(allocateLocation)
    inst
  }

  /**
   * Make a top-level literal result element into a stylesheet. This implements
   * the "Simplified Stylesheet" facility.
   *
   * @param topLevel true if this is the top level module of a stylesheet; false if it is included or imported
   * @return the reconstructed stylesheet with an xsl:stylesheet and xsl:template element added
   * @throws XPathException if anything goes wrong
   */
  @throws[XPathException]
  def makeStylesheet(topLevel: Boolean) = { // the implementation grafts the LRE node onto a containing xsl:template and
    // xsl:stylesheet
    val nodeFactory = getCompilation.getStyleNodeFactory(topLevel)
    if (!isInScopeNamespace(NamespaceConstant.XSLT)) {
      var message = null
      if (getLocalPart == "stylesheet" || getLocalPart == "transform") message = "Namespace for stylesheet element should be " + NamespaceConstant.XSLT
      else message = "The supplied file does not appear to be a stylesheet"
      val err = new XPathException(message)
      err.setLocation(allocateLocation)
      err.setErrorCode("XTSE0150")
      err.setIsStaticError(true)
      //noinspection EmptyCatchBlock
      compileError(err)
      throw err
    }
    // check there is an xsl:version attribute (it's mandatory), and copy
    // it to the new xsl:stylesheet element
    val version = getAttributeValue(NamespaceConstant.XSLT, "version")
    if (version == null) {
      val err = new XPathException("Simplified stylesheet: xsl:version attribute is missing")
      err.setErrorCode("XTSE0150")
      err.setIsStaticError(true)
      err.setLocation(allocateLocation)
      compileError(err)
      throw err
    }
    try {
      val oldRoot = getRoot.asInstanceOf[DocumentImpl]
      val builder = new LinkedTreeBuilder(getConfiguration.makePipelineConfiguration)
      builder.setNodeFactory(nodeFactory)
      builder.setSystemId(this.getSystemId)
      builder.open()
      builder.startDocument(ReceiverOption.NONE)
      val loc = Loc.NONE
      val map = getAllNamespaces.put("xsl", NamespaceConstant.XSLT)
      var atts = EmptyAttributeMap.getInstance
      atts = atts.put(new AttributeInfo(new NoNamespaceName("version"), BuiltInAtomicType.UNTYPED_ATOMIC, version, loc, ReceiverOption.NONE))
      val st = StandardNames.XSL_STYLESHEET
      builder.startElement(new CodedName(st, "xsl", getNamePool), Untyped.getInstance, atts, map, loc, ReceiverOption.NONE)
      atts = EmptyAttributeMap.getInstance
      atts = atts.put(new AttributeInfo(new NoNamespaceName("match"), BuiltInAtomicType.UNTYPED_ATOMIC, "/", loc, ReceiverOption.NONE))
      val te = StandardNames.XSL_TEMPLATE
      builder.startElement(new CodedName(te, "xsl", getNamePool), Untyped.getInstance, atts, map, loc, ReceiverOption.NONE)
      builder.graftElement(this)
      builder.endElement()
      builder.endElement()
      builder.endDocument()
      builder.close()
      val newRoot = builder.getCurrentRoot.asInstanceOf[DocumentImpl]
      newRoot.graftLocationMap(oldRoot)
      newRoot
    } catch {
      case err: XPathException =>
        //TransformerConfigurationException e = new TransformerConfigurationException(err);
        err.setLocation(allocateLocation)
        throw err
    }
  }

  /**
   * Get a name identifying the object of the expression, for example a function name, template name,
   * variable name, key name, element name, etc. This is used only where the name is known statically.
   * If there is no name, the value will be -1.
   *
   * @return the name of the literal result element
   */
  override def getObjectName = new StructuredQName(getPrefix, getURI, getLocalPart)
}