////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.instruct.Choose
import net.sf.saxon.expr.parser._
import net.sf.saxon.functions.LocalName_1
import net.sf.saxon.functions.PositionAndLast
import net.sf.saxon.functions.SystemFunction
import net.sf.saxon.functions.registry.VendorFunctionSetHE
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.pattern._
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.value._
import java.math.BigInteger

/**
 * A FilterExpression contains a base expression and a filter predicate, which may be an
 * integer expression (positional filter), or a boolean expression (qualifier)
 */
object FilterExpression {
  val FILTERED = 10000
  val FILTER_PREDICATE = new OperandRole(OperandRole.USES_NEW_FOCUS | OperandRole.HIGHER_ORDER, OperandUsage.INSPECTION, SequenceType.ANY_SEQUENCE)

  /**
   * Construct an expression that obtains the effective boolean value of a given expression,
   * by wrapping it in a call of the boolean() function
   *
   * @param in the given expression
   * @return an expression that wraps the given expression in a call to the fn:boolean() function
   */
  private def forceToBoolean(in: Expression): Expression = {
    if (in.getItemType.getPrimitiveType == StandardNames.XS_BOOLEAN) return in
    SystemFunction.makeCall("boolean", in.getRetainedStaticContext, in)
  }

  @throws[XPathException]
  private def tryToRewritePositionalFilterSupport(start: Expression, comparand: Expression, operator: Int, th: TypeHierarchy) = if (th.isSubType(comparand.getItemType, BuiltInAtomicType.INTEGER)) operator match {
    case Token.FEQ =>
      if (Literal.isConstantOne(comparand)) FirstItemExpression.makeFirstItemExpression(start)
      else if (comparand.isInstanceOf[Literal] && (comparand.asInstanceOf[Literal]).getValue.asInstanceOf[IntegerValue].asBigInteger.compareTo(BigInteger.ZERO) <= 0) Literal.makeEmptySequence
      else new SubscriptExpression(start, comparand)
    case Token.FLT =>
      val args = new Array[Expression](3)
      args(0) = start
      args(1) = Literal.makeLiteral(Int64Value.makeIntegerValue(1), start)
      if (Literal.isAtomic(comparand)) {
        val n = (comparand.asInstanceOf[Literal]).getValue.asInstanceOf[NumericValue].longValue
        args(2) = Literal.makeLiteral(Int64Value.makeIntegerValue(n - 1), start)
      }
      else {
        val decrement = new ArithmeticExpression(comparand, Token.MINUS, Literal.makeLiteral(Int64Value.makeIntegerValue(1), start))
        decrement.setCalculator(Calculator.getCalculator( // bug 2704
          StandardNames.XS_INTEGER, StandardNames.XS_INTEGER, Calculator.MINUS, true))
        args(2) = decrement
      }
      SystemFunction.makeCall("subsequence", start.getRetainedStaticContext, args)
    case Token.FLE =>
      val args = new Array[Expression](3)
      args(0) = start
      args(1) = Literal.makeLiteral(Int64Value.makeIntegerValue(1), start)
      args(2) = comparand
      SystemFunction.makeCall("subsequence", start.getRetainedStaticContext, args)
    case Token.FNE =>
      SystemFunction.makeCall("remove", start.getRetainedStaticContext, start, comparand)
    case Token.FGT =>
      val args = new Array[Expression](2)
      args(0) = start
      if (Literal.isAtomic(comparand)) {
        val n = (comparand.asInstanceOf[Literal]).getValue.asInstanceOf[NumericValue].longValue
        args(1) = Literal.makeLiteral(Int64Value.makeIntegerValue(n + 1), start)
      }
      else args(1) = new ArithmeticExpression(comparand, Token.PLUS, Literal.makeLiteral(Int64Value.makeIntegerValue(1), start))
      SystemFunction.makeCall("subsequence", start.getRetainedStaticContext, args)
    case Token.FGE =>
      SystemFunction.makeCall("subsequence", start.getRetainedStaticContext, start, comparand)
    case _ =>
      throw new IllegalArgumentException("operator")
  }
  else { // the comparand is not known statically to be an integer
    operator match {
      case Token.FEQ =>
        new SubscriptExpression(start, comparand)
      case Token.FLT =>
        // rewrite SEQ[position() lt V] as
        // let $N := V return subsequence(SEQ, 1, if (is-whole-number($N)) then $N-1 else floor($N)))
        val let = new LetExpression
        let.setRequiredType(SequenceType.makeSequenceType(comparand.getItemType, StaticProperty.ALLOWS_ONE))
        let.setVariableQName(new StructuredQName("pp", NamespaceConstant.SAXON, "pp" + let.hashCode))
        let.setSequence(comparand)
        val isWholeArg = new LocalVariableReference(let)
        val arithArg = new LocalVariableReference(let)
        val floorArg = new LocalVariableReference(let)
        val isWhole = VendorFunctionSetHE.getInstance.makeFunction("is-whole-number", 1).makeFunctionCall(isWholeArg)
        val minusOne = new ArithmeticExpression(arithArg, Token.MINUS, Literal.makeLiteral(Int64Value.makeIntegerValue(1), start))
        val floor = SystemFunction.makeCall("floor", start.getRetainedStaticContext, floorArg)
        val choice = Choose.makeConditional(isWhole, minusOne, floor)
        val subs = SystemFunction.makeCall("subsequence", start.getRetainedStaticContext, start, Literal.makeLiteral(Int64Value.makeIntegerValue(1), start), choice)
        let.setAction(subs)
        //decl.fixupReferences(let);
        let
      case Token.FLE =>
        val floor = SystemFunction.makeCall("floor", start.getRetainedStaticContext, comparand)
        SystemFunction.makeCall("subsequence", start.getRetainedStaticContext, start, Literal.makeLiteral(Int64Value.makeIntegerValue(1), start), floor)
      case Token.FNE =>
        // rewrite SEQ[position() ne V] as
        // let $N := V return remove(SEQ, if (is-whole-number($N)) then xs:integer($N) else 0)
        val let = new LetExpression
        ExpressionTool.copyLocationInfo(start, let)
        let.setRequiredType(SequenceType.makeSequenceType(comparand.getItemType, StaticProperty.ALLOWS_ONE))
        let.setVariableQName(new StructuredQName("pp", NamespaceConstant.SAXON, "pp" + let.hashCode))
        let.setSequence(comparand)
        val isWholeArg = new LocalVariableReference(let)
        val castArg = new LocalVariableReference(let)
        val isWhole = VendorFunctionSetHE.getInstance.makeFunction("is-whole-number", 1).makeFunctionCall(isWholeArg)
        ExpressionTool.copyLocationInfo(start, isWhole)
        val cast = new CastExpression(castArg, BuiltInAtomicType.INTEGER, false)
        ExpressionTool.copyLocationInfo(start, cast)
        val choice = Choose.makeConditional(isWhole, cast, Literal.makeLiteral(Int64Value.makeIntegerValue(0), start))
        val rem = SystemFunction.makeCall("remove", start.getRetainedStaticContext, start, choice)
        let.setAction(rem)
        let
      case Token.FGT =>
        // rewrite SEQ[position() gt V] as
        // let $N := V return subsequence(SEQ, if (is-whole-number($N)) then $N+1 else ceiling($N)))
        val let = new LetExpression
        let.setRequiredType(SequenceType.makeSequenceType(comparand.getItemType, StaticProperty.ALLOWS_ONE))
        let.setVariableQName(new StructuredQName("pp", NamespaceConstant.SAXON, "pp" + let.hashCode))
        let.setSequence(comparand)
        val isWholeArg = new LocalVariableReference(let)
        val arithArg = new LocalVariableReference(let)
        val ceilingArg = new LocalVariableReference(let)
        val isWhole = VendorFunctionSetHE.getInstance.makeFunction("is-whole-number", 1).makeFunctionCall(isWholeArg)
        val plusOne = new ArithmeticExpression(arithArg, Token.PLUS, Literal.makeLiteral(Int64Value.makeIntegerValue(1), start))
        val ceiling = SystemFunction.makeCall("ceiling", start.getRetainedStaticContext, ceilingArg)
        val choice = Choose.makeConditional(isWhole, plusOne, ceiling)
        val subs = SystemFunction.makeCall("subsequence", start.getRetainedStaticContext, start, choice)
        let.setAction(subs)
        let
      case Token.FGE =>
        // rewrite SEQ[position() ge V] => subsequence(SEQ, ceiling(V))
        val ceiling = SystemFunction.makeCall("ceiling", start.getRetainedStaticContext, comparand)
        SystemFunction.makeCall("subsequence", start.getRetainedStaticContext, start, ceiling)
      case _ =>
        throw new IllegalArgumentException("operator")
    }
  }

  /**
   * Determine whether an expression, when used as a filter, is potentially positional;
   * that is, where it either contains a call on position() or last(), or where it is capable of returning
   * a numeric result.
   *
   * @param exp the expression to be examined
   * @param th  the type hierarchy cache
   * @return true if the expression depends on position() or last() explicitly or implicitly
   */
  def isPositionalFilter(exp: Expression, th: TypeHierarchy): Boolean = {
    val `type` = exp.getItemType
    if (`type` == BuiltInAtomicType.BOOLEAN) { // common case, get it out of the way quickly
      return isExplicitlyPositional(exp)
    }
    `type` == BuiltInAtomicType.ANY_ATOMIC || `type`.isInstanceOf[AnyItemType] || `type` == BuiltInAtomicType.INTEGER || `type` == NumericType.getInstance || NumericType.isNumericType(`type`) || isExplicitlyPositional(exp)
  }

  /**
   * Determine whether an expression, when used as a filter, has an explicit dependency on position() or last()
   *
   * @param exp the expression being tested
   * @return true if the expression is explicitly positional, that is, if it contains an explicit call on
   *         position() or last()
   */
  private def isExplicitlyPositional(exp: Expression) = (exp.getDependencies & (StaticProperty.DEPENDS_ON_POSITION | StaticProperty.DEPENDS_ON_LAST)) ne 0
}

final class FilterExpression(val base: Expression, val filter: Expression)

/**
 * Constructor
 *
 * @param base   The base expression to be filtered.
 * @param filter An expression defining the filter predicate
 */
  extends BinaryExpression(base, Token.LSQB, filter) with ContextSwitchingExpression {
  baseValue.setFiltered(true)
  private var filterIsPositional = false // true if the value of the filter might depend on
  // the context position
  private var filterIsSingletonBoolean = false // true if the filter expression always returns a single boolean
  private var filterIsIndependent = false // true if the filter expression does not
  // depend on the context item or position. (It may depend on last()).
  var doneReorderingPredicates = false

  override protected def getOperandRole(arg: Int) = if (arg == 0) OperandRole.SAME_FOCUS_ACTION
  else FilterExpression.FILTER_PREDICATE

  def getBase = getLhsExpression

  def setBase(base: Expression) = setLhsExpression(base)

  /**
   * Get the filter expression
   *
   * @return the expression acting as the filter predicate
   */
  def getFilter = getRhsExpression

  def setFilter(filter: Expression) = setRhsExpression(filter)

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "filter"

  /**
   * Get the data type of the items returned
   *
   * @return an integer representing the data type
   */
  /*@NotNull*/ override def getItemType: ItemType = { // special case the expression B[. instance of x]
    if (getFilter.isInstanceOf[InstanceOfExpression] && getFilter.asInstanceOf[InstanceOfExpression].getBaseExpression.isInstanceOf[ContextItemExpression]) return getFilter.asInstanceOf[InstanceOfExpression].getRequiredItemType
    getBase.getItemType
  }

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @param contextItemType the static type of the context item
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   */
  override def getStaticUType(contextItemType: UType) = getBase.getStaticUType(contextItemType)

  /**
   * Get the base expression
   *
   * @return the base expression being filtered
   */
  override def getSelectExpression = getBase

  /**
   * Ask if the filter is positional (used from bytecode)
   *
   * @return true filter is positional
   */
  def isFilterIsPositional = filterIsPositional

  /**
   * Get the subexpression that is evaluated in the new context
   *
   * @return the subexpression evaluated in the context set by the controlling expression
   */
  override def getActionExpression = getFilter

  /**
   * Determine if the filter is positional
   *
   * @param th the Type Hierarchy (for cached access to type information)
   * @return true if the value of the filter depends on the position of the item against
   *         which it is evaluated
   */
  def isPositional(th: TypeHierarchy) = FilterExpression.isPositionalFilter(getFilter, th)

  /**
   * Test if the filter always returns a singleton boolean.
   * <p>This information is available only after typeCheck() has been called.</p>
   *
   * @return true if the filter is a simple boolean expression
   */
  def isSimpleBooleanFilter = filterIsSingletonBoolean

  /**
   * Determine whether the filter is independent of the context item and position
   * <p>This information is available only after typeCheck() has been called.</p>
   *
   * @return true if the filter is a numeric value that does not depend on the context item or position
   */
  def isIndependentFilter = filterIsIndependent

  /**
   * Simplify an expression
   *
   * @throws XPathException if any failure occurs
   */
  @throws[XPathException]
  override def simplify: Expression = {
    setBase(getBase.simplify)
    setFilter(getFilter.simplify)
    // ignore the filter if the base expression is an empty sequence
    if (Literal.isEmptySequence(getBase)) return getBase
    // check whether the filter is a constant true() or false()
    if (getFilter.isInstanceOf[Literal] && !(getFilter.asInstanceOf[Literal]).getValue.isInstanceOf[NumericValue]) try if (getFilter.effectiveBooleanValue(new EarlyEvaluationContext(getConfiguration))) return getBase
    else return Literal.makeEmptySequence
    catch {
      case e: XPathException =>
        e.maybeSetLocation(getLocation)
        throw e
    }
    // check whether the filter is [last()] (note, [position()=last()] is handled elsewhere)
    if (getFilter.isCallOn(classOf[PositionAndLast.Last])) {
      setFilter(new IsLastExpression(true))
      adoptChildExpression(getFilter)
    }
    this
  }

  /**
   * Type-check the expression
   *
   * @param visitor     the expression visitor
   * @param contextInfo return the expression after type-checking (potentially modified to add run-time
   *                    checks and/or conversions)
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    getLhs.typeCheck(visitor, contextInfo)
    getBase.setFiltered(true)
    if (Literal.isEmptySequence(getBase)) return getBase
    val baseItemType = config.makeContextItemStaticInfo(getSelectExpression.getItemType, false)
    baseItemType.setContextSettingExpression(getBase)
    getRhs.typeCheck(visitor, baseItemType)
    // The filter expression usually doesn't need to be sorted
    val filter2 = ExpressionTool.unsortedIfHomogeneous(getFilter, visitor.isOptimizeForStreaming)
    if (filter2 ne getFilter) setFilter(filter2)
    // detect head expressions (E[1]) and treat them specially
    if (Literal.isConstantOne(getFilter)) {
      val fie = FirstItemExpression.makeFirstItemExpression(getBase)
      ExpressionTool.copyLocationInfo(this, fie)
      return fie
    }
    // determine whether the filter might depend on position
    filterIsPositional = FilterExpression.isPositionalFilter(getFilter, th)
    // determine whether the filter always evaluates to a single boolean
    filterIsSingletonBoolean = getFilter.getCardinality == StaticProperty.EXACTLY_ONE && getFilter.getItemType == BuiltInAtomicType.BOOLEAN
    // determine whether the filter expression is independent of the focus
    filterIsIndependent = (getFilter.getDependencies & StaticProperty.DEPENDS_ON_FOCUS) eq 0
    ExpressionTool.resetStaticProperties(this)
    this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val opt = visitor.obtainOptimizer
    val tracing = config.getBooleanProperty(Feature.TRACE_OPTIMIZER_DECISIONS)
    val th = config.getTypeHierarchy
    getLhs.optimize(visitor, contextItemType)
    getBase.setFiltered(true)
    val baseItemType = config.makeContextItemStaticInfo(getSelectExpression.getItemType, false)
    baseItemType.setContextSettingExpression(getBase)
    getRhs.optimize(visitor, baseItemType)
    val filter2 = ExpressionTool.unsortedIfHomogeneous(getFilter, visitor.isOptimizeForStreaming)
    if (filter2 ne getFilter) setFilter(filter2)
    // Rewrite child::X[last()] as child::X[empty(following-sibling::X)] - especially useful for patterns
    if (getFilter.isInstanceOf[IsLastExpression] && getFilter.asInstanceOf[IsLastExpression].getCondition && getBase.isInstanceOf[AxisExpression] && getBase.asInstanceOf[AxisExpression].getAxis == AxisInfo.CHILD) {
      val test = getBase.asInstanceOf[AxisExpression].getNodeTest
      val fs = new AxisExpression(AxisInfo.FOLLOWING_SIBLING, test)
      setFilter(SystemFunction.makeCall("empty", getRetainedStaticContext, fs))
      if (tracing) Optimizer.trace(config, "Replaced [last()] predicate by test for following-sibling", this)
    }
    // rewrite axis::*[local-name() = 'literal'] as axis::*:local (people write this a lot in XSLT 1.0)
    if (getBase.isInstanceOf[AxisExpression] && (getBase.asInstanceOf[AxisExpression].getNodeTest eq NodeKindTest.ELEMENT) && getFilter.isInstanceOf[CompareToStringConstant] && getFilter.asInstanceOf[CompareToStringConstant].getSingletonOperator == Token.FEQ && getFilter.asInstanceOf[CompareToStringConstant].getLhsExpression.isCallOn(classOf[LocalName_1]) && (getFilter.asInstanceOf[CompareToStringConstant]).getLhsExpression.asInstanceOf[SystemFunctionCall].getArg(0).isInstanceOf[ContextItemExpression]) {
      val ax2 = new AxisExpression(getBase.asInstanceOf[AxisExpression].getAxis, new LocalNameTest(config.getNamePool, Type.ELEMENT, getFilter.asInstanceOf[CompareToStringConstant].getComparand))
      ExpressionTool.copyLocationInfo(this, ax2)
      return ax2
    }
    // if the result of evaluating the filter cannot include numeric values, then we can use
    // its effective boolean value
    val filterType = getFilter.getItemType
    if (!th.isSubType(filterType, BuiltInAtomicType.BOOLEAN) && (th.relationship(filterType, NumericType.getInstance) eq Affinity.DISJOINT)) {
      val f = SystemFunction.makeCall("boolean", getRetainedStaticContext, getFilter)
      setFilter(f.optimize(visitor, baseItemType))
    }
    // the filter expression may have been reduced to a constant boolean by previous optimizations
    if (getFilter.isInstanceOf[Literal] && getFilter.asInstanceOf[Literal].getValue.isInstanceOf[BooleanValue]) if ((getFilter.asInstanceOf[Literal]).getValue.asInstanceOf[BooleanValue].getBooleanValue) {
      if (tracing) opt.trace("Redundant filter removed", getBase)
      return getBase
    }
    else {
      val result = Literal.makeEmptySequence
      ExpressionTool.copyLocationInfo(this, result)
      if (tracing) opt.trace("Filter expression eliminated because predicate is always false", result)
      return result
    }
    filterIsPositional = FilterExpression.isPositionalFilter(getFilter, th)
    filterIsSingletonBoolean = getFilter.getCardinality == StaticProperty.EXACTLY_ONE && getFilter.getItemType == BuiltInAtomicType.BOOLEAN
    // determine whether the filter is indexable
    if (!filterIsPositional && !visitor.isOptimizeForStreaming) {
      val isIndexable = opt.isIndexableFilter(getFilter)
      // If the filter is indexable consider creating a key, or an indexed filter expression
      // (This happens in Saxon-EE only)
      if (isIndexable != 0) {
        val contextIsDoc = contextItemType != null && (contextItemType.getItemType ne ErrorType.getInstance) && th.isSubType(contextItemType.getItemType, NodeKindTest.DOCUMENT)
        val f = opt.tryIndexedFilter(this, visitor, isIndexable > 0, contextIsDoc)
        if (f ne this) return f.typeCheck(visitor, contextItemType).optimize(visitor, contextItemType)
      }
    }
    // if the filter is positional, try changing f[a and b] to f[a][b] to increase
    // the chances of finishing early.
    if (filterIsPositional && getFilter.isInstanceOf[BooleanExpression] && getFilter.asInstanceOf[BooleanExpression].operator == Token.AND) {
      val bf = getFilter.asInstanceOf[BooleanExpression]
      if (FilterExpression.isExplicitlyPositional(bf.getLhsExpression) && !FilterExpression.isExplicitlyPositional(bf.getRhsExpression)) {
        val p0 = FilterExpression.forceToBoolean(bf.getLhsExpression)
        val p1 = FilterExpression.forceToBoolean(bf.getRhsExpression)
        val f1 = new FilterExpression(getBase, p0)
        ExpressionTool.copyLocationInfo(this, f1)
        val f2 = new FilterExpression(f1, p1)
        ExpressionTool.copyLocationInfo(this, f2)
        if (tracing) opt.trace("Composite filter replaced by nested filter expressions", f2)
        return f2.optimize(visitor, contextItemType)
      }
      if (FilterExpression.isExplicitlyPositional(bf.getRhsExpression) && !FilterExpression.isExplicitlyPositional(bf.getLhsExpression)) {
        val p0 = FilterExpression.forceToBoolean(bf.getLhsExpression)
        val p1 = FilterExpression.forceToBoolean(bf.getRhsExpression)
        val f1 = new FilterExpression(getBase, p1)
        ExpressionTool.copyLocationInfo(this, f1)
        val f2 = new FilterExpression(f1, p0)
        ExpressionTool.copyLocationInfo(this, f2)
        if (tracing) opt.trace("Composite filter replaced by nested filter expressions", f2)
        return f2.optimize(visitor, contextItemType)
      }
    }
    if (getFilter.isInstanceOf[IsLastExpression] && getFilter.asInstanceOf[IsLastExpression].getCondition) if (getBase.isInstanceOf[Literal]) setFilter(Literal.makeLiteral(new Int64Value(getBase.asInstanceOf[Literal].getValue.getLength), this))
    else return new LastItemExpression(getBase)
    val subsequence = tryToRewritePositionalFilter(visitor, tracing)
    if (subsequence != null) {
      if (tracing) {
        subsequence.setRetainedStaticContext(getRetainedStaticContext) // Avoids errors in debug explain
        opt.trace("Rewrote Filter Expression as:", subsequence)
      }
      ExpressionTool.copyLocationInfo(this, subsequence)
      return subsequence.simplify.typeCheck(visitor, contextItemType).optimize(visitor, contextItemType)
    }
    // If there are two non-positional filters, consider changing their order based on the estimated cost
    // of evaluation, so we evaluate the cheapest predicates first
    if (!filterIsPositional && !doneReorderingPredicates && !getParentExpression.isInstanceOf[FilterExpression]) {
      val f2 = opt.reorderPredicates(this, visitor, contextItemType)
      if (f2 ne this) {
        f2.doneReorderingPredicates = true
        return f2
      }
    }
    val sequence = tryEarlyEvaluation(visitor)
    if (sequence != null) {
      val value = sequence.materialize
      return Literal.makeLiteral(value, this)
    }
    this
  }

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   *
   * @return the estimated cost
   */
  override def getCost = Math.max(getLhsExpression.getCost + 5 * getRhsExpression.getCost, MAX_COST)

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * For an expression that returns an integer or a sequence of integers, get
   * a lower and upper bound on the values of the integers that may be returned, from
   * static analysis. The default implementation returns null, meaning "unknown" or
   * "not applicable". Other implementations return an array of two IntegerValue objects,
   * representing the lower and upper bounds respectively. The values
   * UNBOUNDED_LOWER and UNBOUNDED_UPPER are used by convention to indicate that
   * the value may be arbitrarily large. The values MAX_STRING_LENGTH and MAX_SEQUENCE_LENGTH
   * are used to indicate values limited by the size of a string or the size of a sequence.
   *
   * @return the lower and upper bounds of integer values in the result, or null to indicate
   *         unknown or not applicable.
   */
  override def getIntegerBounds = getBase.getIntegerBounds

  private def tryEarlyEvaluation(visitor: ExpressionVisitor): Sequence = { // Attempt early evaluation of a filter expression if the base sequence is constant and the
    // filter depends only on the context. (This can't be done if, for example, the predicate uses
    // local variables, even variables declared within the predicate)
    try if (getBase.isInstanceOf[Literal] && !ExpressionTool.refersToVariableOrFunction(getFilter) && ((getFilter.getDependencies & ~StaticProperty.DEPENDS_ON_FOCUS) eq 0)) {
      val context = visitor.getStaticContext.makeEarlyEvaluationContext
      return iterate(context).materialize
    }
    catch {
      case e: Exception =>
        // can happen for a variety of reasons, for example the filter references a global parameter,
        // references the doc() function, uses element constructors, etc.
        return null
    }
    null
  }

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   *
   * @param pathMap        the PathMap to which the expression should be added
   * @param pathMapNodeSet the PathMapNodeSet to which the paths embodied in this expression should be added
   * @return the pathMapNode representing the focus established by this expression, in the case where this
   *         expression is the first operand of a path expression or filter expression
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = {
    val target = getBase.addToPathMap(pathMap, pathMapNodeSet)
    getFilter.addToPathMap(pathMap, target)
    target
  }

  /**
   * Attempt to rewrite a filter expression whose predicate is a test of the form
   * [position() op expr] as a call on functions such as subsequence, remove, or saxon:itemAt
   *
   * @param visitor the current expression visitor
   * @return the rewritten expression if a rewrite was possible, or null otherwise
   * @throws XPathException if an error occurs
   */
  @throws[XPathException]
  private def tryToRewritePositionalFilter(visitor: ExpressionVisitor, tracing: Boolean): Expression = {
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    if (getFilter.isInstanceOf[Literal]) {
      val `val` = getFilter.asInstanceOf[Literal].getValue
      if (`val`.isInstanceOf[NumericValue]) {
        var result = null
        val lvalue = `val`.asInstanceOf[NumericValue].asSubscript
        if (lvalue != -1) if (lvalue == 1) result = FirstItemExpression.makeFirstItemExpression(getBase)
        else result = new SubscriptExpression(getBase, getFilter)
        else result = Literal.makeEmptySequence
        if (tracing) Optimizer.trace(config, "Rewriting numeric filter expression with constant subscript", result)
        return result
      }
      else {
        val result = if (ExpressionTool.effectiveBooleanValue(`val`.iterate)) getBase
        else Literal.makeEmptySequence
        if (tracing) Optimizer.trace(config, "Rewriting boolean filter expression with constant subscript", result)
        return result
      }
    }
    if (NumericType.isNumericType(getFilter.getItemType) && !Cardinality.allowsMany(getFilter.getCardinality) && ((getFilter.getDependencies & StaticProperty.DEPENDS_ON_FOCUS) eq 0)) {
      val result = new SubscriptExpression(getBase, getFilter)
      if (tracing) Optimizer.trace(config, "Rewriting numeric filter expression with focus-independent subscript", result)
      return result
    }
    if (getFilter.isInstanceOf[ComparisonExpression]) { //VendorFunctionLibrary lib = getConfiguration().getVendorFunctionLibrary();
      val lhs = getFilter.asInstanceOf[ComparisonExpression].getLhsExpression()
      val rhs = getFilter.asInstanceOf[ComparisonExpression].getRhsExpression()
      var operator = getFilter.asInstanceOf[ComparisonExpression].getSingletonOperator()
      var comparand = null
      if (lhs.isCallOn(classOf[PositionAndLast.Position]) && NumericType.isNumericType(rhs.getItemType)) comparand = rhs
      else if (rhs.isCallOn(classOf[PositionAndLast.Position]) && NumericType.isNumericType(lhs.getItemType)) {
        comparand = lhs
        operator = Token.inverse(operator)
      }
      else return null
      if (ExpressionTool.dependsOnFocus(comparand)) return null
      val card = comparand.getCardinality
      if (Cardinality.allowsMany(card)) return null
      // If the comparand might be an empty sequence, do the base rewrite and then wrap the
      // rewritten expression EXP in "let $n := comparand if exists($n) then EXP else ()
      if (Cardinality.allowsZero(card)) {
        val let = new LetExpression
        let.setRequiredType(SequenceType.makeSequenceType(comparand.getItemType, card))
        let.setVariableQName(new StructuredQName("pp", NamespaceConstant.SAXON, "pp" + let.hashCode))
        let.setSequence(comparand)
        comparand = new LocalVariableReference(let)
        val existsArg = new LocalVariableReference(let)
        val exists = SystemFunction.makeCall("exists", getRetainedStaticContext, existsArg)
        val rewrite = FilterExpression.tryToRewritePositionalFilterSupport(getBase, comparand, operator, th)
        if (rewrite == null) return this
        val choice = Choose.makeConditional(exists, rewrite)
        let.setAction(choice)
        let
      }
      else FilterExpression.tryToRewritePositionalFilterSupport(getBase, comparand, operator, th)
    }
    else if (getFilter.isInstanceOf[IntegerRangeTest]) { // rewrite SEQ[position() = N to M]
      // => let $n := N return subsequence(SEQ, $n, (M - ($n - 1))
      // (precise form is optimized for the case where $n is a literal, especially N = 1)
      val `val` = getFilter.asInstanceOf[IntegerRangeTest].getValue
      if (!`val`.isCallOn(classOf[PositionAndLast])) return null
      var min = getFilter.asInstanceOf[IntegerRangeTest].getMin
      val max = getFilter.asInstanceOf[IntegerRangeTest].getMax
      if (ExpressionTool.dependsOnFocus(min)) return null
      if (ExpressionTool.dependsOnFocus(max)) if (max.isCallOn(classOf[PositionAndLast.Last])) {
        val result = SystemFunction.makeCall("subsequence", getRetainedStaticContext, getBase, min)
        if (tracing) Optimizer.trace(config, "Rewriting numeric range filter expression using subsequence()", result)
        return result
      }
      else return null
      val let = new LetExpression
      let.setRequiredType(SequenceType.SINGLE_INTEGER)
      let.setVariableQName(new StructuredQName("nn", NamespaceConstant.SAXON, "nn" + let.hashCode))
      let.setSequence(min)
      min = new LocalVariableReference(let)
      val min2 = new LocalVariableReference(let)
      val minMinusOne = new ArithmeticExpression(min2, Token.MINUS, Literal.makeLiteral(Int64Value.makeIntegerValue(1), this))
      val length = new ArithmeticExpression(max, Token.MINUS, minMinusOne)
      val subs = SystemFunction.makeCall("subsequence", getRetainedStaticContext, getBase, min, length)
      let.setAction(subs)
      if (tracing) Optimizer.trace(config, "Rewriting numeric range filter expression using subsequence()", subs)
      let
    }
    else null
  }

  /**
   * Replace this expression by a simpler expression that delivers the results without regard
   * to order.
   *
   * @param retainAllNodes set to true if the result must contain exactly the same nodes as the
   *                       original; set to false if the result can eliminate (or introduce) duplicates.
   * @param forStreaming   set to true if optimizing for streaming
   */
  @throws[XPathException]
  override def unordered(retainAllNodes: Boolean, forStreaming: Boolean) = {
    if (!filterIsPositional) setBase(getBase.unordered(retainAllNodes, forStreaming))
    this
  }

  /**
   * Rearrange a filter expression so that predicates that are independent of a given
   * set of range variables come first, allowing them to be promoted along with the base
   * expression
   *
   * @param bindings the given set of range variables
   * @param opt      the Optimizer
   * @param th       the type hierarchy cache
   * @return the expression after promoting independent predicates
   */
  private def promoteIndependentPredicates(bindings: Array[Binding], opt: Optimizer, th: TypeHierarchy): FilterExpression = {
    if (!ExpressionTool.dependsOnVariable(getBase, bindings)) return this
    if (isPositional(th)) return this
    if (getBase.isInstanceOf[FilterExpression]) {
      val fe = getBase.asInstanceOf[FilterExpression]
      if (fe.isPositional(th)) return this
      if (!ExpressionTool.dependsOnVariable(fe.getFilter, bindings)) return this
      if (!ExpressionTool.dependsOnVariable(getFilter, bindings)) {
        val result = new FilterExpression(new FilterExpression(fe.getBase, getFilter).promoteIndependentPredicates(bindings, opt, th), fe.getFilter)
        opt.trace("Reordered filter predicates:", result)
        return result
      }
    }
    this
  }

  /**
   * Get the static cardinality of this expression
   *
   * @return the cardinality. The method attempts to determine the case where the
   *         filter predicate is guaranteed to select at most one item from the sequence being filtered
   */
  override def computeCardinality: Int = {
    if (getFilter.isInstanceOf[Literal] && getFilter.asInstanceOf[Literal].getValue.isInstanceOf[NumericValue]) if ((getFilter.asInstanceOf[Literal]).getValue.asInstanceOf[NumericValue].compareTo(1) == 0 && !Cardinality.allowsZero(getBase.getCardinality)) return StaticProperty.ALLOWS_ONE
    else return StaticProperty.ALLOWS_ZERO_OR_ONE
    if (filterIsIndependent) {
      val filterType = getFilter.getItemType.getPrimitiveItemType
      if ((filterType eq BuiltInAtomicType.INTEGER) || (filterType eq BuiltInAtomicType.DOUBLE) || (filterType eq BuiltInAtomicType.DECIMAL) || (filterType eq BuiltInAtomicType.FLOAT)) return StaticProperty.ALLOWS_ZERO_OR_ONE
      if (getFilter.isInstanceOf[ArithmeticExpression]) return StaticProperty.ALLOWS_ZERO_OR_ONE
    }
    if (getFilter.isInstanceOf[IsLastExpression] && getFilter.asInstanceOf[IsLastExpression].getCondition) return StaticProperty.ALLOWS_ZERO_OR_ONE
    if (!Cardinality.allowsMany(getBase.getCardinality)) return StaticProperty.ALLOWS_ZERO_OR_ONE
    StaticProperty.ALLOWS_ZERO_OR_MORE
  }

  /**
   * Get the static properties of this expression (other than its type). The result is
   * bit-significant. These properties are used for optimizations. In general, if
   * property bit is set, it is true, but if it is unset, the value is unknown.
   *
   * @return the static properties of the expression, as a bit-significant value
   */
  override def computeSpecialProperties = getBase.getSpecialProperties

  /**
   * Is this expression the same as another expression?
   *
   * @param other the expression to be compared with this one
   * @return true if the two expressions are statically equivalent
   */
  override def equals(other: Any): Boolean = {
    if (other.isInstanceOf[FilterExpression]) {
      val f = other.asInstanceOf[FilterExpression]
      return getBase.isEqual(f.getBase) && getFilter.isEqual(f.getFilter)
    }
    false
  }

  /**
   * get HashCode for comparing two expressions
   *
   * @return the hash code
   */
  override def computeHashCode = "FilterExpression".hashCode + getBase.hashCode + getFilter.hashCode

  /**
   * Convert this expression to an equivalent XSLT pattern
   *
   * @param config the Saxon configuration
   * @return the equivalent pattern
   * @throws net.sf.saxon.trans.XPathException if conversion is not possible
   */
  @throws[XPathException]
  override def toPattern(config: Configuration): Pattern = {
    val base = getSelectExpression
    val filter = getFilter
    val th = config.getTypeHierarchy
    val basePattern = base.toPattern(config)
    if (!isPositional(th)) return new BasePatternWithPredicate(basePattern, filter)
    else if (basePattern.isInstanceOf[NodeTestPattern] && basePattern.getItemType.isInstanceOf[NodeTest] && filterIsPositional && base.isInstanceOf[AxisExpression] && base.asInstanceOf[AxisExpression].getAxis == AxisInfo.CHILD && ((filter.getDependencies & StaticProperty.DEPENDS_ON_LAST) eq 0)) if (filter.isInstanceOf[Literal] && filter.asInstanceOf[Literal].getValue.isInstanceOf[IntegerValue]) return new SimplePositionalPattern(basePattern.getItemType.asInstanceOf[NodeTest], (filter.asInstanceOf[Literal]).getValue.asInstanceOf[IntegerValue].longValue.toInt)
    else return new GeneralPositionalPattern(basePattern.getItemType.asInstanceOf[NodeTest], filter)
    if (base.getItemType.isInstanceOf[NodeTest]) new GeneralNodePattern(this, base.getItemType.asInstanceOf[NodeTest])
    else throw new XPathException("The filtered expression in an XSLT 2.0 pattern must be a simple step")
  }

  /**
   * Iterate over the results, returning them in the correct order
   *
   * @param context the dynamic context for the evaluation
   * @return an iterator over the expression results
   * @throws XPathException if any dynamic error occurs
   */
  @throws[XPathException]
  override def iterate(context: XPathContext): SequenceIterator = { // Fast path where the filter value is independent of the focus
    if (filterIsIndependent) try {
      val it = getFilter.iterate(context)
      val first = it.next
      if (first == null) return EmptyIterator.emptyIterator
      if (first.isInstanceOf[NumericValue]) if (it.next != null) ExpressionTool.ebvError("sequence of two or more items starting with a numeric value", getFilter)
      else { // Filter is a constant number
        val pos = first.asInstanceOf[NumericValue].asSubscript
        if (pos != -1) if (getBase.isInstanceOf[VariableReference]) {
          val baseVal = getBase.asInstanceOf[VariableReference].evaluateVariable(context)
          if (baseVal.isInstanceOf[MemoClosure]) {
            val m = baseVal.asInstanceOf[MemoClosure].itemAt(pos - 1)
            return if (m == null) EmptyIterator.emptyIterator
            else m.iterate
          }
          else {
            val m = baseVal.materialize.itemAt(pos - 1)
            return if (m == null) EmptyIterator.emptyIterator
            else m.iterate
          }
        }
        else if (getBase.isInstanceOf[Literal]) {
          val i = getBase.asInstanceOf[Literal].getValue.itemAt(pos - 1)
          return if (i == null) EmptyIterator.emptyIterator
          else i.iterate
        }
        else {
          val baseIter = getBase.iterate(context)
          return SubsequenceIterator.make(baseIter, pos, pos)
        }
        // a non-integer value or non-positive number will never be equal to position()
        return EmptyIterator.emptyIterator
      }
      else { // Filter is focus-independent, but not numeric: need to use the effective boolean value
        var ebv = false
        if (first.isInstanceOf[NodeInfo]) ebv = true
        else if (first.isInstanceOf[BooleanValue]) {
          ebv = first.asInstanceOf[BooleanValue].getBooleanValue
          if (it.next != null) ExpressionTool.ebvError("sequence of two or more items starting with a boolean value", getFilter)
        }
        else if (first.isInstanceOf[StringValue]) {
          ebv = !(first.asInstanceOf[StringValue]).isZeroLength
          if (it.next != null) ExpressionTool.ebvError("sequence of two or more items starting with a boolean value", getFilter)
        }
        else ExpressionTool.ebvError("sequence starting with an atomic value other than a boolean, number, or string", getFilter)
        if (ebv) return getBase.iterate(context)
        else return EmptyIterator.emptyIterator
      }
    } catch {
      case e: XPathException =>
        e.maybeSetLocation(getLocation)
        throw e
    }
    // get an iterator over the base nodes
    val baseIter = getBase.iterate(context)
    // quick exit for an empty sequence
    if (baseIter.isInstanceOf[EmptyIterator]) return baseIter
    if (filterIsPositional && !filterIsSingletonBoolean) new FilterIterator(baseIter, getFilter, context)
    else new FilterIterator.NonNumeric(baseIter, getFilter, context)
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @param rebindings a mutable list of (old binding, new binding) pairs
   *                   that is used to update the bindings held in any
   *                   local variable references that are copied.
   * @return the copy of the original expression
   */
  override def copy(rebindings: RebindingMap) = {
    val fe = new FilterExpression(getBase.copy(rebindings), getFilter.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, fe)
    fe.filterIsIndependent = filterIsIndependent
    fe.filterIsPositional = filterIsPositional
    fe.filterIsSingletonBoolean = filterIsSingletonBoolean
    fe
  }

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "FilterExpression"

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   */
  override def toString = ExpressionTool.parenthesize(getBase) + "[" + getFilter + "]"

  override def toShortString = getBase.toShortString + "[" + getFilter.toShortString + "]"

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   *
   * @param out the ExpressionPresenter to be used
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    out.startElement("filter", this)
    var flags = ""
    if (filterIsIndependent) flags += "i"
    if (filterIsPositional) flags += "p"
    if (filterIsSingletonBoolean) flags += "b"
    out.emitAttribute("flags", flags)
    getBase.`export`(out)
    getFilter.`export`(out)
    out.endElement
  }

  def setFlags(flags: String) = {
    filterIsIndependent = flags.contains("i")
    filterIsPositional = flags.contains("p")
    filterIsSingletonBoolean = flags.contains("b")
  }
}