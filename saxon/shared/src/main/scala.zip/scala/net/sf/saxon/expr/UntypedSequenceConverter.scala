////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.lib.ConversionRules
import net.sf.saxon.model._
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.UntypedAtomicValue

/**
 * An UntypedSequenceConverter is an expression that performs a cast on each member of
 * a supplied sequence that is an untypedAtomic value, while leaving other items unchanged
 */
object UntypedSequenceConverter {
  /**
   * Create an AtomicSequenceConverter that converts all untypedAtomic values in the input sequence to
   * a specified target type, while leaving items other than untypedAtomic unchanged
   *
   * @param config           the Saxon configuration
   * @param operand          the expression that delivers the input sequence
   * @param requiredItemType the type to which untypedAtomic values should be cast, which must either be an
   *                         atomic type or a "plain" union type
   * @return an AtomicSequenceConverter that performs the required conversion
   * @throws net.sf.saxon.trans.XPathException
   * if an error occurs, for example if the target type is namespace-sensitive
   */
    @throws[XPathException]
    def makeUntypedSequenceConverter(config: Configuration, operand: Expression, requiredItemType: PlainType) = {
      val atomicSeqConverter = new UntypedSequenceConverter(operand, requiredItemType)
      val rules = config.getConversionRules
      var untypedConverter = null
      if (requiredItemType.isNamespaceSensitive) throw new XPathException("Cannot convert untyped atomic values to a namespace-sensitive type", "XPTY0117")
      if (requiredItemType.isAtomicType) untypedConverter = rules.getConverter(BuiltInAtomicType.UNTYPED_ATOMIC, requiredItemType.asInstanceOf[AtomicType])
      else if (requiredItemType eq NumericType.getInstance) { // converting untyped to numeric is common, and is effectively the same as converting to double
        untypedConverter = rules.getConverter(BuiltInAtomicType.UNTYPED_ATOMIC, BuiltInAtomicType.DOUBLE)
        atomicSeqConverter.requiredItemType = BuiltInAtomicType.DOUBLE
      }
      else untypedConverter = new StringConverter.StringToUnionConverter(requiredItemType, rules)
      // source type not known statically; create a converter that decides at run-time
      val converter = new UntypedSequenceConverter.UntypedConverter(rules, untypedConverter)
      atomicSeqConverter.setConverter(converter)
      atomicSeqConverter
    }

  /**
   * A Converter that converts untyped atomic values to the required type, while
   * leaving other values unchanged
   */
  class UntypedConverter(val rules: ConversionRules, val converter: Converter)

  /**
   * Create an UntypedConverter
   *
   * @param rules     the conversion rules
   * @param converter the converter to be used in the case where the supplied
   *                  value is untypedAtomic
   */
  //untypedConverter.setConversionRules(rules);
    extends Converter(rules) {
    untypedConverter = converter
    private[expr] var untypedConverter = null

    /*@NotNull*/ override def convert(input: AtomicValue) = if (input.isInstanceOf[UntypedAtomicValue]) untypedConverter.convert(input)
    else input
  }

  def makeUntypedSequenceRejector(config: Configuration, operand: Expression, requiredItemType: PlainType) = {
    val atomicSeqConverter = new UntypedSequenceConverter(operand, requiredItemType)
    val rules = config.getConversionRules
    val untypedConverter = new Converter() { // called when an untyped atomic value is encountered
      override def convert(input: AtomicValue) = {
        val vf = new ValidationFailure("Implicit conversion of untypedAtomic value to " + requiredItemType.toString + " is not allowed")
        vf.setErrorCode("XPTY0117")
        vf.setLocator(operand.getLocation)
        vf
      }
    }
    val converter = new UntypedSequenceConverter.UntypedConverter(rules, untypedConverter)
    atomicSeqConverter.setConverter(converter)
    atomicSeqConverter
  }
}

final class UntypedSequenceConverter(val sequence: Expression, val requiredItemType: PlainType)

/**
 * Constructor
 *
 * @param sequence         this must be a sequence of atomic values. This is not checked; a ClassCastException
 *                         will occur if the precondition is not satisfied.
 * @param requiredItemType the item type to which all items in the sequence should be converted,
 *                         using the rules for "cast as".
 */
  extends AtomicSequenceConverter(sequence, requiredItemType) {
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val e2 = super.typeCheck(visitor, contextInfo)
    if (e2 ne this) return e2
    val th = visitor.getConfiguration.getTypeHierarchy
    val base = getBaseExpression
    if ((th.relationship(base.getItemType, BuiltInAtomicType.UNTYPED_ATOMIC) eq Affinity.DISJOINT) || base.hasSpecialProperty(StaticProperty.NOT_UNTYPED_ATOMIC)) { // operand cannot return untyped atomic values, so there's nothing to convert
      return getBaseExpression
    }
    this
  }

  /**
   * Determine the special properties of this expression
   *
   * @return { @link net.sf.saxon.expr.StaticProperty#NO_NODES_NEWLY_CREATED}.
   */
  override def computeSpecialProperties = {
    val p = super.computeSpecialProperties
    p | StaticProperty.NO_NODES_NEWLY_CREATED | StaticProperty.NOT_UNTYPED_ATOMIC
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings
   */
  override def copy(rebindings: RebindingMap) = {
    val atomicConverter = new UntypedSequenceConverter(getBaseExpression.copy(rebindings), getRequiredItemType)
    ExpressionTool.copyLocationInfo(this, atomicConverter)
    atomicConverter.setConverter(converter)
    atomicConverter.setRoleDiagnostic(getRoleDiagnostic)
    atomicConverter
  }

  /**
   * Determine the data type of the items returned by the expression, if possible
   *
   * @return a value such as Type.STRING, Type.BOOLEAN, Type.NUMBER, Type.NODE,
   *         or Type.ITEM (meaning not known in advance)
   */
  override def getItemType = if (getBaseExpression.getItemType eq BuiltInAtomicType.UNTYPED_ATOMIC) getRequiredItemType
  else {
    val th = getConfiguration.getTypeHierarchy
    Type.getCommonSuperType(getRequiredItemType, getBaseExpression.getItemType, th)
  }

  /**
   * Determine the static cardinality of the expression
   */
  override def computeCardinality = getBaseExpression.getCardinality

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any) = other.isInstanceOf[UntypedSequenceConverter] && getBaseExpression.isEqual(other.asInstanceOf[UntypedSequenceConverter].getBaseExpression)

  /**
   * get HashCode for comparing two expressions.
   */
  override def computeHashCode = super.computeHashCode

  override protected def displayOperator(config: Configuration) = "convertUntyped"

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "convertUntyped"

  override def toShortString = getBaseExpression.toShortString

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("cvUntyped", this)
    destination.emitAttribute("to", AlphaCode.fromItemType(getRequiredItemType))
    if (getRoleDiagnostic != null) destination.emitAttribute("diag", getRoleDiagnostic.save)
    getBaseExpression.`export`(destination)
    destination.endElement
  }
}