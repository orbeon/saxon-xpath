////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.expr.instruct.GlobalContextRequirement
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.trans._
import net.sf.saxon.trans.packages.PackageDetails
import net.sf.saxon.trans.rules.RuleManager
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.value.Whitespace
import java.util

/**
 * Handler for xsl:use-package elements in stylesheet.
 */
class XSLUsePackage extends StyleElement {
  private var nameAtt = null
  private var versionRanges = null
  private var usedPackage = null
  private var acceptors = null

  /**
   * Bind to the package to which this xsl:use-package element refers.
   */
  @throws[XPathException]
  private[style] def findUsedPackage(info: CompilerInfo) = if (usedPackage == null) {
    if (nameAtt == null) nameAtt = Whitespace.trim(getAttributeValue("", "name"))
    if (nameAtt == null) {
      reportAbsence("name")
      nameAtt = "unnamed-package"
    }
    val pack = info.getPackageLibrary.findPackage(nameAtt, getPackageVersionRanges)
    usedPackage = if (pack == null) null
    else pack.loadedPackage
    if (usedPackage == null) {
      compileErrorInAttribute("Package " + nameAtt + " could not be found", "XTSE3000", "name")
      // For error recovery, create an empty package
      usedPackage = getConfiguration.makeStylesheetPackage
      usedPackage.setJustInTimeCompilation(info.isJustInTimeCompilation)
    }
    val gcr = usedPackage.getContextItemRequirements
    if (gcr != null && !gcr.isMayBeOmitted) compileError("Package " + getAttributeValue("name") + " requires a global context item, so it cannot be used as a library package", "XTTE0590")
  }

  /**
   * Get the package to which this xsl:use-package element refers. Assumes that findPackage()
   * has already been called.
   *
   * @return the package that is referenced.
   */
  override def getUsedPackage = usedPackage

  /**
   * Get the ranges of package versions this use-package directive will accept.
   * <p>
   * <p>This will involve processing the attributes once to derive any ranges declared (and the name of the required package).
   * If no range is defined, the catchall '*' is assumed. </p>
   *
   * @return the ranges of versions of the named package that this declaration will accept
   * @throws XPathException should not happen
   */
  @throws[XPathException]
  private def getPackageVersionRanges = {
    if (versionRanges == null) prepareAttributes()
    versionRanges
  }

  override protected def prepareAttributes() = {
    val atts = attributes
    var ranges = "*"
    import scala.collection.JavaConversions._
    for (att <- atts) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      if (f == "name") nameAtt = Whitespace.trim(att.getValue)
      else if (f == "package-version") ranges = Whitespace.trim(att.getValue).replaceAll("\\\\", "")
      else checkUnknownAttribute(attName)
    }
    try versionRanges = new PackageVersionRanges(ranges)
    catch {
      case e: XPathException =>
        compileError(e)
    }
  }

  override def isDeclaration = true

  override def validate(decl: ComponentDeclaration) = {
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.getNodeKind == Type.TEXT) compileError("Character content is not allowed as a child of xsl:use-package")
      else { //noinspection StatementWithEmptyBody
        if (child.isInstanceOf[XSLAccept] || child.isInstanceOf[XSLOverride]) {
          // no action
        }
        else compileError("Child element " + Err.wrap(child.getDisplayName, Err.ELEMENT) + " is not allowed as a child of xsl:use-package", "XTSE0010")
      }
    }
  }

  @throws[XPathException]
  private def getExplicitAcceptedComponentNames = {
    val explicitAccepts = new util.HashSet[SymbolicName]
    import scala.collection.JavaConversions._
    for (child <- children(classOf[XSLAccept].isInstance)) {
      val explicitComponentTests = child.asInstanceOf[XSLAccept].getExplicitComponentTests
      import scala.collection.JavaConversions._
      for (test <- explicitComponentTests) {
        val name = test.getSymbolicNameIfExplicit
        explicitAccepts.add(name)
      }
    }
    explicitAccepts
  }

  @throws[XPathException]
  override def postValidate() = {
    import scala.collection.JavaConversions._
    for (curr <- children) {
      if (curr.isInstanceOf[XSLOverride] || curr.isInstanceOf[XSLAccept]) curr.asInstanceOf[StyleElement].postValidate()
    }
    val accepts = getExplicitAcceptedComponentNames
    val overrides = getNamedOverrides
    if (!accepts.isEmpty) {
      import scala.collection.JavaConversions._
      for (o <- overrides) {
        if (accepts.contains(o)) compileError("Cannot accept and override the same component (" + o + ")", "XTSE3051")
        if (o.getComponentKind == StandardNames.XSL_FUNCTION) { // Bug 4326: where xsl:accept gives the function QName but not the arity, the entry will have an arity of -1
          val n = new SymbolicName.F(o.getComponentName, -1)
          if (accepts.contains(n)) compileError("Cannot accept and override the same function (" + o + ")", "XTSE3051")
        }
      }
    }
  }

  /**
   * Get the child xsl:accept elements
   *
   * @return the list of child xsl:accept elements
   */
  private[style] def getAcceptors = {
    if (this.acceptors == null) {
      acceptors = new util.ArrayList[XSLAccept]
      import scala.collection.JavaConversions._
      for (decl <- children(classOf[XSLAccept].isInstance)) {
        acceptors.add(decl.asInstanceOf[XSLAccept])
      }
    }
    acceptors
  }

  /**
   * Process all the xsl:override declarations in the xsl:use-package, adding the overriding named components
   * to the list of top-level declarations
   *
   * @param module    the top-level stylesheet module of this package
   * @param topLevel  the list of declarations in this package (to which this method appends)
   * @param overrides set of named components for which this xsl:use-package provides an override
   *                  (which this method populates).
   * @throws XPathException in the event of an error.
   */
  @throws[XPathException]
  private[style] def gatherNamedOverrides(module: PrincipalStylesheetModule, topLevel: util.List[ComponentDeclaration], overrides: util.Set[SymbolicName]): Unit = {
    if (usedPackage == null) return // error already reported
    import scala.collection.JavaConversions._
    for (`override` <- children(classOf[XSLOverride].isInstance)) {
      import scala.collection.JavaConversions._
      for (overridingDeclaration <- `override`.children(classOf[StylesheetComponent].isInstance)) {
        val decl = new ComponentDeclaration(module, overridingDeclaration.asInstanceOf[StyleElement])
        topLevel.add(decl)
        val name = overridingDeclaration.asInstanceOf[StylesheetComponent].getSymbolicName
        if (name != null) overrides.add(name)
        else if (overridingDeclaration.isInstanceOf[XSLTemplate] && overridingDeclaration.getAttributeValue("", "match") != null) {
          val modeNames = overridingDeclaration.asInstanceOf[XSLTemplate].getModeNames
          for (m <- modeNames) {
            overrides.add(new SymbolicName(StandardNames.XSL_MODE, m))
          }
        }
      }
    }
  }

  private def getNamedOverrides = {
    val overrides = new util.HashSet[SymbolicName]
    val kids = iterateAxis(AxisInfo.CHILD, NodeKindTest.ELEMENT)
    var `override` = null
    while ( {
      (`override` = kids.next) != null
    }) if (`override`.isInstanceOf[XSLOverride]) {
      val overridings = `override`.iterateAxis(AxisInfo.CHILD, NodeKindTest.ELEMENT)
      var overridingDeclaration = null
      while ( {
        (overridingDeclaration = overridings.next) != null
      }) if (overridingDeclaration.isInstanceOf[StylesheetComponent]) {
        val name = overridingDeclaration.asInstanceOf[StylesheetComponent].getSymbolicName
        if (name != null) overrides.add(name)
      }
    }
    overrides
  }

  /**
   * Process all the xsl:override declarations in the xsl:use-package, adding the overriding template rules
   * to the list of top-level declarations
   *
   * @param module    the top-level stylesheet module of this package (the using package)
   * @param overrides set of named components for which this xsl:use-package provides an override
   *                  (which this method populates). If the xsl:override contains any template rules, then the named
   *                  mode will be included in this list, but the individual template rules will not be added to
   *                  the top-level list.
   * @throws XPathException in the event of an error.
   */
  @throws[XPathException]
  private[style] def gatherRuleOverrides(module: PrincipalStylesheetModule, overrides: util.Set[SymbolicName]) = {
    val thisPackage = module.getStylesheetPackage
    val ruleManager = module.getRuleManager
    val kids = iterateAxis(AxisInfo.CHILD, NodeKindTest.ELEMENT)
    val overriddenModes = new util.HashSet[SymbolicName]
    // Process all template rules within xsl:override elements
    var `override` = null
    while ( {
      (`override` = kids.next) != null
    }) if (`override`.isInstanceOf[XSLOverride]) {
      val overridings = `override`.iterateAxis(AxisInfo.CHILD, NodeKindTest.ELEMENT)
      var overridingDeclaration = null
      while ( {
        (overridingDeclaration = overridings.next) != null
      }) if (overridingDeclaration.isInstanceOf[XSLTemplate] && overridingDeclaration.getAttributeValue("", "match") != null) {
        val modeNames = overridingDeclaration.asInstanceOf[XSLTemplate].getModeNames
        for (modeName <- modeNames) {
          if (modeName == Mode.OMNI_MODE) {
            overridingDeclaration.asInstanceOf[StyleElement].compileError("The mode name #all must not appear in an overriding template rule", "XTSE3440")
            continue //todo: continue is not supported
          }
          val symbolicName = new SymbolicName(StandardNames.XSL_MODE, modeName)
          overrides.add(symbolicName)
          overriddenModes.add(symbolicName)
          val derivedComponent = thisPackage.getComponent(symbolicName).asInstanceOf[Component.M]
          if (derivedComponent == null) {
            overridingDeclaration.asInstanceOf[StyleElement].compileError("Mode " + modeName.getDisplayName + " is not defined in the used package", "XTSE3060")
            continue //todo: continue is not supported
          }
          if (derivedComponent.getBaseComponent == null) {
            overridingDeclaration.asInstanceOf[StyleElement].compileError("Mode " + modeName.getDisplayName + " cannot be overridden because it is local to this package", "XTSE3440")
            continue //todo: continue is not supported
          }
          val usedComponent = derivedComponent.getBaseComponent.asInstanceOf[Component.M]
          if (usedComponent.getVisibility eq Visibility.FINAL) {
            overridingDeclaration.asInstanceOf[StyleElement].compileError("Cannot define overriding template rules in mode " + modeName.getDisplayName + " because it has visibility=final", "XTSE3060")
            continue //todo: continue is not supported
          }
          val usedMode = usedComponent.getActor
          if (usedComponent.getVisibility ne Visibility.PUBLIC) {
            overridingDeclaration.asInstanceOf[StyleElement].compileError("Cannot override template rules in mode " + modeName.getDisplayName + ", because the mode is not public", "XTSE3060")
            continue //todo: continue is not supported
          }
          if (derivedComponent.getActor eq usedMode) {
            val overridingMode = new SimpleMode(modeName)
            val newCompoundMode = new CompoundMode(usedMode, overridingMode)
            newCompoundMode.setDeclaringComponent(derivedComponent)
            ruleManager.registerMode(newCompoundMode)
            derivedComponent.setActor(newCompoundMode)
          }
        }
      }
    }
    // Now process all public/final modes in the used package that have not been overridden by new template rules
    val usedPackageRuleManager = usedPackage.getRuleManager
    if (usedPackageRuleManager != null) {
      import scala.collection.JavaConversions._
      for (m <- usedPackageRuleManager.getAllNamedModes) {
        val sn = m.getSymbolicName
        if (!overriddenModes.contains(sn)) {
          val c = thisPackage.getComponent(sn)
          if (c != null && (c.getVisibility ne Visibility.PRIVATE)) ruleManager.registerMode(c.getActor.asInstanceOf[Mode])
        }
      }
    }
  }
}