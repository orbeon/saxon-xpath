////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.ma.trie.ImmutableHashTrieMap
import net.sf.saxon.tree.util.FastStringBuffer
import java.util

/**
 * An implementation of AttributeMap suitable for larger collections of attributes (say, more than five).
 * This provides direct access to an attribute by name, avoiding the cost of a sequential search. The
 * map preserves the order of insertion of attributes: this is done by maintaining a doubly-linked list
 * of attributes in insertion order (when an attribute is replaced by another with the same name, it
 * currently occupies the position of the original; but this is not guaranteed).
 */
object LargeAttributeMap {

  private class AttributeInfoLink {
    private[om] val payload = null
    private[om] val prior = null
    private[om] val next = null
  }

}

class LargeAttributeMap private() extends AttributeMap {
  private var attributes = null
  private var first = null
  private var last = null
  private var size = 0

  def this(atts: util.List[AttributeInfo])={
    this()
    assert(!atts.isEmpty)
    this.attributes = ImmutableHashTrieMap.empty
    this.size = atts.size
    var current = null
    import scala.collection.JavaConversions._
    for (att <- atts) {
      if (attributes.get(att.getNodeName) != null) throw new IllegalArgumentException("Attribute map contains duplicates")
      val link = new LargeAttributeMap.AttributeInfoLink
      link.payload = att
      if (current == null) first = att.getNodeName
      else {
        current.next = att.getNodeName
        link.prior = current.payload.getNodeName
      }
      current = link
      attributes = attributes.put(att.getNodeName, link)
    }
    last = current.payload.getNodeName
  }

  def this(attributes: ImmutableHashTrieMap[NodeName, LargeAttributeMap.AttributeInfoLink], size: Int, first: NodeName, last: NodeName) {
    this()
    this.attributes = attributes
    this.size = size
    this.first = first
    this.last = last
  }

  /**
   * Return the number of attributes in the map.
   *
   * @return The number of attributes in the map.
   */
  override def size = size

  override def get(name: NodeName) = {
    val link = attributes.get(name)
    if (link == null) null
    else link.payload
  }

  override def get(uri: String, local: String) = {
    val name = new FingerprintedQName("", uri, local)
    get(name)
  }

  override def getByFingerprint(fingerprint: Int, namePool: NamePool) = {
    val name = new FingerprintedQName(namePool.getStructuredQName(fingerprint), fingerprint)
    get(name)
  }

  override def put(att: AttributeInfo) = {
    val existing = attributes.get(att.getNodeName)
    val link = new LargeAttributeMap.AttributeInfoLink
    var last2 = last
    link.payload = att
    if (existing == null) {
      link.prior = last
      last2 = att.getNodeName
      val oldLast = attributes.get(last)
      val penult = new LargeAttributeMap.AttributeInfoLink
      penult.payload = oldLast.payload
      penult.next = att.getNodeName
      penult.prior = oldLast.prior
      attributes = attributes.put(last, penult)
    }
    else {
      link.prior = existing.prior
      link.next = existing.next
    }
    val att2 = attributes.put(att.getNodeName, link)
    val size2 = if (existing == null) size + 1
    else size
    new LargeAttributeMap(att2, size2, first, last2)
  }

  override def remove(name: NodeName) = { // Not actually used (or tested)
    if (attributes.get(name) == null) this
    else {
      var first2 = first
      var last2 = last
      val att2 = attributes.remove(name)
      val existing = attributes.get(name)
      if (existing.prior != null) {
        val priorLink = attributes.get(existing.prior)
        val priorLink2 = new LargeAttributeMap.AttributeInfoLink
        priorLink2.payload = priorLink.payload
        priorLink2.prior = priorLink.prior
        priorLink2.next = existing.next
        att2.put(existing.prior, priorLink2)
      }
      else first2 = existing.next
      if (existing.next != null) {
        val nextLink = attributes.get(existing.next)
        val nextLink2 = new LargeAttributeMap.AttributeInfoLink
        nextLink2.payload = nextLink.payload
        nextLink2.next = nextLink.next
        nextLink2.prior = existing.prior
        att2.put(existing.next, nextLink2)
      }
      else last2 = existing.prior
      new LargeAttributeMap(att2, size - 1, first2, last2)
    }
  }

  override def iterator = new util.Iterator[AttributeInfo]() {
    private[om] var current = first
    override

    def hasNext: Boolean = return current != null

    override

    def next = {
      val link = attributes.get(current)
      current = link.next
      link.payload
    }
  }

  override def asList = {
    val result = new util.ArrayList[AttributeInfo](size)
    iterator.forEachRemaining(result.add)
    result
  }

  override def toString = {
    val sb = new FastStringBuffer(256)
    import scala.collection.JavaConversions._
    for (att <- this) {
      sb.cat(att.getNodeName.getDisplayName).cat("=\"").cat(att.getValue).cat("\" ")
    }
    sb.toString.trim
  }
}