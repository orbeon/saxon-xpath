////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.model.AnyItemType
import net.sf.saxon.pattern.NodeTest
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XmlProcessingException
import net.sf.saxon.tree.jiter.MonoIterator
import net.sf.saxon.value.SequenceType
import java.io.PrintWriter
import java.io.StringWriter
import java.util

/**
 * Information about a sub-expression and its relationship to the parent expression
 */
object Operand {
  private val DEBUG = false

  def typeDeterminedUsage(`type`: ItemType) = if (`type`.isPlainType) OperandUsage.ABSORPTION
  else if (`type`.isInstanceOf[NodeTest] || (`type` eq AnyItemType.getInstance)) OperandUsage.NAVIGATION
  else OperandUsage.INSPECTION
}

final class Operand(val parentExpression: Expression, val childExpression: Expression, var role: OperandRole)

/**
 * Create an operand object
 *
 * @param parentExpression the expression of which this is an operand
 * @param childExpression  the actual expression used as the operand
 * @param role             information about the role this operand plays within the parent expression
 */
  extends Iterable[Operand] with ExpressionOwner {
  setChildExpression(childExpression)
  private var childExpression = null

  /**
   * Get the parent expression of this operand
   *
   * @return the parent expression
   */
  def getParentExpression = parentExpression

  /**
   * Get the expression used as the actual operand
   *
   * @return the child expression
   */
  override def getChildExpression = childExpression

  /**
   * Change the child expression used for this operand. This is the only approved way of
   * making structural changes to the expression tree, and the implementation of this
   * method is responsible for maintaining the consistency of the tree
   *
   * @param childExpression the new child expression
   */
  override def setChildExpression(childExpression: Expression) = if (childExpression ne this.childExpression) {
    if (role.isConstrainedClass && this.childExpression != null && (childExpression.getClass ne this.childExpression.getClass)) throw new AssertionError
    this.childExpression = childExpression
    parentExpression.adoptChildExpression(childExpression)
    parentExpression.resetLocalStaticProperties()
    //childExpression.verifyParentPointers();
  }

  def detachChild() = if (Operand.DEBUG) {
    childExpression.setParentExpression(null)
    val sw = new StringWriter
    new XPathException("dummy").printStackTrace(new PrintWriter(sw))
    childExpression = new ErrorExpression("child expression has been detached: " + sw.toString, "ZZZ", false)
    ExpressionTool.copyLocationInfo(parentExpression, childExpression)
  }

  /**
   * Get the operand role
   *
   * @return the operand role
   */
  def getOperandRole = role

  /**
   * Set the operand role
   *
   * @param role the operand role
   */
  def setOperandRole(role: OperandRole) = this.role = role

  /**
   * Ask whether the child expression sets a new focus for evaluation of other operands
   *
   * @return true if the child expression is evaluated with the same focus as its parent expression
   */
  def setsNewFocus = role.setsNewFocus

  def hasSpecialFocusRules = role.hasSpecialFocusRules

  /**
   * Ask whether the child expression is evaluated with the same focus as its parent expression
   *
   * @return true if the child expression is evaluated with the same focus as its parent expression
   */
  def hasSameFocus = role.hasSameFocus

  /**
   * Ask whether the operand is a higher-order operand,: typically this means that the child expression
   * is evaluated repeatedly during a single evaluation of the parent expression (but there are some cases
   * like xsl:for-each select=".." where the operand is higher-order despite not being evaluated
   * repeatedly).
   *
   * @return true if the operand is higher-order
   */
  def isHigherOrder = role.isHigherOrder

  /**
   * Ask whether the operand is is evaluated repeatedly during a single evaluation of the parent
   * expression. This is true if the operand is higher-order and the operand does not have the
   * {@link OperandRole#SINGLETON} property.
   *
   * @return true if the operand is higher-order
   */
  def isEvaluatedRepeatedly = role.isEvaluatedRepeatedly

  /**
   * Get the usage of the operand
   *
   * @return the usage
   */
  def getUsage = role.getUsage

  /**
   * Set the usage of the operand
   *
   * @param usage the operand usage
   */
  def setUsage(usage: OperandUsage.type) = role = new OperandRole(role.properties, usage, role.getRequiredType)

  /**
   * Get the required type of the operand
   *
   * @return the required type
   */
  def getRequiredType = role.getRequiredType

  /**
   * Ask whether the operand is a member of a choice group
   *
   * @return true if the operand is in a choice group
   */
  def isInChoiceGroup = role.isInChoiceGroup

  /**
   * Get a singleton iterator that returns this operand only
   *
   * @return a singleton iterator
   */
  override def iterator = new MonoIterator[Operand](this)

  @throws[XPathException]
  def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = try setChildExpression(getChildExpression.typeCheck(visitor, contextInfo))
  catch {
    case e: XPathException =>
      e.maybeSetLocation(getChildExpression.getLocation)
      if (!e.isReportableStatically) {
        visitor.getStaticContext.issueWarning("Evaluation will always throw a dynamic error: " + e.getMessage, getChildExpression.getLocation)
        setChildExpression(new ErrorExpression(new XmlProcessingException(e)))
      }
      else throw e
  }

  @throws[XPathException]
  def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = try setChildExpression(getChildExpression.optimize(visitor, contextInfo))
  catch {
    case e: XPathException =>
      e.maybeSetLocation(getChildExpression.getLocation)
      if (!e.isReportableStatically) {
        visitor.getStaticContext.issueWarning("Evaluation will always throw a dynamic error: " + e.getMessage, getChildExpression.getLocation)
        setChildExpression(new ErrorExpression(new XmlProcessingException(e)))
      }
      else throw e
  }
}