////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.event.ReceiverWithOutputProperties
import net.sf.saxon.event.SequenceWriter
import net.sf.saxon.lib.SaxonOutputKeys
import net.sf.saxon.ma.arrays.ArrayItem
import net.sf.saxon.ma.map.KeyValuePair
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.Item
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.Sequence
import net.sf.saxon.query.QueryResult
import net.sf.saxon.serialize.charcode.CharacterSet
import net.sf.saxon.serialize.codenorm.Normalizer
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.StringValue
import javax.xml.transform.OutputKeys
import javax.xml.transform.stream.StreamResult
import java.io.StringWriter
import java.util._

/**
 * This class implements the JSON serialization method defined in XSLT+XQuery Serialization 3.1.
 *
 * @author Michael H. Kay
 */
class JSONSerializer @throws[XPathException]
(val pipe: PipelineConfiguration, var emitter: JSONEmitter, val outputProperties: Properties) extends SequenceWriter(pipe) with ReceiverWithOutputProperties {
  setOutputProperties(outputProperties)
  private var allowDuplicateKeys = false
  private var nodeOutputMethod = "xml"
  private var level = 0
  private var topLevelCount = 0
  private var maxLineLength = 80
  private var outputProperties = null
  private val characterSet = null
  private var isIndenting = false
  private var propertySorter = null
  private var unfailing = false

  /**
   * Set output properties
   *
   * @param details the output serialization properties
   */
  def setOutputProperties(details: Properties) = {
    this.outputProperties = details
    if ("yes" == details.getProperty(SaxonOutputKeys.ALLOW_DUPLICATE_NAMES)) allowDuplicateKeys = true
    if ("yes" == details.getProperty(OutputKeys.INDENT)) isIndenting = true
    if ("yes" == details.getProperty(SaxonOutputKeys.UNFAILING)) {
      unfailing = true
      allowDuplicateKeys = true
    }
    val jnom = details.getProperty(SaxonOutputKeys.JSON_NODE_OUTPUT_METHOD)
    if (jnom != null) nodeOutputMethod = jnom
    val max = details.getProperty(SaxonOutputKeys.LINE_LENGTH)
    if (max != null) try maxLineLength = max.toInt
    catch {
      case err: NumberFormatException =>

      // ignore the error.
    }
  }

  def setPropertySorter(sorter: Comparator[AtomicValue]) = this.propertySorter = sorter

  /**
   * Get the output properties
   *
   * @return the properties that were set using setOutputProperties
   */
  override def getOutputProperties = outputProperties

  /**
   * Set the Unicode normalizer to be used for normalizing strings.
   *
   * @param normalizer the normalizer to be used
   */
  def setNormalizer(normalizer: Normalizer) = emitter.setNormalizer(normalizer)

  /**
   * Set the CharacterMap to be used, if any
   *
   * @param map the character map
   */
  def setCharacterMap(map: CharacterMap) = emitter.setCharacterMap(map)

  /**
   * Append an arbitrary item (node or atomic value) to the output
   *
   * @param item the item to be appended
   * @throws net.sf.saxon.trans.XPathException if the operation fails
   */
  @throws[XPathException]
  override def write(item: Item) = {
    if (level == 0 && {
      topLevelCount += 1; topLevelCount
    } >= 2) throw new XPathException("JSON output method cannot handle sequences of two or more items", "SERE0023")
    if (item.isInstanceOf[AtomicValue]) emitter.writeAtomicValue(item.asInstanceOf[AtomicValue])
    else if (item.isInstanceOf[MapItem]) {
      var keys = null
      if (!allowDuplicateKeys) keys = new util.HashSet[String]
      val oneLiner = !isIndenting || isOneLinerMap(item.asInstanceOf[MapItem])
      emitter.startMap(oneLiner)
      val first = true
      val keyList = new util.ArrayList[AtomicValue]
      import scala.collection.JavaConversions._
      for (pair <- item.asInstanceOf[MapItem].keyValuePairs) {
        keyList.add(pair.key)
      }
      if (propertySorter != null) keyList.sort(propertySorter)
      import scala.collection.JavaConversions._
      for (key <- keyList) {
        val stringKey = key.getStringValue
        emitter.writeKey(stringKey)
        if (!allowDuplicateKeys && !keys.add(stringKey)) throw new XPathException("Key value \"" + stringKey + "\" occurs more than once in JSON map", "SERE0022")
        val value = item.asInstanceOf[MapItem].get(key)
        writeSequence(value.materialize)
      }
      emitter.endMap()
    }
    else if (item.isInstanceOf[ArrayItem]) {
      val oneLiner = !isIndenting || isOneLinerArray(item.asInstanceOf[ArrayItem])
      emitter.startArray(oneLiner)
      val first = true
      import scala.collection.JavaConversions._
      for (member <- item.asInstanceOf[ArrayItem].members) {
        writeSequence(member.materialize)
      }
      emitter.endArray()
    }
    else if (item.isInstanceOf[NodeInfo]) {
      val s = serializeNode(item.asInstanceOf[NodeInfo])
      emitter.writeAtomicValue(new StringValue(s))
    }
    else if (unfailing) {
      val s = item.getStringValue
      emitter.writeAtomicValue(new StringValue(s))
    }
    else throw new XPathException("JSON output method cannot handle an item of type " + item.getClass, "SERE0021")
  }

  private def isOneLinerArray(array: ArrayItem): Boolean = {
    var totalSize = 0
    if (array.arrayLength < 2) return true
    import scala.collection.JavaConversions._
    for (member <- array.members) {
      if (!member.isInstanceOf[AtomicValue]) return false
      totalSize += member.asInstanceOf[AtomicValue].getStringValueCS.length + 1
      if (totalSize > maxLineLength) return false
    }
    true
  }

  private def isOneLinerMap(map: MapItem): Boolean = {
    var totalSize = 0
    if (map.size < 2) return true
    import scala.collection.JavaConversions._
    for (entry <- map.keyValuePairs) {
      if (!entry.value.isInstanceOf[AtomicValue]) return false
      totalSize += entry.key.getStringValueCS.length + entry.value.asInstanceOf[AtomicValue].getStringValueCS.length + 4
      if (totalSize > maxLineLength) return false
    }
    true
  }

  @throws[XPathException]
  private def serializeNode(node: NodeInfo) = {
    val sw = new StringWriter
    val props = new Properties
    props.setProperty("method", nodeOutputMethod)
    props.setProperty("indent", "no")
    props.setProperty("omit-xml-declaration", "yes")
    QueryResult.serialize(node, new StreamResult(sw), props)
    sw.toString.trim
  }

  @throws[XPathException]
  private def writeSequence(seq: GroundedValue) = {
    val len = seq.getLength
    if (len == 0) emitter.writeAtomicValue(null)
    else if (len == 1) {
      level += 1
      write(seq.head)
      level -= 1
    }
    else throw new XPathException("JSON serialization: cannot handle a sequence of length " + len + Err.depictSequence(seq), "SERE0023")
  }

  /**
   * End of the document.
   */
  @throws[XPathException]
  override def close() = {
    if (topLevelCount == 0) emitter.writeAtomicValue(null)
    emitter.close()
    super.close()
  }
}