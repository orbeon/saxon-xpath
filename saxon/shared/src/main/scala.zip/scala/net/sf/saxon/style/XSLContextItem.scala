////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.StaticProperty
import net.sf.saxon.model.AnyItemType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.Type
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace

/**
 * An xsl:context-item element in the stylesheet. <br>
 */
class XSLContextItem extends StyleElement {
  private var requiredType = AnyItemType.getInstance
  private var mayBeOmitted = true
  private var absentFocus = false

  override def prepareAttributes(): Unit = {
    var asAtt = null
    var useAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "as" =>
          asAtt = Whitespace.trim(value)
        case "use" =>
          useAtt = Whitespace.trim(value)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (asAtt != null) {
      var st = null
      try st = makeSequenceType(asAtt)
      catch {
        case e: XPathException =>
          st = SequenceType.SINGLE_ITEM
          compileErrorInAttribute(e.getMessage, e.getErrorCodeLocalPart, "as")
      }
      if (st.getCardinality != StaticProperty.EXACTLY_ONE) {
        compileError("The xsl:context-item/@use attribute must be an item type (no occurrence indicator allowed)", "XTSE0020")
        return
      }
      requiredType = st.getPrimaryType
    }
    if (useAtt != null) useAtt match {
      case "required" =>
        mayBeOmitted = false
      case "optional" =>
      // no action, this is the default
      case "absent" =>
        absentFocus = true
      case _ =>
        invalidAttribute("use", "required|optional|absent")
    }
    if (asAtt != null && absentFocus) compileError("The 'as' attribute must be omitted when use='absent' is specified", "XTSE3089")
  }

  /**
   * Check that the stylesheet element is valid. This is called once for each element, after
   * the entire tree has been built. As well as validation, it can perform first-time
   * initialisation. The default implementation does nothing; it is normally overriden
   * in subclasses.
   *
   * @param decl the declaration to be validated
   * @throws XPathException if any error is found during validation
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration): Unit = {
    if (!getParent.isInstanceOf[XSLTemplate]) {
      compileError("xsl:context-item can appear only as a child of xsl:template")
      return
    }
    if (mayBeOmitted && getParent.asInstanceOf[XSLTemplate].getTemplateName == null) compileError("xsl:context-item appearing in an xsl:template declaration with no name attribute must specify use=required", "XTSE0020")
    getParent.asInstanceOf[XSLTemplate].setContextItemRequirements(requiredType, mayBeOmitted, absentFocus)
    iterateAxis(AxisInfo.PRECEDING_SIBLING).forEachOrFail((prec: Item) => {
      def foo(prec: Item) = {
        if (prec.asInstanceOf[NodeInfo].getNodeKind != Type.TEXT || !Whitespace.isWhite(prec.getStringValueCS)) compileError("xsl:context-item must be the first child of xsl:template")
      }

      foo(prec)
    })
  }

  def getRequiredContextItemType = requiredType

  def isMayBeOmitted = mayBeOmitted

  def isAbsentFocus = absentFocus
}