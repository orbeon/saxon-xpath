////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.XPathException

/**
 * An exception thrown by the Saxon s9api API. This is always a wrapper for some other underlying exception
 */
class SaxonApiException extends Exception {
  private var message = null
  /**
   * Create a SaxonApiException
   *
   * @param cause the underlying cause of the exception
   */
    def this(cause: Throwable) {
      this()
      this.initCause(cause)
    }

  /**
   * Create a SaxonApiException
   *
   * @param message the message
   */
  def this(message: String) {
    this()
    this.message = message
  }

  /**
   * Create a SaxonApiException
   *
   * @param message the message
   * @param cause   the underlying cause of the exception
   */
  def this(message: String, cause: Throwable) {
    this()
    this.message= message
    this.initCause(cause)
  }

  /**
   * Returns the detail message string of this throwable.
   *
   * @return the detail message string of this <tt>Throwable</tt> instance
   *         (which may be <tt>null</tt>).
   */
  override def getMessage:String = {
    if(message == null ){
      return getCause.getMessage
    }
    return message
  }

  /**
   * Get the error code associated with the exception, if there is one
   *
   * @return the associated error code, or null if no error code is available
   * @since 9.3
   */
  /*@Nullable*/ def getErrorCode = {
    val cause = getCause
    if (cause.isInstanceOf[XPathException]) {
      val code = cause.asInstanceOf[XPathException].getErrorCodeQName
      if (code == null) null
      else new QName(code)
    }
    else null
  }

  /**
   * Get the line number associated with the exception, if known.
   *
   * @return the line number (typically of a line in a stylesheet, query, or schema, but
   *         in the case of validation errors it may be a line in a source document); or -1 if not known
   * @since 9.6
   */
  def getLineNumber = {
    val cause = getCause
    if (cause.isInstanceOf[XPathException]) {
      val loc = cause.asInstanceOf[XPathException].getLocator
      if (loc == null) -1
      else loc.getLineNumber
    }
    else -1
  }

  /**
   * Get the URI of the module associated with the exception, if known.
   *
   * @return the URI of the module (typically a stylesheet, query, or schema, but
   *         in the case of validation errors it may be a source document); or null if not known
   * @since 9.6
   */
  def getSystemId = {
    val cause = getCause
    if (cause.isInstanceOf[XPathException]) {
      val loc = cause.asInstanceOf[XPathException].getLocator
      if (loc == null) null
      else loc.getSystemId
    }
    else null
  }
}