////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XmlProcessingIncident

/**
 * This element is a surrogate for an extension element (or indeed an xsl element)
 * for which no implementation is available.
 */
class AbsentExtensionElement extends StyleElement {
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   */
  override def mayContainSequenceConstructor = true

  /**
   * Process the attributes of this element and all its children
   */
  @throws[XPathException]
  override def processAllAttributes(): Unit = {
    if (reportingCircumstances eq OnFailure.IGNORED_INSTRUCTION) return
    if (reportingCircumstances eq OnFailure.REPORT_ALWAYS) compileError(validationError)
    if (isTopLevel && forwardsCompatibleModeIsEnabled) {
      // do nothing
    }
    else super.processAllAttributes()
  }

  override def prepareAttributes() = {
  }

  /**
   * Recursive walk through the stylesheet to validate all nodes
   *
   * @param decl
   * @param excludeStylesheet
   */
  @throws[XPathException]
  override def validateSubtree(decl: ComponentDeclaration, excludeStylesheet: Boolean) = if ((reportingCircumstances eq OnFailure.IGNORED_INSTRUCTION) || (isTopLevel && forwardsCompatibleModeIsEnabled)) {
  }
  else super.validateSubtree(decl, excludeStylesheet)

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = {
    if (isTopLevel || (reportingCircumstances eq OnFailure.IGNORED_INSTRUCTION)) return null
    // if there are fallback children, compile the code for the fallback elements
    if (validationError == null) validationError = new XmlProcessingIncident("Unknown instruction")
    fallbackProcessing(exec, decl, this)
  }
}