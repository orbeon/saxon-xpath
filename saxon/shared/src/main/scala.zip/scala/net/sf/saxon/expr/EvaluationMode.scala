////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.Evaluator

/**
 * An evaluation mode represents a way in which expressions can be evaluated
 */
object EvaluationMode extends Enumeration {
  type EvaluationMode = Value
  val UNDECIDED, EVALUATE_LITERAL, EVALUATE_VARIABLE, MAKE_CLOSURE, MAKE_MEMO_CLOSURE, RETURN_EMPTY_SEQUENCE, EVALUATE_AND_MATERIALIZE_VARIABLE, CALL_EVALUATE_OPTIONAL_ITEM, ITERATE_AND_MATERIALIZE, PROCESS, LAZY_TAIL_EXPRESSION, SHARED_APPEND_EXPRESSION, MAKE_INDEXED_VARIABLE, MAKE_SINGLETON_CLOSURE, EVALUATE_SUPPLIED_PARAMETER, STREAMING_ARGUMENT, CALL_EVALUATE_SINGLE_ITEM = Value
  private val code = 0
  private
  val evaluator = nulldef
  this (code: Int, evaluator: Evaluator) {
    this ()
    this.code = code
    this.evaluator = evaluator
  }

  /**
   * Get the integer code associated with an evaluation mode. These codes should be considered
   * stable, as they are recorded in SEF files
   *
   * @return an integer code
   */
  def getCode = code

  /**
   * Get the evaluator corresponding to a particular evaluation mode
   *
   * @return the corresponding evaluator
   */
  def getEvaluator = evaluator

  /**
   * Get the evaluation mode with a particular integer code. This is used when reloading a stylesheet
   * from a SEF file
   *
   * @param code the integer code
   * @return the corresponding evaluation mode
   */
  def forCode(code: Int): EvaluationMode = {
    for (eval <- EvaluationMode.values) {
      if (eval.getCode == code) return eval
    }
    ITERATE_AND_MATERIALIZE
  }
}