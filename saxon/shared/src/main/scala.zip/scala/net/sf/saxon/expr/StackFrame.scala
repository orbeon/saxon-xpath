////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.om.Sequence
import java.util

/**
 * This class represents a stack frame holding details of the variables used in a function or in
 * an XSLT template.
 */
object StackFrame {
  val EMPTY = new StackFrame(SlotManager.EMPTY, new Array[Sequence](0))
}

class StackFrame(var map: SlotManager, val slots: Array[Sequence]) {
  this.slots = slots.asInstanceOf[Array[Sequence]]
  protected var slots = null
  protected var dynamicStack = null

  def getStackFrameMap = map

  def getStackFrameValues = slots

  def setStackFrameValues(values: Array[Sequence]) = slots = values.asInstanceOf[Array[Sequence]]

  def copy = {
    val v2 = util.Arrays.copyOf(slots, slots.length)
    val s = new StackFrame(map, v2)
    if (dynamicStack != null) {
      s.dynamicStack = new util.Stack[Sequence]
      s.dynamicStack.addAll(dynamicStack)
    }
    s
  }

  def pushDynamicValue(value: Sequence) = {
    if (this eq StackFrame.EMPTY) throw new IllegalStateException("Immutable stack frame")
    if (dynamicStack == null) dynamicStack = new util.Stack[Sequence]
    dynamicStack.push(value)
  }

  def popDynamicValue = dynamicStack.pop

  def holdsDynamicValue = dynamicStack != null && !dynamicStack.empty
}