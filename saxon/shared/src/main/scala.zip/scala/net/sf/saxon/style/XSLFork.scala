////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.instruct.Fork
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * Handler for xsl:fork elements in XSLT 3.0 stylesheet.
 */
class XSLFork extends StyleElement {
  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
    override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return false: no, it may not contain a sequence constructor
   */
  override def mayContainSequenceConstructor = false

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    var foundGroup = 0
    var foundSequence = 0
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLSequence]) foundSequence += 1
      else if (child.isInstanceOf[XSLForEachGroup]) foundGroup += 1
      else if (child.isInstanceOf[XSLFallback]) {
        // no action
      }
      else compileError(child.getDisplayName + " cannot appear as a child of xsl:fork")
    }
    if (foundGroup > 1) compileError("xsl:fork contains more than one xsl:for-each-group instruction")
    if (foundGroup > 0 && foundSequence > 0) compileError("Cannot mix xsl:sequence and xsl:for-each-group within xsl:fork")
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val content = compileSequenceConstructor(exec, decl, true)
    if (content.isInstanceOf[Block]) new Fork(content.asInstanceOf[Block].getOperanda)
    else content
  }
}