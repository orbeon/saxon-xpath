////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import java.util
import java.util.function.Consumer

/**
 * A helper class for implementing the {@link Destination} interface
 */
class DestinationHelper(var helpee: Destination) {
  private val listeners = new util.ArrayList[Action]

  /**
   * Register a listener to be notified when this destination is closed
   *
   * @param listener an object to be notified when writing to the destination
   *                 is successfully completed
   */
  final def onClose(listener: Action) = listeners.add(listener)

  /**
   * Close the destination and notify all registered listeners that it has been closed.
   * This method is intended for internal use by Saxon. The method first calls {@code close}
   * to close the destination, then it calls {@link Consumer#accept} on each of the
   * listeners in turn to notify the fact that it has been closed.
   *
   * @throws SaxonApiException if the close() method throws { @code SaxonApiException}.
   */
  @throws[SaxonApiException]
  def closeAndNotify() = {
    helpee.close()
    import scala.collection.JavaConversions._
    for (action <- listeners) {
      action.act()
    }
  }

  def getListeners = listeners
}