////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.lib.NamespaceConstant
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * A NamePool holds a collection of expanded names, each containing a namespace URI,
 * and a local name.
 * <p>Each expanded name is allocated a unique 20-bit fingerprint. The fingerprint enables
 * the URI and the local name to be determined. Some subsystems (notably the Tinytree) use
 * the top 10 bits to represent the prefix, but the NamePool is no longer concerned with
 * managing prefixes, and prefixes do not have global codes.</p>
 * <p>The NamePool has been redesigned in Saxon 9.7 to make use of two Java
 * ConcurrentHashMaps, one from QNames to integers, one from integers to QNames.
 * This gives better scaleability in terms of multithreaded concurrency and in terms
 * of the capacity of the NamePool and retention of performance as the size of
 * the vocabulary increases.</p>
 * <p>Fingerprints in the range 0 to 1023 are reserved for system use, and are allocated as constants
 * mainly to names in the XSLT and XML Schema namespaces: constants representing these names
 * are found in {@link StandardNames}.</p>
 *
 * <p>The fingerprint -1 is reserved to mean "not known" or inapplicable.</p>
 * <p>Modified in 9.4 to remove namespace codes.</p>
 * <p>Modified in 9.7 to remove URI codes.</p>
 * <p>Modified in 9.8 to remove namecodes and all handling of prefixes.</p>
 */
object NamePool {
  /**
   * FP_MASK is a mask used to obtain a fingerprint from a nameCode. Given a
   * nameCode nc, the fingerprint is <code>nc &amp; NamePool.FP_MASK</code>.
   * (In practice, Saxon code often uses the literal constant 0xfffff,
   * to extract the bottom 20 bits).
   * <p>The difference between a fingerprint and a nameCode is that
   * a nameCode contains information
   * about the prefix of a name, the fingerprint depends only on the namespace
   * URI and local name. Note that the "null" nameCode (-1) does not produce
   * the "null" fingerprint (also -1) when this mask is applied.</p>
   */
    val FP_MASK = 0xfffff
  val USER_DEFINED_MASK = 0xffc00
  private val MAX_FINGERPRINT = FP_MASK

  /**
   * Determine whether a given namecode has a non-empty prefix (and therefore, in the case of attributes,
   * whether the name is in a non-null namespace
   *
   * @param nameCode the name code to be tested
   * @return true if the name has a non-empty prefix
   */
  def isPrefixed(nameCode: Int) = (nameCode & 0x3ff00000) != 0

  /**
   * Unchecked Exception raised when some limit in the design of the name pool is exceeded
   */
  class NamePoolLimitException(val message: String)

  /**
   * Create the exception
   *
   * @param message the error message associated with the error
   */
    extends RuntimeException(message) {
  }

}


/**
 * Create a NamePool
 */
final class NamePool(){
  final private val qNameToInteger = new ConcurrentHashMap[StructuredQName, Integer](1000)
  final private val integerToQName = new ConcurrentHashMap[Integer, StructuredQName](1000)
  private val unique = new AtomicInteger(1024)
  private val suggestedPrefixes = new ConcurrentHashMap[String, String]

  /**
   * Suggest a preferred prefix to be used with a given URI
   *
   * @param uri    the URI
   * @param prefix the suggested prefix
   */
  def suggestPrefix(prefix: String, uri: String) = suggestedPrefixes.put(uri, prefix)

  /**
   * Get a QName for a given namecode.
   *
   * @param nameCode a code identifying an expanded QName, e.g. of an element or attribute
   * @return a qName containing the URI and local name corresponding to the supplied name code.
   *         The prefix will be set to an empty string.
   */
  def getUnprefixedQName(nameCode: Int): StructuredQName = {
    val fp = nameCode & NamePool.FP_MASK
    if ((fp & NamePool.USER_DEFINED_MASK) == 0) return StandardNames.getUnprefixedQName(fp)
    integerToQName.get(fp)
  }

  /**
   * Get a QName for a given fingerprint.
   *
   * @param fingerprint a code identifying an expanded QName, e.g. of an element or attribute
   * @return a qName containing the URI and local name corresponding to the supplied fingerprint.
   *         There will be no prefix
   */
  def getStructuredQName(fingerprint: Int) = getUnprefixedQName(fingerprint)

  /**
   * Suggest a prefix for a given URI. If there are several, it's undefined which one is returned.
   * If there are no prefixes registered for this URI, return null.
   *
   * @param uri the namespace URI
   * @return a prefix that has previously been associated with this URI, if available; otherwise null
   */
  def suggestPrefixForURI(uri: String): String = {
    if (uri == NamespaceConstant.XML) return "xml"
    suggestedPrefixes.get(uri)
  }

  /**
   * Allocate a fingerprint from the pool, or a new Name if there is not a matching one there
   *
   * @param uri   the namespace URI. Use "" or null for the non-namespace.
   * @param local the local part of the name
   * @return an integer (the "fingerprint") identifying the name within the namepool.
   *         The fingerprint omits information about the prefix, and is the same as the nameCode
   *         for the same name with a prefix equal to "".
   */
  def allocateFingerprint(uri: String, local: String): Int = {
    if (NamespaceConstant.isReserved(uri) || NamespaceConstant.SAXON == uri) {
      val fp = StandardNames.getFingerprint(uri, local)
      if (fp != -1) return fp
    }
    val qName = new StructuredQName("", uri, local)
    var existing = qNameToInteger.get(qName)
    if (existing != null) return existing
    val next = unique.getAndIncrement
    if (next > NamePool.MAX_FINGERPRINT) throw new NamePool.NamePoolLimitException("Too many distinct names in NamePool")
    existing = qNameToInteger.putIfAbsent(qName, next)
    if (existing == null) {
      integerToQName.put(next, qName)
      next
    }
    else existing
  }

  /**
   * Get the namespace-URI of a name, given its name code or fingerprint
   *
   * @param nameCode the name code or fingerprint of a name
   * @return the namespace URI corresponding to this name code. Returns "" for the
   *         no-namespace.
   * @throws IllegalArgumentException if the nameCode is not known to the NamePool.
   */
  /*@NotNull*/ def getURI(nameCode: Int): String = {
    val fp = nameCode & NamePool.FP_MASK
    if ((fp & NamePool.USER_DEFINED_MASK) == 0) return StandardNames.getURI(fp)
    getUnprefixedQName(fp).getURI
  }

  /**
   * Get the local part of a name, given its name code or fingerprint
   *
   * @param nameCode the integer name code or fingerprint of the name
   * @return the local part of the name represented by this name code or fingerprint
   */
  def getLocalName(nameCode: Int) = getUnprefixedQName(nameCode).getLocalPart

  /**
   * Get the display form of a name (the QName), given its name code or fingerprint
   *
   * @param nameCode the integer name code or fingerprint of a name in the name pool
   * @return the corresponding lexical QName (if a fingerprint was supplied, this will
   *         simply be the local name)
   */
  def getDisplayName(nameCode: Int) = getStructuredQName(nameCode).getDisplayName

  /**
   * Get the Clark form of a name, given its name code or fingerprint
   *
   * @param nameCode the integer name code or fingerprint of a name in the name pool
   * @return the local name if the name is in the null namespace, or "{uri}local"
   * otherwise. The name is always interned.
   */
  def getClarkName(nameCode: Int) = getUnprefixedQName(nameCode).getClarkName

  /**
   * Get the EQName form of a name, given its name code or fingerprint
   *
   * @param nameCode the integer name code or fingerprint of a name in the name pool
   * @return the name in the form Q{}local for a name in no namespace, or Q{uri}local for
   *         a name in a namespace
   */
  def getEQName(nameCode: Int) = getUnprefixedQName(nameCode).getEQName

  /**
   * Allocate a fingerprint given a Clark Name
   *
   * @param expandedName the name in Clark notation, that is "localname" or "{uri}localName"
   * @return the fingerprint of the name, which need not previously exist in the name pool
   */
  def allocateClarkName(expandedName: String) = {
    var namespace = null
    var localName = null
    if (expandedName.charAt(0) == '{') {
      val closeBrace = expandedName.indexOf('}')
      if (closeBrace < 0) throw new IllegalArgumentException("No closing '}' in Clark name")
      namespace = expandedName.substring(1, closeBrace)
      if (closeBrace == expandedName.length) throw new IllegalArgumentException("Missing local part in Clark name")
      localName = expandedName.substring(closeBrace + 1)
    }
    else {
      namespace = ""
      localName = expandedName
    }
    allocateFingerprint(namespace, localName)
  }

  /**
   * Get a fingerprint for the name with a given uri and local name.
   * These must be present in the NamePool.
   * The fingerprint has the property that if two fingerprint are the same, the names
   * are the same (ie. same local name and same URI).
   *
   * @param uri       the namespace URI of the required QName
   * @param localName the local part of the required QName
   * @return the integer fingerprint, or -1 if this is not found in the name pool
   */
  def getFingerprint(uri: String, localName: String): Int = { // A read-only version of allocate()
    if (NamespaceConstant.isReserved(uri) || uri == NamespaceConstant.SAXON) {
      val fp = StandardNames.getFingerprint(uri, localName)
      if (fp != -1) {
        return fp
        // otherwise, look for the name in this namepool
      }
    }
    val fp = qNameToInteger.get(new StructuredQName("", uri, localName))
    if (fp == null) -1
    else fp
  }
}