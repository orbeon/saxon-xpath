////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.instruct.IterateInstr
import net.sf.saxon.expr.instruct.LocalParam
import net.sf.saxon.expr.instruct.LocalParamBlock
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.SaxonErrorCode
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.ListIterator
import java.util

/**
 * Handler for xsl:iterate elements in stylesheet. <br>
 */
class XSLIterate extends StyleElement {
  private[style] var select = null
  private[style] var compilable = false

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Specify that xsl:param is a permitted child
   */
  override protected def isPermittedChild(child: StyleElement) = child.isInstanceOf[XSLLocalParam] || child.isInstanceOf[XSLOnCompletion]

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  /**
   * Determine whether this type of element is allowed to contain an xsl:param element
   *
   * @return true if this element is allowed to contain an xsl:param
   */
  override protected def mayContainParam = true

  override def prepareAttributes() = {
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else checkUnknownAttribute(attName)
    }
    if (selectAtt == null) reportAbsence("select")
  }

  def setCompilable(compilable: Boolean) = this.compilable = compilable

  def isCompilable = compilable

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = { //checkParamComesFirst(false);
    select = typeCheck("select", select)
    if (!hasChildNodes) compileWarning("An empty xsl:iterate instruction has no effect", SaxonErrorCode.SXWN9009)
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = {
    val nonFinallyChildren = new util.ArrayList[NodeInfo]
    var finallyExp = null
    val params = new util.ArrayList[XSLLocalParam]
    import scala.collection.JavaConversions._
    for (node <- children) {
      if (node.isInstanceOf[XSLLocalParam]) params.add(node.asInstanceOf[XSLLocalParam])
      else if (node.isInstanceOf[XSLOnCompletion]) finallyExp = node.asInstanceOf[XSLOnCompletion].compile(exec, decl)
      else nonFinallyChildren.add(node)
    }
    val compiledParams = new Array[LocalParam](params.size)
    for (i <- 0 until params.size) {
      compiledParams(i) = params.get(i).compile(exec, decl).asInstanceOf[LocalParam]
      if (compiledParams(i).isImplicitlyRequiredParam) { // see spec bug 25158; Saxon bug 2041
        compileError("The parameter must be given an initial value because () is not valid, given the declared type", "XTSE3520")
      }
    }
    val paramBlock = new LocalParamBlock(compiledParams)
    var action = compileSequenceConstructor(exec, decl, new ListIterator[NodeInfo](nonFinallyChildren), false)
    if (action == null) { // body of xsl:iterate is empty: it's a no-op.
      return Literal.makeEmptySequence
    }
    try {
      action = action.simplify
      new IterateInstr(select, paramBlock, action, finallyExp)
    } catch {
      case err: XPathException =>
        compileError(err)
        null
    }
  }
}