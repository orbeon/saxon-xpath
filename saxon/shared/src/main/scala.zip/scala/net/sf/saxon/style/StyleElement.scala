////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.expr._
import net.sf.saxon.expr.instruct._
import net.sf.saxon.expr.parser._
import net.sf.saxon.expr.sort.SortKeyDefinition
import net.sf.saxon.expr.sort.SortKeyDefinitionList
import net.sf.saxon.functions.Current
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.lib.Validation
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.pattern._
import net.sf.saxon.s9api.HostLanguage
import net.sf.saxon.s9api.Location
import net.sf.saxon.s9api.XmlProcessingError
import net.sf.saxon.trans._
import net.sf.saxon.tree.AttributeLocation
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.tree.iter.ListIterator
import net.sf.saxon.tree.linked.ElementImpl
import net.sf.saxon.tree.linked.NodeImpl
import net.sf.saxon.tree.linked.TextImpl
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.tree.util.Navigator
import net.sf.saxon.value.BigDecimalValue
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace
import javax.xml.transform.SourceLocator
import java.math.BigDecimal
import java.net.URI
import java.net.URISyntaxException
import java.util._

/**
 * Abstract superclass for all element nodes in the stylesheet.
 * <p>Note: this class implements Locator. The element retains information about its own location
 * in the stylesheet, which is useful when an XSLT static error is found.</p>
 */
object StyleElement {

  object OnFailure extends Enumeration {
    type OnFailure = Value
    val REPORT_ALWAYS, REPORT_UNLESS_FORWARDS_COMPATIBLE, REPORT_IF_INSTANTIATED, REPORT_STATICALLY_UNLESS_FALLBACK_AVAILABLE, REPORT_DYNAMICALLY_UNLESS_FALLBACK_AVAILABLE, IGNORED_INSTRUCTION = Value
  }

  val ACTION_VALIDATE = 1
  val ACTION_COMPILE = 2
  val ACTION_TYPECHECK = 4
  val ACTION_OPTIMIZE = 8
  val ACTION_FIXUP = 16
  val ACTION_PROCESS_ATTRIBUTES = 32
  private[style] val YES_NO = Array[String]("0", "1", "false", "no", "true", "yes")

  private[style] def isYes(s: String) = "yes" == s || "true" == s || "1" == s

  private[style] def isNo(s: String) = "no" == s || "false" == s || "0" == s

  /**
   * Create a trace instruction to wrap a real instruction
   *
   * @param source the parent element
   * @param child  the compiled expression tree for the instruction to be traced
   * @return a wrapper instruction that performs the tracing (if activated at run-time)
   */
  private[style] def makeTraceInstruction(source: StyleElement, child: Expression): Expression = {
    if (child.isInstanceOf[TraceExpression] && !source.isInstanceOf[StylesheetComponent]) {
      return child
      // this can happen, for example, after optimizing a compile-time xsl:if
    }
    if (source.isInstanceOf[XSLOnEmpty] || source.isInstanceOf[XSLOnNonEmpty]) { // Cannot wrap these in a trace instruction because this changes the scope of the "emptiness" test
      return child
    }
    //        CodeInjector injector = source.getCompilation().getCompilerInfo().getCodeInjector();
    //        if (injector != null) {
    //            int construct = source.getFingerprint();
    //            if (source instanceof LiteralResultElement) {
    //                construct = LocationKind.LITERAL_RESULT_ELEMENT;
    //            }
    //            Expression tracer = injector.inject(child);
    //            tracer.setLocation(source.allocateLocation());
    //            return tracer;
    //        }
    child
  }
}

abstract class StyleElement()

/**
 * Constructor
 */
  extends ElementImpl {
  /*@Nullable*/ protected var extensionNamespaces = null // a list of URIs
  private var excludedNamespaces = null
  protected var version = -1 // the effective version of this element
  protected var staticContext = null
  protected var validationError = null
  protected var reportingCircumstances = StyleElement.OnFailure.REPORT_ALWAYS
  protected var defaultXPathNamespace = null
  protected var defaultCollationName = null
  protected var defaultMode = null
  protected var expandText = false
  private var objectName = null // for instructions that define an XSLT named object, the name of that object
  private var baseURI = null
  private var compilation = null
  private var savedLocation = null
  private var defaultValidation = Validation.DEFAULT
  protected var actionsCompleted = 0

  def getCompilation = compilation

  def setCompilation(compilation: Compilation) = this.compilation = compilation

  def getPackageData = getPrincipalStylesheetModule.getStylesheetPackage

  override def getConfiguration = compilation.getConfiguration

  /**
   * Get the static context for expressions on this element
   *
   * @return the static context
   */
  def getStaticContext = {
    if (staticContext == null) staticContext = new ExpressionContext(this, null)
    staticContext
  }

  def getStaticContext(attributeName: StructuredQName) = new ExpressionContext(this, attributeName)

  /**
   * Get the base URI of the element, which acts as the static base URI for XPath expressions defined
   * on this element. This is an expensive operation so the result is cached
   *
   * @return the base URI
   */
  override def getBaseURI = {
    if (baseURI == null) baseURI = super.getBaseURI
    baseURI
  }

  /**
   * Make an expression visitor
   *
   * @return the expression visitor
   */
  def makeExpressionVisitor = ExpressionVisitor.make(getStaticContext)

  /**
   * Ask whether the code is compiled in schema-aware mode
   *
   * @return true if the compilation is schema-aware
   */
  def isSchemaAware = getCompilation.isSchemaAware

  /**
   * Make this node a substitute for a temporary one previously added to the tree. See
   * StyleNodeFactory for details. "A node like the other one in all things but its class".
   * Note that at this stage, the node will not yet be known to its parent, though it will
   * contain a reference to its parent; and it will have no children.
   *
   * @param temp the element which this one is substituting for
   */
  def substituteFor(temp: StyleElement) = {
    setRawParent(temp.getRawParent)
    setAttributes(temp.attributes)
    //setNamespaceList(temp.getNamespaceList());
    setNamespaceMap(temp.getAllNamespaces)
    setNodeName(temp.getNodeName)
    setRawSequenceNumber(temp.getRawSequenceNumber)
    extensionNamespaces = temp.extensionNamespaces
    excludedNamespaces = temp.excludedNamespaces
    version = temp.version
    staticContext = temp.staticContext
    validationError = temp.validationError
    reportingCircumstances = temp.reportingCircumstances
    compilation = temp.compilation
    //lineNumber = temp.lineNumber;
  }

  /**
   * Set a validation error. This is an error detected during construction of this element on the
   * stylesheet, but which is not to be reported until later.
   *
   * @param reason        the details of the error
   * @param circumstances a code identifying the circumstances under which the error is to be reported
   */
  def setValidationError(reason: XmlProcessingIncident, circumstances: StyleElement.OnFailure) = {
    validationError = reason
    reportingCircumstances = circumstances
  }

  private[style] def setIgnoreInstruction() = reportingCircumstances = StyleElement.OnFailure.IGNORED_INSTRUCTION

  /**
   * Ask whether this node is an instruction. The default implementation says it isn't.
   *
   * @return true if this element is an instruction
   */
  def isInstruction = false

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import). The default implementation returns false
   *
   * @return true if the element is a permitted child of xsl:stylesheet or xsl:transform
   */
  def isDeclaration = false

  /**
   * Get the visibility of the component. Returns the actual value of the visibility attribute,
   * after validation, unless this is absent, in which case it returns the default value of PRIVATE.
   * Invokes {@link #invalidAttribute(String, String)} if the value is invalid.
   *
   * @return the declared visibility of the component, or { @link Visibility#PRIVATE}
   *                                                              if the visibility attribute is absent.
   */
  def getVisibility = {
    val vis = getAttributeValue("", "visibility")
    if (vis == null) Visibility.PRIVATE
    else interpretVisibilityValue(vis, "")
  }

  /**
   * Get the visibility of the component. Returns the actual value of the visibility attribute,
   * after validation, unless this is absent, in which case it returns null.
   *
   * @return the declared visibility of the component, or null if the visibility attribute is absent.
   */
  def getDeclaredVisibility = {
    val vis = getAttributeValue("", "visibility")
    if (vis == null) null
    else interpretVisibilityValue(vis, "")
  }

  /**
   * Mark tail-recursive calls on templates and functions.
   * For most instructions, this returns false.
   *
   * @return true if one or more tail calls were identified
   */
  protected def markTailCalls = false

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true if this instruction is allowed to contain a sequence constructor
   */
  protected def mayContainSequenceConstructor = false

  /**
   * Determine whether this type of element is allowed to contain an xsl:fallback
   * instruction. Note that this is only relevant if the element is an instruction.
   *
   * @return true if this element is allowed to contain an xsl:fallback
   */
  protected def mayContainFallback = mayContainSequenceConstructor

  /**
   * Determine whether this type of element is allowed to contain an xsl:param element
   *
   * @return true if this element is allowed to contain an xsl:param
   */
  protected def mayContainParam = false

  /**
   * Get the effective value of the default-validation attribute
   *
   * @return the value of default-validation, as a constant from the { @link Validation} class,
   *                                                                         or Validation.STRIP if there is no containing element with a default-validation
   *                                                                         attribute.
   */
  private[style] def getDefaultValidation: Int = {
    var v = defaultValidation
    var p = this
    while ( {
      v == Validation.DEFAULT
    }) {
      p = p.getParent
      if (!p.isInstanceOf[StyleElement]) {
        return Validation.STRIP
        //return getCompilation().isSchemaAware() ? Validation.PRESERVE : Validation.STRIP;
      }
      v = p.asInstanceOf[StyleElement].defaultValidation
    }
    v
  }

  /**
   * Make a structured QName, using this Element as the context for namespace resolution.
   * If the name is unprefixed, the default namespace is <b>not</b> used. If the name is
   * not valid, then a compileError is reported, and the value saxon:error-name is returned.
   *
   * @param lexicalQName  The lexical QName as written, in the form "[prefix:]localname". Leading and trailing whitespace
   *                      will be trimmed. The EQName syntax "Q{uri}local" is also
   *                      accepted.
   * @param errorCode     The error code to be used if the QName is not valid. If this is set to null,
   *                      then the code used is XTSE0280 for an undeclared prefix, and XTSE0020
   *                      for all other errors. The code XTSE0080 is used if the URI is a reserved
   *                      namespace, regardless of the supplied error code.
   * @param attributeName EQName of the attribute containing the QName, for use in error reporting.
   *                      May be null.
   * @return the StructuredQName representation of this lexical QName
   */
  final def makeQName(lexicalQName: String, errorCode: String, attributeName: String): StructuredQName = {
    var qName = null
    try qName = StructuredQName.fromLexicalQName(lexicalQName, false, true, this)
    catch {
      case e: XPathException =>
        e.setIsStaticError(true)
        if (errorCode == null) {
          val code = e.getErrorCodeLocalPart
          if ("FONS0004" == code) e.setErrorCode("XTSE0280")
          else if ("FOCA0002" == code) e.setErrorCode("XTSE0020")
          else if (code == null) e.setErrorCode("XTSE0020")
        }
        else e.setErrorCode(errorCode)
        if (attributeName == null) e.setLocator(this)
        else e.setLocator(new AttributeLocation(this, StructuredQName.fromEQName(attributeName)))
        compileError(e)
        qName = new StructuredQName("saxon", NamespaceConstant.SAXON, "error-name")
    }
    if (NamespaceConstant.isReserved(qName.getURI)) {
      if (qName.hasURI(NamespaceConstant.XSLT)) {
        if (qName.getLocalPart == "initial-template" && (this.isInstanceOf[XSLTemplate] || this.isInstanceOf[XSLCallTemplate])) return qName
        if (qName.getLocalPart == "original") { // OK if within xsl:override
          if (findAncestorElement(StandardNames.XSL_OVERRIDE) != null) return qName
        }
      }
      val err = new XmlProcessingIncident("Namespace prefix " + qName.getPrefix + " refers to a reserved namespace", "XTSE0080")
      compileError(err)
      qName = new StructuredQName("saxon", NamespaceConstant.SAXON, "error-name")
    }
    qName
  }

  /**
   * Get the first ancestor element in the stylesheet tree that has a given name, supplied by
   * fingerprint.
   *
   * @param fingerprint the name of the required element
   * @return the first (innermost) ancestor with the required name, or null if none is found
   */
  private[style] def findAncestorElement(fingerprint: Int): StyleElement = {
    var parent = getParent
    while ( {
      true
    }) if (parent.isInstanceOf[StyleElement]) if (parent.getFingerprint == fingerprint) return parent.asInstanceOf[StyleElement]
    else parent = parent.getParent
    else return null
  }

  /**
   * Assuming this is an xsl:use-package element, find the package to which it refers.
   *
   * @return the package referenced by this xsl:use-package element; or null if this is not
   *         an xsl:use-package element
   */
  def getUsedPackage = null

  /**
   * Check that a reference to xsl:original appears within an xsl:override element, and that
   * the name of the containing component matches the name of a component in the used stylesheet
   * package; return the component in that package with matching symbolic name
   *
   * @param componentKind the kind of component required, e.g. StandardNames.XSL_TEMPLATE
   * @return the component with matching name in the used stylesheet
   * @throws XPathException if the xsl:original reference appears in an invalid context
   */
  @throws[XPathException]
  def getXslOriginal(componentKind: Int): Actor = {
    val container = if (componentKind == getFingerprint) this
    else findAncestorElement(componentKind)
    if (!container.isInstanceOf[StylesheetComponent]) throw new XPathException("A reference to xsl:original appears within the wrong kind of component: in this case" + ", it must be within xsl:" + getNamePool.getLocalName(componentKind), "XTSE0650", this)
    val originalName = container.asInstanceOf[StylesheetComponent].getSymbolicName()
    val xslOverride = container.findAncestorElement(StandardNames.XSL_OVERRIDE)
    if (xslOverride == null) throw new XPathException("A reference to xsl:original can be used only within an xsl:override element")
    val usePackage = xslOverride.findAncestorElement(StandardNames.XSL_USE_PACKAGE)
    if (usePackage == null) throw new XPathException("The parent of xsl:override must be an xsl:use-package element", "XTSE0010", xslOverride)
    val overridden = usePackage.getUsedPackage.getComponent(originalName)
    if (overridden == null) { // the error will be detected and reported elsewhere
      return null
    }
    overridden.getActor
  }

  /**
   * Get the component that this declaration overrides, or null if this is not an overriding declaration
   *
   * @return the overridden component, or null
   */
  private[style] def getOverriddenComponent: Component = {
    if (!this.isInstanceOf[StylesheetComponent]) return null
    val originalName = this.asInstanceOf[StylesheetComponent].getSymbolicName()
    val xslOverride = findAncestorElement(StandardNames.XSL_OVERRIDE)
    if (xslOverride == null) return null
    val usePackage = xslOverride.findAncestorElement(StandardNames.XSL_USE_PACKAGE)
    if (usePackage == null) return null
    usePackage.getUsedPackage.getComponent(originalName)
  }

  def makeRetainedStaticContext = getStaticContext.makeRetainedStaticContext

  /**
   * Ask whether this instruction requires a different retained static context from the containing
   * (parent) instruction. That is, this instruction changes the static base URI, the default collation,
   * or the set of in-scope namespaces.
   *
   * @return true if the context for evaluating this instruction differs in relevant ways from that
   *         of the calling instruction
   */
  private[style] def changesRetainedStaticContext = {
    val parent = getParent
    parent == null || !ExpressionTool.equalOrNull(getBaseURI, parent.getBaseURI) || defaultCollationName != null || defaultXPathNamespace != null || !parent.isInstanceOf[StyleElement] || (getAllNamespaces ne parent.getAllNamespaces) || getEffectiveVersion != parent.asInstanceOf[StyleElement].getEffectiveVersion
  }

  /**
   * Get the namespace context of the instruction.
   *
   * @return the namespace context. This method does not make a copy of the namespace context,
   *         so a reference to the returned NamespaceResolver will lock the stylesheet tree in memory.
   */
  def getNamespaceResolver = this

  /**
   * Process the attributes of this element and all its children
   *
   * @throws XPathException in the event of a static error being detected
   */
  @throws[XPathException]
  def processAllAttributes() = {
    processDefaultCollationAttribute()
    processDefaultMode()
    staticContext = new ExpressionContext(this, null)
    processAttributes()
    import scala.collection.JavaConversions._
    for (child <- children(classOf[StyleElement].isInstance)) {
      child.asInstanceOf[StyleElement].processAllAttributes()
    }
  }

  /**
   * Process the standard attributes such as {@code [xsl:]expand-text}. Invokes
   * {@link #compileError(String)} or similar if the value of any of these attributes
   * is invalid.
   *
   * <p>The method processes:</p>
   * <ul>
   * <li>{@code extension-element-prefixes}</li>
   * <li>{@code exclude-result-prefixes}</li>
   * <li>{@code version}</li>
   * <li>{@code default-xpath-namespace}</li>
   * <li>{@code default-validation}</li>
   * <li>{@code expand-text}</li>
   * </ul>
   *
   * <p>but not:</p>
   * <ul>
   * <li>{@code default-collation}</li>
   * <li>{@code default-mode}</li>
   * </ul>
   *
   * @param namespace either "" to find the attributes in the null namespace,
   *                  or NamespaceConstant.XSLT to find them in the XSLT namespace
   */
  def processStandardAttributes(namespace: String) = {
    processExtensionElementAttribute(namespace)
    processExcludedNamespaces(namespace)
    processVersionAttribute(namespace)
    processDefaultXPathNamespaceAttribute(namespace)
    processDefaultValidationAttribute(namespace)
    processExpandTextAttribute(namespace)
  }

  /**
   * Get an attribute value given the Clark name of the attribute (that is,
   * the name in {uri}local format).
   *
   * @param clarkName the name of the attribute in {uri}local format
   * @return the value of the attribute if it exists, or null otherwise
   */
  def getAttributeValue(clarkName: String) = {
    val nn = FingerprintedQName.fromClarkName(clarkName)
    getAttributeValue(nn.getURI, nn.getLocalPart)
  }

  /**
   * Process the attribute list for the element. This is a wrapper method that calls
   * prepareAttributes (provided in the subclass) and traps any exceptions
   */
  final private[style] def processAttributes() = prepareAttributes()

  /**
   * Check whether an unknown attribute is permitted.
   *
   * @param nc The name code of the attribute name
   */
  protected def checkUnknownAttribute(nc: NodeName): Unit = {
    val attributeURI = nc.getURI
    val elementURI = getURI
    val clarkName = nc.getStructuredQName.getClarkName
    if (forwardsCompatibleModeIsEnabled) { // then unknown attributes are permitted and ignored
      return
    }
    // allow xsl:extension-element-prefixes etc on an extension element
    if (isInstruction && attributeURI == NamespaceConstant.XSLT && !(elementURI == NamespaceConstant.XSLT) && (clarkName.endsWith("}default-collation") || clarkName.endsWith("}default-mode") || clarkName.endsWith("}xpath-default-namespace") || clarkName.endsWith("}expand-text") || clarkName.endsWith("}extension-element-prefixes") || clarkName.endsWith("}exclude-result-prefixes") || clarkName.endsWith("}version") || clarkName.endsWith("}default-validation") || clarkName.endsWith("}use-when"))) return
    // allow standard attributes on an XSLT element
    if (elementURI == NamespaceConstant.XSLT && (clarkName == "default-collation" || clarkName == "default-mode" || clarkName == "expand-text" || clarkName == "xpath-default-namespace" || clarkName == "extension-element-prefixes" || clarkName == "exclude-result-prefixes" || clarkName == "version" || clarkName == "default-validation" || clarkName == "use-when")) return
    if ("" == attributeURI || NamespaceConstant.XSLT == attributeURI) compileErrorInAttribute("Attribute " + Err.wrap(nc.getDisplayName, Err.ATTRIBUTE) + " is not allowed on element " + Err.wrap(getDisplayName, Err.ELEMENT), "XTSE0090", clarkName)
    else if (NamespaceConstant.SAXON == attributeURI) compileWarning("Unrecognized attribute in Saxon namespace: " + nc.getDisplayName, "XTSE0090")
  }

  /**
   * Set the attribute list for the element. This is called to process the attributes (note
   * the distinction from processAttributes in the superclass).
   * Must be supplied in a subclass
   */
  protected def prepareAttributes()

  /**
   * Find the last child instruction of this instruction. Returns null if
   * there are no child instructions, or if the last child is a text node.
   *
   * @return the last child instruction, or null if there are no child instructions
   */
  private[style] def getLastChildInstruction = {
    var last = null
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[StyleElement]) last = child.asInstanceOf[StyleElement]
      else last = null
    }
    last
  }

  /**
   * Compile an XPath expression in the context of this stylesheet element
   *
   * @param expression the source text of the XPath expression
   * @param att        the attribute containing the XPath expression, or
   *                   null if the expression is in a text node
   * @return the compiled expression tree for the XPath expression. In the case of an error,
   *         returns an ErrorExpression that will fail at run-time if executed.
   */
  def makeExpression(expression: String, att: AttributeInfo) = try {
    var env = staticContext
    if (att != null) {
      val attName = att.getNodeName.getStructuredQName
      env = getStaticContext(attName)
    }
    ExpressionTool.make(expression, env, 0, Token.EOF, getCompilation.getCompilerInfo.getCodeInjector)
  } catch {
    case err: XPathException =>
      err.maybeSetLocation(allocateLocation)
      if (err.isReportableStatically) compileError(err)
      val erexp = new ErrorExpression(new XmlProcessingException(err))
      erexp.setRetainedStaticContext(makeRetainedStaticContext)
      erexp.setLocation(allocateLocation)
      erexp
  }

  /**
   * Make a pattern in the context of this stylesheet element
   *
   * @param pattern the source text of the pattern
   * @return the compiled pattern
   */
  private[style] def makePattern(pattern: String, attributeName: String) = try {
    val env = getStaticContext(new StructuredQName("", "", attributeName))
    val p = Pattern.make(pattern, env, getCompilation.getPackageData)
    p.setLocation(allocateLocation)
    p
  } catch {
    case err: XPathException =>
      err.maybeSetErrorCode("XTSE0340")
      if ("XPST0003" == err.getErrorCodeLocalPart) err.setErrorCode("XTSE0340")
      compileError(err)
      val nsp = new NodeTestPattern(AnyNodeTest.getInstance)
      nsp.setLocation(allocateLocation)
      nsp
  }

  /**
   * Make an attribute value template in the context of this stylesheet element
   *
   * @param expression the source text of the attribute value template
   * @param att        the attribute containing the AVT, or null in the case of a text value template
   * @return a compiled XPath expression that computes the value of the attribute (including
   *         concatenating the results of embedded expressions with any surrounding fixed text)
   */
  protected def makeAttributeValueTemplate(expression: String, att: AttributeInfo) = {
    var env = if (att == null) staticContext
    else getStaticContext(att.getNodeName.getStructuredQName)
    if (att != null) {
      val attName = att.getNodeName.getStructuredQName
      env = getStaticContext(attName)
    }
    try AttributeValueTemplate.make(expression, env)
    catch {
      case err: XPathException =>
        compileError(err)
        new StringLiteral(expression)
    }
  }

  /**
   * Check the value of an attribute, as supplied statically
   *
   * @param name    the name of the attribute
   * @param value   the value of the attribute
   * @param avt     set to true if the value is permitted to be an attribute value template
   * @param allowed list of permitted values, which must be in alphabetical order
   */
  private[style] def checkAttributeValue(name: String, value: String, avt: Boolean, allowed: Array[String]): Unit = {
    if (avt && value.contains("{")) return
    if (util.Arrays.binarySearch(allowed, value) < 0) {
      val sb = new FastStringBuffer(FastStringBuffer.C64)
      sb.append("Invalid value for ")
      sb.append("@")
      sb.append(name)
      sb.append(". Value must be one of (")
      for (i <- 0 until allowed.length) {
        sb.append(if (i == 0) ""
        else "|")
        sb.append(allowed(i))
      }
      sb.append(")")
      compileError(sb.toString, "XTSE0020")
    }
  }

  /**
   * Process an attribute whose value is yes, no, true, false, 1, or 0; returning true or false.
   *
   * @param name  the name of the attribute (used for diagnostics)
   * @param value the value of the attribute
   */
  def processBooleanAttribute(name: String, value: String) = {
    val s = Whitespace.trim(value)
    if (StyleElement.isYes(s)) true
    else if (StyleElement.isNo(s)) false
    else {
      invalidAttribute(name, "yes|no | true|false | 1|0")
      false // never get here
    }
  }

  private[style] def processStreamableAtt(streamableAtt: String): Boolean = {
    val streamable = processBooleanAttribute("streamable", streamableAtt)
    if (streamable) {
      if (!getConfiguration.isLicensedFeature(Configuration.LicenseFeature.ENTERPRISE_XSLT)) {
        compileWarning("Request for streaming ignored: this Saxon configuration does not support streaming", SaxonErrorCode.SXST0068)
        return false
      }
      if ("off" == getConfiguration.getConfigurationProperty(Feature.STREAMABILITY)) {
        compileWarning("Request for streaming ignored: streaming is disabled in this Saxon configuration", SaxonErrorCode.SXST0068)
        return false
      }
    }
    streamable
  }

  /**
   * Process an attribute whose value is a SequenceType
   *
   * @param sequenceType the source text of the attribute
   * @return the processed sequence type
   * @throws XPathException if the syntax is invalid or for example if it refers to a type
   *                        that is not in the static context
   */
  @throws[XPathException]
  def makeSequenceType(sequenceType: String) = {
    val env = getStaticContext
    var languageLevel = env.getXPathVersion
    if (languageLevel == 30) languageLevel = 305 // XPath 3.0 + XSLT extensions
    val parser = getConfiguration.newExpressionParser("XP", false, languageLevel)
    val qp = new QNameParser(staticContext.getNamespaceResolver).withAcceptEQName(staticContext.getXPathVersion >= 30).withErrorOnBadSyntax("XPST0003").withErrorOnUnresolvedPrefix("XPST0081")
    parser.setQNameParser(qp)
    parser.parseSequenceType(sequenceType, staticContext)
  }

  @throws[XPathException]
  private[style] def makeExtendedSequenceType(sequenceType: String) = {
    getStaticContext
    val parser = getConfiguration.newExpressionParser("XP", false, 31)
    val qp = new QNameParser(staticContext.getNamespaceResolver).withAcceptEQName(staticContext.getXPathVersion >= 30).withErrorOnBadSyntax("XPST0003").withErrorOnUnresolvedPrefix("XPST0081")
    parser.setQNameParser(qp)
    parser.parseExtendedSequenceType(sequenceType, staticContext)
  }

  /**
   * Process the [xsl:]extension-element-prefixes attribute if there is one
   *
   * @param ns the namespace URI of the attribute - either the XSLT namespace or "" for the null namespace
   */
  private[style] def processExtensionElementAttribute(ns: String) = {
    val ext = getAttributeValue(ns, "extension-element-prefixes")
    if (ext != null) { // go round twice, once to count the values and next to add them to the array
      var count = 0
      val st1 = new StringTokenizer(ext, " \t\n\r", false)
      while ( {
        st1.hasMoreTokens
      }) {
        st1.nextToken
        count += 1
      }
      extensionNamespaces = new Array[String](count)
      count = 0
      val st2 = new StringTokenizer(ext, " \t\n\r", false)
      while ( {
        st2.hasMoreTokens
      }) {
        var s = st2.nextToken
        if ("#default" == s) s = ""
        val uri = getURIForPrefix(s, false)
        if (uri == null) {
          extensionNamespaces = null
          compileError("Namespace prefix " + s + " is undeclared", "XTSE1430")
        }
        else if (NamespaceConstant.isReserved(uri)) {
          compileError("Namespace " + uri + " is reserved: it cannot be used for extension instructions " + "(perhaps exclude-result-prefixes was intended).", "XTSE0085")
          extensionNamespaces({
            count += 1; count - 1
          }) = uri
        }
        else extensionNamespaces({
          count += 1; count - 1
        }) = uri
      }
    }
  }

  /**
   * Process the [xsl:]exclude-result-prefixes attribute if there is one
   *
   * @param ns the namespace URI of the attribute required, either the XSLT namespace or ""
   */
  private[style] def processExcludedNamespaces(ns: String) = {
    val ext = getAttributeValue(ns, "exclude-result-prefixes")
    if (ext != null) if ("#all" == Whitespace.trim(ext)) {
      val excluded = new util.ArrayList[String]
      import scala.collection.JavaConversions._
      for (binding <- getAllNamespaces) {
        excluded.add(binding.getURI)
      }
      excludedNamespaces = excluded.toArray(new Array[String](0))
    }
    else {
      var count = 0
      val st1 = new StringTokenizer(ext, " \t\n\r", false)
      while ( {
        st1.hasMoreTokens
      }) {
        st1.nextToken
        count += 1
      }
      excludedNamespaces = new Array[String](count)
      count = 0
      val st2 = new StringTokenizer(ext, " \t\n\r", false)
      while ( {
        st2.hasMoreTokens
      }) {
        var s = st2.nextToken
        if ("#default" == s) s = ""
        else if ("#all" == s) compileError("In exclude-result-prefixes, cannot mix #all with other values", "XTSE0020")
        val uri = getURIForPrefix(s, true)
        if (uri == null) {
          excludedNamespaces = null
          compileError("Namespace prefix " + s + " is not declared", "XTSE0808")
          break //todo: break is not supported
        }
        excludedNamespaces({
          count += 1; count - 1
        }) = uri
        if (s.isEmpty && uri.isEmpty) compileError("Cannot exclude the #default namespace when no default namespace is declared", "XTSE0809")
      }
    }
  }

  /**
   * Process the [xsl:]version attribute if there is one
   *
   * @param ns the namespace URI of the attribute required, either the XSLT namespace or ""
   */
  protected def processVersionAttribute(ns: String) = {
    val v = Whitespace.trim(getAttributeValue(ns, "version"))
    if (v != null) {
      val `val` = BigDecimalValue.makeDecimalValue(v, true)
      if (`val`.isInstanceOf[ValidationFailure]) {
        version = 30
        compileError("The version attribute must be a decimal literal", "XTSE0110")
      }
      else { // Note this will normalize the decimal so that trailing spaces are not significant
        version = `val`.asInstanceOf[BigDecimalValue].getDecimalValue.multiply(BigDecimal.TEN).intValue
        if (version < 20 && version != 10) { // XSLT 2.0 says use backwards compatible mode. XSLT 3.0 says we can raise an error.
          // Both allow a warning
          issueWarning("Unrecognized version " + `val` + ": treated as 1.0", this)
          version = 10
        }
        else if (version > 20 && version < 30) {
          issueWarning("Unrecognized version " + `val` + ": treated as 2.0", this)
          version = 20
        }
      }
    }
  }

  /**
   * Get the numeric value of the version number appearing as an attribute on this element,
   * or inherited from its ancestors
   *
   * @return the version number times ten as an integer
   */
  private[style] def getEffectiveVersion: Int = {
    if (version == -1) {
      val node = getParent
      if (node.isInstanceOf[StyleElement]) version = node.asInstanceOf[StyleElement].getEffectiveVersion
      else return 20 // defensive programming
    }
    version
  }

  /**
   * Validate the value of the [xsl:]validation attribute
   *
   * @param value the raw value of the attribute
   * @return the encoded value of the attribute
   */
  protected def validateValidationAttribute(value: String) = {
    var code = Validation.getCode(value)
    if (code == Validation.INVALID) {
      val prefix = if (this.isInstanceOf[LiteralResultElement]) "xsl:"
      else ""
      compileError("Invalid value of " + prefix + "validation attribute: '" + value + "'", "XTSE0020")
      code = getDefaultValidation
    }
    if (!isSchemaAware) {
      if (code == Validation.STRICT) compileError("To perform validation, a schema-aware XSLT processor is needed", "XTSE1660")
      code = Validation.STRIP
    }
    code
  }

  /**
   * Ask if an extension attribute is allowed; if no Professional Edition license is available,
   * issue a warning saying the attribute is ignored, and return false
   *
   * @param attribute the name of the attribute
   */
  protected def isExtensionAttributeAllowed(attribute: String) = if (getConfiguration.isLicensedFeature(Configuration.LicenseFeature.PROFESSIONAL_EDITION)) true
  else {
    issueWarning("The option " + getDisplayName + "/@" + attribute + " is ignored because it requires a Saxon-PE license", this)
    false
  }

  /**
   * Determine whether forwards-compatible mode is enabled for this element
   *
   * @return true if forwards-compatible mode is enabled
   */
  private[style] def forwardsCompatibleModeIsEnabled = getEffectiveVersion > 30

  /**
   * Determine whether 1.0-compatible mode is enabled for this element
   *
   * @return true if 1.0 compatable mode is enabled, that is, if this or an enclosing
   *         element specifies an [xsl:]version attribute whose value is less than 2.0
   */
  private[style] def xPath10ModeIsEnabled = getEffectiveVersion < 20

  /**
   * Process the [xsl:]default-collation attribute if there is one.
   */
  private[style] def processDefaultCollationAttribute(): Unit = {
    val ns = if (getURI == NamespaceConstant.XSLT) ""
    else NamespaceConstant.XSLT
    val v = getAttributeValue(ns, "default-collation")
    val reasons = new StringBuilder
    if (v != null) {
      val st = new StringTokenizer(v, " \t\n\r", false)
      while ( {
        st.hasMoreTokens
      }) {
        var uri = st.nextToken
        if (uri == NamespaceConstant.CODEPOINT_COLLATION_URI) {
          defaultCollationName = uri
          return
        }
        else {
          var collationURI = null
          try {
            collationURI = new URI(uri)
            if (!collationURI.isAbsolute) {
              val base = new URI(getBaseURI)
              collationURI = base.resolve(collationURI)
              uri = collationURI.toString
            }
          } catch {
            case err: URISyntaxException =>
              compileError("default collation '" + uri + "' is not a valid URI")
              uri = NamespaceConstant.CODEPOINT_COLLATION_URI
          }
          try if (getConfiguration.getCollation(uri) != null) {
            defaultCollationName = uri
            return
          }
          else {
            if (reasons.length != 0) reasons.append("; ")
            reasons.append("Collation ").append(uri).append(" is not recognized")
          }
          catch {
            case e: XPathException =>
              if (reasons.length != 0) reasons.append("; ")
              reasons.append("Collation ").append(uri).append(" is not recognized (").append(e.getMessage).append(")")
            // Ignore an unrecognized collation URI
          }
        }
        // if not recognized, try the next URI in order
      }
      var msg = "No recognized collation URI found in default-collation attribute"
      if (reasons.length != 0) {
        msg += ". "
        msg += reasons.toString
      }
      compileErrorInAttribute(msg, "XTSE0125", new StructuredQName("", ns, "default-collation").getClarkName)
    }
  }

  /**
   * Get the default collation for this stylesheet element. If no default collation is
   * specified in the stylesheet, return the Unicode codepoint collation name.
   *
   * @return the name of the default collation
   */
  protected def getDefaultCollationName: String = {
    var e = this
    while ( {
      true
    }) {
      if (e.defaultCollationName != null) return e.defaultCollationName
      val p = e.getParent
      if (!p.isInstanceOf[StyleElement]) break //todo: break is not supported
      e = p.asInstanceOf[StyleElement]
    }
    getConfiguration.getDefaultCollationName
  }

  /**
   * Find a named collation. Note this method should only be used at compile-time, before declarations
   * have been pre-processed. After that time, use getCollation().
   *
   * @param name    identifies the name of the collation required
   * @param baseURI the base URI to be used for resolving the collation name if it is relative
   * @return null if the collation is not found
   * @throws XPathException if either URI is invalid as a URI
   */
  @throws[XPathException]
  private[style] def findCollation(name: String, baseURI: String) = getConfiguration.getCollation(name, baseURI)

  /**
   * Process the [xsl:]default-mode attribute if there is one
   */
  private[style] def processDefaultMode() = {
    val ns = if (getURI == NamespaceConstant.XSLT) ""
    else NamespaceConstant.XSLT
    val v = getAttributeValue(ns, "default-mode")
    if (v != null) if (v == "#unnamed") defaultMode = Mode.UNNAMED_MODE_NAME
    else defaultMode = makeQName(v, null, "default-mode")
    val psm = compilation.getPrincipalStylesheetModule
    val checkedName = defaultMode
    if (psm != null && psm.isDeclaredModes) { // It will be null on the xsl:package element itself
      psm.addFixupAction(() => {
        def foo() = {
          if (psm.getRuleManager.obtainMode(checkedName, false) == null) {
            val err = new XPathException("Mode " + checkedName.getDisplayName + " is not declared in an xsl:mode declaration", "XTSE3085")
            err.setLocation(this)
            throw err
          }
        }

        foo()
      })
    }
  }

  /**
   * Get the default mode for this stylesheet element.
   *
   * @return the name of the default mode, obtained by looking for the default-mode attribute on this element
   *         and all all its ancestors. In the absence of a default-mode attribute, returns the magic value
   *         { @link Mode#UNNAMED_MODE_NAME}
   */
  @throws[XPathException]
  private[style] def getDefaultMode: StructuredQName = {
    if (defaultMode == null) {
      processDefaultMode()
      if (defaultMode == null) {
        val p = getParent
        if (p.isInstanceOf[StyleElement]) return defaultMode = p.asInstanceOf[StyleElement].getDefaultMode
        else return defaultMode = Mode.UNNAMED_MODE_NAME
      }
    }
    defaultMode
  }

  /**
   * Check whether a particular extension element namespace is defined on this node.
   * This checks this node only, not the ancestor nodes.
   * The implementation checks whether the prefix is included in the
   * [xsl:]extension-element-prefixes attribute.
   *
   * @param uri the namespace URI being tested
   * @return true if this namespace is defined on this element as an extension element namespace
   */
  private def definesExtensionElement(uri: String): Boolean = {
    if (extensionNamespaces == null) return false
    for (extensionNamespace <- extensionNamespaces) {
      if (extensionNamespace == uri) return true
    }
    false
  }

  /**
   * Check whether a namespace uri defines an extension element. This checks whether the
   * namespace is defined as an extension namespace on this or any ancestor node.
   *
   * @param uri the namespace URI being tested
   * @return true if the URI is an extension element namespace URI
   */
  def isExtensionNamespace(uri: String): Boolean = {
    var anc = this
    while ( {
      anc.isInstanceOf[StyleElement]
    }) {
      if (anc.asInstanceOf[StyleElement].definesExtensionElement(uri)) return true
      anc = anc.getParent
    }
    false
  }

  /**
   * Check whether this node excludes a particular namespace from the result.
   * This method checks this node only, not the ancestor nodes.
   *
   * @param uri the namespace URI being tested
   * @return true if the namespace is excluded by virtue of an [xsl:]exclude-result-prefixes attribute
   */
  private def definesExcludedNamespace(uri: String): Boolean = {
    if (excludedNamespaces == null) return false
    for (excludedNamespace <- excludedNamespaces) {
      if (excludedNamespace == uri) return true
    }
    false
  }

  /**
   * Check whether a namespace uri defines an namespace excluded from the result.
   * This checks whether the namespace is defined as an excluded namespace on this
   * or any ancestor node.
   *
   * @param uri the namespace URI being tested
   * @return true if this namespace URI is a namespace excluded by virtue of exclude-result-prefixes
   *         on this element or on an ancestor element
   */
  private[style] def isExcludedNamespace(uri: String): Boolean = {
    if (uri == NamespaceConstant.XSLT || uri == NamespaceConstant.XML) return true
    if (isExtensionNamespace(uri)) return true
    var anc = this
    while ( {
      anc.isInstanceOf[StyleElement]
    }) {
      if (anc.asInstanceOf[StyleElement].definesExcludedNamespace(uri)) return true
      anc = anc.getParent
    }
    false
  }

  /**
   * Process the [xsl:]xpath-default-namespace attribute if there is one
   *
   * @param ns the namespace URI of the attribute required  (the default namespace or the XSLT namespace.)
   */
  private[style] def processDefaultXPathNamespaceAttribute(ns: String) = {
    val v = getAttributeValue(ns, "xpath-default-namespace")
    if (v != null) defaultXPathNamespace = v
  }

  /**
   * Get the default XPath namespace for elements and types
   *
   * @return the default namespace for elements and types.
   *         Return { @link NamespaceConstant#NULL} for the non-namespace
   */
  def getDefaultXPathNamespace: String = {
    var anc = this
    while ( {
      anc.isInstanceOf[StyleElement]
    }) {
      val x = anc.asInstanceOf[StyleElement].defaultXPathNamespace
      if (x != null) return x
      anc = anc.getParent
    }
    compilation.getCompilerInfo.getDefaultElementNamespace
  }

  /**
   * Process the [xsl:]expand-text attribute if there is one (and if XSLT 3.0 is enabled)
   *
   * @param ns the namespace URI of the attribute required  (the default namespace or the XSLT namespace.)
   */
  private[style] def processExpandTextAttribute(ns: String) = {
    val v = getAttributeValue(ns, "expand-text")
    if (v != null) expandText = processBooleanAttribute("expand-text", v)
    else {
      val parent = getParent
      expandText = parent.isInstanceOf[StyleElement] && parent.asInstanceOf[StyleElement].expandText
    }
  }

  /**
   * Process the [xsl:]expand-text attribute if there is one
   *
   * @param ns the namespace URI of the attribute required  (the default namespace or the XSLT namespace.)
   */
  private[style] def processDefaultValidationAttribute(ns: String) = {
    val v = getAttributeValue(ns, "default-validation")
    if (v != null) {
      val `val` = Validation.getCode(v)
      if (`val` == Validation.STRIP || `val` == Validation.PRESERVE) defaultValidation = `val`
      else compileErrorInAttribute("@default-validation must be preserve|strip", "XTSE0020", "default-validation")
    }
  }

  /**
   * Ask whether content value templates are available within this element
   *
   * @return true if content value templates are enabled
   */
  private[style] def isExpandingText = expandText

  /**
   * Get the Schema type definition for a type named in the stylesheet (in a
   * "type" attribute).
   *
   * @param typeAtt the value of the type attribute
   * @return the corresponding schema type
   */
  def getSchemaType(typeAtt: String): SchemaType = {
    try {
      var uri = null
      var lname = null
      if (typeAtt.startsWith("Q{")) {
        val q = makeQName(typeAtt, "XTSE1520", "type")
        uri = q.getURI
        lname = q.getLocalPart
      }
      else {
        val parts = NameChecker.getQNameParts(typeAtt)
        lname = parts(1)
        if ("" == parts(0)) { // Name is unprefixed: use the default-xpath-namespace
          uri = getDefaultXPathNamespace
        }
        else {
          uri = getURIForPrefix(parts(0), false)
          if (uri == null) {
            compileError("Namespace prefix for type annotation is undeclared", "XTSE1520")
            return null
          }
        }
      }
      if (uri == NamespaceConstant.SCHEMA) {
        val t = BuiltInType.getSchemaTypeByLocalName(lname)
        if (t == null) {
          compileError("Unknown built-in type " + typeAtt, "XTSE1520")
          return null
        }
        return t
      }
      // not a built-in type: look in the imported schemas
      if (!getPrincipalStylesheetModule.isImportedSchema(uri)) {
        compileError("There is no imported schema for the namespace of type " + typeAtt, "XTSE1520")
        return null
      }
      val qName = new StructuredQName("", uri, lname)
      val stype = getConfiguration.getSchemaType(qName)
      if (stype == null) compileError("There is no type named " + typeAtt + " in an imported schema", "XTSE1520")
      return stype
    } catch {
      case err: QNameException =>
        compileError("Invalid type name. " + err.getMessage, "XTSE1520")
    }
    null
  }

  /**
   * Get the type annotation to use for a given schema type
   *
   * @param schemaType the schema type
   * @return the corresponding numeric type annotation
   */
  def getTypeAnnotation(schemaType: SchemaType) = schemaType.asInstanceOf[SimpleType]

  /**
   * Check that the stylesheet element is valid. This is called once for each element, after
   * the entire tree has been built. As well as validation, it can perform first-time
   * initialisation. The default implementation does nothing; it is normally overriden
   * in subclasses.
   *
   * @param decl the declaration to be validated
   * @throws XPathException if any error is found during validation
   */
  @throws[XPathException]
  def validate(decl: ComponentDeclaration) = {
  }

  /**
   * Hook to allow additional validation of a parent element immediately after its
   * children have been validated.
   *
   * @throws XPathException if any error is found during post-traversal validation
   */
  @throws[XPathException]
  def postValidate() = {
  }

  /**
   * Method supplied by declaration elements to add themselves to a stylesheet-level index
   *
   * @param decl the Declaration being indexed. (This corresponds to the StyleElement object
   *             except in cases where one module is imported several times with different precedence.)
   * @param top  represents the outermost XSLStylesheet or XSLPackage element
   * @throws XPathException if any error is encountered
   */
  @throws[XPathException]
  def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = {
  }

  /**
   * Type-check an expression. This is called to check each expression while the containing
   * instruction is being validated. It is not just a static type-check, it also adds code
   * to perform any necessary run-time type checking and/or conversion.
   *
   * @param name the name of the attribute containing the expression to be checked (used for diagnostics)
   * @param exp  the expression to be checked
   * @return the (possibly rewritten) expression after type checking
   * @throws XPathException if type-checking fails statically, that is, if it can be determined that the
   *                        supplied value for the expression cannot possibly be of the required type
   */
  // Note: the typeCheck() call is done at the level of individual path expression; the optimize() call is done
  // for a template or function as a whole. We can't do it all at the function/template level because
  // the static context (e.g. namespaces) changes from one XPath expression to another.
  @throws[XPathException]
  def typeCheck(name: String, exp: Expression): Expression = {
    if (exp == null) return null
    val config = getConfiguration
    if (config.getBooleanProperty(Feature.STRICT_STREAMABILITY)) return exp
    try {
      exp = exp.typeCheck(makeExpressionVisitor, config.makeContextItemStaticInfo(Type.ITEM_TYPE, true))
      exp = ExpressionTool.resolveCallsToCurrentFunction(exp)
      //            if (explaining) {
      //                System.err.println("Attribute '" + name + "' of element '" + getDisplayName() + "' at line " + getLineNumber() + ':');
      //                System.err.println("Static type: " +
      //                        SequenceType.makeSequenceType(exp.getItemType(), exp.getCardinality()));
      //                System.err.println("Optimized expression tree:");
      //                exp.display(10, getNamePool(), System.err);
      //            CodeInjector injector = getCompilation().getCompilerInfo().getCodeInjector();
      //            if (injector != null) {
      //                return injector.inject(exp, getStaticContext(), LocationKind.XPATH_IN_XSLT, new StructuredQName("", "", name));
      exp
    } catch {
      case err: XPathException =>
        // we can't report a dynamic error such as divide by zero unless the expression
        // is actually executed.
        //err.printStackTrace();
        if (err.isReportableStatically) {
          err.setLocation(new AttributeLocation(this, StructuredQName.fromClarkName(name)))
          compileError(err)
          exp
        }
        else {
          val erexp = new ErrorExpression(new XmlProcessingException(err))
          ExpressionTool.copyLocationInfo(exp, erexp)
          erexp
        }
    }
  }

  /**
   * Allocate slots in the local stack frame to range variables used in an XPath expression
   *
   * @param exp the XPath expression for which slots are to be allocated
   */
  private[style] def allocateLocalSlots(exp: Expression) = {
    val slotManager = getContainingSlotManager
    if (slotManager == null) throw new AssertionError("Slot manager has not been allocated")
    else {
      val firstSlot = slotManager.getNumberOfVariables
      val highWater = ExpressionTool.allocateSlots(exp, firstSlot, slotManager)
      if (highWater > firstSlot) {
        slotManager.setNumberOfVariables(highWater)
        // This algorithm is not very efficient because it never reuses
        // a slot when a variable goes out of scope. But at least it is safe.
        // Note that range variables within XPath expressions need to maintain
        // a slot until the instruction they are part of finishes, e.g. in
        // xsl:for-each.
      }
    }
  }

  /**
   * Type-check a pattern. This is called to check each pattern while the containing
   * instruction is being validated. It is not just a static type-check, it also adds code
   * to perform any necessary run-time type checking and/or conversion.
   *
   * @param name    the name of the attribute holding the pattern, for example "match": used in
   *                diagnostics
   * @param pattern the compiled pattern
   * @return the original pattern, or a substitute pattern if it has been rewritten. Returns null
   *         if and only if the supplied pattern is null.
   * @throws net.sf.saxon.trans.XPathException if the pattern fails optimistic static type-checking
   */
  @throws[XPathException]
  def typeCheck(name: String, pattern: Pattern): Pattern = {
    if (pattern == null) return null
    try {
      val cit = Type.ITEM_TYPE
      pattern = pattern.typeCheck(makeExpressionVisitor, getConfiguration.makeContextItemStaticInfo(cit, true))
      var usesCurrent = false
      import scala.collection.JavaConversions._
      for (o <- pattern.operands) {
        val filter = o.getChildExpression
        if (ExpressionTool.callsFunction(filter, Current.FN_CURRENT, false)) {
          usesCurrent = true
          break //todo: break is not supported
        }
      }
      if (usesCurrent) {
        val p2 = new PatternThatSetsCurrent(pattern)
        pattern.bindCurrent(p2.getCurrentBinding)
        pattern = p2
      }
      pattern
    } catch {
      case err: XPathException =>
        // we can't report a dynamic error such as divide by zero unless the pattern
        // is actually executed. We don't have an error pattern available, so we
        // construct one
        if (err.isReportableStatically) {
          val e2 = new XPathException("Error in " + name + " pattern", err)
          e2.setLocator(this)
          e2.setErrorCodeQName(err.getErrorCodeQName)
          throw e2
        }
        else {
          val p = new BasePatternWithPredicate(new NodeTestPattern(ErrorType.getInstance), new ErrorExpression(new XmlProcessingException(err)))
          p.setLocation(allocateLocation)
          p
        }
    }
  }

  /**
   * Fix up references from XPath expressions. Overridden for function declarations
   * and variable declarations
   *
   * @throws net.sf.saxon.trans.XPathException if any references cannot be fixed up.
   */
  @throws[XPathException]
  def fixupReferences() = {
    import scala.collection.JavaConversions._
    for (child <- children(classOf[StyleElement].isInstance)) {
      child.asInstanceOf[StyleElement].fixupReferences()
    }
  }

  /**
   * Get the SlotManager for the containing Procedure definition
   *
   * @return the SlotManager associated with the containing Function, Template, etc,
   *         or null if there is no such containing Function, Template etc.
   */
  def getContainingSlotManager: SlotManager = {
    var node = this
    while ( {
      true
    }) {
      val next = node.getParent
      assert(next != null)
      if (next.isInstanceOf[XSLModuleRoot] || next.getFingerprint == StandardNames.XSL_OVERRIDE) if (node.isInstanceOf[StylesheetComponent]) return node.asInstanceOf[StylesheetComponent].getSlotManager()
      else return null
      node = next
    }
  }

  /**
   * Recursive walk through the stylesheet to validate all nodes
   *
   * @param decl              the declaration to be validated
   * @param excludeStylesheet true if the XSLStylesheet element is to be excluded
   * @throws XPathException if validation fails
   */
  @throws[XPathException]
  def validateSubtree(decl: ComponentDeclaration, excludeStylesheet: Boolean): Unit = {
    if (isActionCompleted(StyleElement.ACTION_VALIDATE)) return
    setActionCompleted(StyleElement.ACTION_VALIDATE)
    if (validationError != null) if (reportingCircumstances eq StyleElement.OnFailure.REPORT_ALWAYS) compileError(validationError)
    else if ((reportingCircumstances eq StyleElement.OnFailure.REPORT_UNLESS_FORWARDS_COMPATIBLE) && !forwardsCompatibleModeIsEnabled) compileError(validationError)
    else if (reportingCircumstances eq StyleElement.OnFailure.REPORT_STATICALLY_UNLESS_FALLBACK_AVAILABLE) {
      var hasFallback = false
      import scala.collection.JavaConversions._
      for (child <- children(classOf[XSLFallback].isInstance)) {
        hasFallback = true
        child.asInstanceOf[XSLFallback].validateSubtree(decl, false)
      }
      if (!hasFallback) compileError(validationError)
    }
    else if (reportingCircumstances eq StyleElement.OnFailure.REPORT_DYNAMICALLY_UNLESS_FALLBACK_AVAILABLE) {
      import scala.collection.JavaConversions._
      for (child <- children(classOf[XSLFallback].isInstance)) {
        child.asInstanceOf[XSLFallback].validateSubtree(decl, false)
      }
    }
    else {
      try validate(decl)
      catch {
        case err: XPathException =>
          compileError(err)
      }
      validateChildren(decl, excludeStylesheet)
      if (getCompilation.getErrorCount == 0) postValidate()
    }
  }

  /**
   * Validate the children of this node, recursively. Overridden for top-level
   * data elements.
   *
   * @param decl              the declaration whose children are to be validated
   * @param excludeStylesheet true if the xsl:stylesheet element is to be excluded
   * @throws XPathException if validation fails
   */
  @throws[XPathException]
  protected def validateChildren(decl: ComponentDeclaration, excludeStylesheet: Boolean) = {
    val containsInstructions = mayContainSequenceConstructor
    var lastChild = null
    var endsWithTextTemplate = false
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[StyleElement]) if (!(excludeStylesheet && child.isInstanceOf[XSLStylesheet])) {
        endsWithTextTemplate = false
        if (containsInstructions && !(child.asInstanceOf[StyleElement]).isInstruction && !isPermittedChild(child.asInstanceOf[StyleElement])) child.asInstanceOf[StyleElement].compileError("An " + getDisplayName + " element must not contain an " + child.getDisplayName + " element", "XTSE0010")
        child.asInstanceOf[StyleElement].validateSubtree(decl, excludeStylesheet)
        lastChild = child.asInstanceOf[StyleElement]
      }
      else endsWithTextTemplate = examineTextNode(child)
    }
    if (lastChild.isInstanceOf[XSLLocalVariable] && !this.isInstanceOf[XSLStylesheet] && !endsWithTextTemplate) lastChild.compileWarning("A variable with no following sibling instructions has no effect", SaxonErrorCode.SXWN9001)
  }

  /**
   * Examine a text node in the stylesheet to see if it is a text value template
   *
   * @param node the text node
   * @throws XPathException if the node is is a text value template with variable content
   */
  @throws[XPathException]
  private def examineTextNode(node: NodeInfo) = if (node.isInstanceOf[TextValueTemplateNode]) {
    node.asInstanceOf[TextValueTemplateNode].validate()
    !(node.asInstanceOf[TextValueTemplateNode]).getContentExpression.isInstanceOf[Literal]
  }
  else false

  /**
   * Check whether a given child is permitted for this element. This method is used when a non-instruction
   * child element such as xsl:sort is encountered in a context where instructions would normally be expected.
   *
   * @param child the child that may or may not be permitted
   * @return true if the child is permitted.
   */
  protected def isPermittedChild(child: StyleElement) = false

  /**
   * Get the principal stylesheet module of the package in which
   * this XSLT element appears
   *
   * @return the containing package
   */
  def getPrincipalStylesheetModule = getCompilation.getPrincipalStylesheetModule

  /**
   * Get the containing package (the principal stylesheet module of the package in which
   * this XSLT element appears)
   *
   * @return the containing package. May be null if the method is called during initialization.
   */
  def getContainingPackage = {
    val psm = getPrincipalStylesheetModule
    if (psm == null) null
    else psm.getStylesheetPackage
  }

  /**
   * Check that among the children of this element, any xsl:sort elements precede any other elements
   *
   * @param sortRequired true if there must be at least one xsl:sort element
   */
  private[style] def checkSortComesFirst(sortRequired: Boolean) = {
    var sortFound = false
    var nonSortFound = false
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLSort]) {
        if (nonSortFound) child.asInstanceOf[XSLSort].compileError("Within " + getDisplayName + ", xsl:sort elements must come before other instructions", "XTSE0010")
        sortFound = true
      }
      else if (child.getNodeKind == Type.TEXT) { // with xml:space=preserve, white space nodes may still be there
        if (!Whitespace.isWhite(child.getStringValueCS)) nonSortFound = true
      }
      else nonSortFound = true
    }
    if (sortRequired && !sortFound) compileError(getDisplayName + " must have at least one xsl:sort child", "XTSE0010")
  }

  /**
   * Convenience method to check that the stylesheet element is at the top level (that is,
   * as a child of xsl:stylesheet or xsl:transform)
   *
   * @param errorCode     the error to throw if it is not at the top level; defaults to XTSE0010
   *                      if the value is null
   * @param allowOverride true if the element is allowed to appear as a child of xsl:override
   */
  def checkTopLevel(/*@NotNull*/ errorCode: String, allowOverride: Boolean) = {
    val parent = getParent
    assert(parent != null)
    if (parent.getFingerprint == StandardNames.XSL_OVERRIDE) if (!allowOverride) compileError("Element " + getDisplayName + " is not allowed as a child of xsl:override")
    else if (!isTopLevel) compileError("Element " + getDisplayName + " must be top-level (a child of xsl:stylesheet, xsl:transform, or xsl:package)", errorCode)
  }

  /**
   * Convenience method to check that the stylesheet element is empty
   */
  def checkEmpty() = if (hasChildNodes) compileError("Element must be empty", "XTSE0260")

  /**
   * Convenience method to report the absence of a mandatory attribute
   *
   * @param attribute the name of the attribute whose absence is to be reported
   */
  def reportAbsence(attribute: String) = compileError("Element must have an " + Err.wrap(attribute, Err.ATTRIBUTE) + " attribute", "XTSE0010")

  /**
   * Compile the instruction on the stylesheet tree into an executable instruction
   * for use at run-time.
   *
   * @param compilation the compilation episode
   * @param decl        the containing top-level declaration, for example xsl:function or xsl:template
   * @return either a ComputedExpression, or null. The value null is returned when compiling an instruction
   *         that returns a no-op, or when compiling a top-level object such as an xsl:template that compiles
   *         into something other than an instruction.
   * @throws net.sf.saxon.trans.XPathException if validation fails
   */
  @throws[XPathException]
  def compile(compilation: Compilation, decl: ComponentDeclaration) = { // no action: default for non-instruction elements
    null
  }

  protected def isWithinDeclaredStreamableConstruct: Boolean = {
    val streamableAtt = getAttributeValue("streamable")
    if (streamableAtt != null) return processStreamableAtt(streamableAtt)
    val parent = getParent
    parent.isInstanceOf[StyleElement] && parent.asInstanceOf[StyleElement].isWithinDeclaredStreamableConstruct
  }

  protected def generateId = {
    val buff = new FastStringBuffer(FastStringBuffer.C16)
    generateId(buff)
    buff.toString
  }

  /**
   * Compile a declaration in the stylesheet tree
   * for use at run-time.
   *
   * @param compilation the compilation episode
   * @param decl        the containing top-level declaration, for example xsl:function or xsl:template
   * @throws net.sf.saxon.trans.XPathException if compilation fails
   */
  @throws[XPathException]
  def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = {
    // no action: default for elements that are not declarations
  }

  /**
   * Compile the children of this instruction on the stylesheet tree, adding the
   * subordinate instructions to the parent instruction on the execution tree.
   *
   * @param compilation   the Executable
   * @param decl          the Declaration of the containing top-level stylesheet element
   * @param includeParams true if xsl:param elements are to be treated as child instructions (true
   *                      for templates but not for functions)
   * @return the compiled sequence constructor
   * @throws net.sf.saxon.trans.XPathException if compilation fails
   */
  @throws[XPathException]
  def compileSequenceConstructor(compilation: Compilation, decl: ComponentDeclaration, includeParams: Boolean) = { // If there are any xsl:on-empty or xsl:on-non-empty children, then reorder the children so
    // that local variable declarations come first. This is necessary to ensure that the instructions
    // remain part of a single "block", since the containing block affects the semantics of
    // on-empty and on-non-empty. Moving variables to come first would probably be a safe strategy in all
    // cases, but there might be a performance disadvantage in some cases, and it's unnecessarily disruptive,
    // especially if there are calls on user extension functions having side-effects.
    // Note: we have already bound variable references to their declarations at this stage, so the reordering
    // does not change the scope of variables.
    // We also move any on-empty instructions to the end of the list, since this makes streaming easier.
    var containsEmptyTest = false
    import scala.collection.JavaConversions._
    for (child <- children) {
      val fp = child.getFingerprint
      if (fp == StandardNames.XSL_ON_EMPTY || fp == StandardNames.XSL_ON_NON_EMPTY) containsEmptyTest = true
    }
    if (containsEmptyTest) {
      val vars = new util.ArrayList[NodeInfo]
      val onEmpties = new util.ArrayList[NodeInfo]
      val others = new util.ArrayList[NodeInfo]
      import scala.collection.JavaConversions._
      for (kid <- children) {
        val fp = kid.getFingerprint
        if (fp == StandardNames.XSL_VARIABLE || fp == StandardNames.XSL_PARAM) vars.add(kid)
        else if (fp == StandardNames.XSL_ON_EMPTY) onEmpties.add(kid)
        else others.add(kid)
      }
      vars.addAll(others)
      vars.addAll(onEmpties)
      compileSequenceConstructor(compilation, decl, new ListIterator[NodeInfo](vars), includeParams)
    }
    else compileSequenceConstructor(compilation, decl, iterateAxis(AxisInfo.CHILD), includeParams)
  }

  /**
   * Compile the children of this instruction on the stylesheet tree, adding the
   * subordinate instructions to the parent instruction on the execution tree.
   *
   * @param compilation   the Executable
   * @param decl          the Declaration of the containing top-level stylesheet element
   * @param iter          Iterator over the children. This is used in the case where there are children
   *                      that are not part of the sequence constructor, for example the xsl:sort children of xsl:for-each;
   *                      the iterator can be positioned past such elements.
   * @param includeParams true if xsl:param elements are to be treated as child instructions (true
   *                      for templates but not for functions)
   * @return the compiled sequence constructor
   * @throws net.sf.saxon.trans.XPathException if compilation fails
   */
  @throws[XPathException]
  def compileSequenceConstructor(compilation: Compilation, decl: ComponentDeclaration, iter: SequenceIterator, includeParams: Boolean): Expression = {
    var locationId = allocateLocation
    val contents = new util.ArrayList[Expression](10)
    var containsSpecials = false
    var node = null
    while ( {
      (node = iter.next.asInstanceOf[NodeInfo]) != null
    }) if (node.getNodeKind == Type.TEXT) if (isExpandingText) compileContentValueTemplate(node.asInstanceOf[TextImpl], contents)
    else { // handle literal text nodes by generating an xsl:value-of instruction, unless expand-text is enabled
      val lookahead = node.iterateAxis(AxisInfo.FOLLOWING_SIBLING)
      val sibling = lookahead.next
      if (!(sibling.isInstanceOf[XSLLocalParam] || sibling.isInstanceOf[XSLSort] || sibling.isInstanceOf[XSLContextItem] || sibling.isInstanceOf[XSLOnCompletion])) { // The test for XSLParam and XSLSort is to eliminate whitespace nodes that have been retained
        // because of xml:space="preserve"
        val text = new ValueOf(new StringLiteral(node.getStringValue), false, false)
        text.setLocation(allocateLocation)
        //                        CodeInjector injector = getCompilation().getCompilerInfo().getCodeInjector();
        //                        if (injector != null) {
        //                            Expression tracer = injector.inject(text);
        //                            tracer.setLocation(text.getLocation());
        //                            text = tracer;
        //                        }
        contents.add(text)
      }
    }
    else if (node.isInstanceOf[XSLLocalVariable]) {
      val `var` = node.asInstanceOf[XSLLocalVariable]
      val sourceBinding = `var`.getSourceBinding
      `var`.compileLocalVariable(compilation, decl)
      val tail = compileSequenceConstructor(compilation, decl, iter, includeParams)
      if (tail == null || Literal.isEmptySequence(tail)) {
        // this doesn't happen, because if there are no instructions following
        // a variable, we'll have taken the var==null path above
        //return result;
      }
      else {
        val let = new LetExpression
        let.setInstruction(true)
        let.setRequiredType(`var`.getRequiredType)
        let.setVariableQName(sourceBinding.getVariableQName)
        let.setSequence(sourceBinding.getSelectExpression)
        let.setAction(tail)
        sourceBinding.fixupBinding(let)
        locationId = node.asInstanceOf[StyleElement].allocateLocation
        let.setLocation(locationId)
        //                    if (getCompilation().getCompilerInfo().isCompileWithTracing()) {
        //                        TraceExpression t = new TraceExpression(let);
        //                        t.setConstructType(LocationKind.LET_EXPRESSION);
        //                        t.setObjectName(var.getSourceBinding().getVariableQName());
        //                        t.setNamespaceResolver(getNamespaceResolver());
        //                        contents.add(t);
        //                    } else {
        contents.add(let)
        //                    }
        if (`var`.changesRetainedStaticContext) let.setRetainedStaticContext(makeRetainedStaticContext)
        //result.setLocationId(locationId);
      }
    }
    else if (node.isInstanceOf[StyleElement]) {
      val snode = node.asInstanceOf[StyleElement]
      val fp = snode.getFingerprint
      if (fp == StandardNames.XSL_ON_EMPTY || fp == StandardNames.XSL_ON_NON_EMPTY) containsSpecials = true
      var child = null
      if (snode.validationError != null && !snode.isInstanceOf[AbsentExtensionElement]) if (snode.reportingCircumstances eq StyleElement.OnFailure.REPORT_IF_INSTANTIATED) child = new ErrorExpression(snode.validationError)
      else child = fallbackProcessing(compilation, decl, snode)
      else {
        child = snode.compile(compilation, decl)
        if (child != null) {
          if (snode.changesRetainedStaticContext) child.setRetainedStaticContext(snode.makeRetainedStaticContext)
          if ((includeParams || !node.isInstanceOf[XSLLocalParam]) && getCompilation.getCompilerInfo.isCompileWithTracing) child = StyleElement.makeTraceInstruction(snode, child)
        }
      }
      if (child != null) contents.add(child)
    }
    if (containsSpecials) return new ConditionalBlock(contents)
    val block = Block.makeBlock(contents)
    if (block.getLocation == null) block.setLocation(locationId)
    if (block.getLocalRetainedStaticContext == null) block.setRetainedStaticContext(makeRetainedStaticContext)
    block
  }

  /**
   * Compile a content value text node.
   *
   * @param node     the text node potentially containing the template
   * @param contents a list to which expressions representing the fixed and variable parts of the content template
   *                 will be appended
   */
  private[style] def compileContentValueTemplate(node: TextImpl, contents: util.List[Expression]) = if (node.isInstanceOf[TextValueTemplateNode]) {
    var exp = node.asInstanceOf[TextValueTemplateNode].getContentExpression
    if (getConfiguration.getBooleanProperty(Feature.STRICT_STREAMABILITY) && !exp.isInstanceOf[Literal]) exp = new SequenceInstr(exp)
    contents.add(exp)
  }
  else contents.add(new StringLiteral(node.getStringValue))

  /**
   * Perform fallback processing. Generate fallback code for an extension
   * instruction that is not recognized by the implementation.
   *
   * @param exec        the Executable
   * @param decl        the Declaration of the top-level element containing the extension instruction
   * @param instruction The unknown extension instruction
   * @return the expression tree representing the fallback code
   * @throws net.sf.saxon.trans.XPathException if any error occurs
   */
  @throws[XPathException]
  private[style] def fallbackProcessing(exec: Compilation, decl: ComponentDeclaration, instruction: StyleElement) = { // process any xsl:fallback children; if there are none,
    // generate code to report the original failure reason
    var fallback = null
    import scala.collection.JavaConversions._
    for (child <- children(classOf[XSLFallback].isInstance)) {
      var b = child.asInstanceOf[XSLFallback].compileSequenceConstructor(exec, decl, true)
      if (b == null) b = Literal.makeEmptySequence
      if (fallback == null) fallback = b
      else {
        fallback = Block.makeBlock(fallback, b)
        fallback.setLocation(allocateLocation)
      }
    }
    if (fallback != null) fallback
    else new ErrorExpression(instruction.validationError)
  }

  /**
   * Allocate a location
   *
   * @return an location which can be used to report the location of the instruction
   */
  protected def allocateLocation = {
    if (savedLocation == null) savedLocation = new Loc(this)
    savedLocation
  }

  /**
   * Construct sort keys for a SortedIterator
   *
   * @param compilation the compilation episode
   * @param decl        the declaration containing the sort keys  @throws XPathException if any error is detected
   * @return an array of SortKeyDefinition objects if there are any sort keys;
   *         or null if there are none.
   * @throws XPathException if an error is found
   */
  @throws[XPathException]
  private[style] def makeSortKeys(compilation: Compilation, decl: ComponentDeclaration) = { // handle sort keys if any
    var numberOfSortKeys = 0
    import scala.collection.JavaConversions._
    for (child <- children(classOf[XSLSortOrMergeKey].isInstance)) {
      child.asInstanceOf[XSLSortOrMergeKey].compile(compilation, decl)
      if (child.isInstanceOf[XSLSort]) if (numberOfSortKeys != 0 && child.asInstanceOf[XSLSort].getStable != null) compileError("stable attribute may appear only on the first xsl:sort element", "XTSE1017")
      numberOfSortKeys += 1
    }
    if (numberOfSortKeys > 0) {
      val keys = new Array[SortKeyDefinition](numberOfSortKeys)
      var k = 0
      import scala.collection.JavaConversions._
      for (child <- children(classOf[XSLSortOrMergeKey].isInstance)) {
        keys({
          k += 1; k - 1
        }) = child.asInstanceOf[XSLSortOrMergeKey].getSortKeyDefinition.simplify.asInstanceOf[SortKeyDefinition]
      }
      new SortKeyDefinitionList(keys)
    }
    else null
  }

  /**
   * Get the list of attribute-set names associated with this element.
   * This is used for xsl:element, xsl:copy, xsl:attribute-set, and on literal
   * result elements
   *
   * @param use the original value of the [xsl:]use-attribute-sets attribute
   * @return an array of names of the attribute sets
   */
  private[style] def getUsedAttributeSets(use: String) = {
    val nameList = new util.ArrayList[StructuredQName](4)
    val st = new StringTokenizer(use, " \t\n\r", false)
    while ( {
      st.hasMoreTokens
    }) {
      val asetname = st.nextToken
      val name = makeQName(asetname, "XTSE0710", "use-attribute-sets")
      nameList.add(name)
    }
    nameList.toArray(new Array[StructuredQName](0))
  }

  /**
   * Process the value of the visibility attribute (XSLT 3.0). Invokes
   * {@link #invalidAttribute(String, String)} if the value is invalid.
   *
   * @param s     the value of the attribute after whitespace collapsing
   * @param flags contains "h" if the value "hidden" is allowed, "a" if the value "absent" is allowed
   * @return the corresponding visibility
   */
  private[style] def interpretVisibilityValue(s: String, flags: String): Visibility = {
    for (v <- Visibility.values) {
      if (v.show == s && (flags.contains("h") || !(s == "hidden")) && (flags.contains("a") || !(s == "absent"))) return v
    }
    invalidAttribute("visibility", "public|final|private|abstract" + (if (flags.contains("h")) "|hidden"
    else "") + (if (flags.contains("a")) "|absent"
    else ""))
    null
  }

  /**
   * Get the list of xsl:with-param elements for a calling element (apply-templates,
   * call-template, apply-imports, next-match). This method can be used to get either
   * the tunnel parameters, or the non-tunnel parameters.
   *
   * @param compilation the compilation episode
   * @param decl        the containing stylesheet declaration
   * @param tunnel      true if the tunnel="yes" parameters are wanted, false to get
   * @return an array of WithParam objects for either the ordinary parameters
   *         or the tunnel parameters, as an array containing the results of
   *         compiling the xsl:with-param children of this instruction (if any)
   * @throws XPathException if any error is detected
   */
  @throws[XPathException]
  def getWithParamInstructions(parent: Expression, compilation: Compilation, decl: ComponentDeclaration, tunnel: Boolean): Array[WithParam] = {
    var count = 0
    import scala.collection.JavaConversions._
    for (child <- children(classOf[XSLWithParam].isInstance)) {
      val wp = child.asInstanceOf[XSLWithParam]
      if (wp.getSourceBinding.hasProperty(SourceBinding.BindingProperty.TUNNEL) == tunnel) count += 1
    }
    if (count == 0) return WithParam.EMPTY_ARRAY
    val array = new Array[WithParam](count)
    count = 0
    import scala.collection.JavaConversions._
    for (child <- children(classOf[XSLWithParam].isInstance)) {
      val wp = child.asInstanceOf[XSLWithParam]
      if (wp.getSourceBinding.hasProperty(SourceBinding.BindingProperty.TUNNEL) == tunnel) {
        val p = wp.compileWithParam(parent, compilation, decl)
        if (wp.getParent.isInstanceOf[XSLNextIteration] && wp.hasChildNodes) { // Type-check against the declared type of the xsl:param, unless this was done earlier
          val required = wp.getParent.asInstanceOf[XSLNextIteration].getDeclaredParamType(wp.getSourceBinding.getVariableQName)
          wp.checkAgainstRequiredType(required)
          p.getSelectOperand.setChildExpression(wp.sourceBinding.getSelectExpression)
        }
        array({
          count += 1; count - 1
        }) = p
      }
    }
    array
  }

  /**
   * Report an error with diagnostic information
   *
   * @param error contains information about the error
   */
  def compileError(error: XmlProcessingError) = {
    XmlProcessingIncident.maybeSetHostLanguage(error, HostLanguage.XSLT)
    // Set the location of the error if there is no current location information,
    // or if the current location information is local to an XPath expression, unless we are
    // positioned on an xsl:function or xsl:template, in which case this would lose too much information
    if (error.getLocation == null || ((error.getLocation.isInstanceOf[Loc] || error.getLocation.isInstanceOf[Expression]) && !this.isInstanceOf[StylesheetComponent])) XmlProcessingIncident.maybeSetLocation(error, this)
    getCompilation.reportError(error)
  }

  def compileError(err: XPathException) = {
    if (err.getLocator == null) err.setLocation(this)
    val se = new XmlProcessingIncident(err.getMessage, err.getErrorCodeLocalPart, err.getLocator)
    se.setHostLanguage(HostLanguage.XSLT)
    compileError(se)
  }

  /**
   * Report a static error in the stylesheet
   *
   * @param message the error message
   */
  def compileError(message: String) = compileError(message, "XTSE0010")

  /**
   * Compile time error, specifying an error code
   *
   * @param message   the error message
   * @param errorCode the error code. May be null if not known or not defined
   */
  def compileError(message: String, errorCode: StructuredQName) = {
    val error = new XmlProcessingIncident(message, errorCode.getEQName, this)
    error.setHostLanguage(HostLanguage.XSLT)
    compileError(error)
  }

  def compileError(message: String, errorCode: String) = compileError(new XPathException(message, errorCode, this))

  def compileError(message: String, errorCode: String, loc: Location) = compileError(new XPathException(message, errorCode, loc))

  /**
   * Compile time error, specifying an error code and the name of the attribute that
   * is in error.
   *
   * @param message       the error message
   * @param errorCode     the error code. May be null if not known or not defined
   * @param attributeName the name of the attribute. For attributes in no namespace
   *                      this is the local part of the name; for namespaced attributes
   *                      a name in Clark format may be supplied.
   */
  def compileErrorInAttribute(message: String, errorCode: String, attributeName: String) = {
    val att = StructuredQName.fromClarkName(attributeName)
    val location = new AttributeLocation(this, att)
    compileError(new XPathException(message, errorCode, location))
  }

  protected def invalidAttribute(attributeName: String, allowedValues: String) = compileErrorInAttribute("Attribute " + getDisplayName + "/@" + attributeName + " must be " + allowedValues, "XTSE0020", attributeName)

  /**
   * Ask whether XSLT syntax extensions are allowed, for example xsl:when/@select. Returns true if
   * explicitly enabled in the configuration. Note, this is not affected by forwards-compatibility mode
   * (because it's too error-prone to simply ignore the presence of these attributes).
   */
  protected def requireSyntaxExtensions(attributeName: String) = if (!getConfiguration.getBooleanProperty(Feature.ALLOW_SYNTAX_EXTENSIONS)) compileErrorInAttribute("Attribute " + getDisplayName + "/@" + attributeName + " is allowed only if syntax extensions are enabled", "XTSE0020", attributeName)

  private[style] def undeclaredNamespaceError(prefix: String, errorCode: String, attributeName: String) = {
    if (errorCode == null) errorCode = "XTSE0280"
    compileErrorInAttribute("Undeclared namespace prefix " + Err.wrap(prefix), errorCode, attributeName)
  }

  def compileWarning(message: String, errorCode: StructuredQName) = getCompilation.reportWarning(message, errorCode.getEQName, this)

  def compileWarning(message: String, errorCode: String) = getCompilation.reportWarning(message, errorCode, this)

  def compileWarning(message: String, errorCode: String, location: Location) = getCompilation.reportWarning(message, errorCode, location)

  /**
   * Report a warning to the error listener
   *
   * @param error an exception containing the warning text
   */
  protected def issueWarning(error: XPathException) = {
    if (error.getLocator == null) error.setLocator(this)
    getCompilation.reportWarning(error)
  }

  /**
   * Report a warning to the error listener
   *
   * @param message the warning message text
   * @param locator the location of the problem in the source stylesheet
   */
  protected def issueWarning(message: String, locator: SourceLocator) = {
    val tce = new XPathException(message)
    if (locator == null) tce.setLocator(this)
    else tce.setLocator(locator)
    issueWarning(tce)
  }

  /**
   * Test whether this is a top-level element
   *
   * @return true if the element is a child of the xsl:stylesheet or xsl:package element
   */
  def isTopLevel = getParent.isInstanceOf[XSLModuleRoot]

  /**
   * Ask whether this is an instruction that is known to be constructing nodes which
   * will become children of a parent document or element node, and will not have an
   * independent existence of their own.
   *
   * @return true if it is known that this is an instruction that creates nodes that
   *         will immediately be attached to a parent element or document node
   */
  private[style] def isConstructingComplexContent: Boolean = {
    if (!isInstruction) return false
    var parent = getParent
    while ( {
      true
    }) {
      if (!(parent.isInstanceOf[StyleElement] && (parent.asInstanceOf[StyleElement]).isInstruction)) return false
      if (parent.isInstanceOf[XSLGeneralVariable]) return parent.asInstanceOf[XSLGeneralVariable].getAttributeValue("as") == null
      if (parent.isInstanceOf[XSLElement] || parent.isInstanceOf[LiteralResultElement] || parent.isInstanceOf[XSLDocument] || parent.isInstanceOf[XSLCopy]) return true
      parent = parent.getParent
    }
  }

  /**
   * Ask whether this element contains a binding for a variable with a given name; and if it does,
   * return the source binding information
   *
   * @param name the variable name
   * @return the binding information if this element binds a variable of this name; otherwise null
   */
  def getBindingInformation(name: StructuredQName) = null

  /**
   * Bind a variable used in this element to the compiled form of the XSLVariable element in which it is
   * declared
   *
   * @param qName The name of the variable
   * @return the XSLVariableDeclaration (that is, an xsl:variable or xsl:param instruction) for the variable,
   *         or null if no declaration of the variable can be found
   */
  def bindVariable(qName: StructuredQName): SourceBinding = {
    val decl = bindLocalVariable(qName)
    if (decl != null) return decl
    // Now check for a global variable
    // we rely on the search following the order of decreasing import precedence.
    val binding = getPrincipalStylesheetModule.getGlobalVariableBinding(qName)
    if (binding == null || Navigator.isAncestorOrSelf(binding.getSourceElement, this)) { // test case variable-0118
      null
    }
    else binding
  }

  /**
   * Bind a variable reference used in this element to the compiled form of the XSLVariable element in which it is
   * declared, considering only local variables and params
   *
   * @param qName The name of the variable
   * @return the XSLVariableDeclaration (that is, an xsl:variable or xsl:param instruction) for the variable,
   *         or null if no local declaration of the variable can be found
   */
  def bindLocalVariable(qName: StructuredQName): SourceBinding = {
    var curr = this
    var prev = this
    var `implicit` = hasImplicitBinding(qName)
    if (`implicit` != null) return `implicit`
    // first search for a local variable declaration
    if (!isTopLevel) {
      var preceding = curr.iterateAxis(AxisInfo.PRECEDING_SIBLING)
      while ( {
        true
      }) {
        curr = preceding.next
        while ( {
          curr == null
        }) {
          curr = prev.getParent
          if (curr.isInstanceOf[StyleElement]) {
            `implicit` = curr.asInstanceOf[StyleElement].hasImplicitBinding(qName)
            if (`implicit` != null) return `implicit`
          }
          while ( {
            curr.isInstanceOf[StyleElement] && !(curr.asInstanceOf[StyleElement]).seesAvuncularVariables
          }) { // a local variable is not visible within a sibling xsl:fallback or xsl:catch element
            curr = curr.getParent
          }
          prev = curr
          if (curr.getParent.isInstanceOf[XSLModuleRoot]) {
            break //todo: break is not supported
            // top level
          }
          preceding = curr.iterateAxis(AxisInfo.PRECEDING_SIBLING)
          curr = preceding.next
        }
        if (curr.getParent.isInstanceOf[XSLModuleRoot]) break //todo: break is not supported
        if (curr.isInstanceOf[XSLGeneralVariable]) {
          val sourceBinding = curr.asInstanceOf[XSLGeneralVariable].getBindingInformation(qName)
          if (sourceBinding != null) return sourceBinding
        }
      }
    }
    null
  }

  /**
   * Ask whether variables declared in an "uncle" element are visible.
   *
   * @return true for all elements except xsl:fallback and xsl:catch
   */
  protected def seesAvuncularVariables = true

  /**
   * Ask whether this particular element implicitly binds a given variable (used for xsl:accumulator-rule)
   */
  protected def hasImplicitBinding(name: StructuredQName) = null

  /**
   * Get a name identifying the object of the expression, for example a function name, template name,
   * variable name, key name, element name, etc. This is used only where the name is known statically.
   * If there is no name, the value will be null.
   *
   * @return the name of the object declared in this element, if any
   */
  def getObjectName = objectName

  /**
   * Set the object name, for example the name of a function, variable, or template declared on this element
   *
   * @param qName the object name as a QName
   */
  def setObjectName(qName: StructuredQName) = objectName = qName

  /**
   * Get an iterator over all the properties available. The values returned by the iterator
   * will be of type String, and each string can be supplied as input to the getProperty()
   * method to retrieve the value of the property.
   */
  def getProperties = {
    val list = new util.ArrayList[String](10)
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      list.add(att.getNodeName.getStructuredQName.getClarkName)
    }
    list.iterator
  }

  /**
   * Ask if an action on this StyleElement has been completed
   *
   * @param action for example ACTION_VALIDATE
   * @return true if the action has already been performed
   */
  private[style] def isActionCompleted(action: Int) = (actionsCompleted & action) != 0

  /**
   * Say that an action on this StyleElement has been completed
   *
   * @param action for example ACTION_VALIDATE
   */
  private[style] def setActionCompleted(action: Int) = actionsCompleted |= action
}