////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.om.NodeName
import net.sf.saxon.s9api.Location
import net.sf.saxon.serialize.charcode.UTF16CharacterSet
import net.sf.saxon.serialize.charcode.XMLCharacterData
import net.sf.saxon.trans.XPathException

/**
 * This class is used on the serialization pipeline to check that the document conforms
 * to XML 1.0 rules. It is placed on the pipeline only when the configuration permits
 * XML 1.1 constructs, but the particular output document is being serialized as XML 1.0
 *
 * <p>Simplified in Saxon 9.6 because the rules for XML Names in 1.0 are now the same as
 * the rules in 1.1; only the rules for valid characters are different.</p>
 */
class XML10ContentChecker(val next: Receiver) extends ProxyReceiver(next) {
  /**
   * Notify the start of an element
   *
   * @param elemName   the name of the element.
   * @param type       the type annotation of the element.
   * @param attributes the attributes of this element
   * @param namespaces the in-scope namespaces of this element: generally this is all the in-scope
   *                   namespaces, without relying on inheriting namespaces from parent elements
   * @param location   an object providing information about the module, line, and column where the node originated
   * @param properties bit-significant properties of the element node. If there are no relevant
   *                   properties, zero is supplied. The definitions of the bits are in class { @link ReceiverOption}
   * @throws XPathException if an error occurs
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      checkString(att.getValue, att.getLocation)
    }
    nextReceiver.startElement(elemName, `type`, attributes, namespaces, location, properties)
  }

  /**
   * Character data
   */
  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = {
    checkString(chars, locationId)
    nextReceiver.characters(chars, locationId, properties)
  }

  /**
   * Output a comment
   */
  @throws[XPathException]
  override def comment(chars: CharSequence, locationId: Location, properties: Int) = {
    checkString(chars, locationId)
    nextReceiver.comment(chars, locationId, properties)
  }

  /**
   * Processing Instruction
   */
  @throws[XPathException]
  override def processingInstruction(target: String, /*@NotNull*/ data: CharSequence, locationId: Location, properties: Int) = {
    checkString(data, locationId)
    nextReceiver.processingInstruction(target, data, locationId, properties)
  }

  /**
   * Check that a string consists of valid XML 1.0 characters (UTF-16 encoded)
   *
   * @param in         the string to be checked
   * @param locationId the location of the string
   */
  @throws[XPathException]
  private def checkString(in: CharSequence, locationId: Location) = {
    val len = in.length
    var c = 0
    while ( {
      c < len
    }) {
      var ch32 = in.charAt(c)
      if (UTF16CharacterSet.isHighSurrogate(ch32)) {
        val low = in.charAt({
          c += 1; c
        })
        ch32 = UTF16CharacterSet.combinePair(ch32.toChar, low)
      }
      if (!XMLCharacterData.isValid10(ch32)) {
        val err = new XPathException("The result tree contains a character not allowed by XML 1.0 (hex " + Integer.toHexString(ch32) + ')')
        err.setErrorCode("SERE0006")
        err.setLocator(locationId)
        throw err
      }
      c += 1
    }
  }
}