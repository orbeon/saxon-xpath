////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.LastPositionFinder
import net.sf.saxon.expr.StaticProperty
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.om._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.GroundedIterator
import net.sf.saxon.tree.iter.ListIterator
import net.sf.saxon.tree.iter.ReverseListIterator
import net.sf.saxon.tree.iter.UnfailingIterator
import net.sf.saxon.tree.util.FastStringBuffer
import java.util
import java.util.{ArrayList, List}

/**
 * A sequence value implemented extensionally. That is, this class represents a sequence
 * by allocating memory to each item in the sequence.
 */
object SequenceExtent {
  /**
   * Factory method to make a GroundedValue holding the contents of any SequenceIterator.
   *
   * @param iter a Sequence iterator that may or may not be consumed to deliver the items in the sequence.
   *             The iterator must be positioned at the start.
   * @return a GroundedValue holding the items delivered by the SequenceIterator. If the
   *         sequence is empty the result will be an instance of { @link EmptySequence}. If it is of length
   *                                                                     one, the result will be an { @link Item}. In all other cases, it will be an instance of
   *                                                                     { @link SequenceExtent}.
   * @throws net.sf.saxon.trans.XPathException
   * if an error occurs processing the values from
   * the iterator.
   * @deprecated since 9.9: use { @link SequenceIterator#materialize()}
   */
    @throws[XPathException]
    def makeSequenceExtent(iter: SequenceIterator) = iter.materialize

  /**
   * Factory method to make a GroundedValue holding the contents of any SequenceIterator.
   *
   * @param iter a Sequence iterator that may or may not be consumed to deliver the items in the sequence.
   *             The iterator must be positioned at the start.
   * @return a GroundedValue holding the items delivered by the SequenceIterator. If the
   *         sequence is empty the result will be an instance of { @link EmptySequence}. If it is of length
   *                                                                     one, the result will be an { @link Item}. In other cases, the actual implementation class
   *                                                                     is not defined.
   *                                                                     <p>This method is intended primarily for internal use. For external applications, calling
   *                                                                     { @link SequenceIterator#materialize()} is preferable, because it recognizes cases that can
   *                                                                     be optimized (notably, cases where the iterator is already backed by an array or list in memory).</p>
   * @throws net.sf.saxon.trans.XPathException if an error occurs processing the values from
   *                                           the iterator.
   * @deprecated since 9.9: use { @link SequenceIterator#materialize()}
   */
  @throws[XPathException]
  def fromIterator(iter: SequenceIterator) = new SequenceExtent(iter).reduce

  /**
   * Factory method to make a GroundedValue holding the remaining contents of any SequenceIterator,
   * that is, the contents that have not yet been read
   *
   * @param iter a Sequence iterator that may or may not be consumed to deliver the items in the sequence.
   *             The iterator need not be positioned at the start.
   * @return a GroundedValue holding the items delivered by the SequenceIterator. If the
   *         sequence is empty the result will be an instance of { @link EmptySequence}. If it is of length
   *                                                                     one, the result will be an { @link Item}. In all other cases, it will be an instance of
   *                                                                     { @link SequenceExtent}.
   * @throws net.sf.saxon.trans.XPathException if an error occurs processing the values from
   *                                           the iterator.
   */
  @throws[XPathException]
  def makeResidue(iter: SequenceIterator): GroundedValue = {
    if (iter.getProperties.contains(SequenceIterator.Property.GROUNDED)) return iter.asInstanceOf[GroundedIterator].getResidue
    val extent = new SequenceExtent(iter)
    extent.reduce
  }

  /**
   * Factory method to make a Value holding the contents of any List of items
   *
   * @param input a List containing the items in the sequence
   * @return a ValueRepresentation holding the items in the list. If the
   *         sequence is empty the result will be an instance of { @link EmptySequence}. If it is of length
   *                                                                     one, the result will be an { @link Item}. In all other cases, it will be an instance of
   *                                                                     { @link SequenceExtent}.
   */
  def makeSequenceExtent[T <: Item](/*@NotNull*/ input: util.List[T]) = {
    val len = input.size
    if (len == 0) EmptySequence.getInstance
    else if (len == 1) input.get(0)
    else new SequenceExtent(new util.ArrayList[T](input))
  }
}

class SequenceExtent extends GroundedValue {
  protected var value = null

  /**
   * Construct an sequence from an array of items. Note, the array of items is used as is,
   * which means the caller must not subsequently change its contents.
   *
   * @param items the array of items to be included in the sequence
   */
  def this(items: Array[Item]) {
    this()
    value = util.Arrays.asList(items)
  }

  /**
   * Construct a SequenceExtent from a List. The members of the list must all
   * be Items
   *
   * @param list the list of items to be included in the sequence
   */
  def this(list: util.List[_ <: Item]) {
    this()
    this.value = list
  }

  /**
   * Construct a sequence containing all the remaining items in a SequenceIterator.
   *
   * @param iter The supplied sequence of items. The returned sequence will contain all
   *             items delivered by repeated calls on next() on this iterator, and the
   *             iterator will be consumed by calling the method.
   * @throws net.sf.saxon.trans.XPathException
   * if reading the items using the
   * SequenceIterator raises an error
   */
  def this(iter: SequenceIterator)={
    this()
    val len = if (!iter.getProperties.contains(SequenceIterator.Property.LAST_POSITION_FINDER)) 20
    else iter.asInstanceOf[LastPositionFinder].getLength
    val list = new util.ArrayList[Item](len)
    iter.forEachOrFail(list.add)
    value = list
  }

  @throws[XPathException]
  override def getStringValue = SequenceTool.getStringValue(this)

  @throws[XPathException]
  override def getStringValueCS = SequenceTool.getStringValue(this)

  /**
   * Get the first item in the sequence.
   *
   * @return the first item in the sequence if there is one, or null if the sequence
   *         is empty
   */
  override def head = itemAt(0)

  /**
   * Get the number of items in the sequence
   *
   * @return the number of items in the sequence
   */
  override def getLength = value.size

  /**
   * Determine the cardinality
   *
   * @return the cardinality of the sequence, using the constants defined in
   *         net.sf.saxon.value.Cardinality
   * @see net.sf.saxon.value.Cardinality
   */
  def getCardinality = value.size match {
    case 0 =>
      StaticProperty.EMPTY
    case 1 =>
      StaticProperty.EXACTLY_ONE
    case _ =>
      StaticProperty.ALLOWS_ONE_OR_MORE
  }

  /**
   * Get the n'th item in the sequence (starting with 0 as the first item)
   *
   * @param n the position of the required item
   * @return the n'th item in the sequence, or null if the position is out of range
   */
  /*@Nullable*/ override def itemAt(n: Int) = if (n < 0 || n >= getLength) null
  else value.get(n)

  /**
   * Return an iterator over this sequence.
   *
   * @return the required SequenceIterator, positioned at the start of the
   *         sequence
   */
  override def iterate = new ListIterator[_ <: Item](value)

  /**
   * Return an enumeration of this sequence in reverse order (used for reverse axes)
   *
   * @return an AxisIterator that processes the items in reverse order
   */
  def reverseIterate = new ReverseListIterator[_ <: Item](value)

  /**
   * Get the effective boolean value
   */
  @throws[XPathException]
  override def effectiveBooleanValue = {
    val len = getLength
    if (len == 0) false
    else {
      val first = value.get(0)
      if (first.isInstanceOf[NodeInfo]) true
      else if (len == 1 && first.isInstanceOf[AtomicValue]) first.effectiveBooleanValue
      else { // this will fail - reuse the error messages
        ExpressionTool.effectiveBooleanValue(iterate)
      }
    }
  }

  /**
   * Get a subsequence of the value
   *
   * @param start  the index of the first item to be included in the result, counting from zero.
   *               A negative value is taken as zero. If the value is beyond the end of the sequence, an empty
   *               sequence is returned
   * @param length the number of items to be included in the result. Specify Integer.MAX_VALUE to
   *               get the subsequence up to the end of the base sequence. If the value is negative, an empty sequence
   *               is returned. If the value goes off the end of the sequence, the result returns items up to the end
   *               of the sequence
   * @return the required subsequence. If min is
   */
  override def subsequence(start: Int, length: Int): GroundedValue = {
    if (start < 0) start = 0
    if (start > value.size) return EmptySequence.getInstance
    new SequenceSlice(value, start, length).reduce
  }

  override def toString = {
    val fsb = new FastStringBuffer(FastStringBuffer.C64)
    for (i <- 0 until value.size) {
      fsb.append(if (i == 0) "("
      else ", ")
      fsb.append(value.get(i).toString)
    }
    fsb.cat(')')
    fsb.toString
  }

  /**
   * Reduce the sequence to its simplest form. If the value is an empty sequence, the result will be
   * EmptySequence.getInstance(). If the value is a single atomic value, the result will be an instance
   * of AtomicValue. If the value is a single item of any other kind, the result will be an instance
   * of One. Otherwise, the result will typically be unchanged.
   *
   * @return the simplified sequence
   */
  override def reduce = {
    val len = getLength
    if (len == 0) EmptySequence.getInstance
    else if (len == 1) itemAt(0)
    else this
  }

  /**
   * Get the contents of this value in the form of a Java {@link java.lang.Iterable},
   * so that it can be used in a for-each expression
   *
   * @return an Iterable containing the same sequence of items
   */
  override def asIterable = value

  /**
   * Get an iterator (a Java {@link java.util.Iterator}) over the items in this sequence.
   *
   * @return an iterator over the items in this sequence.
   */
  //@Override
  def iterator = value.iterator
}