////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event.ProxyReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.Item
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.om.NodeName
import net.sf.saxon.s9api.Destination
import net.sf.saxon.s9api.Location
import net.sf.saxon.s9api.SaxonApiException
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XsltController

/**
 * This class is added to the output pipeline for the principal result destination for a transformation
 * if the transformation uses xsl:result-document instructions. It is there to deal with the possibility
 * that an xsl:result-document instruction will use the same output URI (or no output URI) in which case
 * it is defined to write to the principal output destination, but potentially with different serialization
 * parameters.
 * <p>If actual output is produced to the principal result destination, then this {@code PrincipalOutputGatekeeper}
 * will be marked as being "used by primary", which will cause any attempt to open a secondary result destination on the
 * same URI (either explicitly, or by omitting the {@code href} attribute, or by setting {@code href} to
 * a zero length string) as an error. Apart from this marker, the {@code PrincipalOutputGatekeeper} acts as
 * a pass-through filter for the output events.</p>
 * <p>If a secondary result destination is opened using the principal output URI (either explicitly or implicitly),
 * then the {@code PrincipalOutputGatekeeper} is marked as being "used by secondary", which will cause any
 * attempts to write events to the {@code PrincipalOutputGatekeeper} to fail. Secondary result output is not
 * actually directed through the gatekeeper; the gatekeeper is merely notified of its existence.</p>
 */
class PrincipalOutputGatekeeper(var controller: XsltController, val next: Receiver) extends ProxyReceiver(next) {
  private var usedAsPrimaryResult = false
  private var usedAsSecondaryResult = false
  private var open = false
  private var closed = false

  @throws[XPathException]
  override def open() = {
    if (closed) {
      val uri = if (getSystemId == XsltController.ANONYMOUS_PRINCIPAL_OUTPUT_URI) "(no URI supplied)"
      else getSystemId
      val err = new XPathException("Cannot write more than one result document to the principal output destination: " + uri)
      err.setErrorCode("XTDE1490")
      throw err
    }
    super.open()
    open = true
  }

  @throws[XPathException]
  override def startDocument(properties: Int) = {
    if (!open) open()
    //checkNotClosed();
    nextReceiver.startDocument(properties)
  }

  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    useAsPrimary()
    nextReceiver.startElement(elemName, `type`, attributes, namespaces, location, properties)
  }

  @throws[XPathException]
  override def characters(chars: CharSequence, locationId: Location, properties: Int) = {
    useAsPrimary()
    nextReceiver.characters(chars, locationId, properties)
  }

  @throws[XPathException]
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = {
    useAsPrimary()
    nextReceiver.processingInstruction(target, data, locationId, properties)
  }

  @throws[XPathException]
  override def comment(chars: CharSequence, locationId: Location, properties: Int) = {
    useAsPrimary()
    nextReceiver.comment(chars, locationId, properties)
  }

  @throws[XPathException]
  override def append(item: Item, locationId: Location, copyNamespaces: Int) = {
    useAsPrimary()
    nextReceiver.append(item, locationId, copyNamespaces)
  }

  @throws[XPathException]
  private def useAsPrimary() = {
    if (closed) {
      val err = new XPathException("Cannot write to the principal output destination as it has already been closed: " + identifySystemId)
      err.setErrorCode("XTDE1490")
      throw err
    }
    if (usedAsSecondaryResult) {
      val err = new XPathException("Cannot write to the principal output destination as it has already been used by xsl:result-document: " + identifySystemId)
      err.setErrorCode("XTDE1490")
      throw err
    }
    usedAsPrimaryResult = true
  }

  @throws[XPathException]
  def useAsSecondary() = {
    if (usedAsPrimaryResult) {
      val err = new XPathException("Cannot use xsl:result-document to write to a destination already used for the principal output: " + identifySystemId)
      err.setErrorCode("XTDE1490")
      throw err
    }
    if (usedAsSecondaryResult) {
      val err = new XPathException("Cannot write more than one xsl:result-document to the principal output destination: " + identifySystemId)
      err.setErrorCode("XTDE1490")
      throw err
    }
    usedAsSecondaryResult = true
  }

  def makeReceiver(params: SerializationProperties): Receiver = {
    try {
      val dest = controller.getPrincipalDestination
      if (dest != null) return dest.getReceiver(controller.makePipelineConfiguration, params)
    } catch {
      case e: SaxonApiException =>
        return null
    }
    null
  }

  private def identifySystemId = {
    val uri = getSystemId
    if (uri == null) "(no URI supplied)"
    else uri
  }

  @throws[XPathException]
  override def close() = {
    closed = true
    if (usedAsPrimaryResult) nextReceiver.close()
  }
}