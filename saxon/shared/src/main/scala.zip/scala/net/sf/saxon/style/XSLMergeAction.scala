////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

class XSLMergeAction extends StyleElement {
  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
    override def isInstruction = false

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val content = compileSequenceConstructor(exec, decl, true)
    content
  }

  override protected def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = if (!getParent.isInstanceOf[XSLMerge]) compileError("xsl:merge-action may appear only as a child of xsl:merge", "XTSE0010")
}