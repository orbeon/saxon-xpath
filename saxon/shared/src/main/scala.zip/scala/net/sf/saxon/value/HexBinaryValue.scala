////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.sort.AtomicMatchKey
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.om.SequenceTool
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.util

/**
 * A value of type xs:hexBinary
 */
class HexBinaryValue extends AtomicValue with AtomicMatchKey with Comparable[_] {
  private var binaryValue = null

  /**
   * Constructor: create a hexBinary value from a supplied string, in which
   * each octet is represented by a pair of values from 0-9, a-f, A-F
   *
   * @param in character representation of the hexBinary value
   * @throws XPathException if the input is invalid
   */
  def this(in: CharSequence)={
    this()
    val s = Whitespace.trimWhitespace(in)
    if ((s.length & 1) != 0) {
      val err = new XPathException("A hexBinary value must contain an even number of characters")
      err.setErrorCode("FORG0001")
      throw err
    }
    binaryValue = new Array[Byte](s.length / 2)
    for (i <- 0 until binaryValue.length) {
      binaryValue(i) = ((fromHex(s.charAt(2 * i)) << 4) + fromHex(s.charAt(2 * i + 1))).toByte
    }
    typeLabel = BuiltInAtomicType.HEX_BINARY
  }

  /**
   * Constructor: create a HexBinary value from a supplied string in hexBinary encoding,
   * with a specified type. This method throws no checked exceptions; the caller is expected
   * to ensure that the string is a valid Base64 lexical representation, that it conforms
   * to the specified type, and that the type is indeed a subtype of xs:base64Binary.
   * An unchecked exception such as an IllegalArgumentException may be thrown if these
   * conditions are not satisfied, but this is not guaranteed.
   *
   * @param s    the value in hexBinary encoding, with no leading or trailing whitespace
   * @param type the atomic type. This must be xs:base64binary or a subtype.
   */
  def this( s: CharSequence, `type`: AtomicType)={
    this()
    if ((s.length & 1) != 0) throw new IllegalArgumentException("A hexBinary value must contain an even number of characters")
    binaryValue = new Array[Byte](s.length / 2)
    try {
      for (i <- 0 until binaryValue.length) {
        binaryValue(i) = ((fromHex(s.charAt(2 * i)) << 4) + fromHex(s.charAt(2 * i + 1))).toByte
      }
    }catch {
      case e: XPathException =>
        throw new IllegalArgumentException(e.getMessage)
    }
    typeLabel = `type`

  }

  /**
   * Constructor: create a hexBinary value from a given array of bytes
   *
   * @param value the value as an array of bytes
   */
  def this(value: Array[Byte])= {
    this()
    binaryValue = value
    typeLabel = BuiltInAtomicType.HEX_BINARY
  }

  /**
   * Create a primitive copy of this atomic value (usually so that the type label can be changed).
   *
   * @param typeLabel the target type (a derived type from hexBinary)
   */
  override def copyAsSubType(typeLabel: AtomicType) = {
    val v = new HexBinaryValue(binaryValue)
    v.typeLabel = typeLabel
    v
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.HEX_BINARY

  /**
   * Get the binary value
   *
   * @return the binary value, as a byte array
   */
  def getBinaryValue = binaryValue

  /**
   * Decode a single hex digit
   *
   * @param c the hex digit
   * @return the numeric value of the hex digit
   * @throws XPathException if it isn't a hex digit
   */
  @throws[XPathException]
  private def fromHex(c: Char) = {
    var d = "0123456789ABCDEFabcdef".indexOf(c)
    if (d > 15) d = d - 6
    if (d < 0) {
      val err = new XPathException("Invalid hexadecimal digit '" + c + "'")
      err.setErrorCode("FORG0001")
      throw err
    }
    d
  }

  /**
   * Convert to string
   *
   * @return the canonical representation.
   */
  override def getPrimitiveStringValue = {
    val digits = "0123456789ABCDEF"
    val sb = new FastStringBuffer(binaryValue.length * 2)
    for (aBinaryValue <- binaryValue) {
      sb.cat(digits.charAt((aBinaryValue >> 4) & 0xf))
      sb.cat(digits.charAt(aBinaryValue & 0xf))
    }
    sb
  }

  /**
   * Get the number of octets in the value
   *
   * @return the number of octets (bytes) in the value
   */
  def getLengthInOctets = binaryValue.length

  /**
   * Support XML Schema comparison semantics
   */
  override def getSchemaComparable = new HexBinaryValue#HexBinaryComparable

  private class HexBinaryComparable extends Comparable[HexBinaryValue#HexBinaryComparable] {
    def getHexBinaryValue = thisHexBinaryValue

    override def compareTo(o: HexBinaryValue#HexBinaryComparable) = if (util.Arrays.equals(getHexBinaryValue.binaryValue, o.getHexBinaryValue.binaryValue)) 0
    else SequenceTool.INDETERMINATE_ORDERING

    override def equals(o: Any) = o.isInstanceOf[HexBinaryValue#HexBinaryComparable] && compareTo(o.asInstanceOf[HexBinaryValue#HexBinaryComparable]) == 0

    override def hashCode = thisHexBinaryValue.hashCode
  }

  /**
   * Get an object value that implements the XPath equality and ordering comparison semantics for this value.
   * If the ordered parameter is set to true, the result will be a Comparable and will support a compareTo()
   * method with the semantics of the XPath lt/gt operator, provided that the other operand is also obtained
   * using the getXPathComparable() method. In all cases the result will support equals() and hashCode() methods
   * that support the semantics of the XPath eq operator, again provided that the other operand is also obtained
   * using the getXPathComparable() method. A context argument is supplied for use in cases where the comparison
   * semantics are context-sensitive, for example where they depend on the implicit timezone or the default
   * collation.
   *
   * @param ordered          true if an ordered comparison is required. In this case the result is null if the
   *                         type is unordered; in other cases the returned value will be a Comparable.
   * @param collator         collation to be used for comparing strings
   * @param implicitTimezone to be used for comparing dates/times with no timezone
   * @return a key used for performing the comparison
   */
  /*@Nullable*/ override def getXPathComparable(ordered: Boolean, collator: StringCollator, implicitTimezone: Int) = this

  /**
   * Test if the two hexBinary or Base64Binaryvalues are equal.
   */
  override def equals(other: Any) = other.isInstanceOf[HexBinaryValue] && util.Arrays.equals(binaryValue, other.asInstanceOf[HexBinaryValue].binaryValue)

  override def hashCode = Base64BinaryValue.byteArrayHashCode(binaryValue)

  override def compareTo(o: Any): Int = {
    val other = o.asInstanceOf[HexBinaryValue].binaryValue
    val len0 = binaryValue.length
    val len1 = other.length
    val shorter = java.lang.Math.min(len0, len1)
    for (i <- 0 until shorter) {
      val a = binaryValue(i).toInt & 0xff
      val b = other(i).toInt & 0xff
      if (a != b) return if (a < b) -1
      else +1
    }
    Integer.signum(len0 - len1)
  }
}