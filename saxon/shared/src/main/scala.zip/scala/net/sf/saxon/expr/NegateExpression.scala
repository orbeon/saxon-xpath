////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser._
import net.sf.saxon.model.ItemType
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.DoubleValue
import net.sf.saxon.value.NumericValue
import net.sf.saxon.value.SequenceType

/**
 * Negate Expression: implements the unary minus operator.
 * This expression is initially created as an ArithmeticExpression (or in backwards
 * compatibility mode, an ArithmeticExpression10) to take advantage of the type checking code.
 * So we don't need to worry about type checking or argument conversion.
 */
class NegateExpression(val base: Expression)

/**
 * Create a NegateExpression
 *
 * @param base the expression that computes the value whose sign is to be reversed
 */
  extends UnaryExpression(base) {
  private var backwardsCompatible = false

  /**
   * Set whether the expression is to be evaluated in XPath 1.0 compatibility mode
   *
   * @param compatible true if XPath 1.0 compatibility mode is enabled
   */
  def setBackwardsCompatible(compatible: Boolean) = backwardsCompatible = compatible

  /**
   * Ask whether the expression is to be evaluated in XPath 1.0 compatibility mode
   *
   * @return true if XPath 1.0 compatibility mode is enabled
   */
  def isBackwardsCompatible = backwardsCompatible

  override protected def getOperandRole = OperandRole.SINGLE_ATOMIC

  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    getOperand.typeCheck(visitor, contextInfo)
    val role = new RoleDiagnostic(RoleDiagnostic.UNARY_EXPR, "-", 0)
    val operand = visitor.getConfiguration.getTypeChecker(backwardsCompatible).staticTypeCheck(getBaseExpression, SequenceType.OPTIONAL_NUMERIC, role, visitor)
    setBaseExpression(operand)
    if (operand.isInstanceOf[Literal]) {
      val v = operand.asInstanceOf[Literal].getValue
      if (v.isInstanceOf[NumericValue]) return Literal.makeLiteral(v.asInstanceOf[NumericValue].negate, this)
    }
    this
  }

  /**
   * Determine the data type of the expression, if this is known statically
   */
  override def getItemType = getBaseExpression.getItemType.getPrimitiveItemType

  override def computeCardinality = getBaseExpression.getCardinality & ~StaticProperty.ALLOWS_MANY

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = EVALUATE_METHOD

  /**
   * Evaluate the expression.
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext): NumericValue = {
    val v1 = getBaseExpression.evaluateItem(context).asInstanceOf[NumericValue]
    if (v1 == null) return if (backwardsCompatible) DoubleValue.NaN
    else null
    v1.negate
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings
   */
  override def copy(rebindings: RebindingMap) = {
    val exp = new NegateExpression(getBaseExpression.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, exp)
    exp
  }

  override protected def displayOperator(config: Configuration) = "-"

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "minus"

  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    out.startElement("minus", this)
    if (backwardsCompatible) out.emitAttribute("vn", "1")
    getBaseExpression.`export`(out)
    out.endElement
  }
}