////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.expr.XPathContext
import net.sf.saxon.expr.instruct.TemplateRule
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.om.Item
import java.util

/**
 * A trace listener for XSLT that only handles invocation of template rules; enabled
 * using saxon:trace="yes" on the xsl:mode declaration
 */
class ModeTraceListener extends AbstractTraceListener {
  private val stack = new util.Stack[Item]

  /**
   * Generate attributes to be included in the opening trace element
   */
  override protected def getOpeningAttributes = "xmlns:xsl=\"" + NamespaceConstant.XSLT + '\"'

  override def startCurrentItem(item: Item) = if (stack.empty || (stack.peek ne item)) {
    super.startCurrentItem(item)
    stack.push(item)
  }

  override def endCurrentItem(item: Item) = if (stack.peek eq item) {
    super.endCurrentItem(item)
    stack.pop
  }

  /**
   * Called when an instruction in the stylesheet gets processed
   */
  def enter(/*@NotNull*/ info: Traceable, context: XPathContext) = if (info.isInstanceOf[TemplateRule]) {
    val file = abbreviateLocationURI(info.getLocation.getSystemId)
    val msg = AbstractTraceListener.spaces(indent) + "<rule match=\"" + escape(info.asInstanceOf[TemplateRule].getMatchPattern.toString) + '"' + " line=\"" + info.getLocation.getLineNumber + '"' + " module=\"" + escape(file) + '"' + '>'
    out.info(msg)
    indent += 1
  }

  override def leave(info: Traceable) = if (info.isInstanceOf[TemplateRule]) {
    indent -= 1
    out.info(AbstractTraceListener.spaces(indent) + "</rule>")
  }

  override protected def tag(info: Traceable) = ""
}