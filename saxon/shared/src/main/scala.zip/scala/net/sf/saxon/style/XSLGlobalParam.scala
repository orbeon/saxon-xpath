////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.GlobalParam
import net.sf.saxon.expr.parser.Optimizer
import net.sf.saxon.trans.Visibility
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import java.util

/**
 * An xsl:param element representing a global parameter (stylesheet parameter) in the stylesheet. <br>
 * The xsl:param element has mandatory attribute name and optional attributes
 * select, required, as, ...
 */
class XSLGlobalParam() extends XSLGlobalVariable {
  sourceBinding.setProperty(SourceBinding.BindingProperty.PARAM, true)

  override protected def getPermittedAttributes = util.EnumSet.of(SourceBinding.BindingProperty.REQUIRED, SourceBinding.BindingProperty.SELECT, SourceBinding.BindingProperty.AS, SourceBinding.BindingProperty.STATIC)

  /*@Nullable*/ private[style] val conversion = null

  /**
   * Default visibility for xsl:param is public
   *
   * @return the declared visibility, or "public" if not declared
   */
  override def getVisibility = {
    val statik = getAttributeValue("static")
    if (statik == null) Visibility.PUBLIC
    else {
      val isStatic = processBooleanAttribute("static", statik)
      if (isStatic) Visibility.PRIVATE
      else Visibility.PUBLIC
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    if (sourceBinding.hasProperty(SourceBinding.BindingProperty.REQUIRED)) {
      if (sourceBinding.getSelectExpression != null) { // NB, we do this test before setting the default select attribute
        compileError("The select attribute must be absent when required='yes'", "XTSE0010")
      }
      if (hasChildNodes) compileError("A parameter specifying required='yes' must have empty content", "XTSE0010")
      val vis = getVisibility
      if (!sourceBinding.isStatic && !((vis eq Visibility.PUBLIC) || (vis eq Visibility.FINAL) || (vis eq Visibility.ABSTRACT))) compileError("The visibility of a required non-static parameter must be public, final, or abstract", "XTSE3370")
    }
    super.validate(decl)
  }

  /**
   * Compile a global xsl:param element: this ensures space is available for local variables declared within
   * this global variable
   */
  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration) = if (sourceBinding.isStatic) super.compileDeclaration(compilation, decl)
  else if (!redundant) {
    sourceBinding.handleSequenceConstructor(compilation, decl)
    val binding = compiledVariable.asInstanceOf[GlobalParam]
    binding.setPackageData(getCompilation.getPackageData)
    binding.obtainDeclaringComponent(this)
    val select = sourceBinding.getSelectExpression
    binding.setBody(select)
    binding.setVariableQName(sourceBinding.getVariableQName)
    initializeBinding(binding)
    if (select != null && compilation.getCompilerInfo.getCodeInjector != null) compilation.getCompilerInfo.getCodeInjector.process(binding)
    binding.setRequiredType(getRequiredType)
    binding.setRequiredParam(sourceBinding.hasProperty(SourceBinding.BindingProperty.REQUIRED))
    binding.setImplicitlyRequiredParam(sourceBinding.hasProperty(SourceBinding.BindingProperty.IMPLICITLY_REQUIRED))
    sourceBinding.fixupBinding(binding)
    //compiledVariable = binding;
    val overridden = getOverriddenComponent
    if (overridden != null) checkCompatibility(overridden)
  }

  /**
   * Get the static type of the parameter. This is the declared type, because we cannot know
   * the actual value in advance.
   */
  override def getRequiredType = {
    val declaredType = sourceBinding.getDeclaredType
    if (declaredType != null) declaredType
    else SequenceType.ANY_SEQUENCE
  }

  def insertBytecodeCandidate(opt: Optimizer) = {
  }
}