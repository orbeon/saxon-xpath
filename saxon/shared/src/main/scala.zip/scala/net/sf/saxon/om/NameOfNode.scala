////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.tree.wrapper.AbstractVirtualNode

/**
 * An implementation of NodeName that gets the name of an existing NodeInfo object.
 * Useful when nodes are copied. However, it's not safe to use when the node is mutable.
 */
object NameOfNode {
  /**
   * Make a NodeName object based on the name of a supplied node.
   *
   * @param node the supplied node
   * @return a NameOfNode object unless the node is mutable, in which case an immutable name is returned.
   */
    def makeName(node: NodeInfo) = if (node.isInstanceOf[MutableNodeInfo]) new FingerprintedQName(node.getPrefix, node.getURI, node.getLocalPart)
    else if (node.isInstanceOf[AbstractVirtualNode]) new NameOfNode(node.asInstanceOf[AbstractVirtualNode].getUnderlyingNode)
    else new NameOfNode(node)
}

class NameOfNode private(var node: NodeInfo)

/**
 * Constructor is private to protect against use with mutable nodes
 *
 * @param node the node whose name is required
 */
  extends NodeName {
  /**
   * Get the prefix of the QName.
   *
   * @return the prefix. Returns the empty string if the name is unprefixed.
   */
  override def getPrefix = node.getPrefix

  /**
   * Get the namespace URI of the QName.
   *
   * @return the URI. Returns the empty string to represent the no-namespace
   */
  override def getURI = node.getURI

  /**
   * Get the local part of the QName
   *
   * @return the local part of the QName
   */
  override def getLocalPart = node.getLocalPart

  /**
   * Get the display name, that is the lexical QName in the form [prefix:]local-part
   *
   * @return the lexical QName
   */
  override def getDisplayName = node.getDisplayName

  /**
   * Get the name in the form of a StructuredQName
   *
   * @return the name in the form of a StructuredQName
   */
  override def getStructuredQName = new StructuredQName(getPrefix, getURI, getLocalPart)

  /**
   * Test whether this name is in a given namespace
   *
   * @param ns the namespace to be tested against
   * @return true if the name is in the specified namespace
   */
  override def hasURI(ns: String) = node.getURI == ns

  /**
   * Get a {@link net.sf.saxon.om.NamespaceBinding} whose (prefix, uri) pair are the prefix and URI of this
   * node name
   *
   * @return the corresponding NamespaceBinding
   */
  override def getNamespaceBinding = NamespaceBinding.makeNamespaceBinding(getPrefix, getURI)

  /**
   * Ask whether this node name representation has a known namecode and fingerprint
   *
   * @return true if the methods getFingerprint() and getNameCode() will
   *         return a result other than -1
   */
  override def hasFingerprint = node.hasFingerprint

  /**
   * Get the fingerprint of this name if known. This method should not to any work to allocate
   * a fingerprint if none is already available
   *
   * @return the fingerprint if known; otherwise -1
   */
  override def getFingerprint = if (hasFingerprint) node.getFingerprint
  else -1

  /**
   * Get the nameCode of this name, allocating a new code from the namepool if necessary
   *
   * @param namePool the NamePool used to allocate the name
   * @return a nameCode for this name, newly allocated if necessary
   */
  override def obtainFingerprint(namePool: NamePool) = if (node.hasFingerprint) node.getFingerprint
  else namePool.allocateFingerprint(node.getURI, node.getLocalPart)

  /**
   * Returns a hash code value for the object.
   */
  override def hashCode = StructuredQName.computeHashCode(getURI, getLocalPart)

  /**
   * Indicates whether some other object is "equal to" this one.
   */
  override def equals(obj: Any) = if (obj.isInstanceOf[NodeName]) {
    val n = obj.asInstanceOf[NodeName]
    if (node.hasFingerprint && n.hasFingerprint) node.getFingerprint == n.getFingerprint
    else n.getLocalPart == node.getLocalPart && n.hasURI(node.getURI)
  }
  else false

  /**
   * Determine whether two IdentityComparable objects are identical. This is a stronger
   * test than equality (even schema-equality); for example two dateTime values are not identical unless
   * they are in the same timezone.
   *
   * @param other
   * @return true if the two values are indentical, false otherwise
   */
  override def isIdentical(other: IdentityComparable) = other.isInstanceOf[NodeName] && this == other && this.getPrefix == other.asInstanceOf[NodeName].getPrefix

  /**
   * Get a hashCode that offers the guarantee that if A.isIdentical(B), then A.identityHashCode() == B.identityHashCode()
   *
   * @return a hashCode suitable for use when testing for identity.
   */
  override def identityHashCode = hashCode ^ getPrefix.hashCode
}