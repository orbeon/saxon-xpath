////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct._
import net.sf.saxon.lib.StandardURIChecker
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om._
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * An xsl:element element in the stylesheet. <br>
 */
class XSLElement extends StyleElement {
  /*@Nullable*/ private var elementName = null
  private var namespace = null
  private var use = null
  private var attributeSets = null
  private var validation = 0
  private var schemaType = null
  private var inheritNamespaces = true

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var nameAtt = null
    var namespaceAtt = null
    var validationAtt = null
    var typeAtt = null
    var inheritAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      f match {
        case "name" =>
          nameAtt = Whitespace.trim(value)
          elementName = makeAttributeValueTemplate(nameAtt, att)
        case "namespace" =>
          namespaceAtt = value
          namespace = makeAttributeValueTemplate(namespaceAtt, att)
        case "validation" =>
          validationAtt = Whitespace.trim(value)
        case "type" =>
          typeAtt = Whitespace.trim(value)
        case "inherit-namespaces" =>
          inheritAtt = Whitespace.trim(value)
        case "use-attribute-sets" =>
          use = value
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (nameAtt == null) reportAbsence("name")
    else if (elementName.isInstanceOf[StringLiteral]) if (!NameChecker.isQName((elementName.asInstanceOf[StringLiteral]).getStringValue)) {
      compileError("Element name " + Err.wrap(elementName.asInstanceOf[StringLiteral].getStringValue) + " is not a valid QName", "XTDE0820")
      // to prevent duplicate error messages:
      elementName = new StringLiteral("saxon-error-element")
    }
    if (namespaceAtt != null) if (namespace.isInstanceOf[StringLiteral]) if (!StandardURIChecker.getInstance.isValidURI((namespace.asInstanceOf[StringLiteral]).getStringValue)) compileError("The value of the namespace attribute must be a valid URI", "XTDE0835")
    if (validationAtt != null) validation = validateValidationAttribute(validationAtt)
    else validation = getDefaultValidation
    if (typeAtt != null) {
      if (!isSchemaAware) compileError("The @type attribute is available only with a schema-aware XSLT processor", "XTSE1660")
      schemaType = getSchemaType(typeAtt)
      validation = Validation.BY_TYPE
    }
    if (typeAtt != null && validationAtt != null) compileError("The @validation and @type attributes are mutually exclusive", "XTSE1505")
    if (inheritAtt != null) inheritNamespaces = processBooleanAttribute("inherit-namespaces", inheritAtt)
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    if (use != null) { // get the names of referenced attribute sets
      attributeSets = getUsedAttributeSets(use)
    }
    elementName = typeCheck("name", elementName)
    namespace = typeCheck("namespace", namespace)
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration): Expression = { // deal specially with the case where the element name is known statically
    if (elementName.isInstanceOf[StringLiteral]) {
      val qName = elementName.asInstanceOf[StringLiteral].getStringValue
      var parts = null
      try parts = NameChecker.getQNameParts(qName)
      catch {
        case e: QNameException =>
          compileErrorInAttribute("Invalid element name: " + qName, "XTDE0820", "name")
          return null
      }
      var nsuri = null
      if (namespace.isInstanceOf[StringLiteral]) {
        nsuri = namespace.asInstanceOf[StringLiteral].getStringValue
        if (nsuri.isEmpty) parts(0) = ""
      }
      else if (namespace == null) {
        nsuri = getURIForPrefix(parts(0), true)
        if (nsuri == null) undeclaredNamespaceError(parts(0), "XTDE0830", "name")
      }
      if (nsuri != null) { // Local name and namespace are both known statically: generate a FixedElement instruction
        val qn = new FingerprintedQName(parts(0), nsuri, parts(1))
        qn.obtainFingerprint(getNamePool)
        val inst = new FixedElement(qn, NamespaceMap.emptyMap, inheritNamespaces, true, schemaType, validation)
        inst.setLocation(allocateLocation)
        return compileContentExpression(exec, decl, inst)
      }
    }
    val inst = new ComputedElement(elementName, namespace, schemaType, validation, inheritNamespaces, false)
    inst.setLocation(allocateLocation)
    compileContentExpression(exec, decl, inst)
  }

  @throws[XPathException]
  private def compileContentExpression(exec: Compilation, decl: ComponentDeclaration, inst: ElementCreator) = {
    var content = compileSequenceConstructor(exec, decl, true)
    if (attributeSets != null) {
      val use = UseAttributeSet.makeUseAttributeSets(attributeSets, this)
      if (content == null) content = use
      else {
        content = Block.makeBlock(use, content)
        content.setLocation(allocateLocation)
      }
    }
    if (content == null) content = Literal.makeEmptySequence
    inst.setContentExpression(content)
    inst
  }
}