////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.ComputedAttribute
import net.sf.saxon.expr.instruct.FixedAttribute
import net.sf.saxon.expr.instruct.Instruction
import net.sf.saxon.lib.StandardURIChecker
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.SimpleType
import net.sf.saxon.om._
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.value.StringValue
import net.sf.saxon.value.Whitespace

/**
 * xsl:attribute element in stylesheet. <br>
 */
final class XSLAttribute extends XSLLeafNodeConstructor {
  /*@Nullable*/ private var attributeName = null
  private var separator = null
  private var namespace = null
  private var validationAction = Validation.PRESERVE
  private var schemaType = null

  override def prepareAttributes(): Unit = {
    var nameAtt = null
    var namespaceAtt = null
    var selectAtt = null
    var separatorAtt = null
    var validationAtt = null
    var typeAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      f match {
        case "name" =>
          nameAtt = Whitespace.trim(value)
          attributeName = makeAttributeValueTemplate(nameAtt, att)
        case "namespace" =>
          namespaceAtt = Whitespace.trim(value)
          namespace = makeAttributeValueTemplate(namespaceAtt, att)
        case "select" =>
          selectAtt = value
          select = makeExpression(selectAtt, att)
        case "separator" =>
          separatorAtt = value
          separator = makeAttributeValueTemplate(separatorAtt, att)
        case "validation" =>
          validationAtt = Whitespace.trim(value)
        case "type" =>
          typeAtt = Whitespace.trim(value)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (nameAtt == null) {
      reportAbsence("name")
      return
    }
    if (attributeName.isInstanceOf[StringLiteral]) {
      if (!NameChecker.isQName((attributeName.asInstanceOf[StringLiteral]).getStringValue)) invalidAttributeName("Attribute name " + Err.wrap(nameAtt) + " is not a valid QName")
      if (nameAtt == "xmlns") if (namespace == null) invalidAttributeName("Invalid attribute name: xmlns")
      if (nameAtt.startsWith("xmlns:")) if (namespaceAtt == null) invalidAttributeName("Invalid attribute name: " + Err.wrap(nameAtt))
      else { // ignore the prefix "xmlns"
        nameAtt = nameAtt.substring(6)
        attributeName = new StringLiteral(nameAtt)
      }
    }
    if (namespaceAtt != null) if (namespace.isInstanceOf[StringLiteral]) if (!StandardURIChecker.getInstance.isValidURI((namespace.asInstanceOf[StringLiteral]).getStringValue)) compileError("The value of the namespace attribute must be a valid URI", "XTDE0865")
    if (separatorAtt == null) if (selectAtt == null) separator = new StringLiteral(StringValue.EMPTY_STRING)
    else separator = new StringLiteral(StringValue.SINGLE_SPACE)
    if (validationAtt != null) validationAction = validateValidationAttribute(validationAtt)
    else validationAction = getDefaultValidation
    if (typeAtt != null) if (!isSchemaAware) compileError("The @type attribute is available only with a schema-aware XSLT processor", "XTSE1660")
    else {
      val `type` = getSchemaType(typeAtt)
      if (`type` == null) compileError("Unknown attribute type " + typeAtt, "XTSE1520")
      else if (`type`.isSimpleType) schemaType = `type`.asInstanceOf[SimpleType]
      else compileError("Type annotation for attributes must be a simple type", "XTSE1530")
      validationAction = Validation.BY_TYPE
    }
    if (typeAtt != null && validationAtt != null) {
      compileError("The validation and type attributes are mutually exclusive", "XTSE1505")
      validationAction = getDefaultValidation
      schemaType = null
    }
  }

  private def invalidAttributeName(message: String) = {
    compileErrorInAttribute(message, "XTDE0850", "name")
    // prevent a duplicate error message...
    attributeName = new StringLiteral("saxon-error-attribute")
    //        }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    if (schemaType != null) if (schemaType.isNamespaceSensitive) compileErrorInAttribute("Validation at attribute level must not specify a " + "namespace-sensitive type (xs:QName or xs:NOTATION)", "XTTE1545", "type")
    attributeName = typeCheck("name", attributeName)
    namespace = typeCheck("namespace", namespace)
    select = typeCheck("select", select)
    separator = typeCheck("separator", separator)
    //onEmpty = typeCheck("on-empty", onEmpty);
    super.validate(decl)
  }

  /**
   * Get the error code to be returned when the element has a select attribute but is not empty.
   *
   * @return the error code defined for this condition, for this particular instruction
   */
  override protected def getErrorCodeForSelectPlusContent = "XTSE0840"

  @throws[XPathException]
  override def compile(compilation: Compilation, decl: ComponentDeclaration): Instruction = {
    var nsContext = null
    // deal specially with the case where the attribute name is known statically
    if (attributeName.isInstanceOf[StringLiteral] /*&& onEmpty == null*/ ) {
      val qName = Whitespace.trim(attributeName.asInstanceOf[StringLiteral].getStringValue)
      var parts = null
      try parts = NameChecker.getQNameParts(qName)
      catch {
        case e: QNameException =>
          // This can't happen, because of previous checks
          return null
      }
      if (namespace == null) {
        var nsuri = ""
        if (!(parts(0) == "")) {
          nsuri = getURIForPrefix(parts(0), false)
          if (nsuri == null) {
            undeclaredNamespaceError(parts(0), "XTDE0860", "name")
            return null
          }
        }
        val attributeName = new FingerprintedQName(parts(0), nsuri, parts(1))
        attributeName.obtainFingerprint(getNamePool)
        val inst = new FixedAttribute(attributeName, validationAction, schemaType)
        inst.setInstruction(true)
        inst.setLocation(allocateLocation)
        compileContent(compilation, decl, inst, separator)
        return inst
      }
      else if (namespace.isInstanceOf[StringLiteral]) {
        val nsuri = namespace.asInstanceOf[StringLiteral].getStringValue
        if (nsuri == "") parts(0) = ""
        else if (parts(0) == "") { // Need to choose an arbitrary prefix
          // First see if the requested namespace is declared in the stylesheet
          val iter = iterateAxis(AxisInfo.NAMESPACE)
          var ns = null
          while ( {
            (ns = iter.next) != null
          }) if (ns.getStringValue == nsuri) {
            parts(0) = ns.getLocalPart
            break //todo: break is not supported
          }
          // Otherwise see the URI is known to the namepool
          if (parts(0) == "") {
            val p = getNamePool.suggestPrefixForURI(namespace.asInstanceOf[StringLiteral].getStringValue)
            if (p != null) parts(0) = p
          }
          // Otherwise choose something arbitrary. This will get changed
          // if it clashes with another attribute
          if (parts(0) == "") parts(0) = "ns0"
        }
        val nodeName = new FingerprintedQName(parts(0), nsuri, parts(1))
        nodeName.obtainFingerprint(getNamePool)
        val inst = new FixedAttribute(nodeName, validationAction, schemaType)
        inst.setInstruction(true)
        compileContent(compilation, decl, inst, separator)
        return inst
      }
    }
    else { // if the namespace URI must be deduced at run-time from the attribute name
      // prefix, we need to save the namespace context of the instruction
      if (namespace == null) nsContext = getAllNamespaces
    }
    val inst = new ComputedAttribute(attributeName, namespace, nsContext, validationAction, schemaType, false)
    //inst.bindStaticContext(getStaticContext());
    inst.setInstruction(true)
    inst.setLocation(allocateLocation)
    compileContent(compilation, decl, inst, separator)
    inst
  }
}