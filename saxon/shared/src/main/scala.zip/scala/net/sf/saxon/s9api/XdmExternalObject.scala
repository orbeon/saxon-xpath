////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.value.ExternalObject
import net.sf.saxon.value.ObjectValue

/**
 * The class XdmExternalObject represents an XDM item that wraps an external (Java or .NET) object.
 * As such, it is outside the scope of the XDM specification (but permitted as an extension).
 * <p>In releases prior to 9.5, external objects in Saxon were represented as atomic values. From
 * 9.5 they are represented as a fourth kind of item, alongside nodes, atomic values, and functions.</p>
 */
class XdmExternalObject private() extends XdmItem {
  /**
   * Create an XdmExternalObject that wraps a supplied Java object
   *
   * @param value the supplied Java object. Must not be null.
   * @throws NullPointerException if the supplied value is null.
   */
  def this(value: Any) {
    this()
    if (value.isInstanceOf[ObjectValue[_]]) {
      this.setValue(value.asInstanceOf[ObjectValue[_]])
    } else {
      this.setValue(new ObjectValue[AnyRef](value))
    }
  }

  /**
   * Get the wrapped Java object
   *
   * @return the wrapped object
   */
  def getExternalObject = getUnderlyingValue.asInstanceOf[ExternalObject[_]].getObject

  /**
   * Get the result of converting the external value to a string.
   *
   * @return the result of applying toString() to the wrapped external object.
   */
  override def toString = getExternalObject.toString

  /**
   * Compare two external objects for equality. Two instances of {@code XdmExternalObject} are equal
   * if the Java objects that they wrap are equal.
   *
   * @param other the object to be compared
   * @return true if the other object is an { @code XdmExternalObject} and the two wrapped objects
   *                                                are equal under the { @code equals()} method.
   */
  override def equals(other: Any) = other.isInstanceOf[XdmExternalObject] && getUnderlyingValue == other.asInstanceOf[XdmExternalObject].getUnderlyingValue

  /**
   * Return a hash code for the object. This respects the semantics of {@link #equals(Object)};
   *
   * @return a suitable hash code
   */
  override def hashCode = getUnderlyingValue.hashCode
}