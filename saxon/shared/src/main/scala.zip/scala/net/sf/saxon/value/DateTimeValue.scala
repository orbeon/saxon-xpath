////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.Controller
import net.sf.saxon.expr.XPathContext
import net.sf.saxon.functions.AccessorFn
import net.sf.saxon.lib.ConversionRules
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ConversionResult
import net.sf.saxon.model.ValidationFailure
import net.sf.saxon.om.SequenceTool
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.NoDynamicContextException
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode
import java.time._
import java.time.format.DateTimeParseException
import java.time.temporal.ChronoField
import java.time.temporal.TemporalAccessor
import java.time.temporal.TemporalField
import java.time.temporal.UnsupportedTemporalTypeException
import java.util._

/**
 * A value of type {@code xs:dateTime}. This contains integer fields year, month, day, hour, minute,
 * second, and nanosecond. All these fields except year must be non-negative. In the internal
 * representation, the sequence of years runs -2, -1, 0, +1, +2: that is, the year before year 1
 * is year 0.
 * <p>The value also contains a boolean flag <code>hasNoYearZero</code>. When this flag is set, accessor
 * methods that expose the year value subtract one if it is non-positive: that is, year 0 is displayed
 * as -1, year -1 as -2, and so on. Constructor methods, unless otherwise specified, do not set this
 * flag.</p>
 * <p>From Saxon 9.9, this class implements the Java 8 interface {@link TemporalAccessor} which enables
 * it to interoperate with Java 8 temporal classes such as {@link Instant} and {@link ZonedDateTime}.</p>
 */
object DateTimeValue {
  /**
   * Get the dateTime value representing the nominal
   * date/time of this transformation run. Two calls within the same
   * query or transformation will always return the same answer.
   *
   * @param context the XPath dynamic context. May be null, in which case
   *                the current date and time are taken directly from the system clock
   * @return the current xs:dateTime
   */
    /*@Nullable*/ def getCurrentDateTime(context: XPathContext) = {
      var c = null
      if (context == null || (c = context.getController) == null) { // non-XSLT/XQuery environment
        // We also take this path when evaluating compile-time expressions that require an implicit timezone.
        now
      }
      else c.getCurrentDateTime
    }

  /**
   * Get the dateTime value representing the moment of invocation of this method,
   * in the default timezone set for the platform on which the application is running.
   *
   * @return the current dateTime, in the local timezone for the platform.
   */
  def now = DateTimeValue.fromZonedDateTime(ZonedDateTime.now)

  /**
   * Factory method: create a dateTime value given a Java Date object. The returned dateTime
   * value will always have a timezone, which will always be UTC.
   *
   * @param suppliedDate holds the date and time
   * @return the corresponding xs:dateTime value
   * @throws XPathException if a dynamic error occurs
   */
  /*@NotNull*/ @throws[XPathException]
  def fromJavaDate(suppliedDate: Date) = {
    val millis = suppliedDate.getTime
    EPOCH.add(DayTimeDurationValue.fromMilliseconds(millis))
  }

  /**
   * Factory method: create a dateTime value given a Java time, expressed in milliseconds since 1970. The returned dateTime
   * value will always have a timezone, which will always be UTC.
   *
   * @param time the time in milliseconds since the epoch
   * @return the corresponding xs:dateTime value
   * @throws XPathException if a dynamic error occurs
   */
  @throws[XPathException]
  def fromJavaTime(time: Long) = EPOCH.add(DayTimeDurationValue.fromMilliseconds(time))

  /**
   * Factory method: create a dateTime value given the components of a Java Instant. The java.time.Instant class
   * is new in JDK 8, and this method was introduced under older JDKs, so this method takes two arguments,
   * the seconds and nano-seconds values, which can be obtained from a Java Instant
   * using the methods getEpochSecond() and getNano() respectively
   *
   * @param seconds the time in seconds since the epoch
   * @param nano    the additional nanoseconds
   * @return the corresponding xs:dateTime value, which will have timezone Z (UTC)
   * @throws XPathException if a dynamic error occurs (typically due to overflow)
   */
  @throws[XPathException]
  def fromJavaInstant(seconds: Long, nano: Int) = EPOCH.add(DayTimeDurationValue.fromSeconds(new BigDecimal(seconds)).add(DayTimeDurationValue.fromNanoseconds(nano)))

  /**
   * Factory method: create a dateTime value given a Java {@link Instant}. The {@code java.time.Instant} class
   * is new in JDK 8.
   *
   * @param instant the point in time
   * @return the corresponding xs:dateTime value, which will have timezone Z (UTC)
   * @since 9.9
   */
  def fromJavaInstant(instant: Instant) = try fromJavaInstant(instant.getEpochSecond, instant.getNano)
  catch {
    case e: XPathException =>
      throw new AssertionError
  }

  /**
   * Factory method: create a dateTime value given a Java {@link ZonedDateTime}. The {@code java.time.ZonedDateTime} class
   * is new in JDK 8.
   *
   * @param zonedDateTime the supplied zonedDateTime value
   * @return the corresponding xs:dateTime value, which will have the same timezone offset as the supplied ZonedDateTime;
   *         the actual (civil) timezone information is lost. The returned value will be an instance of the built-in
   *         subtype { @code xs:dateTimeStamp}
   * @since 9.9. Changed in 10.0 to retain nanosecond precision.
   */
  def fromZonedDateTime(zonedDateTime: ZonedDateTime) = fromOffsetDateTime(zonedDateTime.toOffsetDateTime)

  /**
   * Factory method: create a dateTime value given a Java {@link OffsetDateTime}. The {@code java.time.OffsetDateTime} class
   * is new in JDK 8.
   *
   * @param offsetDateTime the supplied zonedDateTime value
   * @return the corresponding xs:dateTime value, which will have the same timezone offset as the supplied OffsetDateTime.
   *         The returned value will be an instance of the built-in subtype { @code xs:dateTimeStamp}
   * @since 10.0.
   */
  def fromOffsetDateTime(offsetDateTime: OffsetDateTime) = {
    val ldt = offsetDateTime.toLocalDateTime
    val zo = offsetDateTime.getOffset
    val tz = zo.getTotalSeconds / 60
    val dtv = new DateTimeValue(ldt.getYear, ldt.getMonthValue.toByte, ldt.getDayOfMonth.toByte, ldt.getHour.toByte, ldt.getMinute.toByte, ldt.getSecond.toByte, ldt.getNano, tz)
    dtv.typeLabel = BuiltInAtomicType.DATE_TIME_STAMP
    dtv.hasNoYearZero = false
    dtv
  }

  /**
   * Factory method: create a dateTime value given a Java {@link LocalDateTime}. The {@code java.time.LocalDateTime} class
   * is new in JDK 8.
   *
   * @param localDateTime the supplied localDateTime value
   * @return the corresponding xs:dateTime value, which will have no timezone.
   * @since 9.9. Changed in 10.0 to retain nanosecond precision.
   */
  def fromLocalDateTime(localDateTime: LocalDateTime) = {
    val dtv = new DateTimeValue(localDateTime.getYear, localDateTime.getMonthValue.toByte, localDateTime.getDayOfMonth.toByte, localDateTime.getHour.toByte, localDateTime.getMinute.toByte, localDateTime.getSecond.toByte, localDateTime.getNano, NO_TIMEZONE)
    dtv.hasNoYearZero = false
    dtv
  }

  /**
   * Fixed date/time used by Java (and Unix) as the origin of the universe: 1970-01-01T00:00:00Z
   */
  val EPOCH = new DateTimeValue(1970, 1.toByte, 1.toByte, 0.toByte, 0.toByte, 0.toByte, 0, 0, true)

  /**
   * Factory method: create a dateTime value given a date and a time.
   *
   * @param date the date
   * @param time the time
   * @return the dateTime with the given components. If either component is null, returns null. The returned
   *         { @code DateTimeValue} will have the { @code #hasNoYearZero} property if and only if the supplied
   *                 date has this property.
   * @throws XPathException if the timezones are both present and inconsistent
   */
  @throws[XPathException]
  def makeDateTimeValue(date: DateValue, time: TimeValue): DateTimeValue = {
    if (date == null || time == null) return null
    val tz1 = date.getTimezoneInMinutes
    val tz2 = time.getTimezoneInMinutes
    if (tz1 != NO_TIMEZONE && tz2 != NO_TIMEZONE && tz1 != tz2) {
      val err = new XPathException("Supplied date and time are in different timezones")
      err.setErrorCode("FORG0008")
      throw err
    }
    val v = date.toDateTime
    v.hour = time.getHour
    v.minute = time.getMinute
    v.second = time.getSecond
    v.nanosecond = time.getNanosecond
    v.setTimezoneInMinutes(Math.max(tz1, tz2))
    v.typeLabel = BuiltInAtomicType.DATE_TIME
    v.hasNoYearZero = date.hasNoYearZero
    v
  }

  /**
   * Factory method: create a dateTime value from a supplied string, in
   * ISO 8601 format.
   * <p>If the supplied {@link ConversionRules} object has {@link ConversionRules#isAllowYearZero()} returning
   * true, then (a) a year value of zero is allowed in the supplied string, and (b) the {@code hasNoYearZero}
   * property in the result is set to false. If {@link ConversionRules#isAllowYearZero()} returns false,
   * the (a) the year value in the supplied string must not be zero, (b) a year value of -1 in the supplied
   * string is interpreted as representing the year before year 1, and (c) the {@code hasNoYearZero} property
   * in the result is set to true.</p>
   *
   * @param s     a string in the lexical space of xs:dateTime
   * @param rules the conversion rules to be used (determining whether year zero is allowed)
   * @return either a DateTimeValue representing the xs:dateTime supplied, or a ValidationFailure if
   *         the lexical value was invalid
   */
  def makeDateTimeValue(s: CharSequence, rules: ConversionRules): ConversionResult = { // input must have format [-]yyyy-mm-ddThh:mm:ss[.fff*][([+|-]hh:mm | Z)]
    val dt = new DateTimeValue
    dt.hasNoYearZero = !rules.isAllowYearZero
    val tok = new StringTokenizer(Whitespace.trimWhitespace(s).toString, "-:.+TZ", true)
    if (!tok.hasMoreElements) return badDate("too short", s)
    var part = tok.nextElement.asInstanceOf[String]
    var era = +1
    if ("+" == part) return badDate("Date must not start with '+' sign", s)
    else if ("-" == part) {
      era = -1
      if (!tok.hasMoreElements) return badDate("No year after '-'", s)
      part = tok.nextElement.asInstanceOf[String]
    }
    var value = DurationValue.simpleInteger(part)
    if (value < 0) if (value == -1) return badDate("Non-numeric year component", s)
    else return badDate("Year is outside the range that Saxon can handle", s, "FODT0001")
    dt.year = value * era
    if (part.length < 4) return badDate("Year is less than four digits", s)
    if (part.length > 4 && part.charAt(0) == '0') return badDate("When year exceeds 4 digits, leading zeroes are not allowed", s)
    if (dt.year == 0 && !rules.isAllowYearZero) return badDate("Year zero is not allowed", s)
    if (era < 0 && !rules.isAllowYearZero) dt.year += 1 // if year zero not allowed, -0001 is the year before +0001, represented as 0 internally.
    if (!tok.hasMoreElements) return badDate("Too short", s)
    if (!("-" == tok.nextElement)) return badDate("Wrong delimiter after year", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    part = tok.nextElement.asInstanceOf[String]
    if (part.length != 2) return badDate("Month must be two digits", s)
    value = DurationValue.simpleInteger(part)
    if (value < 0) return badDate("Non-numeric month component", s)
    dt.month = value.toByte
    if (dt.month < 1 || dt.month > 12) return badDate("Month is out of range", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    if (!("-" == tok.nextElement)) return badDate("Wrong delimiter after month", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    part = tok.nextElement.asInstanceOf[String]
    if (part.length != 2) return badDate("Day must be two digits", s)
    value = DurationValue.simpleInteger(part)
    if (value < 0) return badDate("Non-numeric day component", s)
    dt.day = value.toByte
    if (dt.day < 1 || dt.day > 31) return badDate("Day is out of range", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    if (!("T" == tok.nextElement)) return badDate("Wrong delimiter after day", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    part = tok.nextElement.asInstanceOf[String]
    if (part.length != 2) return badDate("Hour must be two digits", s)
    value = DurationValue.simpleInteger(part)
    if (value < 0) return badDate("Non-numeric hour component", s)
    dt.hour = value.toByte
    if (dt.hour > 24) return badDate("Hour is out of range", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    if (!(":" == tok.nextElement)) return badDate("Wrong delimiter after hour", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    part = tok.nextElement.asInstanceOf[String]
    if (part.length != 2) return badDate("Minute must be two digits", s)
    value = DurationValue.simpleInteger(part)
    if (value < 0) return badDate("Non-numeric minute component", s)
    dt.minute = value.toByte
    if (dt.minute > 59) return badDate("Minute is out of range", s)
    if (dt.hour == 24 && dt.minute != 0) return badDate("If hour is 24, minute must be 00", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    if (!(":" == tok.nextElement)) return badDate("Wrong delimiter after minute", s)
    if (!tok.hasMoreElements) return badDate("Too short", s)
    part = tok.nextElement.asInstanceOf[String]
    if (part.length != 2) return badDate("Second must be two digits", s)
    value = DurationValue.simpleInteger(part)
    if (value < 0) return badDate("Non-numeric second component", s)
    dt.second = value.toByte
    if (dt.second > 59) return badDate("Second is out of range", s)
    if (dt.hour == 24 && dt.second != 0) return badDate("If hour is 24, second must be 00", s)
    var tz = 0
    var negativeTz = false
    var state = 0
    while ( {
      tok.hasMoreElements
    }) {
      if (state == 9) return badDate("Characters after the end", s)
      val delim = tok.nextElement.asInstanceOf[String]
      if ("." == delim) {
        if (state != 0) return badDate("Decimal separator occurs twice", s)
        if (!tok.hasMoreElements) return badDate("Decimal point must be followed by digits", s)
        part = tok.nextElement.asInstanceOf[String]
        if (part.length > 9 && part.matches("^[0-9]+$")) part = part.substring(0, 9)
        value = DurationValue.simpleInteger(part)
        if (value < 0) return badDate("Non-numeric fractional seconds component", s)
        val fractionalSeconds = '.' + part.toDouble
        var nanoSeconds = fractionalSeconds * 1000000000.round.toInt
        if (nanoSeconds == 1000000000) nanoSeconds -= 1 // truncate fractional seconds to .999_999_999 if nanoseconds rounds to 1_000_000_000
        dt.nanosecond = nanoSeconds
        if (dt.hour == 24 && dt.nanosecond != 0) return badDate("If hour is 24, fractional seconds must be 0", s)
        state = 1
      }
      else if ("Z" == delim) {
        if (state > 1) return badDate("Z cannot occur here", s)
        tz = 0
        state = 9 // we've finished
        dt.setTimezoneInMinutes(0)
      }
      else if ("+" == delim || "-" == delim) {
        if (state > 1) return badDate(delim + " cannot occur here", s)
        state = 2
        if (!tok.hasMoreElements) return badDate("Missing timezone", s)
        part = tok.nextElement.asInstanceOf[String]
        if (part.length != 2) return badDate("Timezone hour must be two digits", s)
        value = DurationValue.simpleInteger(part)
        if (value < 0) return badDate("Non-numeric timezone hour component", s)
        tz = value
        if (tz > 14) return badDate("Timezone is out of range (-14:00 to +14:00)", s)
        tz *= 60
        if ("-" == delim) negativeTz = true
      }
      else if (":" == delim) {
        if (state != 2) return badDate("Misplaced ':'", s)
        state = 9
        part = tok.nextElement.asInstanceOf[String]
        value = DurationValue.simpleInteger(part)
        if (value < 0) return badDate("Non-numeric timezone minute component", s)
        val tzminute = value
        if (part.length != 2) return badDate("Timezone minute must be two digits", s)
        if (tzminute > 59) return badDate("Timezone minute is out of range", s)
        if (Math.abs(tz) == 14 * 60 && tzminute != 0) return badDate("Timezone is out of range (-14:00 to +14:00)", s)
        tz += tzminute
        if (negativeTz) tz = -tz
        dt.setTimezoneInMinutes(tz)
      }
      else return badDate("Timezone format is incorrect", s)
    }
    if (state == 2 || state == 3) return badDate("Timezone incomplete", s)
    var midnight = false
    if (dt.hour == 24) {
      dt.hour = 0
      midnight = true
    }
    // Check that this is a valid calendar date
    if (!DateValue.isValidDate(dt.year, dt.month, dt.day)) return badDate("Non-existent date", s)
    // Adjust midnight to 00:00:00 on the next day
    if (midnight) {
      val t = DateValue.tomorrow(dt.year, dt.month, dt.day)
      dt.year = t.getYear
      dt.month = t.getMonth
      dt.day = t.getDay
    }
    dt.typeLabel = BuiltInAtomicType.DATE_TIME
    dt
  }

  /**
   * Factory method: create a dateTime value from a supplied string, in ISO 8601 format, allowing
   * a year value of 0 to represent the year before year 1 (that is, following the XSD 1.1 rules).
   * <p>The {@code hasNoYearZero} property in the result is set to false.</p>
   *
   * @param s a string in the lexical space of xs:dateTime
   * @return a DateTimeValue representing the xs:dateTime supplied, including a timezone offset if
   *         present in the lexical representation
   * @throws DateTimeParseException if the format of the supplied string is invalid.
   * @since 9.9
   */
  @throws[DateTimeParseException]
  def parse(s: CharSequence) = {
    val result = makeDateTimeValue(s, ConversionRules.DEFAULT)
    if (result.isInstanceOf[ValidationFailure]) throw new DateTimeParseException(result.asInstanceOf[ValidationFailure].getMessage, s, 0)
    else result.asInstanceOf[DateTimeValue]
  }

  private def badDate(msg: String, value: CharSequence) = {
    val err = new ValidationFailure("Invalid dateTime value " + Err.wrap(value, Err.VALUE) + " (" + msg + ")")
    err.setErrorCode("FORG0001")
    err
  }

  private def badDate(msg: String, value: CharSequence, errorCode: String) = {
    val err = new ValidationFailure("Invalid dateTime value " + Err.wrap(value, Err.VALUE) + " (" + msg + ")")
    err.setErrorCode(errorCode)
    err
  }

  /**
   * Get the DateTimeValue corresponding to a given Julian instant
   *
   * @param instant the Julian instant: a decimal value whose integer part is the Julian day number
   *                multiplied by the number of seconds per day, and whose fractional part is the fraction of the second.
   * @return the xs:dateTime value corresponding to the Julian instant. This will always be in timezone Z.
   */
  def fromJulianInstant(instant: BigDecimal) = {
    val julianSecond = instant.toBigInteger
    val nanoseconds = instant.subtract(new BigDecimal(julianSecond)).multiply(BigDecimalValue.BIG_DECIMAL_ONE_BILLION)
    var js = julianSecond.longValue
    val jd = js / (24L * 60L * 60L)
    val date = DateValue.dateFromJulianDayNumber(jd.toInt)
    js = js % (24L * 60L * 60L)
    val hour = (js / (60L * 60L)).toByte
    js = js % (60L * 60L)
    val minute = (js / 60L).toByte
    js = js % 60L
    new DateTimeValue(date.getYear, date.getMonth, date.getDay, hour, minute, js.toByte, nanoseconds.intValue, 0)
  }

  private[value] def hashCode(year: Int, month: Byte, day: Byte, hour: Byte, minute: Byte, second: Byte, nanosecond: Int, tzMinutes: Int) = {
    val tz = if (tzMinutes == CalendarValue.NO_TIMEZONE) 0
    else -tzMinutes
    var h = hour
    var mi = minute
    mi += tz
    if (mi < 0 || mi > 59) {
      h += Math.floor(mi / 60.0)
      mi = (mi + 60 * 24) % 60
    }
    while ( {
      h < 0
    }) {
      h += 24
      val t = DateValue.yesterday(year, month, day)
      year = t.getYear
      month = t.getMonth
      day = t.getDay
    }
    while ( {
      h > 23
    }) {
      h -= 24
      val t = DateValue.tomorrow(year, month, day)
      year = t.getYear
      month = t.getMonth
      day = t.getDay
    }
    (year << 4) ^ (month << 28) ^ (day << 23) ^ (h << 18) ^ (mi << 13) ^ second ^ nanosecond
  }
}

final class DateTimeValue private()

/**
 * Private default constructor
 */
  extends CalendarValue with Comparable[_] with TemporalAccessor {
  private var year = 0 // the year as written, +1 for BC years
  private var month = 0 // the month as written, range 1-12
  private var day = 0 // the day as written, range 1-31
  private var hour = 0 // the hour as written (except for midnight), range 0-23
  private var minute = 0 // the minutes as written, range 0-59
  private var second = 0 // the seconds as written, range 0-59 (no leap seconds)
  private var nanosecond = 0 // the number of nanoseconds within the current second
  private var hasNoYearZero = false // true if XSD 1.0 rules apply for negative years
  /**
   * Constructor: create a dateTime value given a Java calendar object.
   * The {@code #hasNoYearZero} flag is set to {@code true}.
   *
   * @param calendar    holds the date and time
   * @param tzSpecified indicates whether the timezone is specified
   */
  def this(calendar: Calendar, tzSpecified: Boolean){
    this()
    val era = calendar.get(GregorianCalendar.ERA)
    year = calendar.get(Calendar.YEAR)
    if (era == GregorianCalendar.BC) year = 1 - year
    month = (calendar.get(Calendar.MONTH) + 1).toByte
    day = calendar.get(Calendar.DATE).toByte
    hour = calendar.get(Calendar.HOUR_OF_DAY).toByte
    minute = calendar.get(Calendar.MINUTE).toByte
    second = calendar.get(Calendar.SECOND).toByte
    nanosecond = calendar.get(Calendar.MILLISECOND) * 1000000
    if (tzSpecified) {
      val tz = (calendar.get(Calendar.ZONE_OFFSET) + calendar.get(Calendar.DST_OFFSET)) / 60000
      setTimezoneInMinutes(tz)
    }
    typeLabel = BuiltInAtomicType.DATE_TIME
    hasNoYearZero = true
  }

  /**
   * Constructor: construct a DateTimeValue from its components.
   * This constructor performs no validation.
   * <p>Note: this constructor accepts the fractional seconds value
   * to nanosecond precision. It creates a DateTimeValue that follows XSD 1.1 conventions:
   * that is, there is a year zero. This can be changed by setting the {@code hasNoYearZero} property.</p>
   *
   * @param year       The year (the year before year 1 is year 0)
   * @param month      The month, 1-12
   * @param day        The day 1-31
   * @param hour       the hour value, 0-23
   * @param minute     the minutes value, 0-59
   * @param second     the seconds value, 0-59
   * @param nanosecond the number of nanoseconds, 0-999_999_999
   * @param tz         the timezone displacement in minutes from UTC. Supply the value
   *                   { @link CalendarValue#NO_TIMEZONE} if there is no timezone component.
   */
  def this(year: Int, month: Byte, day: Byte, hour: Byte, minute: Byte, second: Byte, nanosecond: Int, tz: Int) = {
    this()
    this.hasNoYearZero = false
    this.year = year
    this.month = month
    this.day = day
    this.hour = hour
    this.minute = minute
    this.second = second
    this.nanosecond = nanosecond
    setTimezoneInMinutes(tz)
    typeLabel = BuiltInAtomicType.DATE_TIME
  }

  /**
   * Constructor: construct a DateTimeValue from its components.
   * This constructor performs no validation.
   * <p>Note: for historic reasons, this constructor accepts the fractional seconds value
   * only to microsecond precision. To get nanosecond precision, use the 8-argument constructor
   * and set the XSD 1.0 option separately</p>
   *
   * @param year        The year as held internally (so the year before year 1 is year 0)
   * @param month       The month, 1-12
   * @param day         The day 1-31
   * @param hour        the hour value, 0-23
   * @param minute      the minutes value, 0-59
   * @param second      the seconds value, 0-59
   * @param microsecond the number of microseconds, 0-999999
   * @param tz          the timezone displacement in minutes from UTC. Supply the value
   *                    { @link CalendarValue#NO_TIMEZONE} if there is no timezone component.
   * @param hasNoYearZero true if the dateTime value should behave under XSD 1.0 rules, that is,
   *                      negative dates assume there is no year zero. Note that regardless of this
   *                      setting, the year argument is set on the basis that the year before +1 is
   *                      supplied as zero; but if the hasNoYearZero flag is set, this value will be displayed
   *                      with a year of -1, and { @link #getYear() will return -1}
   */
  def this(year: Int, month: Byte, day: Byte, hour: Byte, minute: Byte, second: Byte, microsecond: Int, tz: Int, hasNoYearZero: Boolean) {
    this()
    this.hasNoYearZero = hasNoYearZero
    this.year = year
    this.month = month
    this.day = day
    this.hour = hour
    this.minute = minute
    this.second = second
    this.nanosecond = microsecond * 1000
    setTimezoneInMinutes(tz)
    typeLabel = BuiltInAtomicType.DATE_TIME
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.DATE_TIME

  /**
   * Get the year component, in its internal form (which allows a year zero)
   *
   * @return the year component
   */
  def getYear = year

  /**
   * Get the month component, 1-12
   *
   * @return the month component
   */
  def getMonth = month

  /**
   * Get the day component, 1-31
   *
   * @return the day component
   */
  def getDay = day

  /**
   * Get the hour component, 0-23
   *
   * @return the hour component (never 24, even if the input was specified as 24:00:00)
   */
  def getHour = hour

  /**
   * Get the minute component, 0-59
   *
   * @return the minute component
   */
  def getMinute = minute

  /**
   * Get the second component, 0-59
   *
   * @return the second component
   */
  def getSecond = second

  /**
   * Get the microsecond component, 0-999999
   *
   * @return the nanosecond component divided by 1000, rounded towards zero
   */
  def getMicrosecond = nanosecond / 1000

  /**
   * Get the nanosecond component, 0-999999
   *
   * @return the nanosecond component
   */
  def getNanosecond = nanosecond

  /**
   * Convert the value to an xs:dateTime, retaining all the components that are actually present, and
   * substituting conventional values for components that are missing. (This method does nothing in
   * the case of xs:dateTime, but is there to implement a method in the {@link CalendarValue} interface).
   *
   * @return the value as an xs:dateTime
   */
  override def toDateTime = this

  /**
   * Ask whether this value uses the XSD 1.0 rules (which don't allow year zero) or the XSD 1.1 rules (which do).
   *
   * @return true if the value uses the XSD 1.0 rules
   */
  def isXsd10Rules = hasNoYearZero

  /**
   * Check that the value can be handled in Saxon-JS
   *
   * @throws XPathException if it can't be handled in Saxon-JS
   */
  @throws[XPathException]
  override def checkValidInJavascript() = if (year <= 0 || year > 9999) throw new XPathException("Year out of range for Saxon-JS", "FODT0001")

  /**
   * Normalize the date and time to be in timezone Z.
   *
   * @param implicitTimezone used to supply the implicit timezone, used when the value has
   *                         no explicit timezone
   * @return in general, a new DateTimeValue in timezone Z, representing the same instant in time.
   *         Returns the original DateTimeValue if this is already in timezone Z.
   * @throws NoDynamicContextException if the implicit timezone is needed and is CalendarValue.MISSING_TIMEZONE
   *                                   or CalendarValue.NO_TIMEZONE
   */
  @throws[NoDynamicContextException]
  def adjustToUTC(implicitTimezone: Int) = if (hasTimezone) adjustTimezone(0)
  else {
    if (implicitTimezone == CalendarValue.MISSING_TIMEZONE || implicitTimezone == CalendarValue.NO_TIMEZONE) throw new NoDynamicContextException("DateTime operation needs access to implicit timezone")
    val dt = copyAsSubType(null)
    dt.setTimezoneInMinutes(implicitTimezone)
    dt.adjustTimezone(0)
  }

  /**
   * Get the Julian instant: a decimal value whose integer part is the Julian day number
   * multiplied by the number of seconds per day,
   * and whose fractional part is the fraction of the second.
   * This method operates on the local time, ignoring the timezone. The caller should call normalize()
   * before calling this method to get a normalized time.
   *
   * @return the Julian instant corresponding to this xs:dateTime value
   */
  def toJulianInstant = {
    val julianDay = DateValue.getJulianDayNumber(year, month, day)
    var julianSecond = julianDay * 24L * 60L * 60L
    julianSecond += ((hour * 60L + minute) * 60L) + second
    val j = BigDecimal.valueOf(julianSecond)
    if (nanosecond == 0) j
    else j.add(BigDecimal.valueOf(nanosecond).divide(BigDecimalValue.BIG_DECIMAL_ONE_BILLION, 9, RoundingMode.HALF_EVEN))
  }

  /**
   * Get a Java Calendar object representing the value of this DateTime. This will respect the timezone
   * if there is one (provided the timezone is within the range supported by the {@code GregorianCalendar}
   * class, which in practice means that it is not -14:00). If there is no timezone or if
   * the timezone is out of range, the result will be in GMT.
   *
   * @return a Java GregorianCalendar object representing the value of this xs:dateTime value.
   */
  override def getCalendar: GregorianCalendar = {
    val tz = if (hasTimezone) getTimezoneInMinutes * 60000
    else 0
    val zone = new SimpleTimeZone(tz, "LLL")
    val calendar = new GregorianCalendar(zone)
    if (tz < calendar.getMinimum(Calendar.ZONE_OFFSET) || tz > calendar.getMaximum(Calendar.ZONE_OFFSET)) return adjustTimezone(0).getCalendar
    calendar.setGregorianChange(new Date(Long.MIN_VALUE))
    calendar.setLenient(false)
    var yr = year
    if (year <= 0) {
      yr = if (hasNoYearZero) 1 - year
      else 0 - year
      calendar.set(Calendar.ERA, GregorianCalendar.BC)
    }
    //noinspection MagicConstant
    calendar.set(yr, month - 1, day, hour, minute, second)
    calendar.set(Calendar.MILLISECOND, nanosecond / 1000000) // loses precision unavoidably
    calendar.set(Calendar.ZONE_OFFSET, tz)
    calendar.set(Calendar.DST_OFFSET, 0)
    calendar
  }

  /**
   * Get a Java 8 {@link Instant} corresponding to this date and time. The value will respect the time zone
   * offset if present, or will assume UTC otherwise.
   */
  def toJavaInstant = Instant.from(this)

  /**
   * Get a Java 8 {@link ZonedDateTime} corresponding to this date and time. The value will respect the time zone
   * offset if present, or will assume UTC otherwise.
   *
   * @return a { @code ZonedDateTime} representing this date and time, including its timezone if present, or
   *                   interpreted as a UTC date/time otherwise.
   * @since 9.9
   */
  def toZonedDateTime = if (hasTimezone) ZonedDateTime.from(this)
  else try ZonedDateTime.from(adjustToUTC(0))
  catch {
    case e: NoDynamicContextException =>
      throw new AssertionError(e)
  }

  /**
   * Get a Java 8 {@link OffsetDateTime} corresponding to this date and time. The value will respect the time zone
   * offset if present, or will assume UTC otherwise.
   *
   * @return a { @code OffsetDateTime} representing this date and time, including its timezone if present, or
   *                   interpreted as a UTC date/time otherwise.
   * @since 9.9
   */
  def toOffsetDateTime = if (hasTimezone) OffsetDateTime.from(this)
  else try OffsetDateTime.from(adjustToUTC(0))
  catch {
    case e: NoDynamicContextException =>
      throw new AssertionError(e)
  }

  /**
   * Get a Java 8 {@link LocalDateTime} corresponding to this date and time. The value will ignore any timezone
   * offset present in this value.
   *
   * @return a { @code LocalDateTime} equivalent to this date and time, discarding any time zone offset if present.
   * @since 9.9
   */
  def toLocalDateTime = LocalDateTime.from(this)

  /**
   * Convert to string
   *
   * @return ISO 8601 representation. The value returned is the localized representation:
   *         that is it uses the timezone contained within the value itself. In the case
   *         of a year earlier than year 1, the value output is the internally-held year,
   *         unless the { @code hasNoYearZero} flag is set, in which case it is the
   *                            internal year minus one.
   */
  override def getPrimitiveStringValue = {
    val sb = new FastStringBuffer(30)
    var yr = year
    if (year <= 0) {
      yr = -yr + (if (hasNoYearZero) 1
      else 0) // no year zero in lexical space for XSD 1.0
      if (yr != 0) sb.cat('-')
    }
    appendString(sb, yr, if (yr > 9999) (yr + "").length
    else 4)
    sb.cat('-')
    appendTwoDigits(sb, month)
    sb.cat('-')
    appendTwoDigits(sb, day)
    sb.cat('T')
    appendTwoDigits(sb, hour)
    sb.cat(':')
    appendTwoDigits(sb, minute)
    sb.cat(':')
    appendTwoDigits(sb, second)
    if (nanosecond != 0) {
      sb.cat('.')
      var ms = nanosecond
      var div = 100000000
      while ( {
        ms > 0
      }) {
        val d = ms / div
        sb.cat((d + '0').toChar)
        ms = ms % div
        div /= 10
      }
    }
    if (hasTimezone) appendTimezone(sb)
    sb
  }

  /**
   * Extract the Date part
   *
   * @return a DateValue representing the date part of the dateTime, retaining the timezone or its absence
   */
  def toDateValue = new DateValue(year, month, day, getTimezoneInMinutes, hasNoYearZero)

  /**
   * Extract the Time part
   *
   * @return a TimeValue representing the date part of the dateTime, retaining the timezone or its absence
   */
  def toTimeValue = new TimeValue(hour, minute, second, nanosecond, getTimezoneInMinutes, "")

  /**
   * Get the canonical lexical representation as defined in XML Schema. This is not always the same
   * as the result of casting to a string according to the XPath rules. For an xs:dateTime it is the
   * date/time adjusted to UTC.
   *
   * @return the canonical lexical representation as defined in XML Schema
   */
  override def getCanonicalLexicalRepresentation = if (hasTimezone && getTimezoneInMinutes != 0) adjustTimezone(0).getStringValueCS
  else getStringValueCS

  /**
   * Make a copy of this date, time, or dateTime value, but with a new type label
   *
   * @param typeLabel the type label to be attached to the new copy. It is the caller's responsibility
   *                  to ensure that the value actually conforms to the rules for this type.
   */
  override def copyAsSubType(typeLabel: AtomicType) = {
    val v = new DateTimeValue(year, month, day, hour, minute, second, nanosecond, getTimezoneInMinutes)
    v.hasNoYearZero = hasNoYearZero
    v.typeLabel = typeLabel
    v
  }

  /**
   * Return a new dateTime with the same normalized value, but
   * in a different timezone.
   *
   * @param timezone the new timezone offset, in minutes
   * @return the date/time in the new timezone. This will be a new DateTimeValue unless no change
   *         was required to the original value
   */
  override def adjustTimezone(timezone: Int): DateTimeValue = {
    if (!hasTimezone) {
      val in = copyAsSubType(typeLabel)
      in.setTimezoneInMinutes(timezone)
      return in
    }
    val oldtz = getTimezoneInMinutes
    if (oldtz == timezone) return this
    val tz = timezone - oldtz
    var h = hour
    var mi = minute
    mi += tz
    if (mi < 0 || mi > 59) {
      h += Math.floor(mi / 60.0)
      mi = (mi + 60 * 24) % 60
    }
    if (h >= 0 && h < 24) {
      val d2 = new DateTimeValue(year, month, day, h.toByte, mi.toByte, second, nanosecond, timezone)
      d2.hasNoYearZero = hasNoYearZero
      return d2
    }
    // Following code is designed to handle the corner case of adjusting from -14:00 to +14:00 or
    // vice versa, which can cause a change of two days in the date
    var dt = this
    while ( {
      h < 0
    }) {
      h += 24
      val t = DateValue.yesterday(dt.getYear, dt.getMonth, dt.getDay)
      dt = new DateTimeValue(t.getYear, t.getMonth, t.getDay, h.toByte, mi.toByte, second, nanosecond, timezone)
      dt.hasNoYearZero = hasNoYearZero
    }
    if (h > 23) {
      h -= 24
      val t = DateValue.tomorrow(year, month, day)
      dt = new DateTimeValue(t.getYear, t.getMonth, t.getDay, h.toByte, mi.toByte, second, nanosecond, timezone)
      dt.hasNoYearZero = hasNoYearZero
    }
    dt
  }

  /**
   * Add a duration to a dateTime
   *
   * @param duration the duration to be added (may be negative)
   * @return the new date
   * @throws net.sf.saxon.trans.XPathException
   * if the duration is an xs:duration, as distinct from
   * a subclass thereof
   */
  @throws[XPathException]
  override def add(duration: DurationValue) = if (duration.isInstanceOf[DayTimeDurationValue]) {
    val seconds = duration.asInstanceOf[DayTimeDurationValue].getTotalSeconds
    var julian = toJulianInstant
    julian = julian.add(seconds)
    val dt = DateTimeValue.fromJulianInstant(julian)
    dt.setTimezoneInMinutes(getTimezoneInMinutes)
    dt.hasNoYearZero = this.hasNoYearZero
    dt
  }
  else if (duration.isInstanceOf[YearMonthDurationValue]) {
    val months = duration.asInstanceOf[YearMonthDurationValue].getLengthInMonths
    var m = (month - 1) + months
    var y = year + m / 12
    m = m % 12
    if (m < 0) {
      m += 12
      y -= 1
    }
    m += 1
    var d = day
    while ( {
      !DateValue.isValidDate(y, m, d)
    }) d -= 1
    val dtv = new DateTimeValue(y, m.toByte, d.toByte, hour, minute, second, nanosecond, getTimezoneInMinutes)
    dtv.hasNoYearZero = hasNoYearZero
    dtv
  }
  else {
    val err = new XPathException("DateTime arithmetic is not supported on xs:duration, only on its subtypes")
    err.setErrorCode("XPTY0004")
    err.setIsTypeError(true)
    throw err
  }

  /**
   * Determine the difference between two points in time, as a duration
   *
   * @param other   the other point in time
   * @param context the XPath dynamic context
   * @return the duration as an xs:dayTimeDuration
   * @throws net.sf.saxon.trans.XPathException
   * for example if one value is a date and the other is a time
   */
  @throws[XPathException]
  override def subtract(other: CalendarValue, context: XPathContext) = {
    if (!other.isInstanceOf[DateTimeValue]) {
      val err = new XPathException("First operand of '-' is a dateTime, but the second is not")
      err.setErrorCode("XPTY0004")
      err.setIsTypeError(true)
      throw err
    }
    super.subtract(other, context)
  }

  def secondsSinceEpoch = try {
    val dtv = adjustToUTC(0)
    val d1 = dtv.toJulianInstant
    val d2 = DateTimeValue.EPOCH.toJulianInstant
    d1.subtract(d2)
  } catch {
    case e: NoDynamicContextException =>
      throw new AssertionError(e)
  }

  /**
   * Get a component of the value. Returns null if the timezone component is
   * requested and is not present.
   *
   * @param component identifies the required component
   */
  @throws[XPathException]
  override def getComponent(component: AccessorFn.Component) = component match {
    case YEAR_ALLOWING_ZERO =>
      Int64Value.makeIntegerValue(year)
    case YEAR =>
      Int64Value.makeIntegerValue(if (year > 0 || !hasNoYearZero) year
      else year - 1)
    case MONTH =>
      Int64Value.makeIntegerValue(month)
    case DAY =>
      Int64Value.makeIntegerValue(day)
    case HOURS =>
      Int64Value.makeIntegerValue(hour)
    case MINUTES =>
      Int64Value.makeIntegerValue(minute)
    case SECONDS =>
      var d = BigDecimal.valueOf(nanosecond)
      d = d.divide(BigDecimalValue.BIG_DECIMAL_ONE_BILLION, 6, BigDecimal.ROUND_HALF_UP)
      d = d.add(BigDecimal.valueOf(second))
      new BigDecimalValue(d)
    case WHOLE_SECONDS => //(internal use only)
      Int64Value.makeIntegerValue(second)
    case MICROSECONDS =>
      // internal use only
      new Int64Value(nanosecond / 1000)
    case NANOSECONDS =>
      new Int64Value(nanosecond)
    case TIMEZONE =>
      if (hasTimezone) DayTimeDurationValue.fromMilliseconds(60000L * getTimezoneInMinutes)
      else null
    case _ =>
      throw new IllegalArgumentException("Unknown component for dateTime: " + component)
  }

  override def isSupported(field: TemporalField) = if (field == ChronoField.OFFSET_SECONDS) getTimezoneInMinutes != NO_TIMEZONE
  else if (field.isInstanceOf[ChronoField]) true
  else field.isSupportedBy(this)

  /**
   * Gets the value of the specified field as a {@code long}.
   * <p>This queries the date-time for the value of the specified field.
   * The returned value may be outside the valid range of values for the field.
   * If the date-time cannot return the value, because the field is unsupported or for
   * some other reason, an exception will be thrown.</p>
   *
   * <p>The specification requires some fields (for example {@link ChronoField#EPOCH_DAY} to
   * reflect the local time. The Saxon implementation does not have access to the local time,
   * so it adjusts to UTC instead.</p>
   *
   * @param field the field to get, not null
   * @return the value for the field
   * @throws DateTimeException                if a value for the field cannot be obtained
   * @throws UnsupportedTemporalTypeException if the field is not supported
   * @throws ArithmeticException              if numeric overflow occurs
   * @implSpec Implementations must check and handle all fields defined in { @link ChronoField}.
   *                                                                               If the field is supported, then the value of the field must be returned.
   *                                                                               If unsupported, then an { @code UnsupportedTemporalTypeException} must be thrown.
   *                                                                                                               <p>If the field is not a { @code ChronoField}, then the result of this method
   *                                                                                                               is obtained by invoking { @code TemporalField.getFrom(TemporalAccessor)}
   *                                                                                                               passing { @code this} as the argument.</p>
   *                                                                                                               <p>Implementations must ensure that no observable state is altered when this
   *                                                                                                               read-only method is invoked.</p>
   */
  override def getLong(field: TemporalField) = if (field.isInstanceOf[ChronoField]) field.asInstanceOf[ChronoField] match {
    case NANO_OF_SECOND =>
      nanosecond
    case NANO_OF_DAY =>
      (hour * 3600 + minute * 60 + second) * 1000000000L + nanosecond
    case MICRO_OF_SECOND =>
      nanosecond / 1000
    case MICRO_OF_DAY =>
      (hour * 3600 + minute * 60 + second) * 1000000L + (nanosecond / 1000)
    case MILLI_OF_SECOND =>
      nanosecond / 1000000
    case MILLI_OF_DAY =>
      (hour * 3600 + minute * 60 + second) * 1000L + nanosecond / 1000000
    case SECOND_OF_MINUTE =>
      second
    case SECOND_OF_DAY =>
      hour * 3600 + minute * 60 + second
    case MINUTE_OF_HOUR =>
      minute
    case MINUTE_OF_DAY =>
      hour * 60 + minute
    case HOUR_OF_AMPM =>
      hour % 12
    case CLOCK_HOUR_OF_AMPM =>
      (hour + 11) % 12 + 1
    case HOUR_OF_DAY =>
      hour
    case CLOCK_HOUR_OF_DAY =>
      (hour + 23) % 24 + 1
    case AMPM_OF_DAY =>
      hour / 12 // specification is unclear about noon and midnight
    case DAY_OF_WEEK =>
      DateValue.getDayOfWeek(year, month, day)
    case ALIGNED_DAY_OF_WEEK_IN_MONTH =>
      (day - 1) % 7 + 1
    case ALIGNED_DAY_OF_WEEK_IN_YEAR =>
      (DateValue.getDayWithinYear(year, month, day) - 1) % 7 + 1
    case DAY_OF_MONTH =>
      day
    case DAY_OF_YEAR =>
      DateValue.getDayWithinYear(year, month, day)
    case EPOCH_DAY =>
      val secs = secondsSinceEpoch
      val days = secondsSinceEpoch.longValue / (24 * 60 * 60)
      if (secs.signum < 0) days - 1
      else days
    case ALIGNED_WEEK_OF_MONTH =>
      (day - 1) / 7 + 1
    case ALIGNED_WEEK_OF_YEAR =>
      (DateValue.getDayWithinYear(year, month, day) - 1) / 7 + 1
    case MONTH_OF_YEAR =>
      month
    case PROLEPTIC_MONTH =>
      year * 12 + month - 1
    case YEAR_OF_ERA =>
      Math.abs(year) + (if (year < 0) 1
      else 0)
    case YEAR =>
      year
    case ERA =>
      if (year < 0) 0
      else 1
    case INSTANT_SECONDS =>
      secondsSinceEpoch.setScale(0, BigDecimal.ROUND_FLOOR).longValue
    case OFFSET_SECONDS =>
      val tz = getTimezoneInMinutes
      if (tz == NO_TIMEZONE) throw new UnsupportedTemporalTypeException("xs:dateTime value has no timezone")
      else tz * 60
    case _ =>
      throw new UnsupportedTemporalTypeException(field.toString)
  }
  else field.getFrom(this)

  /**
   * Compare the value to another dateTime value, following the XPath comparison semantics
   *
   * @param other            The other dateTime value
   * @param implicitTimezone The implicit timezone to be used for a value with no timezone
   * @return negative value if this one is the earler, 0 if they are chronologically equal,
   *         positive value if this one is the later. For this purpose, dateTime values with an unknown
   *         timezone are considered to be values in the implicit timezone (the Comparable interface requires
   *         a total ordering).
   * @throws ClassCastException        if the other value is not a DateTimeValue (the parameter
   *                                   is declared as CalendarValue to satisfy the interface)
   * @throws NoDynamicContextException if the implicit timezone is needed and is not available
   */
  @throws[NoDynamicContextException]
  override def compareTo(other: CalendarValue, implicitTimezone: Int): Int = {
    if (!other.isInstanceOf[DateTimeValue]) throw new ClassCastException("DateTime values are not comparable to " + other.getClass)
    val v2 = other.asInstanceOf[DateTimeValue]
    if (getTimezoneInMinutes == v2.getTimezoneInMinutes) { // both values are in the same timezone (explicitly or implicitly)
      if (year != v2.year) return IntegerValue.signum(year - v2.year)
      if (month != v2.month) return IntegerValue.signum(month - v2.month)
      if (day != v2.day) return IntegerValue.signum(day - v2.day)
      if (hour != v2.hour) return IntegerValue.signum(hour - v2.hour)
      if (minute != v2.minute) return IntegerValue.signum(minute - v2.minute)
      if (second != v2.second) return IntegerValue.signum(second - v2.second)
      if (nanosecond != v2.nanosecond) return IntegerValue.signum(nanosecond - v2.nanosecond)
      return 0
    }
    adjustToUTC(implicitTimezone).compareTo(v2.adjustToUTC(implicitTimezone), implicitTimezone)
  }

  /**
   * Context-free comparison of two DateTimeValue values. For this to work,
   * the two values must either both have a timezone or both have none.
   *
   * @param v2 the other value
   * @return the result of the comparison: -1 if the first is earlier, 0 if they
   *         are equal, +1 if the first is later
   * @throws ClassCastException if the values are not comparable (which might be because
   *                            no timezone is available)
   */
  override def compareTo(v2: Any) = try compareTo(v2.asInstanceOf[DateTimeValue], MISSING_TIMEZONE)
  catch {
    case err: Exception =>
      throw new ClassCastException("DateTime comparison requires access to implicit timezone")
  }

  override def getSchemaComparable = new DateTimeValue#DateTimeComparable

  /**
   * DateTimeComparable is an object that implements the XML Schema rules for comparing date/time values
   */
  private class DateTimeComparable extends Comparable[_] {
    private def asDateTimeValue = thisDateTimeValue

    // Rules from XML Schema Part 2
    override def compareTo(o: Any): Int = if (o.isInstanceOf[DateTimeValue#DateTimeComparable]) {
      var dt0 = thisDateTimeValue
      var dt1 = o.asInstanceOf[DateTimeValue#DateTimeComparable].asDateTimeValue
      if (dt0.hasTimezone) if (dt1.hasTimezone) {
        dt0 = dt0.adjustTimezone(0)
        dt1 = dt1.adjustTimezone(0)
        dt0.compareTo(dt1)
      }
      else {
        val dt1max = dt1.adjustTimezone(14 * 60)
        if (dt0.compareTo(dt1max) < 0) return -1
        val dt1min = dt1.adjustTimezone(-14 * 60)
        if (dt0.compareTo(dt1min) > 0) return +1
        SequenceTool.INDETERMINATE_ORDERING
      }
      else if (dt1.hasTimezone) {
        val dt0min = dt0.adjustTimezone(-14 * 60)
        if (dt0min.compareTo(dt1) < 0) return -1
        val dt0max = dt0.adjustTimezone(14 * 60)
        if (dt0max.compareTo(dt1) > 0) return +1
        SequenceTool.INDETERMINATE_ORDERING
      }
      else {
        dt0 = dt0.adjustTimezone(0)
        dt1 = dt1.adjustTimezone(0)
        dt0.compareTo(dt1)
      }
    }
    else SequenceTool.INDETERMINATE_ORDERING

    override def equals(o: Any) = o.isInstanceOf[DateTimeValue#DateTimeComparable] && thisDateTimeValue.hasTimezone == o.asInstanceOf[DateTimeValue#DateTimeComparable].asDateTimeValue.hasTimezone && compareTo(o) == 0

    override def hashCode = {
      val dt0 = adjustTimezone(0)
      (dt0.year << 20) ^ (dt0.month << 16) ^ (dt0.day << 11) ^ (dt0.hour << 7) ^ (dt0.minute << 2) ^ (dt0.second * 1000000000 + dt0.nanosecond)
    }
  }

  /**
   * Context-free comparison of two dateTime values
   *
   * @param o the other date time value
   * @return true if the two values represent the same instant in time. Return false if one value has
   *         a timezone and the other does not (this is the result needed when using keys in a map)
   */
  override def equals(o: Any) = o.isInstanceOf[DateTimeValue] && compareTo(o) == 0

  /**
   * Hash code for context-free comparison of date time values. Note that equality testing
   * and therefore hashCode() works only for values with a timezone
   *
   * @return a hash code
   */
  override def hashCode = DateTimeValue.hashCode(year, month, day, hour, minute, second, nanosecond, getTimezoneInMinutes)
}