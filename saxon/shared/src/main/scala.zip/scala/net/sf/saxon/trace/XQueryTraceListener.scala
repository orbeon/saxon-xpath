////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.flwor.ClauseInfo
import net.sf.saxon.expr.instruct.GlobalVariable
import net.sf.saxon.expr.instruct.UserFunction
import net.sf.saxon.functions.Trace
import net.sf.saxon.om.Item
import net.sf.saxon.query.XQueryExpression
import net.sf.saxon.trans.Mode

/**
 * A Simple trace listener for XQuery that writes messages (by default) to System.err
 */
class XQueryTraceListener extends AbstractTraceListener {
  /**
   * Generate attributes to be included in the opening trace element
   */
    /*@NotNull*/ override protected def getOpeningAttributes = ""

  /**
   * Get the trace element tagname to be used for a particular construct. Return null for
   * trace events that are ignored by this trace listener.
   *
   * @param info
   */
  /*@Nullable*/ override protected def tag(info: Traceable) = if (info.isInstanceOf[TraceableComponent]) if (info.isInstanceOf[GlobalVariable]) "variable"
  else if (info.isInstanceOf[UserFunction]) "function"
  else if (info.isInstanceOf[XQueryExpression]) "query"
  else "misc"
  else if (info.isInstanceOf[Trace]) "fn:trace"
  else if (info.isInstanceOf[ClauseInfo]) info.asInstanceOf[ClauseInfo].getClause.getClauseKey.toString
  else if (info.isInstanceOf[Expression]) {
    var s = info.asInstanceOf[Expression].getExpressionName
    if (s.startsWith("xsl:")) s = s.substring(4)
    s match {
      case "value-of" =>
        "text"
      case "LRE" =>
        "element"
      case "ATTR" =>
        "attribute"
      case _ =>
        s
    }
  }
  else null

  /**
   * Called at the start of a rule search
   */
  override def startRuleSearch() = {
    // do nothing
  }

  /**
   * Called at the end of a rule search
   *
   * @param rule the rule that has been selected
   * @param mode
   * @param item
   */
  override def endRuleSearch(rule: Any, mode: Mode, item: Item) = {
  }
}