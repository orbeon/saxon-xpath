////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.pull

import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.NamespaceBinding
import net.sf.saxon.om.NodeName
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AtomicValue
import java.util

/**
 * PullProvider is Saxon's pull-based interface for reading XML documents and XDM sequences.
 * A PullProvider can deliver any sequence of nodes or atomic values.
 *
 * <p>An {@code UnfailingPullProvider} is a subtype where the methods throw no checked Exceptions.</p>
 */
trait UnfailingPullProvider extends PullProvider {
  @throws[XPathException]
  override def next

  override def current

  override def getAttributes

  override def getNamespaceDeclarations

  override def skipToMatchingEnd

  override def close()

  override def getNodeName

  @throws[XPathException]
  override def getStringValue

  override def getSchemaType

  override def getAtomicValue

  override def getSourceLocator

  override def getUnparsedEntities
}