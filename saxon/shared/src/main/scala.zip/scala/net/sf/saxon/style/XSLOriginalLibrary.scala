////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.StaticContext
import net.sf.saxon.expr.StaticFunctionCall
import net.sf.saxon.expr.instruct.OriginalFunction
import net.sf.saxon.functions.FunctionLibrary
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.om.Function
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.StandardNames
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.SymbolicName
import net.sf.saxon.trans.XPathException
import java.util

/**
 * A function library that recognizes the function name "xsl:original", which may appear within xsl:override
 */
object XSLOriginalLibrary {
  private val THE_INSTANCE = new XSLOriginalLibrary

  def getInstance = THE_INSTANCE

  var XSL_ORIGINAL = new StructuredQName("xsl", NamespaceConstant.XSLT, "original")
}

class XSLOriginalLibrary private() extends FunctionLibrary {
  override def bind(functionName: SymbolicName.F, staticArgs: Array[Expression], env: StaticContext, reasons: util.List[String]) = try {
    val target = getFunctionItem(functionName, env)
    if (target == null) null
    else new StaticFunctionCall(target, staticArgs)
  } catch {
    case e: XPathException =>
      reasons.add(e.getMessage)
      null
  }

  override def isAvailable(functionName: SymbolicName.F) = { // xsl:original is not recognized by function-available() - W3C bug 28122
    false
  }

  override def copy = this

  @throws[XPathException]
  override def getFunctionItem(functionName: SymbolicName.F, env: StaticContext): Function = if (functionName.getComponentKind == StandardNames.XSL_FUNCTION && functionName.getComponentName.hasURI(NamespaceConstant.XSLT) && functionName.getComponentName.getLocalPart == "original" && env.isInstanceOf[ExpressionContext]) {
    val expressionContext = env.asInstanceOf[ExpressionContext]
    var overridingFunction = expressionContext.getStyleElement
    while ( {
      !overridingFunction.isInstanceOf[XSLFunction]
    }) {
      val parent = overridingFunction.getParent
      if (!parent.isInstanceOf[StyleElement]) return null
      overridingFunction = parent.asInstanceOf[StyleElement]
    }
    val originalName = overridingFunction.asInstanceOf[XSLFunction].getSymbolicName
    val `override` = overridingFunction.getParent.asInstanceOf[XSLOverride]
    val use = `override`.getParent.asInstanceOf[XSLUsePackage]
    val overridden = use.getUsedPackage.getComponent(originalName)
    if (overridden == null) throw new XPathException("Function " + originalName + " does not exist in used package", "XTSE3058")
    new OriginalFunction(overridden)
  }
  else null
}