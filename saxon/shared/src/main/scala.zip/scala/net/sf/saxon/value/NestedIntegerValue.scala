////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.sort.AtomicMatchKey
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.util
import java.util.StringTokenizer

/**
 * This class represents a dot-separated sequence of numbers such as 1.12.5, typically
 * used as a software version number.
 * <p>Although the class is implemented as an atomic type derived from xs:string, it
 * has not been integrated into the schema type hierarchy and cannot be used directly
 * in schema validation.</p>
 * <p>The class provides "smart" ordering, for example 1 &lt; 1.2 &lt; 1.12 &lt; 1.12.6</p>
 */
object NestedIntegerValue {
  var ONE = new NestedIntegerValue(Array[Int](1))
  var TWO = new NestedIntegerValue(Array[Int](2))

  @throws[XPathException]
  def parse(v: String) = {
    val st = new StringTokenizer(v, ".")
    val valuei = new Array[Int](st.countTokens)
    try{
    var i = 0
    while ( {
      st.hasMoreTokens
    }) {
      valuei(i) = st.nextToken.toInt
      i += 1
    }
    }catch
    {
      case exc: NumberFormatException =>
        throw new XPathException("Nested integer value has incorrect format: " + v)
    }
    new NestedIntegerValue(valuei)
  }
}

class NestedIntegerValue extends AtomicValue with Comparable[_] with AtomicMatchKey {
  private[value] var value = null

  def this(v: String) {
    this()
    typeLabel = BuiltInAtomicType.STRING
    NestedIntegerValue.parse(v)
  }

  def this(`val`: Array[Int]) {
    this()
    typeLabel = BuiltInAtomicType.STRING
    value = `val`
  }

  def append(leaf: Int) = {
    val v = new Array[Int](value.length + 1)
    System.arraycopy(value, 0, v, 0, value.length)
    v(value.length) = leaf
    new NestedIntegerValue(v)
  }

  def getStem = if (value.length == 0) null
  else {
    val v = new Array[Int](value.length - 1)
    System.arraycopy(value, 0, v, 0, v.length)
    new NestedIntegerValue(v)
  }

  def getDepth = value.length

  def getLeaf = if (value.length == 0) -1
  else value(value.length - 1)

  override def getSchemaComparable = this

  override def getXPathComparable(ordered: Boolean, collator: StringCollator, implicitTimezone: Int) = this

  override def equals(o: Any) = o.isInstanceOf[NestedIntegerValue] && util.Arrays.equals(value, o.asInstanceOf[NestedIntegerValue].value)

  override def getPrimitiveType = BuiltInAtomicType.STRING

  override def copyAsSubType(typeLabel: AtomicType) = {
    val v = new NestedIntegerValue(value)
    v.typeLabel = typeLabel
    v
  }

  override protected def getPrimitiveStringValue = {
    val buffer = new FastStringBuffer(value.length * 2)
    for (i <- 0 until value.length - 1) {
      buffer.append(value(i) + ".")
    }
    buffer.append(value(value.length - 1) + "")
    buffer
  }

  override def compareTo(other: Any): Int = if (!other.isInstanceOf[NestedIntegerValue]) throw new ClassCastException("NestedIntegerValue is not comparable to " + other.getClass)
  else {
    val v2 = other.asInstanceOf[NestedIntegerValue]
    var i = 0
    while ( {
      i < value.length && i < v2.value.length
    }) {
      if (value(i) != v2.value(i)) if (value(i) < v2.value(i)) return -1
      else return 1
      i += 1
    }
    Integer.signum(value.length - v2.value.length)
  }
}