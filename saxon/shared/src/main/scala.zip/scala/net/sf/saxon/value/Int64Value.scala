////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.Calculator
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ValidationFailure
import net.sf.saxon.om.SequenceTool
import net.sf.saxon.om.StandardNames
import net.sf.saxon.trans.XPathException
import java.math.BigDecimal
import java.math.BigInteger

/**
 * An integer value: note this is a subtype of decimal in XML Schema, not a primitive type.
 * This class supports integer values in the range permitted by a Java "long",
 * and also supports the built-in subtypes of xs:integer.
 */
object Int64Value {
  /**
   * IntegerValue representing the value -1
   */
    val MINUS_ONE = new Int64Value(-1)
  /**
   * IntegerValue representing the value zero
   */
  val ZERO = new Int64Value(0)
  /**
   * IntegerValue representing the value +1
   */
  val PLUS_ONE = new Int64Value(+1)
  /**
   * IntegerValue representing the maximum value for a long
   */
  val MAX_LONG = new Int64Value(Long.MAX_VALUE)
  /**
   * IntegerValue representing the minimum value for a long
   */
  val MIN_LONG = new Int64Value(Long.MIN_VALUE)
  /**
   * Array of small integer values
   */
  private val SMALL_INTEGERS = Array(new Int64Value(0), new Int64Value(1), new Int64Value(2), new Int64Value(3), new Int64Value(4), new Int64Value(5), new Int64Value(6), new Int64Value(7), new Int64Value(8), new Int64Value(9), new Int64Value(10), new Int64Value(11), new Int64Value(12), new Int64Value(13), new Int64Value(14), new Int64Value(15), new Int64Value(16), new Int64Value(17), new Int64Value(18), new Int64Value(19), new Int64Value(20))

  /**
   * Factory method: allows Int64Value objects to be reused. Note that
   * a value obtained using this method must not be modified to set a type label, because
   * the value is in general shared.
   *
   * @param value the integer value
   * @return an Int64Value with this integer value
   */
  def makeIntegerValue(value: Long) = if (value <= 20 && value >= 0) SMALL_INTEGERS(value.toInt)
  else new Int64Value(value)

  /**
   * Factory method to create a derived value, with no checking of the value against the
   * derived type
   *
   * @param val  the integer value
   * @param type the subtype of xs:integer
   * @return the constructed value
   */
  /*@NotNull*/ def makeDerived(`val`: Long, `type`: AtomicType) = {
    val v = new Int64Value(`val`)
    v.typeLabel = `type`
    v
  }

  /**
   * Factory method returning the integer -1, 0, or +1 according as the argument
   * is negative, zero, or positive
   *
   * @param val the value to be tested
   * @return the Int64Value representing -1, 0, or +1
   */
  def signum(`val`: Long) = if (`val` == 0) ZERO
  else if (`val` < 0) MINUS_ONE
  else PLUS_ONE

  /**
   * A Comparable that performs comparison of an Int64Value either with another
   * Int64Value or with some other representation of an XPath numeric value
   */
  protected class Int64Comparable(var value: Int64Value) extends Comparable[_] {
    def asLong = value.longValue

    override def compareTo(o: Any) = if (o.isInstanceOf[Int64Value.Int64Comparable]) {
      val long0 = value.longValue
      val long1 = o.asInstanceOf[Int64Value.Int64Comparable].value.longValue
      if (long0 <= long1) if (long0 == long1) 0
      else -1
      else 1
    }
    else if (o.isInstanceOf[BigIntegerValue.BigIntegerComparable]) value.asBigInteger.compareTo(o.asInstanceOf[BigIntegerValue.BigIntegerComparable].asBigInteger)
    else if (o.isInstanceOf[BigDecimalValue.DecimalComparable]) value.getDecimalValue.compareTo(o.asInstanceOf[BigDecimalValue.DecimalComparable].asBigDecimal)
    else SequenceTool.INDETERMINATE_ORDERING

    override def equals(o: Any) = if (o.isInstanceOf[Int64Value.Int64Comparable]) asLong == o.asInstanceOf[Int64Value.Int64Comparable].asLong
    else compareTo(o) == 0

    override def hashCode = { // Must align with hashCodes for other subtypes of xs:decimal
      asLong.toInt
    }
  }

}

final class Int64Value extends IntegerValue {
  private var value = 0L

  /**
   * Constructor supplying a long
   *
   * @param value the value of the IntegerValue
   */
  def this(value: Long) {
    this()
    this.value = value
    typeLabel = BuiltInAtomicType.INTEGER
  }

  /**
   * Constructor for a subtype, supplying a long and a type label.
   *
   * @param val   The supplied value, as an integer
   * @param type  the required item type, a subtype of xs:integer
   * @param check Set to true if the method is required to check that the value is in range;
   *              false if the caller can guarantee that the value has already been checked.
   * @throws XPathException if the supplied value is out of range for the
   *                        target type
   */
  def this(`val`: Long, `type`: BuiltInAtomicType, check: Boolean) {
    this()
    value = `val`
    typeLabel = `type`
    if (check && !checkRange(value, `type`)) {
      val err = new XPathException("Integer value " + `val` + " is out of range for the requested type " + `type`.getDescription)
      err.setErrorCode("XPTY0004")
      err.setIsTypeError(true)
      throw err
    }
  }

  /**
   * Test whether a number is a possible subscript into a sequence, that is,
   * a whole number greater than zero and less than 2^31
   *
   *
   * @return the number as an int if it is a possible subscript, or -1 otherwise
   */
  override def asSubscript = if (value > 0 && value <= Integer.MAX_VALUE) value.toInt
  else -1

  /**
   * Create a copy of this atomic value, with a different type label
   *
   * @param typeLabel the type label of the new copy. The caller is responsible for checking that
   *                  the value actually conforms to this type.
   */
  override def copyAsSubType(typeLabel: AtomicType) = if (typeLabel.getPrimitiveType == StandardNames.XS_INTEGER) {
    val v = new Int64Value(value)
    v.typeLabel = typeLabel
    v
  }
  else new BigDecimalValue(value)

  /**
   * Convert the value to a subtype of xs:integer
   *
   * @param subtype  the target subtype
   * @param validate true if validation is required; false if the caller already knows that the value is valid
   * @return null if the conversion succeeds; a ValidationFailure describing the failure if it fails. Note
   *         that the exception is returned, not thrown.
   */
  /*@Nullable*/ override def convertToSubType(subtype: BuiltInAtomicType, validate: Boolean) = if (!validate) {
    setSubType(subtype)
    null
  }
  else if (checkRange(subtype)) null
  else {
    val err = new ValidationFailure("String " + value + " cannot be converted to integer subtype " + subtype.getDescription)
    err.setErrorCode("FORG0001")
    err
  }

  /**
   * This class allows subtypes of xs:integer to be held, as well as xs:integer values.
   * This method sets the required type label. Note that this method modifies the value in situ.
   *
   * @param type the subtype of integer required
   * @return null if the operation succeeds, or a ValidationException if the value is out of range
   */
  override def validateAgainstSubType(`type`: BuiltInAtomicType) = if (checkRange(value, `type`)) null
  else {
    val err = new ValidationFailure("Value " + value + " cannot be converted to integer subtype " + `type`.getDescription)
    err.setErrorCode("FORG0001")
    err
  }

  /**
   * This class allows subtypes of xs:integer to be held, as well as xs:integer values.
   * This method sets the required type label. It is the caller's responsibility to check that
   * the value is within range.
   *
   * @param type the type label to be assigned
   */
  def setSubType(`type`: AtomicType) = typeLabel = `type`

  /**
   * This class allows subtypes of xs:integer to be held, as well as xs:integer values.
   * This method checks that the value is within range, and also sets the type label.
   *
   * @param type the subtype of integer required
   * @return true if successful, false if value is out of range for the subtype
   */
  def checkRange(`type`: BuiltInAtomicType) = {
    typeLabel = `type`
    checkRange(value, `type`)
  }

  /**
   * Get an object that implements XML Schema comparison semantics
   */
  override def getSchemaComparable = new Int64Value.Int64Comparable(this)

  /**
   * Get the hashCode. This must conform to the rules for other NumericValue hashcodes
   *
   * @see NumericValue#hashCode
   */
  override def hashCode = if (value > Integer.MIN_VALUE && value < Integer.MAX_VALUE) value.toInt
  else Double.valueOf(getDoubleValue).hashCode

  /**
   * Get the value
   *
   * @return the value of the xs:integer, as a Java long
   */
  override def longValue = value

  /**
   * Return the effective boolean value of this integer
   *
   * @return false if the integer is zero, otherwise true
   */
  override def effectiveBooleanValue = value != 0

  /**
   * Compare the value to another numeric value
   *
   * @param other the numeric value to be compared to this value
   * @return -1 if this value is less than the other, 0 if they are equal,
   *         +1 if this value is greater
   */
  override def compareTo(other: NumericValue) = if (other.isInstanceOf[Int64Value]) Long.compare(value, other.asInstanceOf[Int64Value].value)
  else if (other.isInstanceOf[BigIntegerValue]) BigInteger.valueOf(value).compareTo(other.asInstanceOf[BigIntegerValue].asBigInteger)
  else if (other.isInstanceOf[BigDecimalValue]) new BigDecimal(value).compareTo(other.asInstanceOf[BigDecimalValue].getDecimalValue)
  else super.compareTo(other)

  /**
   * Compare the value to a long
   *
   * @param other the value to be compared with
   * @return -1 if this is less, 0 if this is equal, +1 if this is greater or if this is NaN
   */
  override def compareTo(other: Long) = Long.compare(value, other)

  /**
   * Get the value as a String
   *
   * @return a String representation of the value
   */
  override def getPrimitiveStringValue = Long.toString(value)

  /**
   * Get the numeric value as a double
   *
   * @return A double representing this numeric value; NaN if it cannot be
   *         converted
   */
  override def getDoubleValue = value.toDouble

  /**
   * Get the numeric value converted to a float
   *
   * @return a float representing this numeric value; NaN if it cannot be converted
   */
  override def getFloatValue = value.toFloat

  /**
   * Get the numeric value converted to a decimal
   *
   * @return a decimal representing this numeric value;
   */
  override def getDecimalValue = BigDecimal.valueOf(value)

  /**
   * Negate the value
   *
   * @return the result of inverting the sign of the value
   */
  override def negate = if (value == Long.MIN_VALUE) BigIntegerValue.makeIntegerValue(BigInteger.valueOf(value)).negate
  else new Int64Value(-value)

  /**
   * Implement the XPath floor() function
   *
   * @return the integer value, unchanged
   */
  override def floor = this

  /**
   * Implement the XPath ceiling() function
   *
   * @return the integer value, unchanged
   */
  override def ceiling = this

  /**
   * Implement the XPath round() function
   *
   * @param scale the scale (for example scale=2 rounds to 2 decimal places, scale=-2
   *              rounds to a multiple of 100); default value is zero which rounds to an integer
   * @return the integer value, unchanged
   */
  override def round(scale: Int): NumericValue = if (scale >= 0 || value == 0) this
  else {
    if (scale < -15) return new BigIntegerValue(value).round(scale)
    val absolute = Math.abs(value)
    var factor = 1
    for (i <- 1 to -scale) {
      factor *= 10
    }
    val modulus = absolute % factor
    var rval = absolute - modulus
    val d = modulus * 2
    if (value > 0) if (d >= factor) rval += factor
    else {
      if (d > factor) rval += factor
      rval = -rval
    }
    new Int64Value(rval)
  }

  /**
   * Implement the XPath round-to-half-even() function
   *
   * @param scale number of digits required after the decimal point; the
   *              value -2 (for example) means round to a multiple of 100
   * @return if the scale is &gt;=0, return this value unchanged. Otherwise
   *         round it to a multiple of 10**-scale
   */
  override def roundHalfToEven(scale: Int): NumericValue = if (scale >= 0) this
  else {
    if (scale < -15) return new BigIntegerValue(value).roundHalfToEven(scale)
    val absolute = Math.abs(value)
    var factor = 1
    for (i <- 1 to -scale) {
      factor *= 10
    }
    val modulus = absolute % factor
    var rval = absolute - modulus
    val d = modulus * 2
    if (d > factor) rval += factor
    else if (d < factor) {
      // no-op
    }
    else { // round to even
      if (rval % (2 * factor) == 0) {
      }
      else rval += factor
    }
    if (value < 0) rval = -rval
    new Int64Value(rval)
  }

  /**
   * Determine whether the value is negative, zero, or positive
   *
   * @return -1 if negative, 0 if zero, +1 if positive, NaN if NaN
   */
  override def signum: Int = {
    if (value > 0) return +1
    if (value == 0) return 0
    -1
  }

  /**
   * Get the absolute value as defined by the XPath abs() function
   *
   * @return the absolute value
   */
  override def abs = if (value > 0) this
  else if (value == Long.MIN_VALUE) new BigIntegerValue(new BigInteger("9223372036854775808"))
  else Int64Value.makeIntegerValue(-value)

  /**
   * Add another integer
   */
  override def plus(other: IntegerValue): IntegerValue = { // if either of the values is large, we use BigInteger arithmetic to be on the safe side
    if (other.isInstanceOf[Int64Value]) {
      val topa = (value >> 60) & 0xf
      if (topa != 0 && topa != 0xf) return new BigIntegerValue(value).plus(new BigIntegerValue(other.asInstanceOf[Int64Value].value))
      val topb = (other.asInstanceOf[Int64Value].value >> 60) & 0xf
      if (topb != 0 && topb != 0xf) return new BigIntegerValue(value).plus(new BigIntegerValue(other.asInstanceOf[Int64Value].value))
      Int64Value.makeIntegerValue(value + other.asInstanceOf[Int64Value].value)
    }
    else new BigIntegerValue(value).plus(other)
  }

  /**
   * Subtract another integer
   */
  override def minus(other: IntegerValue): IntegerValue = if (other.isInstanceOf[Int64Value]) {
    val topa = (value >> 60) & 0xf
    if (topa != 0 && topa != 0xf) return new BigIntegerValue(value).minus(new BigIntegerValue(other.asInstanceOf[Int64Value].value))
    val topb = (other.asInstanceOf[Int64Value].value >> 60) & 0xf
    if (topb != 0 && topb != 0xf) return new BigIntegerValue(value).minus(new BigIntegerValue(other.asInstanceOf[Int64Value].value))
    Int64Value.makeIntegerValue(value - other.asInstanceOf[Int64Value].value)
  }
  else new BigIntegerValue(value).minus(other)

  /**
   * Multiply by another integer
   */
  override def times(other: IntegerValue) = if (other.isInstanceOf[Int64Value]) if (isLong || other.asInstanceOf[Int64Value].isLong) new BigIntegerValue(value).times(new BigIntegerValue(other.asInstanceOf[Int64Value].value))
  else Int64Value.makeIntegerValue(value * other.asInstanceOf[Int64Value].value)
  else new BigIntegerValue(value).times(other)

  /**
   * Divide by another integer
   */
  @throws[XPathException]
  override def div(other: IntegerValue): NumericValue = if (other.isInstanceOf[Int64Value]) {
    val quotient = other.asInstanceOf[Int64Value].value
    if (quotient == 0) throw new XPathException("Integer division by zero", "FOAR0001")
    if (isLong || other.asInstanceOf[Int64Value].isLong) return new BigIntegerValue(value).div(new BigIntegerValue(quotient))
    // the result of dividing two integers is a decimal; but if
    // one divides exactly by the other, we implement it as an integer
    if (value % quotient == 0) Int64Value.makeIntegerValue(value / quotient)
    else Calculator.decimalDivide(new BigDecimalValue(value), new BigDecimalValue(quotient))
  }
  else new BigIntegerValue(value).div(other)

  /**
   * Take modulo another integer
   */
  @throws[XPathException]
  override def mod(other: IntegerValue) = if (other.isInstanceOf[Int64Value]) {
    val quotient = other.asInstanceOf[Int64Value].value
    if (quotient == 0) throw new XPathException("Integer modulo zero", "FOAR0001")
    if (isLong || other.asInstanceOf[Int64Value].isLong) new BigIntegerValue(value).mod(new BigIntegerValue(other.asInstanceOf[Int64Value].value))
    else Int64Value.makeIntegerValue(value % quotient)
  }
  else new BigIntegerValue(value).mod(other)

  /**
   * Integer divide by another integer
   */
  @throws[XPathException]
  override def idiv(other: IntegerValue): IntegerValue = if (other.isInstanceOf[Int64Value]) {
    if (isLong || other.asInstanceOf[Int64Value].isLong) return new BigIntegerValue(value).idiv(new BigIntegerValue(other.asInstanceOf[Int64Value].value))
    try Int64Value.makeIntegerValue(value / other.asInstanceOf[Int64Value].value)
    catch {
      case err: ArithmeticException =>
        var e = null
        if ("/ by zero" == err.getMessage) e = new XPathException("Integer division by zero", "FOAR0001")
        else e = new XPathException("Integer division failure", err)
        throw e
    }
  }
  else new BigIntegerValue(value).idiv(other)

  /**
   * Test whether this value needs a long to hold it. Specifically, whether
   *
   * the absolute value is > 2^31.
   * @return true if the value is too big to fit in a 32-bit int
   */
  private def isLong = {
    val top = value >> 31
    top != 0
  }

  /**
   * Get the value as a BigInteger
   */
  override def asBigInteger = BigInteger.valueOf(value)
}