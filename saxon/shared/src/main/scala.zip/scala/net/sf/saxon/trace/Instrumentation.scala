////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import java.util

/**
 * Internal class used for instrumentation purposes. It maintains a number of counters and displays these at the
 * end of the run. Currently implemented only for the Transform command line, with -t option set.
 */
object Instrumentation {
  val ACTIVE = true
  var counters = new util.HashMap[String, Integer]

  def count(counter: String) = if (counters.containsKey(counter)) counters.put(counter, counters.get(counter) + 1)
  else counters.put(counter, 1)

  def count(counter: String, increment: Int) = if (counters.containsKey(counter)) counters.put(counter, counters.get(counter) + increment)
  else counters.put(counter, increment)

  def report() = if (ACTIVE && !counters.isEmpty) {
    System.err.println("COUNTERS")
    import scala.collection.JavaConversions._
    for (c <- counters.entrySet) {
      System.err.println(c.getKey + " = " + c.getValue)
    }
  }

  def reset() = counters.clear()
}