////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.instruct.Block
import net.sf.saxon.expr.parser._
import net.sf.saxon.expr.sort.DocumentSorter
import net.sf.saxon.expr.sort.GlobalOrderComparer
import net.sf.saxon.functions.CurrentGroupCall
import net.sf.saxon.functions.SystemFunction
import net.sf.saxon.model._
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.pattern._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.SequenceType
import java.util

/**
 * An expression representing a nodeset that is a union, difference, or
 * intersection of two other NodeSets
 */
class VennExpression(val p1: Expression, val op: Int, val p2: Expression)

/**
 * Constructor
 *
 * @param p1 the left-hand operand
 * @param op the operator (union, intersection, or difference)
 * @param p2 the right-hand operand
 */
  extends BinaryExpression(p1, op, p2) {
  /**
   * Simplify an expression. This performs any static optimization (by rewriting the expression
   * as a different expression). The default implementation simplifies its operands.
   *
   * @return the simplified expression (or the original if unchanged, or if modified in-situ)
   * @throws net.sf.saxon.trans.XPathException if an error is discovered during expression
   *                                           rewriting
   */
  @throws[XPathException]
  override def simplify = { // Force both operands to be sorted in document order. If this turns out to be unnecessary, it will
    // get optimized away
    if (!getLhsExpression.isInstanceOf[DocumentSorter]) setLhsExpression(new DocumentSorter(getLhsExpression))
    if (!getRhsExpression.isInstanceOf[DocumentSorter]) setRhsExpression(new DocumentSorter(getRhsExpression))
    super.simplify
    this
  }

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = operator match {
    case Token.UNION =>
      "union"
    case Token.INTERSECT =>
      "intersect"
    case Token.EXCEPT =>
      "except"
    case _ =>
      "unknown"
  }

  /**
   * Determine the data type of the items returned by this expression
   *
   * @return the data type
   */
  /*@NotNull*/ override final def getItemType = {
    val t1 = getLhsExpression.getItemType
    if (operator == Token.UNION) {
      val t2 = getRhsExpression.getItemType
      val th = getConfiguration.getTypeHierarchy
      Type.getCommonSuperType(t1, t2, th)
    }
    else t1
  }

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType the static type of the context item
   */
  override def getStaticUType(contextItemType: UType) = operator match {
    case Token.UNION =>
      getLhsExpression.getStaticUType(contextItemType).union(getRhsExpression.getStaticUType(contextItemType))
    case Token.INTERSECT =>
      getLhsExpression.getStaticUType(contextItemType).intersection(getRhsExpression.getStaticUType(contextItemType))
    case Token.EXCEPT =>
    case _ =>
      getLhsExpression.getStaticUType(contextItemType)
  }

  /**
   * Determine the static cardinality of the expression
   */
  override final def computeCardinality: Int = {
    val c1 = getLhsExpression.getCardinality
    val c2 = getRhsExpression.getCardinality
    operator match {
      case Token.UNION =>
        if (Literal.isEmptySequence(getLhsExpression)) return c2
        if (Literal.isEmptySequence(getRhsExpression)) return c1
        return c1 | c2 | StaticProperty.ALLOWS_ONE | StaticProperty.ALLOWS_MANY
      // allows ZERO only if one operand allows ZERO
      case Token.INTERSECT =>
        if (Literal.isEmptySequence(getLhsExpression)) return StaticProperty.EMPTY
        if (Literal.isEmptySequence(getRhsExpression)) return StaticProperty.EMPTY
        return (c1 & c2) | StaticProperty.ALLOWS_ZERO | StaticProperty.ALLOWS_ONE
      // allows MANY only if both operands allow MANY
      case Token.EXCEPT =>
        if (Literal.isEmptySequence(getLhsExpression)) return StaticProperty.EMPTY
        if (Literal.isEmptySequence(getRhsExpression)) return c1
        return c1 | StaticProperty.ALLOWS_ZERO | StaticProperty.ALLOWS_ONE
      // allows MANY only if first operand allows MANY
    }
    StaticProperty.ALLOWS_ZERO_OR_MORE
  }

  /**
   * Get the static properties of this expression (other than its type). The result is
   * bit-signficant. These properties are used for optimizations. In general, if
   * property bit is set, it is true, but if it is unset, the value is unknown.
   */
  override def computeSpecialProperties = {
    val prop0 = getLhsExpression.getSpecialProperties
    val prop1 = getRhsExpression.getSpecialProperties
    var props = StaticProperty.ORDERED_NODESET
    if (testContextDocumentNodeSet(prop0, prop1)) props |= StaticProperty.CONTEXT_DOCUMENT_NODESET
    if (testSubTree(prop0, prop1)) props |= StaticProperty.SUBTREE_NODESET
    if (createsNoNewNodes(prop0, prop1)) props |= StaticProperty.NO_NODES_NEWLY_CREATED
    props
  }

  /**
   * Determine whether all the nodes in the node-set are guaranteed to
   * come from the same document as the context node. Used for optimization.
   *
   * @param prop0 contains the Context Document Nodeset property of the first operand
   * @param prop1 contains the Context Document Nodeset property of the second operand
   * @return true if all the nodes come from the context document
   */
  private def testContextDocumentNodeSet(prop0: Int, prop1: Int): Boolean = {
    operator match {
      case Token.UNION =>
        return (prop0 & prop1 & StaticProperty.CONTEXT_DOCUMENT_NODESET) ne 0
      case Token.INTERSECT =>
        return ((prop0 | prop1) & StaticProperty.CONTEXT_DOCUMENT_NODESET) ne 0
      case Token.EXCEPT =>
        return (prop0 & StaticProperty.CONTEXT_DOCUMENT_NODESET) ne 0
    }
    false
  }

  /**
   * Gather the component operands of a union or intersect expression
   *
   * @param operator union or intersect
   * @param set      the set into which the components are to be gathered. If the operator
   *                 is union, this follows the tree gathering all operands of union expressions. Ditto,
   *                 mutatis mutandis, for intersect expressions.
   */
  def gatherComponents(operator: Int, set: util.Set[Expression]) = {
    if (getLhsExpression.isInstanceOf[VennExpression] && getLhsExpression.asInstanceOf[VennExpression].operator == operator) getLhsExpression.asInstanceOf[VennExpression].gatherComponents(operator, set)
    else set.add(getLhsExpression)
    if (getRhsExpression.isInstanceOf[VennExpression] && getRhsExpression.asInstanceOf[VennExpression].operator == operator) getRhsExpression.asInstanceOf[VennExpression].gatherComponents(operator, set)
    else set.add(getRhsExpression)
  }

  /**
   * Determine whether all the nodes in the node-set are guaranteed to
   * come from a subtree rooted at the context node. Used for optimization.
   *
   * @param prop0 contains the SubTree property of the first operand
   * @param prop1 contains the SubTree property of the second operand
   * @return true if all the nodes come from the tree rooted at the context node
   */
  private def testSubTree(prop0: Int, prop1: Int): Boolean = {
    operator match {
      case Token.UNION =>
        return (prop0 & prop1 & StaticProperty.SUBTREE_NODESET) ne 0
      case Token.INTERSECT =>
        return ((prop0 | prop1) & StaticProperty.SUBTREE_NODESET) ne 0
      case Token.EXCEPT =>
        return (prop0 & StaticProperty.SUBTREE_NODESET) ne 0
    }
    false
  }

  /**
   * Determine whether the expression can create new nodes
   *
   * @param prop0 contains the noncreative property of the first operand
   * @param prop1 contains the noncreative property of the second operand
   * @return true if the expression can create new nodes
   */
  private def createsNoNewNodes(prop0: Int, prop1: Int) = ((prop0 & StaticProperty.NO_NODES_NEWLY_CREATED) ne 0) && ((prop1 & StaticProperty.NO_NODES_NEWLY_CREATED) ne 0)

  /**
   * Type-check the expression
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val tc = config.getTypeChecker(false)
    getLhs.typeCheck(visitor, contextInfo)
    getRhs.typeCheck(visitor, contextInfo)
    if (!getLhsExpression.isInstanceOf[Pattern]) {
      val role0 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 0)
      setLhsExpression(tc.staticTypeCheck(getLhsExpression, SequenceType.NODE_SEQUENCE, role0, visitor))
    }
    if (!getRhsExpression.isInstanceOf[Pattern]) {
      val role1 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, Token.tokens(operator), 1)
      setRhsExpression(tc.staticTypeCheck(getRhsExpression, SequenceType.NODE_SEQUENCE, role1, visitor))
    }
    // For the intersect and except operators, if the types are disjoint then we can simplify
    if (operator != Token.UNION) {
      val th = config.getTypeHierarchy
      val t0 = getLhsExpression.getItemType
      val t1 = getRhsExpression.getItemType
      if (th.relationship(t0, t1) eq Affinity.DISJOINT) if (operator == Token.INTERSECT) return Literal.makeEmptySequence
      else if (getLhsExpression.hasSpecialProperty(StaticProperty.ORDERED_NODESET)) return getLhsExpression
      else return new DocumentSorter(getLhsExpression)
    }
    this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws net.sf.saxon.trans.XPathException
   * if an error is discovered during this phase
   * (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    val e = super.optimize(visitor, contextItemType)
    if (e ne this) return e
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    // If either operand is an empty sequence, simplify the expression. This can happen
    // after reduction with constructs of the form //a[condition] | //b[not(condition)],
    // common in XPath 1.0 because there were no conditional expressions.
    val lhs = getLhsExpression
    val rhs = getRhsExpression
    operator match {
      case Token.UNION =>
        if (Literal.isEmptySequence(lhs) && ((rhs.getSpecialProperties & StaticProperty.ORDERED_NODESET) ne 0)) return rhs
        if (Literal.isEmptySequence(rhs) && ((lhs.getSpecialProperties & StaticProperty.ORDERED_NODESET) ne 0)) return lhs
        if (lhs.isInstanceOf[CurrentGroupCall] && rhs.isInstanceOf[ContextItemExpression]) return lhs
      case Token.INTERSECT =>
        if (Literal.isEmptySequence(lhs)) return lhs
        if (Literal.isEmptySequence(rhs)) return rhs
        if (lhs.isInstanceOf[CurrentGroupCall] && rhs.isInstanceOf[ContextItemExpression]) return rhs
      case Token.EXCEPT =>
        if (Literal.isEmptySequence(lhs)) return lhs
        if (Literal.isEmptySequence(rhs) && ((lhs.getSpecialProperties & StaticProperty.ORDERED_NODESET) ne 0)) return lhs
        if (lhs.isInstanceOf[CurrentGroupCall] && rhs.isInstanceOf[ContextItemExpression]) { // Test case si-group-055.
          // The streaming code has problems with (current-group() except .) so we
          // optimize it away. This is a bit of a hack, because the difficulty may
          // affect other expressions as well. The problem arises because part of the
          // pattern needs to be evaluated with each node in the group as anchor node,
          // and part with only the first node in the group as anchor node.
          return new TailExpression(lhs, 2)
        }
    }
    // If both are axis expressions on the same axis, merge them
    // ie. rewrite (axis::test1 | axis::test2) as axis::(test1 | test2)
    if (lhs.isInstanceOf[AxisExpression] && rhs.isInstanceOf[AxisExpression]) {
      val a1 = lhs.asInstanceOf[AxisExpression]
      val a2 = rhs.asInstanceOf[AxisExpression]
      if (a1.getAxis == a2.getAxis) if (a1.getNodeTest == a2.getNodeTest) return if (operator == Token.EXCEPT) Literal.makeEmptySequence
      else a1
      else {
        val ax = new AxisExpression(a1.getAxis, new CombinedNodeTest(a1.getNodeTest, operator, a2.getNodeTest))
        ExpressionTool.copyLocationInfo(this, ax)
        return ax
      }
    }
    // If both are path expressions starting the same way, merge them
    // i.e. rewrite (/X | /Y) as /(X|Y). This applies recursively, so that
    // /A/B/C | /A/B/D becomes /A/B/child::(C|D)
    // This optimization was previously done for all three operators. However, it's not safe for "except":
    // A//B except A//C//B cannot be rewritten as A/descendant-or-self::node()/(B except C//B). As a quick
    // fix, the optimization has been retained for "union" but dropped for "intersect" and "except". Need to
    // do a more rigorous analysis of the conditions under which it is safe.
    // TODO: generalize this code to handle all distributive operators
    if (lhs.isInstanceOf[SlashExpression] && rhs.isInstanceOf[SlashExpression] && operator == Token.UNION) {
      val path1 = lhs.asInstanceOf[SlashExpression]
      val path2 = rhs.asInstanceOf[SlashExpression]
      if (path1.getFirstStep.isEqual(path2.getFirstStep)) {
        val venn = new VennExpression(path1.getRemainingSteps, operator, path2.getRemainingSteps)
        ExpressionTool.copyLocationInfo(this, venn)
        val path = ExpressionTool.makePathExpression(path1.getFirstStep, venn)
        ExpressionTool.copyLocationInfo(this, path)
        return path.optimize(visitor, contextItemType)
      }
    }
    // Try merging two non-positional filter expressions:
    // A[exp0] | A[exp1] becomes A[exp0 or exp1]
    if (lhs.isInstanceOf[FilterExpression] && rhs.isInstanceOf[FilterExpression]) {
      val exp0 = lhs.asInstanceOf[FilterExpression]
      val exp1 = rhs.asInstanceOf[FilterExpression]
      if (!exp0.isPositional(th) && !exp1.isPositional(th) && exp0.getSelectExpression.isEqual(exp1.getSelectExpression)) {
        var filter = null
        operator match {
          case Token.UNION =>
            filter = new OrExpression(exp0.getFilter, exp1.getFilter)
          case Token.INTERSECT =>
            filter = new AndExpression(exp0.getFilter, exp1.getFilter)
          case Token.EXCEPT =>
            val negate2 = SystemFunction.makeCall("not", getRetainedStaticContext, exp1.getFilter)
            filter = new AndExpression(exp0.getFilter, negate2)
          case _ =>
            throw new AssertionError("Unknown operator " + operator)
        }
        ExpressionTool.copyLocationInfo(this, filter)
        val f = new FilterExpression(exp0.getSelectExpression, filter)
        ExpressionTool.copyLocationInfo(this, f)
        return f.simplify.typeCheck(visitor, contextItemType).optimize(visitor, contextItemType)
      }
    }
    // Convert @*|node() into @*,node() to eliminate the sorted merge operation
    // Avoid doing this when streaming because xsl:value-of select="@*,node()" is not currently streamable
    if (!visitor.isOptimizeForStreaming && operator == Token.UNION && lhs.isInstanceOf[AxisExpression] && rhs.isInstanceOf[AxisExpression]) {
      val a0 = lhs.asInstanceOf[AxisExpression]
      val a1 = rhs.asInstanceOf[AxisExpression]
      if (a0.getAxis == AxisInfo.ATTRIBUTE && a1.getAxis == AxisInfo.CHILD) return new Block(Array[Expression](lhs, rhs))
      else if (a1.getAxis == AxisInfo.ATTRIBUTE && a0.getAxis == AxisInfo.CHILD) return new Block(Array[Expression](rhs, lhs))
    }
    // Convert (A intersect B) to use a serial search where one operand is a singleton
    if (operator == Token.INTERSECT && !Cardinality.allowsMany(lhs.getCardinality)) return new SingletonIntersectExpression(lhs, operator, rhs.unordered(false, false))
    if (operator == Token.INTERSECT && !Cardinality.allowsMany(rhs.getCardinality)) return new SingletonIntersectExpression(rhs, operator, lhs.unordered(false, false))
    // If the types of the operands are disjoint, simplify "intersect" and "except"
    if (operandsAreDisjoint(th)) if (operator == Token.INTERSECT) return Literal.makeEmptySequence
    else if (operator == Token.EXCEPT) if ((lhs.getSpecialProperties & StaticProperty.ORDERED_NODESET) ne 0) return lhs
    else return new DocumentSorter(lhs)
    this
  }

  private def operandsAreDisjoint(th: TypeHierarchy) = th.relationship(getLhsExpression.getItemType, getRhsExpression.getItemType) eq Affinity.DISJOINT

  /**
   * Replace this expression by an expression that returns the same result but without
   * regard to order
   *
   * @param retainAllNodes true if all nodes in the result must be retained; false
   *                       if duplicates can be eliminated
   * @param forStreaming   set to true if optimizing for streaming
   */
  override def unordered(retainAllNodes: Boolean, forStreaming: Boolean): Expression = {
    if (operator == Token.UNION && !forStreaming && operandsAreDisjoint(getConfiguration.getTypeHierarchy)) { // replace union operator by comma operator to avoid cost of sorting into document order. See XMark q7
      val block = new Block(Array[Expression](getLhsExpression, getRhsExpression))
      ExpressionTool.copyLocationInfo(this, block)
      return block
    }
    this
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings variables that need to be rebound
   */
  override def copy(rebindings: RebindingMap) = {
    val exp = new VennExpression(getLhsExpression.copy(rebindings), operator, getRhsExpression.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, exp)
    exp
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Get the operand role (applies to both operands)
   *
   * @return the operand role
   * @param arg which argument: 0 for the lhs, 1 for the rhs
   */
  override protected def getOperandRole(arg: Int) = OperandRole.SAME_FOCUS_ACTION

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any): Boolean = { // NOTE: it's possible that the method in the superclass is already adequate for this
    if (other.isInstanceOf[VennExpression]) {
      val b = other.asInstanceOf[VennExpression]
      if (operator != b.operator) return false
      if (getLhsExpression.isEqual(b.getLhsExpression) && getRhsExpression.isEqual(b.getRhsExpression)) return true
      if (operator == Token.UNION || operator == Token.INTERSECT) { // These are commutative and associative, so for example (A|B)|C equals B|(A|C)
        val s0 = new util.HashSet[Expression](10)
        gatherComponents(operator, s0)
        val s1 = new util.HashSet[Expression](10)
        other.asInstanceOf[VennExpression].gatherComponents(operator, s1)
        return s0 == s1
      }
    }
    false
  }

  override def computeHashCode = getLhsExpression.hashCode ^ getRhsExpression.hashCode

  /**
   * Convert this expression to an equivalent XSLT pattern
   *
   * @param config the Saxon configuration
   * @return the equivalent pattern
   * @throws net.sf.saxon.trans.XPathException
   * if conversion is not possible
   */
  @throws[XPathException]
  override def toPattern(config: Configuration) = {
    if (isPredicatePattern(getLhsExpression) || isPredicatePattern(getRhsExpression)) throw new XPathException("Cannot use a predicate pattern as an operand of a union, intersect, or except operator", "XTSE0340")
    if (operator == Token.UNION) new UnionPattern(getLhsExpression.toPattern(config), getRhsExpression.toPattern(config))
    else if (operator == Token.EXCEPT) new ExceptPattern(getLhsExpression.toPattern(config), getRhsExpression.toPattern(config))
    else new IntersectPattern(getLhsExpression.toPattern(config), getRhsExpression.toPattern(config))
  }

  private def isPredicatePattern(exp: Expression) = {
    if (exp.isInstanceOf[ItemChecker]) exp = exp.asInstanceOf[ItemChecker].getBaseExpression
    exp.isInstanceOf[FilterExpression] && (exp.asInstanceOf[FilterExpression]).getSelectExpression.isInstanceOf[ContextItemExpression]
  }

  /**
   * Get the element name used to identify this expression in exported expression format
   *
   * @return the element name used to identify this expression
   */
  override protected def tag: String = {
    if (operator == Token.UNION) return "union"
    Token.tokens(operator)
  }

  /**
   * Iterate over the value of the expression. The result will always be sorted in document order,
   * with duplicates eliminated
   *
   * @param c The context for evaluation
   * @return a SequenceIterator representing the union of the two operands
   */
  @throws[XPathException]
  override def iterate(c: XPathContext): SequenceIterator = {
    val i1 = getLhsExpression.iterate(c)
    val i2 = getRhsExpression.iterate(c)
    operator match {
      case Token.UNION =>
        return new UnionEnumeration(i1, i2, GlobalOrderComparer.getInstance)
      case Token.INTERSECT =>
        return new IntersectionEnumeration(i1, i2, GlobalOrderComparer.getInstance)
      case Token.EXCEPT =>
        return new DifferenceEnumeration(i1, i2, GlobalOrderComparer.getInstance)
    }
    throw new UnsupportedOperationException("Unknown operator in Venn Expression")
  }

  /**
   * Get the effective boolean value. In the case of a union expression, this
   * is reduced to an OR expression, for efficiency
   */
  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext) = if (operator == Token.UNION) { // NOTE: this optimization was probably already done statically
    getLhsExpression.effectiveBooleanValue(context) || getRhsExpression.effectiveBooleanValue(context)
  }
  else super.effectiveBooleanValue(context)

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "VennExpression"
}