////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import java.io.IOException
import java.io.OutputStream
import java.io.Writer

/**
 * Specialized buffering UTF-8 writer.
 * The main reason for custom version is to allow for efficient
 * buffer recycling; the second benefit is that encoder has less
 * overhead for short content encoding (compared to JDK default
 * codecs).
 *
 * @author Tatu Saloranta
 */
object UTF8Writer {
  private val MIN_BUF_LEN = 32
  private val DEFAULT_BUF_LEN = 4000
  private[serialize] val SURR1_FIRST = 0xD800
  private[serialize] val SURR1_LAST = 0xDBFF
  private[serialize] val SURR2_FIRST = 0xDC00
  private[serialize] val SURR2_LAST = 0xDFFF
}

final class UTF8Writer(/*@Nullable*/ var _out: OutputStream, val bufferLength: Int) extends Writer {
  if (bufferLength < UTF8Writer.MIN_BUF_LEN) bufferLength = UTF8Writer.MIN_BUF_LEN
  _outBuffer = new Array[Byte](bufferLength)
  /* Max. expansion for a single Unicode code point is 4 bytes when
           * recombining UCS-2 surrogate pairs, so:
           */ _outBufferLast = bufferLength - 4
  _outPtr = 0
  protected var _outBuffer = null
  final protected var _outBufferLast = 0
  protected var _outPtr = 0
  /**
   * When outputting chars from BMP, surrogate pairs need to be coalesced.
   * To do this, both pairs must be known first; and since it is possible
   * pairs may be split, we need temporary storage for the first half
   */
  private[serialize] var _surrogate = 0

  def this(out: OutputStream) {
    this(out, UTF8Writer.DEFAULT_BUF_LEN)
  }

  @throws[IOException]
  override def close() = if (_out != null) {
    _flushBuffer()
    _outBuffer = null
    _out.close()
    _out = null
    /* If we are left with partial surrogate we have a problem, but
                 * let's not let it prevent closure of the underlying stream
                 */ if (_surrogate != 0) {
      val code = _surrogate
      // but let's clear it, to get just one problem?
      _surrogate = 0
      throwIllegal(code)
    }
  }

  @throws[IOException]
  override def flush() = {
    _flushBuffer()
    _out.flush()
  }

  @throws[IOException]
  override def write(cbuf: Array[Char]) = write(cbuf, 0, cbuf.length)

  @throws[IOException]
  override def write(cbuf: Array[Char], off: Int, len: Int): Unit = {
    if (len < 2) {
      if (len == 1) write(cbuf(off))
      return
    }
    // First: do we have a leftover surrogate to deal with?
    if (_surrogate > 0) {
      val second = cbuf({
        off += 1; off - 1
      })
      len -= 1
      write(_convertSurrogate(second))
      // will have at least one more char
    }
    var outPtr = _outPtr
    val outBuf = _outBuffer
    val outBufLast = _outBufferLast // has 4 'spare' bytes
    // All right; can just loop it nice and easy now:
    len += off // len will now be the end of input buffer
    output_loop //todo: labels are not supported
    while ( {
      off < len
    }) {
      /* First, let's ensure we can output at least 4 bytes
                  * (longest UTF-8 encoded codepoint):
                  */ if (outPtr >= outBufLast) {
        _out.write(outBuf, 0, outPtr)
        outPtr = 0
      }
      var c = cbuf({
        off += 1; off - 1
      })
      // And then see if we have an Ascii char:
      if (c < 0x80) { // If so, can do a tight inner loop:
        outBuf({
          outPtr += 1; outPtr - 1
        }) = c.toByte
        // Let's calc how many ascii chars we can copy at most:
        var maxInCount = len - off
        val maxOutCount = outBufLast - outPtr
        if (maxInCount > maxOutCount) maxInCount = maxOutCount
        maxInCount += off
        ascii_loop //todo: labels are not supported
        while ( {
          true
        }) {
          if (off >= maxInCount) { // done with max. ascii seq
            continue output_loop //todo: continue is not supported
          }
          c = cbuf({
            off += 1; off - 1
          })
          if (c >= 0x80) break ascii_loop // todo: label break is not supported
            outBuf({
              outPtr += 1; outPtr - 1
            }) = c.toByte
        }
      }
      // Nope, multi-byte:
      if (c < 0x800) { // 2-byte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0xc0 | (c >> 6)).toByte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0x80 | (c & 0x3f)).toByte
      }
      else { // 3 or 4 bytes
        // Surrogates?
        if (c < UTF8Writer.SURR1_FIRST || c > UTF8Writer.SURR2_LAST) {
          outBuf({
            outPtr += 1; outPtr - 1
          }) = (0xe0 | (c >> 12)).toByte
          outBuf({
            outPtr += 1; outPtr - 1
          }) = (0x80 | ((c >> 6) & 0x3f)).toByte
          outBuf({
            outPtr += 1; outPtr - 1
          }) = (0x80 | (c & 0x3f)).toByte
          continue //todo: continue is not supported
        }
        // Yup, a surrogate:
        if (c > UTF8Writer.SURR1_LAST) { // must be from first range
          _outPtr = outPtr
          throwIllegal(c)
        }
        _surrogate = c
        // and if so, followed by another from next range
        if (off >= len) { // unless we hit the end?
          break //todo: break is not supported
        }
        c = _convertSurrogate(cbuf({
          off += 1; off - 1
        }))
        if (c > 0x10FFFF) { // illegal, as per RFC 3629
          _outPtr = outPtr
          throwIllegal(c)
        }
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0xf0 | (c >> 18)).toByte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0x80 | ((c >> 12) & 0x3f)).toByte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0x80 | ((c >> 6) & 0x3f)).toByte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0x80 | (c & 0x3f)).toByte
      }
    }
    _outPtr = outPtr
  }

  @throws[IOException]
  override def write(c: Int): Unit = { // First; do we have a left over surrogate?
    if (_surrogate > 0) {
      c = _convertSurrogate(c)
      // If not, do we start with a surrogate?
    }
    else if (c >= UTF8Writer.SURR1_FIRST && c <= UTF8Writer.SURR2_LAST) { // Illegal to get second part without first:
      if (c > UTF8Writer.SURR1_LAST) throwIllegal(c)
      // First part just needs to be held for now
      _surrogate = c
      return
    }
    if (_outPtr >= _outBufferLast) { // let's require enough room, first
      _flushBuffer()
    }
    if (c < 0x80) { // ascii
      _outBuffer({
        _outPtr += 1; _outPtr - 1
      }) = c.toByte
    }
    else {
      var ptr = _outPtr
      if (c < 0x800) {
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0xc0 | (c >> 6)).toByte
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0x80 | (c & 0x3f)).toByte
      }
      else if (c <= 0xFFFF) { // 3 bytes
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0xe0 | (c >> 12)).toByte
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0x80 | ((c >> 6) & 0x3f)).toByte
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0x80 | (c & 0x3f)).toByte
      }
      else { // 4 bytes
        if (c > 0x10FFFF) throwIllegal(c)
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0xf0 | (c >> 18)).toByte
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0x80 | ((c >> 12) & 0x3f)).toByte
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0x80 | ((c >> 6) & 0x3f)).toByte
        _outBuffer({
          ptr += 1; ptr - 1
        }) = (0x80 | (c & 0x3f)).toByte
      }
      _outPtr = ptr
    }
  }

  @throws[IOException]
  override def write(str: String) = write(str, 0, str.length)

  @throws[IOException]
  override def write(str: String, off: Int, len: Int): Unit = {
    if (len < 2) {
      if (len == 1) write(str.charAt(off))
      return
    }
    if (_surrogate > 0) {
      val second = str.charAt({
        off += 1; off - 1
      })
      len -= 1
      write(_convertSurrogate(second))
      // will have at least one more char (case of 1 char was checked earlier on)
    }
    var outPtr = _outPtr
    val outBuf = _outBuffer
    val outBufLast = _outBufferLast
    len += off
    output_loop //todo: labels are not supported
    while ( {
      off < len
    }) { // First, let's ensure we can output at least 4 bytes
      // (longest UTF-8 encoded codepoint):
      if (outPtr >= outBufLast) {
        _out.write(outBuf, 0, outPtr)
        outPtr = 0
      }
      var c = str.charAt({
        off += 1; off - 1
      })
      if (c < 0x80) {
        outBuf({
          outPtr += 1; outPtr - 1
        }) = c.toByte
        var maxInCount = len - off
        val maxOutCount = outBufLast - outPtr
        if (maxInCount > maxOutCount) maxInCount = maxOutCount
        maxInCount += off
        ascii_loop //todo: labels are not supported
        while ( {
          true
        }) {
          if (off >= maxInCount) continue output_loop //todo: continue is not supported
            c = str.charAt({
            off += 1; off - 1
          })
          if (c >= 0x80) break ascii_loop // todo: label break is not supported
            outBuf({
              outPtr += 1; outPtr - 1
            }) = c.toByte
        }
      }
      if (c < 0x800) {
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0xc0 | (c >> 6)).toByte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0x80 | (c & 0x3f)).toByte
      }
      else {
        if (c < UTF8Writer.SURR1_FIRST || c > UTF8Writer.SURR2_LAST) {
          outBuf({
            outPtr += 1; outPtr - 1
          }) = (0xe0 | (c >> 12)).toByte
          outBuf({
            outPtr += 1; outPtr - 1
          }) = (0x80 | ((c >> 6) & 0x3f)).toByte
          outBuf({
            outPtr += 1; outPtr - 1
          }) = (0x80 | (c & 0x3f)).toByte
          continue //todo: continue is not supported
        }
        if (c > UTF8Writer.SURR1_LAST) {
          _outPtr = outPtr
          throwIllegal(c)
        }
        _surrogate = c
        if (off >= len) break //todo: break is not supported
        c = _convertSurrogate(str.charAt({
          off += 1; off - 1
        }))
        if (c > 0x10FFFF) {
          _outPtr = outPtr
          throwIllegal(c)
        }
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0xf0 | (c >> 18)).toByte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0x80 | ((c >> 12) & 0x3f)).toByte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0x80 | ((c >> 6) & 0x3f)).toByte
        outBuf({
          outPtr += 1; outPtr - 1
        }) = (0x80 | (c & 0x3f)).toByte
      }
    }
    _outPtr = outPtr
  }

  @throws[IOException]
  private def _flushBuffer() = if (_outPtr > 0 && _outBuffer != null) {
    _out.write(_outBuffer, 0, _outPtr)
    _outPtr = 0
  }

  /**
   * Method called to calculate UTF codepoint, from a surrogate pair.
   */
  @throws[IOException]
  final private def _convertSurrogate(secondPart: Int) = {
    val firstPart = _surrogate
    _surrogate = 0
    // Ok, then, is the second part valid?
    if (secondPart < UTF8Writer.SURR2_FIRST || secondPart > UTF8Writer.SURR2_LAST) throw new IOException("Broken surrogate pair: first char 0x" + Integer.toHexString(firstPart) + ", second 0x" + Integer.toHexString(secondPart) + "; illegal combination")
    0x10000 + ((firstPart - UTF8Writer.SURR1_FIRST) << 10) + (secondPart - UTF8Writer.SURR2_FIRST)
  }

  @throws[IOException]
  private def throwIllegal(code: Int) = {
    if (code > 0x10FFFF) { // over max?
      throw new IOException("Illegal character point (0x" + Integer.toHexString(code) + ") to output; max is 0x10FFFF as per RFC 3629")
    }
    if (code >= UTF8Writer.SURR1_FIRST) {
      if (code <= UTF8Writer.SURR1_LAST) { // Unmatched first part (closing without second part?)
        throw new IOException("Unmatched first part of surrogate pair (0x" + Integer.toHexString(code) + ")")
      }
      throw new IOException("Unmatched second part of surrogate pair (0x" + Integer.toHexString(code) + ")")
    }
    // should we ever get this?
    throw new IOException("Illegal character point (0x" + Integer.toHexString(code) + ") to output")
  }
}