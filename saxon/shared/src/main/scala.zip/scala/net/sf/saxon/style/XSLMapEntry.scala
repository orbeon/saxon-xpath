////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.SequenceInstr
import net.sf.saxon.lib.Feature
import net.sf.saxon.ma.map.MapFunctionSet
import net.sf.saxon.ma.map.MapType
import net.sf.saxon.model.ItemType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * Handler for xsl:map-entry instructions in an XSLT 3.0 stylesheet. <br>
 */
class XSLMapEntry extends StyleElement {
  private[style] var key = null
  private[style] var select = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine the type of item returned by this instruction (only relevant if
   * it is an instruction).
   *
   * @return the item type returned
   */
  protected def getReturnedItemType = MapType.ANY_MAP_TYPE

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  override def prepareAttributes() = {
    var keyAtt = null
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      if (f == "key") {
        keyAtt = value
        key = makeExpression(keyAtt, att)
      }
      else if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else checkUnknownAttribute(attName)
    }
    if (keyAtt == null) reportAbsence("key")
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration): Unit = {
    key = typeCheck("key", key)
    select = typeCheck("select", select)
    if (select != null) {
      import scala.collection.JavaConversions._
      for (kid <- children) {
        if (!kid.isInstanceOf[XSLFallback]) {
          compileError("An xsl:map-entry element with a select attribute must be empty", "XTSE3280")
          return
        }
      }
    }
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    if (select == null) {
      select = compileSequenceConstructor(exec, decl, false)
      select = select.simplify
    }
    var exp = MapFunctionSet.getInstance.makeFunction("entry", 2).makeFunctionCall(key, select)
    if (getConfiguration.getBooleanProperty(Feature.STRICT_STREAMABILITY)) exp = new SequenceInstr(exp)
    exp
  }
}