////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.Controller
import net.sf.saxon.expr.instruct.ParameterSet
import net.sf.saxon.expr.sort.GroupIterator
import net.sf.saxon.lib.ErrorReporter
import net.sf.saxon.om._
import net.sf.saxon.regex.RegexIterator
import net.sf.saxon.trans.NoDynamicContextException
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.rules.Rule
import net.sf.saxon.value.CalendarValue
import net.sf.saxon.value.DateTimeValue
import javax.xml.transform.URIResolver
import java.util.Collections
import java.util

/**
 * This class is an implementation of XPathContext used when evaluating constant sub-expressions at
 * compile time.
 */
class EarlyEvaluationContext(var config: Configuration)

/**
 * Create an early evaluation context, used for evaluating constant expressions at compile time
 *
 * @param config the Saxon configuration
 *               //@param map    the available collations
 */
  extends XPathContext {
  /**
   * Get the value of a local variable, identified by its slot number
   */
  /*@Nullable*/ override def evaluateLocalVariable(slotnumber: Int) = {
    notAllowed()
    null
  }

  /**
   * Get the calling XPathContext (the next one down the stack). This will be null if unknown, or
   * if the bottom of the stack has been reached.
   */
  override def getCaller = null

  /**
   * Get the URI resolver. This gets the local URIResolver set in the XPathContext if there
   * is one; if not, it gets the URIResolver from the Controller (which itself defaults to the
   * one set in the Configuration).
   *
   * @return the user-supplied URI resolver if there is one, or null otherwise.
   * @since 9.6
   */
  override def getURIResolver = config.getURIResolver

  /**
   * Get the error listener. If no ErrorListener
   * has been set locally, the ErrorListener in the Controller is returned; this in turn defaults
   * to the ErrorListener set in the Configuration.
   *
   * @return the ErrorListener in use. This will always be an UnfailingErrorListener,
   *         which is a Saxon subclass of ErrorListener that throws no exceptions.
   * @since 9.6
   */
  override def getErrorReporter = config.makeErrorReporter

  /**
   * Get the current component
   */
  override def getCurrentComponent = {
    notAllowed()
    null
  }

  /**
   * Get the Configuration
   */
  override def getConfiguration = config

  /**
   * Get the context item
   *
   * @return the context item, or null if the context item is undefined
   */
  override def getContextItem = null

  /**
   * Get the Controller. May return null when running outside XSLT or XQuery
   */
  override def getController = null

  /**
   * Get the current group iterator. This supports the current-group() and
   * current-grouping-key() functions in XSLT 2.0
   *
   * @return the current grouped collection
   */
  override def getCurrentGroupIterator = {
    notAllowed()
    null
  }

  /**
   * Get the current merge group iterator. This supports the current-merge-group() and
   * current-merge-key() functions in XSLT 3.0
   *
   * @return the current grouped collection
   */
  override def getCurrentMergeGroupIterator = {
    notAllowed()
    null
  }

  /**
   * Get the current iterator.
   * This encapsulates the context item, context position, and context size.
   *
   * @return the current iterator, or null if there is no current iterator
   *         (which means the context item, position, and size are undefined).
   */
  override def getCurrentIterator = null

  /**
   * Get the current mode.
   *
   * @return the current mode
   */
  override def getCurrentMode = {
    notAllowed()
    null
  }

  /**
   * Get the current regex iterator. This supports the functionality of the regex-group()
   * function in XSLT 2.0.
   *
   * @return the current regular expressions iterator
   */
  override def getCurrentRegexIterator = null

  /**
   * Get the current template. This is used to support xsl:apply-imports
   *
   * @return the current template
   */
  override def getCurrentTemplateRule = null

  /**
   * Get the context size (the position of the last item in the current node list)
   *
   * @return the context size
   * @throws net.sf.saxon.trans.XPathException
   * if the context position is undefined
   */
  @throws[XPathException]
  override def getLast = {
    val err = new XPathException("The context item is absent")
    err.setErrorCode("XPDY0002")
    throw err
  }

  /**
   * Get the local (non-tunnel) parameters that were passed to the current function or template
   *
   * @return a ParameterSet containing the local parameters
   */
  override def getLocalParameters = {
    notAllowed()
    null
  }

  /**
   * Get the Name Pool
   */
  override def getNamePool = config.getNamePool

  /**
   * Get a reference to the local stack frame for variables. Note that it's
   * the caller's job to make a local copy of this. This is used for creating
   * a Closure containing a retained copy of the variables for delayed evaluation.
   *
   * @return array of variables.
   */
  override def getStackFrame = {
    notAllowed()
    null
  }

  /**
   * Get the tunnel parameters that were passed to the current function or template. This includes all
   * active tunnel parameters whether the current template uses them or not.
   *
   * @return a ParameterSet containing the tunnel parameters
   */
  override def getTunnelParameters = {
    notAllowed()
    null
  }

  /**
   * Determine whether the context position is the same as the context size
   * that is, whether position()=last()
   */
  @throws[XPathException]
  override def isAtLast = {
    val err = new XPathException("The context item is absent")
    err.setErrorCode("XPDY0002")
    throw err
  }

  /**
   * Construct a new context without copying (used for the context in a function call)
   */
  override def newCleanContext = {
    notAllowed()
    null
  }

  /**
   * Construct a new context as a copy of another. The new context is effectively added
   * to the top of a stack, and contains a pointer to the previous context
   */
  override def newContext = {
    val controller = new Controller(config)
    controller.newXPathContext
  }

  /**
   * Construct a new minor context. A minor context can only hold new values of the focus
   * (currentIterator) and current output destination.
   */
  override def newMinorContext = newContext.newMinorContext

  /**
   * Set the calling XPathContext
   */
  override def setCaller(caller: XPathContext) = {
    // no-op
  }

  /**
   * Set a new sequence iterator.
   */
  override def setCurrentIterator(iter: FocusIterator) = notAllowed()

  override def trackFocus(iter: SequenceIterator) = {
    notAllowed()
    null
  }

  /**
   * Set the value of a local variable, identified by its slot number
   */
  override def setLocalVariable(slotNumber: Int, value: Sequence) = notAllowed()

  /**
   * Use local parameter. This is called when a local xsl:param element is processed.
   * If a parameter of the relevant name was supplied, it is bound to the xsl:param element.
   * Otherwise the method returns false, so the xsl:param default will be evaluated
   *
   * @param parameterId Globally-unique parameter identifier
   * @param slotNumber  Slot number of the parameter within the stack frame of the called template
   * @param isTunnel    True if a tunnel parameter is required, else false  @return true if a parameter of this name was supplied, false if not
   */
  override def useLocalParameter(parameterId: StructuredQName, slotNumber: Int, isTunnel: Boolean) = ParameterSet.NOT_SUPPLIED

  /**
   * Get the current date and time. This implementation always throws a
   * NoDynamicContextException.
   *
   * @return the current date and time. All calls within a single query or transformation
   *         will return the same value
   */
  @throws[NoDynamicContextException]
  override def getCurrentDateTime = throw new NoDynamicContextException("current-dateTime")

  /**
   * Get the implicit timezone, as a positive or negative offset from UTC in minutes.
   * The range is -14hours to +14hours. This implementation returns {@link CalendarValue#NO_TIMEZONE},
   * meaning the value is unknown.
   *
   * @return the implicit timezone, as an offset from UTC in minutes
   */
  override def getImplicitTimezone = CalendarValue.MISSING_TIMEZONE

  /**
   * Get the context stack. This method returns an iterator whose items are instances of
   * {@link net.sf.saxon.trace.ContextStackFrame}, starting with the top-most stackframe and
   * ending at the point the query or transformation was invoked by a calling application.
   *
   * @return an iterator over a copy of the run-time call stack
   */
  override def iterateStackFrames = Collections.EMPTY_LIST.iterator

  /**
   * Get the current exception (in saxon:catch)
   *
   * @return the current exception, or null if there is none defined
   */
  override def getCurrentException = null

  @throws[XPathException]
  override def waitForChildThreads() = getCaller.waitForChildThreads()

  override def setTemporaryOutputState(temporary: Int) = {
    // no action
  }

  /**
   * Ask whether the XSLT output state is "temporary" or "final"
   *
   * @return non-zero in temporary output state; zero in final output state
   */
  override def getTemporaryOutputState = 0

  /**
   * Set the current output URI
   *
   * @param uri the current output URI, or null if in temporary output state
   */
  override def setCurrentOutputUri(uri: String) = {
  }

  /**
   * Get the current output URI
   *
   * @return the current output URI, or null if in temporary output state
   */
  override def getCurrentOutputUri = null

  /**
   * Throw an error for operations that aren't supported when doing early evaluation of constant
   * subexpressions
   */
  private def notAllowed() = throw new UnsupportedOperationException(new NoDynamicContextException("Internal error: early evaluation of subexpression with no context"))

  /**
   * Get the thread manager used to process asynchronous xsl:result-document threads.
   *
   * @return the current thread manager; or null if multithreading is not supported
   */
  override def getThreadManager = null

  override def getTargetComponent(bindingSlot: Int) = null
}