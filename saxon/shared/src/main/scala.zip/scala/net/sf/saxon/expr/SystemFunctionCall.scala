////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.event.Outputter
import net.sf.saxon.expr.instruct.AnalyzeString
import net.sf.saxon.expr.oper.OperandArray
import net.sf.saxon.expr.parser._
import net.sf.saxon.functions.Error
import net.sf.saxon.functions._
import net.sf.saxon.functions.registry.BuiltInFunctionSet
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.ma.map.MapFunctionSet
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.om.Function
import net.sf.saxon.om.Sequence
import net.sf.saxon.pattern.NodeSetPattern
import net.sf.saxon.pattern.Pattern
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.IntegerValue
import java.util

/**
 * A call to a system-defined function (specifically, a function implemented as an instance
 * of {@link net.sf.saxon.functions.SystemFunction})
 */
object SystemFunctionCall {

  /**
   * Subclass representing a system function call that has been optimized; this overrides the
   * optimize() method to do nothing, thus ensuring that optimization converges.
   */
  abstract class Optimized(val target: SystemFunction, val arguments: Array[Expression]) extends SystemFunctionCall(target, arguments) {
    @throws[XPathException]
    override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = this // prevent infinite optimization
  }

}

class SystemFunctionCall(val target: SystemFunction, val arguments: Array[Expression]) extends StaticFunctionCall(target, arguments) with Negatable {
  argumentEvaluators = new Array[Evaluator](arguments.length)
  Arrays.fill(argumentEvaluators, Evaluator.LAZY_SEQUENCE)
  var argumentEvaluators = null

  /**
   * Set the retained static context
   *
   * @param rsc the static context to be retained
   */
  override def setRetainedStaticContext(rsc: RetainedStaticContext) = {
    super.setRetainedStaticContext(rsc)
    getTargetFunction.setRetainedStaticContext(rsc)
  }

  /**
   * Pre-evaluate a function at compile time. Functions that do not allow
   * pre-evaluation, or that need access to context information, can prevent early
   * evaluation by setting the LATE bit in the function properties.
   *
   * @param visitor an expression visitor
   * @return the result of the early evaluation, or the original expression, or potentially
   *         a simplified expression
   * @throws net.sf.saxon.trans.XPathException if evaluation fails
   */
  @throws[XPathException]
  override def preEvaluate(visitor: ExpressionVisitor) = {
    val target = getTargetFunction
    if ((target.getDetails.properties & BuiltInFunctionSet.LATE) == 0) super.preEvaluate(visitor)
    else { // Early evaluation of this function is suppressed
      this
    }
  }

  /**
   * Type-check the expression. This also calls preEvaluate() to evaluate the function
   * if all the arguments are constant; functions that do not require this behavior
   * can override the preEvaluate method.
   *
   * @param visitor     the expression visitor
   * @param contextInfo information about the type of the context item
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    typeCheckChildren(visitor, contextInfo)
    checkFunctionCall(getTargetFunction, visitor)
    // Give the function an opportunity to use the type information now available
    getTargetFunction.supplyTypeInformation(visitor, contextInfo, getArguments)
    if ((getTargetFunction.getDetails.properties & BuiltInFunctionSet.LATE) == 0) return preEvaluateIfConstant(visitor)
    allocateArgumentEvaluators(getArguments)
    this
  }

  private def allocateArgumentEvaluators(arguments: Array[Expression]) = for (i <- 0 until arguments.length) {
    val arg = arguments(i)
    val cardinality = if (isCallOn(classOf[Concat])) StaticProperty.ALLOWS_ZERO_OR_ONE
    else getTargetFunction.getDetails.argumentTypes(i).getCardinality
    if (arg.isInstanceOf[Literal]) argumentEvaluators(i) = Evaluator.LITERAL
    else if (arg.isInstanceOf[VariableReference]) argumentEvaluators(i) = Evaluator.VARIABLE
    else if (cardinality == StaticProperty.EXACTLY_ONE) argumentEvaluators(i) = Evaluator.SINGLE_ITEM
    else if (cardinality == StaticProperty.ALLOWS_ZERO_OR_ONE) argumentEvaluators(i) = Evaluator.OPTIONAL_ITEM
    else argumentEvaluators(i) = Evaluator.LAZY_SEQUENCE
  }

  override def getTargetFunction = super.getTargetFunction.asInstanceOf[SystemFunction]

  /**
   * Compute the dependencies of an expression, as the union of the
   * dependencies of its subexpressions. (This is overridden for path expressions
   * and filter expressions, where the dependencies of a subexpression are not all
   * propogated). This method should be called only once, to compute the dependencies;
   * after that, getDependencies should be used.
   *
   * @return the depencies, as a bit-mask
   */
  override def getIntrinsicDependencies = {
    val properties = getTargetFunction.getDetails.properties
    var dep = 0
    if ((properties & BuiltInFunctionSet.LATE) != 0) dep = StaticProperty.DEPENDS_ON_RUNTIME_ENVIRONMENT
    if ((properties & BuiltInFunctionSet.FOCUS) != 0) {
      if ((properties & BuiltInFunctionSet.CDOC) != 0) dep |= StaticProperty.DEPENDS_ON_CONTEXT_DOCUMENT
      if ((properties & BuiltInFunctionSet.CITEM) != 0) dep |= StaticProperty.DEPENDS_ON_CONTEXT_ITEM
      if ((properties & BuiltInFunctionSet.POSN) != 0) dep |= StaticProperty.DEPENDS_ON_POSITION
      if ((properties & BuiltInFunctionSet.LAST) != 0) dep |= StaticProperty.DEPENDS_ON_LAST
    }
    if ((properties & BuiltInFunctionSet.BASE) != 0) dep |= StaticProperty.DEPENDS_ON_STATIC_CONTEXT
    if ((properties & BuiltInFunctionSet.DCOLL) != 0) dep |= StaticProperty.DEPENDS_ON_STATIC_CONTEXT
    if (isCallOn(classOf[RegexGroup]) || isCallOn(classOf[CurrentMergeGroup]) || isCallOn(classOf[CurrentMergeKey])) dep |= StaticProperty.DEPENDS_ON_CURRENT_GROUP
    dep
  }

  /**
   * Compute the static cardinality of this expression
   *
   * @return the computed cardinality, as one of the values { @link net.sf.saxon.expr.StaticProperty#ALLOWS_ZERO_OR_ONE},
   *                                                                { @link net.sf.saxon.expr.StaticProperty#EXACTLY_ONE}, { @link net.sf.saxon.expr.StaticProperty#ALLOWS_ONE_OR_MORE},
   *                                                                { @link net.sf.saxon.expr.StaticProperty#ALLOWS_ZERO_OR_MORE}
   */
  override protected def computeCardinality = getTargetFunction.getCardinality(getArguments)

  /**
   * Compute the special properties of this expression. These properties are denoted by a bit-significant
   * integer, possible values are in class {@link net.sf.saxon.expr.StaticProperty}. The "special" properties are properties
   * other than cardinality and dependencies, and most of them relate to properties of node sequences, for
   * example whether the nodes are in document order.
   *
   * @return the special properties, as a bit-significant integer
   */
  override protected def computeSpecialProperties = getTargetFunction.getSpecialProperties(getArguments)

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   */
  override def getNetCost = getTargetFunction.getNetCost

  override def getScopingExpression: Expression = if (isCallOn(classOf[RegexGroup])) {
    var parent = getParentExpression
    while ( {
      parent != null
    }) {
      if (parent.isInstanceOf[AnalyzeString]) return parent
      parent = parent.getParentExpression
    }
    null
  }
  else super.getScopingExpression

  /**
   * Ask whether the expression can be lifted out of a loop, assuming it has no dependencies
   * on the controlling variable/focus of the loop
   *
   * @param forStreaming true if we are optimizing for streamed evaluation
   */
  override def isLiftable(forStreaming: Boolean) = { // xsl:map-entry is not liftable when streaming because of the special streamability
    // rules for xsl:map; similarly XPath map constructor expressions.
    // The tests for current-merge-group/key were added to fix bug 3652 - it seems
    // an inelegant solution because it's being handled differently from other context
    // dependencies, but it works.
    super.isLiftable(forStreaming) && !isCallOn(classOf[CurrentMergeGroup]) && !isCallOn(classOf[CurrentMergeKey]) && (!forStreaming || !isCallOn(classOf[MapFunctionSet.MapEntry]))
  }

  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val opt = visitor.obtainOptimizer
    val sf = super.optimize(visitor, contextInfo)
    if (sf eq this) { // Give the function an opportunity to regenerate the function call, with more information about
      // the types of the arguments than was previously available
      val sfo = getTargetFunction.makeOptimizedFunctionCall(visitor, contextInfo, getArguments)
      if (sfo != null) {
        sfo.setParentExpression(getParentExpression)
        ExpressionTool.copyLocationInfo(this, sfo)
        if (sfo.isInstanceOf[SystemFunctionCall]) sfo.asInstanceOf[SystemFunctionCall].allocateArgumentEvaluators(sfo.asInstanceOf[SystemFunctionCall].getArguments)
        return sfo
      }
    }
    if (sf.isInstanceOf[SystemFunctionCall] && opt.isOptionSet(OptimizerOptions.CONSTANT_FOLDING)) { // If any arguments are known to be empty, pre-evaluate the result
      val details = sf.asInstanceOf[SystemFunctionCall].getTargetFunction.getDetails
      if ((details.properties & BuiltInFunctionSet.UO) != 0) { // First argument does not need to be in any particular order
        setArg(0, getArg(0).unordered(true, visitor.isOptimizeForStreaming))
      }
      if (getArity <= details.resultIfEmpty.length) { // the condition eliminates concat, which is a special case.
        for (i <- 0 until getArity) {
          if (Literal.isEmptySequence(getArg(i)) && details.resultIfEmpty(i) != null) return Literal.makeLiteral(details.resultIfEmpty(i).materialize, this)
        }
      }
      sf.asInstanceOf[SystemFunctionCall].allocateArgumentEvaluators(sf.asInstanceOf[SystemFunctionCall].getArguments)
    }
    sf
  }

  override def isVacuousExpression = isCallOn(classOf[Error])

  /**
   * Determine the data type of the expression, if possible. All expression return
   * sequences, in general; this method determines the type of the items within the
   * sequence, assuming that (a) this is known in advance, and (b) it is the same for
   * all items in the sequence.
   * <p>This method should always return a result, though it may be the best approximation
   * that is available at the time.</p>
   *
   * @return a value such as Type.STRING, Type.BOOLEAN, Type.NUMBER,
   * Type.NODE, or Type.ITEM (meaning not known at compile time)
   */
  override def getItemType = getTargetFunction.getResultItemType(getArguments)

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @param rebindings variables that need to be re-bound
   * @return the copy of the original expression
   */
  override def copy(rebindings: RebindingMap) = {
    val args = new Array[Expression](getArity)
    for (i <- 0 until args.length) {
      args(i) = getArg(i).copy(rebindings)
    }
    var target = getTargetFunction
    if (target.isInstanceOf[StatefulSystemFunction]) target = target.asInstanceOf[StatefulSystemFunction].copy
    target.makeFunctionCall(args)
  }

  /**
   * For an expression that returns an integer or a sequence of integers, get
   * a lower and upper bound on the values of the integers that may be returned, from
   * static analysis. The default implementation returns null, meaning "unknown" or
   * "not applicable". Other implementations return an array of two IntegerValue objects,
   * representing the lower and upper bounds respectively. The values
   * UNBOUNDED_LOWER and UNBOUNDED_UPPER are used by convention to indicate that
   * the value may be arbitrarily large. The values MAX_STRING_LENGTH and MAX_SEQUENCE_LENGTH
   * are used to indicate values limited by the size of a string or the size of a sequence.
   *
   * @return the lower and upper bounds of integer values in the result, or null to indicate
   *         unknown or not applicable.
   */
  //@Override
  override def getIntegerBounds: Array[IntegerValue] = {
    val fn = getTargetFunction
    if ((fn.getDetails.properties & BuiltInFunctionSet.FILTER) != 0) return getArg(0).getIntegerBounds
    fn.getIntegerBounds
  }

  /**
   * Check whether this specific instance of the expression is negatable
   *
   * @param th the TypeHierarchy (in case it's needed)
   * @return true if it is
   */
  override def isNegatable(th: TypeHierarchy) = isCallOn(classOf[NotFn]) || isCallOn(classOf[BooleanFn]) || isCallOn(classOf[Empty]) || isCallOn(classOf[Exists])

  /**
   * Create an expression that returns the negation of this expression
   *
   * @return the negated expression
   * @throws UnsupportedOperationException if isNegatable() returns false
   */
  override def negate: Expression = {
    val fn = getTargetFunction
    if (fn.isInstanceOf[NotFn]) {
      val arg = getArg(0)
      if ((arg.getItemType eq BuiltInAtomicType.BOOLEAN) && arg.getCardinality == StaticProperty.EXACTLY_ONE) return arg
      else return SystemFunction.makeCall("boolean", getRetainedStaticContext, arg)
    }
    else if (fn.isInstanceOf[BooleanFn]) return SystemFunction.makeCall("not", getRetainedStaticContext, getArg(0))
    else if (fn.isInstanceOf[Exists]) return SystemFunction.makeCall("empty", getRetainedStaticContext, getArg(0))
    else if (fn.isInstanceOf[Empty]) return SystemFunction.makeCall("exists", getRetainedStaticContext, getArg(0))
    throw new UnsupportedOperationException
  }

  /**
   * Replace this expression by a simpler expression that delivers the results without regard
   * to order.
   *
   * @param retainAllNodes set to true if the result must contain exactly the same nodes as the
   *                       original; set to false if the result can eliminate (or introduce) duplicates.
   * @param forStreaming   set to true if the result is to be optimized for streaming
   * @return an expression that delivers the same nodes in a more convenient order
   * @throws net.sf.saxon.trans.XPathException if the rewrite fails
   */
  @throws[XPathException]
  override def unordered(retainAllNodes: Boolean, forStreaming: Boolean): Expression = {
    val fn = getTargetFunction
    if (fn.isInstanceOf[Reverse]) return getArg(0)
    if (fn.isInstanceOf[TreatFn]) setArg(0, getArg(0).unordered(retainAllNodes, forStreaming))
    this
  }

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   * <p>The default implementation of this method assumes that an expression does no navigation other than
   * the navigation done by evaluating its subexpressions, and that the subexpressions are evaluated in the
   * same context as the containing expression. The method must be overridden for any expression
   * where these assumptions do not hold. For example, implementations exist for AxisExpression, ParentExpression,
   * and RootExpression (because they perform navigation), and for the doc(), document(), and collection()
   * functions because they create a new navigation root. Implementations also exist for PathExpression and
   * FilterExpression because they have subexpressions that are evaluated in a different context from the
   * calling expression.</p>
   *
   * @param pathMap        the PathMap to which the expression should be added
   * @param pathMapNodeSet the PathMapNodeSet to which the paths embodied in this expression should be added
   * @return the pathMapNodeSet representing the points in the source document that are both reachable by this
   *         expression, and that represent possible results of this expression. For an expression that does
   *         navigation, it represents the end of the arc in the path map that describes the navigation route. For other
   *         expressions, it is the same as the input pathMapNode.
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = if (isCallOn(classOf[Doc]) || isCallOn(classOf[DocumentFn]) || isCallOn(classOf[CollectionFn])) {
    getArg(0).addToPathMap(pathMap, pathMapNodeSet)
    new PathMap.PathMapNodeSet(pathMap.makeNewRoot(this))
  }
  else if (isCallOn(classOf[KeyFn])) getTargetFunction.asInstanceOf[KeyFn].addToPathMap(pathMap, pathMapNodeSet)
  else super.addToPathMap(pathMap, pathMapNodeSet)

  /**
   * Convert this expression to an equivalent XSLT pattern
   *
   * @param config the Saxon configuration
   * @return the equivalent pattern
   * @throws net.sf.saxon.trans.XPathException if conversion is not possible
   */
  @throws[XPathException]
  override def toPattern(config: Configuration): Pattern = {
    val fn = getTargetFunction
    if (fn.isInstanceOf[Root_1]) if (getArg(0).isInstanceOf[ContextItemExpression] || (getArg(0).isInstanceOf[ItemChecker] && getArg(0).asInstanceOf[ItemChecker].getBaseExpression.isInstanceOf[ContextItemExpression])) return new NodeSetPattern(this)
    super.toPattern(config)
  }

  @throws[XPathException]
  override def evaluateArguments(context: XPathContext) = {
    val operanda = getOperanda
    val numArgs = operanda.getNumberOfOperands
    val actualArgs = new Array[Sequence](numArgs)
    for (i <- 0 until numArgs) {
      val exp = operanda.getOperandExpression(i)
      actualArgs(i) = argumentEvaluators(i).evaluate(exp, context)
    }
    actualArgs
  }

  override def resetLocalStaticProperties() = {
    super.resetLocalStaticProperties()
    if (argumentEvaluators != null) allocateArgumentEvaluators(getArguments)
  }

  @throws[XPathException]
  override def process(output: Outputter, context: XPathContext) = {
    val target = getTargetFunction
    if (target.isInstanceOf[PushableFunction]) {
      val actualArgs = evaluateArguments(context)
      try target.asInstanceOf[PushableFunction].process(output, context, actualArgs)
      catch {
        case e: XPathException =>
          e.maybeSetLocation(getLocation)
          e.maybeSetContext(context)
          e.maybeSetFailingExpression(this)
          throw e
      }
    }
    else super.process(output, context)
  }

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "sysFuncCall"

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   *
   * @param out the destination of the output
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = if (getFunctionName.hasURI(NamespaceConstant.FN)) {
    out.startElement("fn", this)
    out.emitAttribute("name", getFunctionName.getLocalPart)
    getTargetFunction.exportAttributes(out)
    import scala.collection.JavaConversions._
    for (o <- operands) {
      o.getChildExpression.`export`(out)
    }
    getTargetFunction.exportAdditionalArguments(this, out)
    out.endElement
  }
  else { // Function was implemented as an IntegratedFunctionCall in 9.7 and we retain the same export format
    out.startElement("ifCall", this)
    out.emitAttribute("name", getFunctionName)
    out.emitAttribute("type", getTargetFunction.getFunctionItemType.getResultType.toAlphaCode)
    getTargetFunction.exportAttributes(out)
    import scala.collection.JavaConversions._
    for (o <- operands) {
      o.getChildExpression.`export`(out)
    }
    getTargetFunction.exportAdditionalArguments(this, out)
    out.endElement
  }
}