////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.om.NameChecker
import net.sf.saxon.trans.XPathException
import java.util

/**
 * A class to represent an XSLT package version such as 1.12.5 or 3.0-alpha
 * <p>This implements the semantics given in
 * <a href="http://www.w3.org/TR/xslt-30/#package-versions">http://www.w3.org/TR/xslt-30/#package-versions</a>,
 * where a series of dot-separated integers may be followed optionally by '-'NCName</p>
 */
object PackageVersion {
  /**
   *
   */
    var ZERO = new PackageVersion(Array[Int](0))
  var ONE = new PackageVersion(Array[Int](1))
  var MAX_VALUE = new PackageVersion(Array[Int](Integer.MAX_VALUE))
}

class PackageVersion extends Comparable[PackageVersion] {
  var parts = null
  var suffix = null

  /**
   * Return a package version defined by a fixed sequence of int values, which implies no suffix
   *
   * @param values the sequence of integer components
   */
  def this(values: Array[Int]) {
    this()
    parts = new util.ArrayList[Integer](values.length)
    for (value <- values) {
      parts.add(value)
    }
    trimTrailingZeroes()
  }

  /**
   * Remove any trailing zero components from the package version
   */
  private def trimTrailingZeroes(): Unit = for (i <- parts.size - 1 until 0 by -1) {
    if (parts.get(i) ne 0) return
    else parts.remove(i)
  }

  /**
   * Generate a package version from a string description
   *
   * @param s The input string describing the package version according to the grammar given at:
   *          <a href="http://www.w3.org/TR/xslt-30/#package-versions">http://www.w3.org/TR/xslt-30/#package-versions</a>
   * @throws XPathException
   */
  def this(s: String) {
    this()
    parts = new util.ArrayList[Integer]
    val original = s
    if (s.contains("-")) {
      val i = s.indexOf('-')
      suffix = s.substring(i + 1)
      if (!NameChecker.isValidNCName(suffix)) throw new XPathException("Illegal NCName as package-version NamePart: " + original, "XTSE0020")
      s = s.substring(0, i)
    }
    if (s == "") throw new XPathException("No numeric component of package-version: " + original, "XTSE0020")
    if (s.startsWith(".")) throw new XPathException("The package-version cannot start with '.'", "XTSE0020")
    if (s.endsWith(".")) throw new XPathException("The package-version cannot end with '.'", "XTSE0020")
    for (p <- s.trim.split("\\.")) {
      try parts.add(Integer.valueOf(p))
      catch {
        case e: NumberFormatException =>
          throw new XPathException("Error in package-version: " + e.getMessage, "XTSE0020")
      }
    }
    trimTrailingZeroes()
  }

  override def equals(o: Any): Boolean = {
    if (o.isInstanceOf[PackageVersion]) {
      val p = o.asInstanceOf[PackageVersion]
      if (parts == p.parts) if (suffix != null) return suffix == p.suffix
      else return p.suffix == null
    }
    false
  }

  /**
   * Compare two version numbers for equality, ignoring the suffix part
   * of the version number. For example 2.1-alpha compares equal
   * to 2.1-beta
   *
   * @param other the other name/version pair
   * @return true if the values are equal in all respects other than the alphanumeric
   *         suffix of the version number.
   */
  def equalsIgnoringSuffix(other: PackageVersion) = parts == other.parts

  override def compareTo(o: PackageVersion): Int = {
    val pv = o.asInstanceOf[PackageVersion]
    val p = pv.parts
    val extent = parts.size - p.size
    val len = Math.min(parts.size, p.size)
    for (i <- 0 until len) {
      val comp = parts.get(i).compareTo(p.get(i))
      if (comp != 0) return comp
    }
    if (extent == 0) if (suffix != null) if (pv.suffix == null) return -1
    else return suffix.compareTo(pv.suffix)
    else if (pv.suffix != null) return +1
    extent
  }

  override def toString = {
    var result = new StringBuilder
    import scala.collection.JavaConversions._
    for (i <- parts) {
      result.append(".").append(i)
    }
    if (!parts.isEmpty) result = new StringBuilder(result.substring(1))
    if (suffix != null) result.append("-").append(suffix)
    result.toString
  }

  /**
   * Tests whether this package version is a prefix (i.e. shares all its components in order)
   * of another package version, and thus this version.* should match it.
   *
   * @param v The version to be checked that it is equal, or 'extends'  this version
   * @return true if this is a prefix, false if not.
   */
  def isPrefix(v: PackageVersion): Boolean = {
    if (v.parts.size >= parts.size) {
      for (i <- 0 until parts.size) {
        if (!(parts.get(i) == v.parts.get(i))) return false
      }
      return true
    }
    false
  }
}