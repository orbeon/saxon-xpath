////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Type
import net.sf.saxon.om._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.packages.VersionedPackageName
import net.sf.saxon.value.Whitespace

/**
 * Handler for xsl:package elements. Explicit xsl:package elements are not permitted in Saxon-HE, but
 * implicit packages are created, so the class is present in HE. The top-level module of a stylesheet/package
 * will always be represented by an XSLPackage object, but if the original name was xsl:stylesheet or xsl:transform
 * then this original name will be present as the name of the element.
 */
class XSLPackage extends XSLModuleRoot {
  private var nameAtt = null
  private var packageVersion = null
  private var declaredModes = true
  private var prepared = false

  /**
   * Initialise a new ElementImpl with an element name
   *
   * @param elemName       Integer representing the element name, with namespaces resolved
   * @param elementType    the schema type of the element node
   * @param atts           The attribute list: always null
   * @param parent         The parent node
   * @param sequenceNumber Integer identifying this element within the document
   */
  override def initialise(elemName: NodeName, elementType: SchemaType, atts: AttributeMap, parent: NodeInfo, sequenceNumber: Int) = {
    super.initialise(elemName, elementType, atts, parent, sequenceNumber)
    declaredModes = getLocalPart == "package"
  }

  /**
   * Get the name of the package (the value of its @name attribute)
   *
   * @return the name of the package, or null if the @name attribute is omitted
   */
  def getName = {
    if (nameAtt == null) prepareAttributes()
    nameAtt
  }

  /**
   * Get the requested XSLT version (the value of the @version attribute)
   *
   * @return the value of the @version attribute, times ten as an integer
   */
  def getVersion = {
    if (version == -1) prepareAttributes()
    version
  }

  def getNameAndVersion = new VersionedPackageName(getName, getPackageVersion)

  /**
   * Get the package version (the value of the @package-version attribute)
   *
   * @return the value of the @package-version attribute, defaulting to "1.0"
   */
  def getPackageVersion = {
    if (packageVersion == null) prepareAttributes()
    packageVersion
  }

  override protected def prepareAttributes(): Unit = {
    if (prepared) { // already done
      return
    }
    prepared = true
    var inputTypeAnnotationsAtt = null
    var packageVersionAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val lexicalName = attName.getDisplayName
      val value = att.getValue
      if (lexicalName == "name" && getLocalPart == "package") nameAtt = Whitespace.trim(value)
      else if (lexicalName == "id") {
        // no action
      }
      else if (lexicalName == "version") if (version == -1) processVersionAttribute("")
      else if (lexicalName == "package-version" && getLocalPart == "package") packageVersionAtt = Whitespace.trim(value)
      else if (lexicalName == "declared-modes" && getLocalPart == "package") declaredModes = processBooleanAttribute("declared-modes", value)
      else if (lexicalName == "input-type-annotations") inputTypeAnnotationsAtt = value
      else checkUnknownAttribute(attName)
    }
    if (packageVersionAtt == null) packageVersion = PackageVersion.ONE
    else try packageVersion = new PackageVersion(packageVersionAtt)
    catch {
      case ex: XPathException =>
        compileErrorInAttribute(ex.getMessage, ex.getErrorCodeLocalPart, "package-version")
    }
    if (version == -1) {
      version = 30
      reportAbsence("version")
    }
    if (inputTypeAnnotationsAtt != null) inputTypeAnnotationsAtt match {
      case "strip" =>
      //setInputTypeAnnotations(ANNOTATION_STRIP);
      case "preserve" =>
      //setInputTypeAnnotations(ANNOTATION_PRESERVE);
      case "unspecified" =>
      //
      case _ =>
        compileError("Invalid value for input-type-annotations attribute. " + "Permitted values are (strip, preserve, unspecified)", "XTSE0020")
    }
  }

  /**
   * Ask whether it is required that modes be explicitly declared
   *
   * @return true if modes referenced within this package must be explicitly declared
   */
  override def isDeclaredModes = {
    if (nameAtt == null) prepareAttributes()
    declaredModes
  }

  /**
   * Recursive walk through the stylesheet to validate all nodes
   *
   * @param decl not used
   * @throws XPathException if invalid
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    import scala.collection.JavaConversions._
    for (child <- children) {
      val fp = child.getFingerprint
      if (child.getNodeKind == Type.TEXT || (child.isInstanceOf[StyleElement] && child.asInstanceOf[StyleElement].isDeclaration) || child.isInstanceOf[DataElement]) {
        // all is well
      }
      else if (child.isInstanceOf[StyleElement]) if (getLocalPart == "package" && (fp == StandardNames.XSL_USE_PACKAGE || fp == StandardNames.XSL_EXPOSE)) {
      }
      else if (!(NamespaceConstant.XSLT == child.getURI) && !("" == child.getURI)) {
        // elements in other namespaces are allowed and ignored
      }
      else if (child.isInstanceOf[AbsentExtensionElement] && child.asInstanceOf[StyleElement].forwardsCompatibleModeIsEnabled) {
        // this is OK: an unknown XSLT element is allowed in forwards compatibility mode
      }
      else if (NamespaceConstant.XSLT == child.getURI) if (child.isInstanceOf[AbsentExtensionElement]) {
        // then the error will be reported later
      }
      else child.asInstanceOf[StyleElement].compileError("Element " + child.getDisplayName + " must not appear directly within " + getDisplayName, "XTSE0010")
      else child.asInstanceOf[StyleElement].compileError("Element " + child.getDisplayName + " must not appear directly within " + getDisplayName + " because it is not in a namespace", "XTSE0130")
    }
    if (declaredModes) {
      val defaultMode = getAttributeValue("default-mode")
      if (defaultMode != null && getPrincipalStylesheetModule.getRuleManager.obtainMode(getDefaultMode, false) == null) compileError("The default mode " + defaultMode + " has not been declared in an xsl:mode declaration", "XTSE3085")
    }
  }
}