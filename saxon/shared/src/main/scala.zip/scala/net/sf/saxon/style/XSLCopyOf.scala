////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.CopyOf
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.SaxonErrorCode
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * An xsl:copy-of element in the stylesheet. <br>
 */
final class XSLCopyOf extends StyleElement {
  /*@Nullable*/ private var select = null
  private var copyNamespaces = false
  private var copyAccumulators = false
  private var validation = Validation.PRESERVE
  private var schemaType = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  override def prepareAttributes() = {
    var selectAtt = null
    var copyNamespacesAtt = null
    var copyAccumulatorsAtt = null
    var validationAtt = null
    var typeAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else if (f == "copy-namespaces") copyNamespacesAtt = Whitespace.trim(value)
      else if (f == "copy-accumulators") copyAccumulatorsAtt = Whitespace.trim(value)
      else if (f == "validation") validationAtt = Whitespace.trim(value)
      else if (f == "type") typeAtt = Whitespace.trim(value)
      else if (attName.getLocalPart == "read-once" && attName.hasURI(NamespaceConstant.SAXON)) compileError("The saxon:read-once attribute is no longer available - use xsl:stream")
      else checkUnknownAttribute(attName)
    }
    if (selectAtt == null) reportAbsence("select")
    if (copyAccumulatorsAtt == null) copyAccumulators = false
    else {
      copyAccumulators = processBooleanAttribute("copy-accumulators", copyAccumulatorsAtt)
      if (copyAccumulators && isConstructingComplexContent) {
        compileWarning("Copying accumulators is pointless when the copied element " + "is immediately attached to a new parent, since that action " + "will lose the accumulator values", SaxonErrorCode.SXWN9017)
        copyAccumulators = false
      }
    }
    if (copyNamespacesAtt == null) copyNamespaces = true
    else copyNamespaces = processBooleanAttribute("copy-namespaces", copyNamespacesAtt)
    if (validationAtt != null) validation = validateValidationAttribute(validationAtt)
    else validation = getDefaultValidation
    if (typeAtt != null) {
      schemaType = getSchemaType(typeAtt)
      if (!isSchemaAware) compileError("The @type attribute is available only with a schema-aware XSLT processor", "XTSE1660")
      validation = Validation.BY_TYPE
    }
    if (typeAtt != null && validationAtt != null) compileError("The @validation and @type attributes are mutually exclusive", "XTSE1505")
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    checkEmpty()
    select = typeCheck("select", select)
  }

  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val inst = new CopyOf(select, copyNamespaces, validation, schemaType, false)
    inst.setCopyAccumulators(copyAccumulators)
    //inst.setCopyLineNumbers(exec.getConfiguration().isLineNumbering());
    inst.setSchemaAware(exec.isSchemaAware)
    inst
  }
}