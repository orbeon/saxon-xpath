////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.s9api.streams.XdmStream
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.tree.iter.SingletonIterator
import net.sf.saxon.tree.iter.UnfailingIterator
import java.util
import java.util.Spliterator
import java.util.Spliterators
import java.util.stream.Stream
import java.util.stream.StreamSupport

/**
 * An iterator over an XPath sequence.
 * <p>This class implements the standard Java Iterator interface.</p>
 * <p>Because the <code>Iterator</code> interface does not define any checked
 * exceptions, the <code>hasNext()</code> method of this iterator throws an unchecked
 * exception if a dynamic error occurs while evaluating the expression. Applications
 * wishing to control error handling should take care to catch this exception.</p>
 */
object XdmSequenceIterator {
  private val BEFORE_ITEM = 0
  private val ON_ITEM = 1
  private val FINISHED = 2

  def ofNodes(base: AxisIterator) = new XdmSequenceIterator[XdmNode](base)

  def ofAtomicValues(base: UnfailingIterator) = new XdmSequenceIterator[XdmAtomicValue](base)

  protected def ofNode(node: XdmNode) = new XdmSequenceIterator[XdmNode](SingletonIterator.makeIterator(node.getUnderlyingNode))
}

class XdmSequenceIterator[T <: XdmItem] extends util.Iterator[T] {
  /*@Nullable*/ private var next = null
  private var state = 0
  private var base = null

  def this(base: SequenceIterator) {
    this()
    this.base = base
    this.state = XdmSequenceIterator.BEFORE_ITEM
  }

  def this(base: UnfailingIterator) {
    this()
    this.base = base
    this.state = XdmSequenceIterator.BEFORE_ITEM
  }

  /**
   * Returns <tt>true</tt> if the iteration has more elements. (In other
   * words, returns <tt>true</tt> if <tt>next</tt> would return an element
   * rather than throwing an exception.)
   *
   * @return <tt>true</tt> if the iterator has more elements.
   * @throws SaxonApiUncheckedException if a dynamic error occurs during XPath evaluation that
   *                                    is detected at this point.
   */
  @throws[SaxonApiUncheckedException]
  override def hasNext = state match {
    case XdmSequenceIterator.ON_ITEM =>
      true
    case XdmSequenceIterator.FINISHED =>
      false
    case XdmSequenceIterator.BEFORE_ITEM =>
      try { //noinspection unchecked
        next = XdmItem.wrapItem(base.next).asInstanceOf[T]
        if (next == null) {
          state = XdmSequenceIterator.FINISHED
          false
        }
        else {
          state = XdmSequenceIterator.ON_ITEM
          true
        }
      } catch {
        case err: XPathException =>
          throw new SaxonApiUncheckedException(err)
      }
    case _ =>
      throw new IllegalStateException
  }

  /**
   * Returns the next element in the iteration.  Calling this method
   * repeatedly until the {@link #hasNext()} method returns false will
   * return each element in the underlying collection exactly once.
   *
   * @return the next element in the iteration.
   * @throws java.util.NoSuchElementException
   * iteration has no more elements.
   */
  override def next = state match {
    case XdmSequenceIterator.ON_ITEM =>
      state = XdmSequenceIterator.BEFORE_ITEM
      next
    case XdmSequenceIterator.FINISHED =>
      throw new NoSuchElementException
    case XdmSequenceIterator.BEFORE_ITEM =>
      if (hasNext) next
      else throw new NoSuchElementException
    case _ =>
      throw new IllegalStateException
  }

  /**
   * Not supported on this implementation.
   *
   * @throws UnsupportedOperationException always
   */
  override def remove() = throw new UnsupportedOperationException

  /**
   * The close() method should be called to release resources if the caller wants to stop reading
   * data before reaching the end. This is particularly relevant if the query uses saxon:stream()
   * to read its input, since there will then be another thread supplying data, which will be left
   * in suspended animation if no-one is consuming the data.
   *
   * @since 9.5.1.5 (see bug 2016)
   */
  def close() = {
    base.close()
    state = XdmSequenceIterator.FINISHED
  }

  /**
   * Convert this iterator to a Stream
   *
   * @return a Stream delivering the same items as this iterator
   * @since 9.9
   */
  def stream = {
    var base = StreamSupport.stream(Spliterators.spliteratorUnknownSize(this, Spliterator.ORDERED), false)
    base = base.onClose(thisXdmSequenceIterator.close)
    new XdmStream[T](base)
  }
}