////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.Configuration
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Type
import net.sf.saxon.model.Untyped
import net.sf.saxon.om._
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.ArrayIterator
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.tree.iter.SingleNodeIterator
import net.sf.saxon.tree.linked.DocumentImpl
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.tree.util.Navigator
import javax.xml.transform.SourceLocator
import java.util.Collections
import java.util
import java.util.function.Predicate

/**
 * This class represents a temporary tree whose root document node owns a single text node. <BR>
 */
object TextFragmentValue {
  /**
   * Static factory method: create a result tree fragment containing a single text node,
   * unless the text is zero length, in which case an empty document node is returned
   *
   * @param config  the Saxon Configuration
   * @param value   a String containing the value
   * @param baseURI the base URI of the document node
   */
    def makeTextFragment(config: Configuration, value: CharSequence, baseURI: String) = if (value.length == 0) { // Create a childless document node: bug 4246
      val doc = new DocumentImpl
      doc.setSystemId(baseURI)
      doc.setBaseURI(baseURI)
      doc.setConfiguration(config)
      doc
    }
    else new TextFragmentValue(config, value, baseURI)
}

final class TextFragmentValue(val config: Configuration, var text: CharSequence, var baseURI: String)

/**
 * Constructor: create a result tree fragment containing a single text node
 *
 * @param config  the Saxon Configuration
 * @param value   a String containing the value
 * @param baseURI the base URI of the document node
 */
  extends NodeInfo with SourceLocator {
  this.treeInfo = new GenericTreeInfo(configuration)
  this.treeInfo.setRootNode(this)
  private var documentURI = null
  private var treeInfo = null
  private var textNode = null // created on demand
  /**
   * Get information about the tree to which this NodeInfo belongs
   *
   * @return the TreeInfo
   * @since 9.7
   */
  override def getTreeInfo = treeInfo

  /**
   * Get the NodeInfo object representing the document node at the root of the tree
   *
   * @return the document node
   */
  def getRootNode = this

  /**
   * Ask whether the document contains any nodes whose type annotation is anything other than
   * UNTYPED
   *
   * @return true if the document contains elements whose type is other than UNTYPED
   */
  def isTyped = false

  /**
   * Return the type of node.
   *
   * @return Type.DOCUMENT (always)
   */
  override final def getNodeKind = Type.DOCUMENT

  /**
   * Get the String Value
   */
  override def getStringValue = text.toString

  /**
   * Get the value of the item as a CharSequence. This is in some cases more efficient than
   * the version of the method that returns a String.
   */
  override def getStringValueCS = text

  /**
   * Determine whether this is the same node as another node
   *
   * @return true if this Node object and the supplied Node object represent the
   *         same node in the tree.
   */
  override def equals(other: Any) = this eq other

  /**
   * Ask whether this NodeInfo implementation holds a fingerprint identifying the name of the
   * node in the NamePool. If the answer is true, then the {@link #getFingerprint} method must
   * return the fingerprint of the node. If the answer is false, then the {@link #getFingerprint}
   * method should throw an {@code UnsupportedOperationException}. In the case of unnamed nodes
   * such as text nodes, the result can be either true (in which case getFingerprint() should
   * return -1) or false (in which case getFingerprint may throw an exception).
   *
   * @return true if the implementation of this node provides fingerprints.
   * @since 9.8; previously Saxon relied on using <code>FingerprintedNode</code> as a marker interface.
   */
  override def hasFingerprint = true

  /**
   * Get a character string that uniquely identifies this node
   *
   * @param buffer the buffer to contain the generated ID
   */
  override def generateId(/*@NotNull*/ buffer: FastStringBuffer) = {
    buffer.append("tt")
    buffer.append(Long.toString(treeInfo.getDocumentNumber))
  }

  /**
   * Set the system ID (that is, the document URI property) for the document node.
   *
   * @throws UnsupportedOperationException (always). This kind of tree does not have a document URI.
   */
  override def setSystemId(systemId: String) = documentURI = systemId

  /**
   * Get the system ID (the document URI) of the document node.
   */
  override def getSystemId = documentURI

  /**
   * Get the base URI for the document node.
   */
  override def getBaseURI = baseURI

  /**
   * Determine the relative position of this node and another node, in document order.
   * The other node will always be in the same document.
   *
   * @param other The other node, whose position is to be compared with this node
   * @return -1 if this node precedes the other node, +1 if it follows the other
   *         node, or 0 if they are the same node. (In this case, isSameNode() will always
   *         return true, and the two nodes will produce the same result for generateId())
   */
  override def compareOrder(other: NodeInfo): Int = {
    if (this eq other) return 0
    -1
  }

  /**
   * Get the fingerprint of the node, used for matching names
   */
  override def getFingerprint = -1

  /**
   * Get the prefix part of the name of this node. This is the name before the ":" if any.
   *
   * @return the prefix part of the name. For an unnamed node, return "".
   */
  override def getPrefix = ""

  /**
   * Get the URI part of the name of this node. This is the URI corresponding to the
   * prefix, or the URI of the default namespace if appropriate.
   *
   * @return The URI of the namespace of this node. For an unnamed node, or for
   *         an element or attribute in the default namespace, return an empty string.
   */
  override def getURI = ""

  /**
   * Get the display name of this node. For elements and attributes this is [prefix:]localname.
   * For unnamed nodes, it is an empty string.
   *
   * @return The display name of this node.
   *         For a node with no name, return an empty string.
   */
  override def getDisplayName = ""

  /**
   * Get the local name of this node.
   *
   * @return The local name of this node.
   *         For a node with no name, return "".
   */
  override def getLocalPart = ""

  /**
   * Determine whether the node has any children.
   *
   * @return <code>true</code> if this node has any attributes,
   *         <code>false</code> otherwise.
   */
  override def hasChildNodes = text.length != 0

  /**
   * Get an immutable copy of this Location object. By default Location objects may be mutable, so they
   * should not be saved for later use. The result of this operation holds the same location information,
   * but in an immutable form.
   */
  override def saveLocation = this

  /**
   * Get the type annotation of this node, if any. The type annotation is represented as
   * SchemaType object.
   * <p>Types derived from a DTD are not reflected in the result of this method.</p>
   *
   * @return For element and attribute nodes: the type annotation derived from schema
   *         validation (defaulting to xs:untyped and xs:untypedAtomic in the absence of schema
   *         validation). For comments, text nodes, processing instructions, and namespaces: null.
   *         For document nodes, either xs:untyped if the document has not been validated, or
   *         xs:anyType if it has.
   * @since 9.4
   */
  override def getSchemaType = Untyped.getInstance

  /**
   * Get all namespace undeclarations and undeclarations defined on this element.
   *
   * @param buffer If this is non-null, and the result array fits in this buffer, then the result
   *               may overwrite the contents of this array, to avoid the cost of allocating a new array on the heap.
   * @return An array of integers representing the namespace declarations and undeclarations present on
   *         this element. For a node other than an element, return null. Otherwise, the returned array is a
   *         sequence of namespace codes, whose meaning may be interpreted by reference to the name pool. The
   *         top half word of each namespace code represents the prefix, the bottom half represents the URI.
   *         If the bottom half is zero, then this is a namespace undeclaration rather than a declaration.
   *         The XML namespace is never included in the list. If the supplied array is larger than required,
   *         then the first unused entry will be set to -1.
   *         <p>For a node other than an element, the method returns null.</p>
   */
  /*@Nullable*/ override def getDeclaredNamespaces(buffer: Array[NamespaceBinding]) = null

  /**
   * Get all the namespace bindings that are in-scope for this element.
   * <p>For an element return all the prefix-to-uri bindings that are in scope. This may include
   * a binding to the default namespace (represented by a prefix of ""). It will never include
   * "undeclarations" - that is, the namespace URI will never be empty; the effect of an undeclaration
   * is to remove a binding from the in-scope namespaces, not to add anything.</p>
   * <p>For a node other than an element, returns null.</p>
   *
   * @return the in-scope namespaces for an element, or null for any other kind of node.
   */
  override def getAllNamespaces = null

  /**
   * Get the typed value.
   *
   * @return the typed value. If requireSingleton is set to true, the result will always be an
   *         AtomicValue. In other cases it may be a Value representing a sequence whose items are atomic
   *         values.
   * @since 8.5
   */
  override def atomize = new UntypedAtomicValue(text)

  /**
   * Get the string value of a given attribute of this node
   *
   * @param uri   the namespace URI of the attribute name. Supply the empty string for an attribute
   *              that is in no namespace
   * @param local the local part of the attribute name.
   * @return the attribute value if it exists, or null if it does not exist. Always returns null
   *         if this node is not an element.
   * @since 9.4
   */
  override def getAttributeValue(uri: String, local: String) = null

  /**
   * Return an iteration over the nodes reached by the given axis from this node
   *
   * @param axisNumber The axis to be iterated over
   * @return a AxisIterator that scans the nodes reached by the axis in turn.
   * @see net.sf.saxon.om.AxisInfo
   */
  override def iterateAxis(axisNumber: Int) = axisNumber match {
    case AxisInfo.ANCESTOR =>
    case AxisInfo.ATTRIBUTE =>
    case AxisInfo.FOLLOWING =>
    case AxisInfo.FOLLOWING_SIBLING =>
    case AxisInfo.NAMESPACE =>
    case AxisInfo.PARENT =>
    case AxisInfo.PRECEDING =>
    case AxisInfo.PRECEDING_SIBLING =>
    case AxisInfo.PRECEDING_OR_ANCESTOR =>
      EmptyIterator.ofNodes
    case AxisInfo.SELF =>
    case AxisInfo.ANCESTOR_OR_SELF =>
      SingleNodeIterator.makeIterator(this)
    case AxisInfo.CHILD =>
    case AxisInfo.DESCENDANT =>
      SingleNodeIterator.makeIterator(getTextNode)
    case AxisInfo.DESCENDANT_OR_SELF =>
      val nodes = Array(this, getTextNode)
      new ArrayIterator.OfNodes(nodes)
    case _ =>
      throw new IllegalArgumentException("Unknown axis number " + axisNumber)
  }

  /**
   * Return an enumeration over the nodes reached by the given axis from this node
   *
   * @param axisNumber The axis to be iterated over
   * @param nodeTest   A pattern to be matched by the returned nodes
   * @return a AxisIterator that scans the nodes reached by the axis in turn.
   * @see net.sf.saxon.om.AxisInfo
   */
  override def iterateAxis(axisNumber: Int, nodeTest: Predicate[_ >: NodeInfo]) = axisNumber match {
    case AxisInfo.ANCESTOR =>
    case AxisInfo.ATTRIBUTE =>
    case AxisInfo.FOLLOWING =>
    case AxisInfo.FOLLOWING_SIBLING =>
    case AxisInfo.NAMESPACE =>
    case AxisInfo.PARENT =>
    case AxisInfo.PRECEDING =>
    case AxisInfo.PRECEDING_SIBLING =>
    case AxisInfo.PRECEDING_OR_ANCESTOR =>
      EmptyIterator.ofNodes
    case AxisInfo.SELF =>
    case AxisInfo.ANCESTOR_OR_SELF =>
      Navigator.filteredSingleton(this, nodeTest)
    case AxisInfo.CHILD =>
    case AxisInfo.DESCENDANT =>
      Navigator.filteredSingleton(getTextNode, nodeTest)
    case AxisInfo.DESCENDANT_OR_SELF =>
      val b1 = nodeTest.test(this)
      val textNode2 = getTextNode
      val b2 = nodeTest.test(textNode2)
      if (b1) if (b2) {
        val pair = Array(this, textNode2)
        new ArrayIterator.OfNodes(pair)
      }
      else SingleNodeIterator.makeIterator(this)
      else if (b2) SingleNodeIterator.makeIterator(textNode2)
      else EmptyIterator.ofNodes
    case _ =>
      throw new IllegalArgumentException("Unknown axis number " + axisNumber)
  }

  /**
   * Find the parent node of this node.
   *
   * @return The Node object describing the containing element or root node.
   */
  override def getParent = null

  /**
   * Get the root node
   *
   * @return the NodeInfo representing the root of this tree
   */
  override def getRoot = this

  /**
   * Copy the result tree fragment value to a given Outputter
   */
  @throws[XPathException]
  override def copy(out: Receiver, copyOptions: Int, locationId: Location) = out.characters(text, locationId, ReceiverOption.NONE)

  /**
   * Get the element with a given ID.
   *
   * @param id        The unique ID of the required element
   * @param getParent True if, in the case of an element of type xs:ID, we want its parent
   * @return null (this kind of tree contains no elements)
   */
  def selectID(id: String, getParent: Boolean) = null

  /**
   * Get the list of unparsed entities defined in this document
   *
   * @return an Iterator, whose items are of type String, containing the names of all
   *         unparsed entities defined in this document. If there are no unparsed entities or if the
   *         information is not available then an empty iterator is returned
   */
  def getUnparsedEntityNames = Collections.emptyIterator

  /**
   * Get the unparsed entity with a given name
   *
   * @param name the name of the entity
   * @return the URI and public ID of the entity if there is one, or null if not
   */
  def getUnparsedEntity(name: String) = null

  /**
   * Make an instance of the text node
   *
   * @return the new or existing instance
   */
  private def getTextNode = {
    if (textNode == null) textNode = new TextFragmentValue#TextFragmentTextNode
    textNode
  }

  /**
   * Inner class representing the text node; this is created on demand
   */
  private class TextFragmentTextNode extends NodeInfo with SourceLocator {
    /**
     * Ask whether this NodeInfo implementation holds a fingerprint identifying the name of the
     * node in the NamePool. If the answer is true, then the {@link #getFingerprint} method must
     * return the fingerprint of the node. If the answer is false, then the {@link #getFingerprint}
     * method should throw an {@code UnsupportedOperationException}. In the case of unnamed nodes
     * such as text nodes, the result can be either true (in which case getFingerprint() should
     * return -1) or false (in which case getFingerprint may throw an exception).
     *
     * @return true if the implementation of this node provides fingerprints.
     * @since 9.8; previously Saxon relied on using <code>FingerprintedNode</code> as a marker interface.
     */
      override def hasFingerprint = true

    /**
     * Get information about the tree to which this NodeInfo belongs
     *
     * @return the TreeInfo
     * @since 9.7
     */
    override def getTreeInfo = treeInfo

    /**
     * Set the system ID for the entity containing the node.
     */
    override def setSystemId(systemId: String) = {
    }

    /**
     * Return the type of node.
     *
     * @return Type.TEXT (always)
     */
    override final def getNodeKind = Type.TEXT

    /**
     * Get the String Value
     */
    override def getStringValue = text.toString

    /**
     * Get the value of the item as a CharSequence. This is in some cases more efficient than
     * the version of the method that returns a String.
     */
    override def getStringValueCS = text

    /**
     * Determine whether this is the same node as another node
     *
     * @return true if this Node object and the supplied Node object represent the
     *         same node in the tree.
     */
    def equals(other: NodeInfo) = this eq other

    /**
     * Get a character string that uniquely identifies this node
     */
    override def generateId(buffer: FastStringBuffer) = {
      buffer.append("tt")
      buffer.append(Long.toString(treeInfo.getDocumentNumber))
      buffer.append("t1")
    }

    /**
     * Get the system ID for the entity containing the node.
     */
    override def getSystemId = null

    /**
     * Get the base URI for the node. Default implementation for child nodes gets
     * the base URI of the parent node.
     */
    override def getBaseURI = baseURI

    /**
     * Determine the relative position of this node and another node, in document order.
     * The other node will always be in the same document.
     *
     * @param other The other node, whose position is to be compared with this node
     * @return -1 if this node precedes the other node, +1 if it follows the other
     *         node, or 0 if they are the same node. (In this case, isSameNode() will always
     *         return true, and the two nodes will produce the same result for generateId())
     */
    override def compareOrder(other: NodeInfo): Int = {
      if (this eq other) return 0
      +1
    }

    /**
     * Get the fingerprint of the node, used for matching names
     */
    override def getFingerprint = -1

    /**
     * Get the prefix part of the name of this node. This is the name before the ":" if any.
     *
     * @return the prefix part of the name. For an unnamed node, return "".
     */
    override def getPrefix = ""

    /**
     * Get the URI part of the name of this node. This is the URI corresponding to the
     * prefix, or the URI of the default namespace if appropriate.
     *
     * @return The URI of the namespace of this node. For an unnamed node, or for
     *         an element or attribute in the default namespace, return an empty string.
     */
    override def getURI = ""

    /**
     * Get the display name of this node. For elements and attributes this is [prefix:]localname.
     * For unnamed nodes, it is an empty string.
     *
     * @return The display name of this node.
     *         For a node with no name, return an empty string.
     */
    override def getDisplayName = ""

    /**
     * Get the local name of this node.
     *
     * @return The local name of this node.
     *         For a node with no name, return "".
     */
    override def getLocalPart = ""

    /**
     * Determine whether the node has any children.
     *
     * @return <code>true</code> if this node has any attributes,
     *         <code>false</code> otherwise.
     */
    override def hasChildNodes = false

    /**
     * Get the string value of a given attribute of this node
     *
     * @param uri   the namespace URI of the attribute name. Supply the empty string for an attribute
     *              that is in no namespace
     * @param local the local part of the attribute name.
     * @return the attribute value if it exists, or null if it does not exist. Always returns null
     *         if this node is not an element.
     * @since 9.4
     */
    override def getAttributeValue(uri: String, local: String) = null

    /**
     * Get an immutable copy of this Location object. By default Location objects may be mutable, so they
     * should not be saved for later use. The result of this operation holds the same location information,
     * but in an immutable form.
     */
    override def saveLocation = this

    /**
     * Get the type annotation of this node, if any. The type annotation is represented as
     * SchemaType object.
     * <p>Types derived from a DTD are not reflected in the result of this method.</p>
     *
     * @return For element and attribute nodes: the type annotation derived from schema
     *         validation (defaulting to xs:untyped and xs:untypedAtomic in the absence of schema
     *         validation). For comments, text nodes, processing instructions, and namespaces: null.
     *         For document nodes, either xs:untyped if the document has not been validated, or
     *         xs:anyType if it has.
     * @since 9.4
     */
    override def getSchemaType = null

    /**
     * Get all namespace undeclarations and undeclarations defined on this element.
     *
     * @param buffer If this is non-null, and the result array fits in this buffer, then the result
     *               may overwrite the contents of this array, to avoid the cost of allocating a new array on the heap.
     * @return An array of integers representing the namespace declarations and undeclarations present on
     *         this element. For a node other than an element, return null. Otherwise, the returned array is a
     *         sequence of namespace codes, whose meaning may be interpreted by reference to the name pool. The
     *         top half word of each namespace code represents the prefix, the bottom half represents the URI.
     *         If the bottom half is zero, then this is a namespace undeclaration rather than a declaration.
     *         The XML namespace is never included in the list. If the supplied array is larger than required,
     *         then the first unused entry will be set to -1.
     *         <p>For a node other than an element, the method returns null.</p>
     */
    override def getDeclaredNamespaces(buffer: Array[NamespaceBinding]) = null

    /**
     * Get all the namespace bindings that are in-scope for this element.
     * <p>For an element return all the prefix-to-uri bindings that are in scope. This may include
     * a binding to the default namespace (represented by a prefix of ""). It will never include
     * "undeclarations" - that is, the namespace URI will never be empty; the effect of an undeclaration
     * is to remove a binding from the in-scope namespaces, not to add anything.</p>
     * <p>For a node other than an element, returns null.</p>
     *
     * @return the in-scope namespaces for an element, or null for any other kind of node.
     */
    override def getAllNamespaces = null

    /**
     * Get the typed value.
     *
     * @return the typed value. If requireSingleton is set to true, the result will always be an
     *         AtomicValue. In other cases it may be a Value representing a sequence whose items are atomic
     *         values.
     * @since 8.5
     */
    @throws[XPathException]
    override def atomize = new UntypedAtomicValue(text)

    /**
     * Return an enumeration over the nodes reached by the given axis from this node
     *
     * @param axisNumber the axis to be iterated over
     * @return a AxisIterator that scans the nodes reached by the axis in turn.
     */
    override def iterateAxis(axisNumber: Int) = axisNumber match {
      case AxisInfo.ANCESTOR =>
      case AxisInfo.PARENT =>
      case AxisInfo.PRECEDING_OR_ANCESTOR =>
        SingleNodeIterator.makeIterator(thisTextFragmentValue)
      case AxisInfo.ANCESTOR_OR_SELF =>
        val nodes = Array(this, thisTextFragmentValue)
        new ArrayIterator.OfNodes(nodes)
      case AxisInfo.ATTRIBUTE =>
      case AxisInfo.CHILD =>
      case AxisInfo.DESCENDANT =>
      case AxisInfo.FOLLOWING =>
      case AxisInfo.FOLLOWING_SIBLING =>
      case AxisInfo.NAMESPACE =>
      case AxisInfo.PRECEDING =>
      case AxisInfo.PRECEDING_SIBLING =>
        EmptyIterator.ofNodes
      case AxisInfo.SELF =>
      case AxisInfo.DESCENDANT_OR_SELF =>
        SingleNodeIterator.makeIterator(this)
      case _ =>
        throw new IllegalArgumentException("Unknown axis number " + axisNumber)
    }

    /**
     * Return an enumeration over the nodes reached by the given axis from this node
     *
     * @param axisNumber the axis to be iterated over
     * @param nodeTest   A condition to be matched by the returned nodes
     * @return a AxisIterator that scans the nodes reached by the axis in turn.
     */
    override def iterateAxis(axisNumber: Int, nodeTest: Predicate[_ >: NodeInfo]) = axisNumber match {
      case AxisInfo.ANCESTOR =>
      case AxisInfo.PARENT =>
      case AxisInfo.PRECEDING_OR_ANCESTOR =>
        Navigator.filteredSingleton(thisTextFragmentValue, nodeTest)
      case AxisInfo.ANCESTOR_OR_SELF =>
        val matchesDoc = nodeTest.test(thisTextFragmentValue)
        val matchesText = nodeTest.test(this)
        if (matchesDoc && matchesText) {
          val nodes = Array(this, thisTextFragmentValue)
          new ArrayIterator.OfNodes(nodes)
        }
        else if (matchesDoc /* && !matchesText */ ) SingleNodeIterator.makeIterator(thisTextFragmentValue)
        else if (matchesText /* && !matchesDoc */ ) SingleNodeIterator.makeIterator(this)
        else EmptyIterator.ofNodes
      case AxisInfo.ATTRIBUTE =>
      case AxisInfo.CHILD =>
      case AxisInfo.DESCENDANT =>
      case AxisInfo.FOLLOWING =>
      case AxisInfo.FOLLOWING_SIBLING =>
      case AxisInfo.NAMESPACE =>
      case AxisInfo.PRECEDING =>
      case AxisInfo.PRECEDING_SIBLING =>
        EmptyIterator.ofNodes
      case AxisInfo.SELF =>
      case AxisInfo.DESCENDANT_OR_SELF =>
        Navigator.filteredSingleton(this, nodeTest)
      case _ =>
        throw new IllegalArgumentException("Unknown axis number " + axisNumber)
    }

    /**
     * Find the parent node of this node.
     *
     * @return The Node object describing the containing element or root node.
     */
    override def getParent = thisTextFragmentValue

    /**
     * Get the root node
     *
     * @return the NodeInfo representing the root of this tree
     */
    override def getRoot = thisTextFragmentValue

    /**
     * Copy the node to a given Outputter
     */
    @throws[XPathException]
    override def copy(out: Receiver, copyOptions: Int, locationId: Location) = out.characters(text, locationId, ReceiverOption.NONE)
  }

}