////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.sort.AtomicMatchKey
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode
import java.util.Objects

/**
 * A value of type xs:dayTimeDuration.
 * <p>Internally this is held as an integer number of seconds held in a positive long, a positive integer
 * number of microseconds in the range 0 to 999,999,999, and a boolean sign. Some of the constructor
 * and accessor methods cannot handle the full range of values.</p>
 */
object DayTimeDurationValue {
  /**
   * Factory method: create a duration value from a supplied string, in
   * ISO 8601 format {@code [-]PnDTnHnMnS}
   *
   * @param s the lexical representation of the xs:dayTimeDuration value
   * @return a { @code DayTimeDurationValue} if the format is correct, or a { @link ValidationFailure} if not
   */
    def makeDayTimeDurationValue(s: CharSequence): ConversionResult = {
      val d = DurationValue.makeDuration(s, false, true)
      if (d.isInstanceOf[ValidationFailure]) return d
      val dv = d.asInstanceOf[DurationValue]
      Converter.DurationToDayTimeDuration.INSTANCE.convert(dv)
    }

  /**
   * Construct a duration value as a number of seconds.
   *
   * @param seconds the number of seconds in the duration. May be negative
   * @return the xs:dayTimeDuration value with the specified length
   * @throws ArithmeticException if the number of (whole) seconds exceeds 2^63
   **/
  def fromSeconds(seconds: BigDecimal) = {
    val sdv = new DayTimeDurationValue
    sdv.negative = seconds.signum < 0
    if (sdv.negative) seconds = seconds.negate
    val wholeSeconds = seconds.toBigInteger
    sdv.seconds = wholeSeconds.longValueExact // ArithmeticException if out of range
    val fractionalPart = seconds.remainder(BigDecimal.ONE)
    val nanoseconds = fractionalPart.multiply(BigDecimalValue.BIG_DECIMAL_ONE_BILLION)
    sdv.nanoseconds = nanoseconds.intValue
    if (sdv.seconds == 0 && sdv.nanoseconds == 0) { // can happen with underflow (division by a very large number)
      sdv.negative = false
    }
    sdv
  }

  /**
   * Construct a duration value as a number of milliseconds.
   *
   * @param milliseconds the number of milliseconds in the duration (may be negative)
   * @return the corresponding xs:dayTimeDuration value
   * @throws ValidationException if implementation-defined limits are exceeded, specifically
   *                             if the total number of seconds exceeds 2^63.
   **/
  @throws[ValidationException]
  def fromMilliseconds(milliseconds: Long) = {
    val sign = Long.signum(milliseconds)
    if (sign < 0) milliseconds = -milliseconds
    try new DayTimeDurationValue(sign, 0, 0, 0, milliseconds / 1000, (milliseconds % 1000).toInt * 1000)
    catch {
      case err: IllegalArgumentException =>
        // limits exceeded
        throw new ValidationFailure("Duration exceeds limits").makeException
    }
  }

  /**
   * Construct a duration value as a number of microseconds.
   *
   * @param microseconds the number of microseconds in the duration.
   * @return the xs:dayTimeDuration represented by the given number of microseconds
   */
  @throws[IllegalArgumentException]
  def fromMicroseconds(microseconds: Long) = {
    val sign = Long.signum(microseconds)
    if (sign < 0) microseconds = -microseconds
    new DayTimeDurationValue(sign, 0, 0, 0, microseconds / 1000000, (microseconds % 1000000).toInt)
  }

  /**
   * Construct a duration value as a number of nanoseconds.
   *
   * @param nanoseconds the number of nanoseconds in the duration.
   * @return the xs:dayTimeDuration represented by the given number of nanoseconds
   */
  @throws[IllegalArgumentException]
  def fromNanoseconds(nanoseconds: Long) = new DayTimeDurationValue(0, 0, 0, nanoseconds / 1000000000L, (nanoseconds % 1000000000L).toInt)

  /**
   * Factory method taking a Java 8 {@link java.time.Duration} object
   *
   * @param duration a duration as a Java 8 { @code java.time.Duration}
   * @since 9.9
   */
  def fromJavaDuration(duration: Duration) = {
    val seconds = duration.getSeconds
    val nanoseconds = duration.getNano
    val negative = false
    if (seconds < 0) new DayTimeDurationValue(0, 0, 0, seconds, -1000000000 + nanoseconds)
    else new DayTimeDurationValue(0, 0, 0, seconds, nanoseconds)
  }
}

final class DayTimeDurationValue private()

/**
 * Private constructor for internal use
 */
  extends DurationValue with Comparable[DayTimeDurationValue] {
  typeLabel = BuiltInAtomicType.DAY_TIME_DURATION

  /**
   * Create a dayTimeDuration given the number of days, hours, minutes, and seconds. This
   * constructor performs limited validation. The components (apart from sign) must all be non-negative
   * integers; they need not be normalized (for example, 36 hours is acceptable)
   * <p>Note: for historic reasons this constructor only supports microsecond precision. For nanosecond
   * precision, use the constructor {@link #DayTimeDurationValue(int, int, int, long, int)}</p>
   *
   * @param sign         positive number for positive durations, negative for negative duratoins
   * @param days         number of days
   * @param hours        number of hours
   * @param minutes      number of minutes
   * @param seconds      number of seconds
   * @param microseconds number of microseconds
   * @throws IllegalArgumentException if the value is out of range; specifically, if the total
   *                                  number of seconds exceeds 2^63; or if any of the values is negative
   **/
  @throws(classOf[IllegalArgumentException])
  def this(sign: Int, days: Int, hours: Int, minutes: Int, seconds: Long, microseconds: Int)={
    this()
    if (days < 0 || hours < 0 || minutes < 0 || seconds < 0 || microseconds < 0) throw new IllegalArgumentException("Negative component value")
    if (days.toDouble * (24 * 60 * 60) + hours.toDouble * (60 * 60) + minutes.toDouble * 60 + seconds.toDouble > Long.MAX_VALUE) throw new IllegalArgumentException("Duration seconds limit exceeded")
    negative = sign < 0
    months = 0
    val h = days.toLong * 24L + hours.toLong
    val m = h * 60L + minutes.toLong
    var s = m * 60L + seconds
    if (microseconds > 1000000) {
      s += microseconds / 1000000
      microseconds %= 1000000
    }
    this.seconds = s
    this.nanoseconds = microseconds * 1000
    if (s == 0 && microseconds == 0) negative = false
    typeLabel = BuiltInAtomicType.DAY_TIME_DURATION
  }

  /**
   * Create a dayTimeDuration given the number of days, hours, minutes, seconds, and nanoseconds. This
   * constructor performs limited validation. The components need not be normalized (for example,
   * 36 hours is acceptable)
   * <p>To construct a positive duration, all the component values should be positive integers (or zero).
   * To construct a negative duration, all the component values should be negative integers (or zero).</p>
   *
   * @param days        number of days
   * @param hours       number of hours
   * @param minutes     number of minutes
   * @param seconds     number of seconds
   * @param nanoseconds number of nanoseconds
   * @throws IllegalArgumentException if the value is out of range; specifically, if the total
   *                                  number of seconds exceeds 2^63; or if some values are positive and
   *                                  others are negative
   **/
  @throws(classOf[IllegalArgumentException])
  def this(days: Int, hours: Int, minutes: Int, seconds: Long, nanoseconds: Int){
    this()
    val somePositive = days > 0 || hours > 0 || minutes > 0 || seconds > 0 || nanoseconds > 0
    val someNegative = days < 0 || hours < 0 || minutes < 0 || seconds < 0 || nanoseconds < 0
    if (somePositive && someNegative) throw new IllegalArgumentException("Some component values are positive and others are negative")
    if (someNegative) {
      negative = true
      days = -days
      hours = -hours
      minutes = -minutes
      seconds = -seconds
      nanoseconds = -nanoseconds
    }
    if (days.toDouble * (24 * 60 * 60) + hours.toDouble * (60 * 60) + minutes.toDouble * 60 + seconds.toDouble > Long.MAX_VALUE) throw new IllegalArgumentException("Duration seconds limit exceeded")
    months = 0
    val h = days.toLong * 24L + hours.toLong
    val m = h * 60L + minutes.toLong
    var s = m * 60L + seconds
    if (nanoseconds > 1000000000) {
      s += nanoseconds / 1000000000
      nanoseconds %= 1000000000
    }
    this.seconds = s
    this.nanoseconds = nanoseconds
    typeLabel = BuiltInAtomicType.DAY_TIME_DURATION
  }

  /**
   * Create a copy of this atomic value, with a different type label
   *
   * @param typeLabel the type label of the new copy. The caller is responsible for checking that
   *                  the value actually conforms to this type.
   */
  /*@NotNull*/ override def copyAsSubType(typeLabel: AtomicType) = {
    val v = DayTimeDurationValue.fromSeconds(getTotalSeconds)
    v.typeLabel = typeLabel
    v
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.DAY_TIME_DURATION

  /**
   * Convert to string
   *
   * @return ISO 8601 representation.
   */
  override def getPrimitiveStringValue = {
    val sb = new FastStringBuffer(32)
    if (negative) sb.cat('-')
    val days = getDays
    val hours = getHours
    val minutes = getMinutes
    val seconds = getSeconds
    sb.cat('P')
    if (days != 0) sb.append(days + "D")
    if (days == 0 || hours != 0 || minutes != 0 || seconds != 0 || nanoseconds != 0) sb.cat('T')
    if (hours != 0) sb.append(hours + "H")
    if (minutes != 0) sb.append(minutes + "M")
    if (seconds != 0 || nanoseconds != 0 || (days == 0 && minutes == 0 && hours == 0)) if (nanoseconds == 0) sb.append(seconds + "S")
    else formatFractionalSeconds(sb, seconds, (seconds * 1000000000L) + nanoseconds)
    sb
  }

  /**
   * Get the length of duration in seconds. Note this may involve loss of precision. For an exact
   * result, use {@link #getTotalSeconds()}
   *
   * @return an approximation to the length of the duration in seconds, expressed as a double.
   */
  override def getLengthInSeconds = {
    val a = seconds + (nanoseconds.toDouble / 1000000000)
    // System.err.println("Duration length " + days + "/" + hours + "/" + minutes + "/" + seconds + " is " + a);
    if (negative) -a
    else a
  }

  /**
   * Get the length of duration in microseconds, as a long
   *
   * @return the length in nanoseconds, divided by one thousand, rounded towards zero
   * @throws ArithmeticException if the number of microseconds is too high to be returned as a long.
   */
  def getLengthInMicroseconds = {
    if (seconds > Long.MAX_VALUE / 1000000L) throw new ArithmeticException("Value is too large to be expressed in microseconds")
    val a = seconds * 1000000L + (nanoseconds / 1000)
    if (negative) -a
    else a
  }

  /**
   * Get the length of duration in microseconds, as a long
   *
   * @return the length in nanoseconds, divided by one thousand, rounded towards zero
   * @throws ArithmeticException if the number of nanoseconds is too high to be returned as a long.
   */
  def getLengthInNanoseconds = {
    if (seconds > Long.MAX_VALUE / 1000000000L) throw new ArithmeticException("Value is too large to be expressed in nanoseconds")
    val a = seconds * 1000000000L + nanoseconds
    if (negative) -a
    else a
  }

  /**
   * Convert this value to a Java 8 {@link java.time.Duration} object
   *
   * @return the duration expressed as a Java 8 { @code java.time.Duration}
   * @since 9.9
   */
  def toJavaDuration = if (negative) java.time.Duration.ofSeconds(-seconds, -nanoseconds)
  else java.time.Duration.ofSeconds(seconds, nanoseconds)

  /**
   * Multiply a duration by an integer
   *
   * @param factor the number to multiply by
   * @return the result of the multiplication
   */
  @throws[XPathException]
  override def multiply(factor: Long) = { // Fast path for simple cases
    if (Math.abs(factor) < 0x7fffffff && Math.abs(seconds) < 0x7fffffff) new DayTimeDurationValue(0, 0, 0, seconds * factor * (if (negative) -1
    else 1), (nanoseconds * factor * (if (negative) -1
    else 1)).toInt)
    else multiply(BigDecimal.valueOf(factor))
  }

  /**
   * Multiply duration by a number. Follows the semantics of op:multiply-dayTimeDuration.
   *
   * @param n the number to multiply by.
   * @throws XPathException if the operand is Infinite or NaN, or if the resulting duration
   *                        exceeds Saxon limits (2^63 seconds)
   **/
  @throws[XPathException]
  override def multiply(n: Double) = {
    if (Double.isNaN(n)) {
      val err = new XPathException("Cannot multiply a duration by NaN")
      err.setErrorCode("FOCA0005")
      throw err
    }
    if (Double.isInfinite(n)) {
      val err = new XPathException("Cannot multiply a duration by infinity")
      err.setErrorCode("FODT0002")
      throw err
    }
    val factor = BigDecimal.valueOf(n)
    multiply(factor)
  }

  @throws[XPathException]
  private def multiply(factor: BigDecimal) = {
    val secs = getTotalSeconds
    val product = secs.multiply(factor)
    try DayTimeDurationValue.fromSeconds(product)
    catch {
      case err@(_: IllegalArgumentException | _: ArithmeticException) =>
        if (err.getCause.isInstanceOf[XPathException]) throw err.getCause.asInstanceOf[XPathException]
        else {
          val err2 = new XPathException("Overflow when multiplying a duration by a number", err)
          err2.setErrorCode("FODT0002")
          throw err2
        }
    }
  }

  /**
   * Divide duration by a number. Follows the semantics of op:divide-dayTimeDuration.
   *
   * @param n the number to divide by.
   * @throws XPathException if the operand is zero or NaN, or if the resulting duration
   *                        exceeds Saxon limits (2^63 seconds)
   **/
  @throws[XPathException]
  override def divide(n: Double) = {
    if (Double.isNaN(n)) {
      val err = new XPathException("Cannot divide a duration by NaN")
      err.setErrorCode("FOCA0005")
      throw err
    }
    if (n == 0) {
      val err = new XPathException("Cannot divide a duration by zero")
      err.setErrorCode("FODT0002")
      throw err
    }
    val secs = getTotalSeconds
    val product = secs.divide(BigDecimal.valueOf(n))
    try DayTimeDurationValue.fromSeconds(product)
    catch {
      case err@(_: IllegalArgumentException | _: ArithmeticException) =>
        if (err.getCause.isInstanceOf[XPathException]) throw err.getCause.asInstanceOf[XPathException]
        else {
          val err2 = new XPathException("Overflow when dividing a duration by a number", err)
          err2.setErrorCode("FODT0002")
          throw err2
        }
    }
  }

  /**
   * Find the ratio between two durations
   *
   * @param other the dividend
   * @return the ratio, as a decimal
   * @throws XPathException when dividing by zero, or when dividing two durations of different type
   */
  @throws[XPathException]
  override def divide(other: DurationValue) = if (other.isInstanceOf[DayTimeDurationValue]) {
    val v1 = getTotalSeconds
    val v2 = other.getTotalSeconds
    if (v2.signum == 0) {
      val err = new XPathException("Divide by zero (durations)")
      err.setErrorCode("FOAR0001")
      throw err
    }
    new BigDecimalValue(v1.divide(v2, 20, RoundingMode.HALF_EVEN))
  }
  else {
    val err = new XPathException("Cannot divide two durations of different type")
    err.setErrorCode("XPTY0004")
    throw err
  }

  /**
   * Add two dayTimeDurations
   */
  @throws[XPathException]
  override def add(other: DurationValue) = if (other.isInstanceOf[DayTimeDurationValue]) {
    val d2 = other.asInstanceOf[DayTimeDurationValue]
    if (((seconds | d2.seconds) & 0xffffffff00000000L) != 0) { // risk of complications, use BigDecimal arithmetic
      try {
        val v1 = getTotalSeconds
        val v2 = other.getTotalSeconds
        DayTimeDurationValue.fromSeconds(v1.add(v2))
      } catch {
        case e: IllegalArgumentException =>
          val err = new XPathException("Overflow when adding two durations")
          err.setErrorCode("FODT0002")
          throw err
      }
    }
    else { // fast path for common case: no risk of overflow
      DayTimeDurationValue.fromNanoseconds(getLengthInNanoseconds + d2.getLengthInNanoseconds)
    }
  }
  else {
    val err = new XPathException("Cannot add two durations of different type")
    err.setErrorCode("XPTY0004")
    throw err
  }

  /**
   * Subtract two dayTime-durations
   */
  @throws[XPathException]
  override def subtract(other: DurationValue) = if (other.isInstanceOf[DayTimeDurationValue]) {
    val d2 = other.asInstanceOf[DayTimeDurationValue]
    if (((seconds | d2.seconds) & 0xffffffff00000000L) != 0) try {
      val v1 = getTotalSeconds
      val v2 = other.getTotalSeconds
      DayTimeDurationValue.fromSeconds(v1.subtract(v2))
    } catch {
      case e: IllegalArgumentException =>
        val err = new XPathException("Overflow when subtracting two durations")
        err.setErrorCode("FODT0002")
        throw err
    }
    else DayTimeDurationValue.fromNanoseconds(getLengthInNanoseconds - d2.getLengthInNanoseconds)
  }
  else {
    val err = new XPathException("Cannot subtract two durations of different type")
    err.setErrorCode("XPTY0004")
    throw err
  }

  /**
   * Negate a duration (same as subtracting from zero, but it preserves the type of the original duration)
   *
   * @throws IllegalArgumentException in the extremely unlikely event that the duration is one that cannot
   *                                  be negated (because the limit for positive durations is one second
   *                                  off from the limit for negative durations)
   */
  @throws[IllegalArgumentException]
  override def negate = {
    val d2 = new DayTimeDurationValue
    d2.setTypeLabel(typeLabel)
    d2.seconds = seconds
    d2.nanoseconds = nanoseconds
    d2.negative = !negative
    d2
  }

  /**
   * Compare the value to another duration value
   *
   * @param other The other dateTime value
   * @return negative value if this one is the smaller, 0 if they are equal,
   *         positive value if this one is the greater.
   * @throws NullPointerException if the other value is null
   */
  override def compareTo(other: DayTimeDurationValue) = {
    Objects.requireNonNull(other)
    if (this.negative != other.negative) if (this.negative) -1
    else +1
    else if (this.seconds != other.seconds) Long.compare(this.seconds, other.seconds) * (if (this.negative) -1
    else +1)
    else Integer.compare(this.nanoseconds, other.nanoseconds) * (if (this.negative) -1
    else +1)
  }

  /**
   * Get a Comparable value that implements the XPath ordering comparison semantics for this value.
   * Returns null if the value is not comparable according to XPath rules. The default implementation
   * returns the value itself. This is modified for types such as
   * xs:duration which allow ordering comparisons in XML Schema, but not in XPath.
   *
   * @param ordered          true if an ordered comparable is needed
   * @param collator         Collation used for string comparison
   * @param implicitTimezone XPath dynamic context
   */
  override def getXPathComparable(ordered: Boolean, collator: StringCollator, implicitTimezone: Int) = this
}