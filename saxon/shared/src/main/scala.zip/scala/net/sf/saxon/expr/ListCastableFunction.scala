////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.lib.ConversionRules
import net.sf.saxon.model._
import net.sf.saxon.om.NamespaceResolver
import net.sf.saxon.om.Sequence
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value._

/**
 * A function item representing a castability test for a list type
 */
class ListCastableFunction @throws[MissingComponentException]
(val targetType: ListType, val resolver: NamespaceResolver, val allowEmpty: Boolean)

/**
 * Create the constructor function.
 *
 * @param targetType the type to which the function will convert its input
 * @param resolver   namespace resolver for use if the target type is namespace-sensitive
 */
  extends ListConstructorFunction(targetType, resolver, allowEmpty) {
  /**
   * Get the item type of the function item
   *
   * @return the function item's type
   */
  override def getFunctionItemType = new SpecificFunctionType(Array[SequenceType](SequenceType.ANY_SEQUENCE), SequenceType.SINGLE_BOOLEAN)

  /**
   * Get the name of the function, or null if it is anonymous
   *
   * @return the function name, or null for an anonymous inline function
   */
  override def getFunctionName = null

  /**
   * Invoke the function
   *
   * @param context the XPath dynamic evaluation context
   * @param args    the actual arguments to be supplied
   * @return the result of invoking the function
   * @throws net.sf.saxon.trans.XPathException
   * if a dynamic error occurs within the function
   */
  @throws[XPathException]
  override def call(context: XPathContext, args: Array[Sequence]): BooleanValue = {
    val iter = args(0).iterate
    val `val` = iter.next.asInstanceOf[AtomicValue]
    if (`val` == null) return BooleanValue.get(allowEmpty)
    if (iter.next != null) return BooleanValue.FALSE
    if (!`val`.isInstanceOf[StringValue] || `val`.isInstanceOf[AnyURIValue]) return BooleanValue.FALSE
    val rules = context.getConfiguration.getConversionRules
    val cs = `val`.getStringValueCS
    val failure = targetType.validateContent(cs, nsResolver, rules)
    BooleanValue.get(failure == null)
  }
}