////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.value

import net.sf.saxon.expr.sort.AtomicMatchKey
import net.sf.saxon.expr.sort.AtomicSortComparer
import net.sf.saxon.expr.sort.DoubleSortComparer
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.Converter
import net.sf.saxon.model.ValidationException
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.util.FastStringBuffer
import java.math.BigDecimal

/**
 * A numeric (single precision floating point) value
 */
object FloatValue {
  val ZERO = new FloatValue(0.0.toFloat)
  val NEGATIVE_ZERO = new FloatValue(-0.0.toFloat)
  val ONE = new FloatValue(1.0.toFloat)
  val NaN = new FloatValue(Float.NaN)

  /**
   * Static factory method (for convenience in compiled bytecode)
   *
   * @param value the value of the float
   * @return the FloatValue
   */
  def makeFloatValue(value: Float) = new FloatValue(value)

  /**
   * Internal method used for conversion of a float to a string
   *
   * @param value the actual value
   * @return the value converted to a string, according to the XPath casting rules.
   */
  def floatToString(value: Float) = FloatingPointConverter.appendFloat(new FastStringBuffer(FastStringBuffer.C16), value, false)
}

final class FloatValue extends NumericValue {
  private var value = .0

  /**
   * Constructor supplying a float
   *
   * @param value the value of the float
   */
  def this(value: Float) {
    this()
    this.value = value
    typeLabel = BuiltInAtomicType.FLOAT
  }

  /**
   * Constructor supplying a float and an AtomicType, for creating
   * a value that belongs to a user-defined subtype of xs:float. It is
   * the caller's responsibility to ensure that the supplied value conforms
   * to the supplied type.
   *
   * @param value the value of the NumericValue
   * @param type  the type of the value. This must be a subtype of xs:float, and the
   *              value must conform to this type. The method does not check these conditions.
   */
  def this(value: Float, `type`: AtomicType) {
    this()
    this.value = value
    typeLabel = `type`
  }

  /**
   * Create a copy of this atomic value, with a different type label
   *
   * @param typeLabel the type label of the new copy. The caller is responsible for checking that
   *                  the value actually conforms to this type.
   */
  override def copyAsSubType(typeLabel: AtomicType) = {
    val v = new FloatValue(value)
    v.typeLabel = typeLabel
    v
  }

  /**
   * Determine the primitive type of the value. This delivers the same answer as
   * getItemType().getPrimitiveItemType(). The primitive types are
   * the 19 primitive types of XML Schema, plus xs:integer, xs:dayTimeDuration and xs:yearMonthDuration,
   * and xs:untypedAtomic. For external objects, the result is AnyAtomicType.
   */
  override def getPrimitiveType = BuiltInAtomicType.FLOAT

  /**
   * Get the value
   */
  override def getFloatValue = value

  override def getDoubleValue = value.toDouble

  /**
   * Get the numeric value converted to a decimal
   *
   * @return a decimal representing this numeric value;
   * @throws ValidationException
   * if the value cannot be converted, for example if it is NaN or infinite
   */
  @throws[ValidationException]
  override def getDecimalValue = new BigDecimal(value.toDouble)

  /**
   * Return the numeric value as a Java long.
   *
   * @return the numeric value as a Java long. This performs truncation
   *         towards zero.
   * @throws net.sf.saxon.trans.XPathException
   * if the value cannot be converted
   */
  @throws[XPathException]
  override def longValue = value.toLong

  /**
   * Get the hashCode. This must conform to the rules for other NumericValue hashcodes
   *
   * @see NumericValue#hashCode
   */
  override def hashCode = if (value > Integer.MIN_VALUE && value < Integer.MAX_VALUE) value.toInt
  else Double.valueOf(getDoubleValue).hashCode

  /**
   * Test whether the value is the double/float value NaN
   */
  override def isNaN = Float.isNaN(value)

  /**
   * Get the effective boolean value
   *
   * @return true unless the value is zero or NaN
   */
  override def effectiveBooleanValue = value != 0.0 && !(Float.isNaN(value))

  /**
   * Get the value as a String
   *
   * @return a String representation of the value
   */
  /*@NotNull*/ override def getPrimitiveStringValue = FloatValue.floatToString(value)

  /**
   * Get the canonical lexical representation as defined in XML Schema. This is not always the same
   * as the result of casting to a string according to the XPath rules. For xs:float, the canonical
   * representation always uses exponential notation.
   */
  override def getCanonicalLexicalRepresentation = {
    val fsb = new FastStringBuffer(FastStringBuffer.C16)
    FloatingPointConverter.appendFloat(fsb, value, true)
  }

  /**
   * Negate the value
   */
  override def negate = new FloatValue(-value)

  /**
   * Implement the XPath floor() function
   */
  override def floor = new FloatValue(Math.floor(value).toFloat)

  /**
   * Implement the XPath ceiling() function
   */
  override def ceiling = new FloatValue(Math.ceil(value).toFloat)

  /**
   * Implement the XPath round() function
   */
  override def round(scale: Int): NumericValue = {
    if (Float.isNaN(value)) return this
    if (Float.isInfinite(value)) return this
    if (value == 0.0) return this // handles the negative zero case
    if (scale == 0 && value > Integer.MIN_VALUE && value < Integer.MAX_VALUE) {
      if (value >= -0.5 && value < 0.0) return new FloatValue(-0.0f)
      return new FloatValue(value.round.toFloat)
    }
    var d = new DoubleValue(getDoubleValue)
    d = d.round(scale).asInstanceOf[DoubleValue]
    new FloatValue(d.getFloatValue)
  }

  /**
   * Implement the XPath round-to-half-even() function
   */
  override def roundHalfToEven(scale: Int) = {
    var d = new DoubleValue(getDoubleValue)
    d = d.roundHalfToEven(scale).asInstanceOf[DoubleValue]
    new FloatValue(d.getFloatValue)
  }

  /**
   * Determine whether the value is negative, zero, or positive
   *
   * @return -1 if negative, 0 if zero (including negative zero), +1 if positive, NaN if NaN
   */
  override def signum: Int = {
    if (Float.isNaN(value)) return 0
    compareTo(0)
  }

  /**
   * Ask whether this value is negative zero
   *
   * @return true if this value is float or double negative zero
   */
  override def isNegativeZero = value == 0.0 && ((Float.floatToIntBits(value) & FloatingPointConverter.FLOAT_SIGN_MASK) ne 0)

  /**
   * Determine whether the value is a whole number, that is, whether it compares
   * equal to some integer
   */
  override def isWholeNumber = value == Math.floor(value) && !Float.isInfinite(value)

  /**
   * Test whether a number is a possible subscript into a sequence, that is,
   * a whole number greater than zero and less than 2^31
   *
   *
   * @return the number as an int if it is a possible subscript, or -1 otherwise
   */
  override def asSubscript = if (isWholeNumber && value > 0 && value <= Integer.MAX_VALUE) value.toInt
  else -1

  /**
   * Get the absolute value as defined by the XPath abs() function
   *
   * @return the absolute value
   * @since 9.2
   */
  override def abs = if (value > 0.0) this
  else new FloatValue(Math.abs(value))

  override def compareTo(other: NumericValue): Int = {
    if (other.isInstanceOf[FloatValue]) {
      val otherFloat = other.asInstanceOf[FloatValue].value
      // Do not rewrite as Float.compare() - see IntelliJ bug IDEA-196419
      if (value == otherFloat) return 0
      else if (value < otherFloat) return -1
      else return +1
    }
    if (other.isInstanceOf[DoubleValue]) return super.compareTo(other)
    compareTo(Converter.NumericToFloat.INSTANCE.convert(other))
  }

  /**
   * Compare the value to a long
   *
   * @param other the value to be compared with
   * @return -1 if this is less, 0 if this is equal, +1 if this is greater or if this is NaN
   */
  override def compareTo(other: Long): Int = {
    val otherFloat = other.toFloat
    if (value == otherFloat) return 0
    if (value < otherFloat) -1
    else +1
  }

  /**
   * Get an object that implements XML Schema comparison semantics
   */
  override def getSchemaComparable = { // Convert negative to positive zero because Float.compareTo() does the wrong thing
    // Note that for NaN, we return NaN, and rely on the user of the Comparable to use it in a way
    // that ensures NaN != NaN.
    if (value == 0.0f) 0.0f
    else value
  }

  /**
   * Get a value whose equals() method follows the "same key" rules for comparing the keys of a map.
   *
   * @return a value with the property that the equals() and hashCode() methods follow the rules for comparing
   *         keys in maps.
   */
  override def asMapKey = if (isNaN) AtomicSortComparer.COLLATION_KEY_NaN
  else if (Double.isInfinite(value)) new DoubleValue(value)
  else try new BigDecimalValue(value)
  catch {
    case e: ValidationException =>
      // We have already ruled out the values that fail (NaN and INF)
      throw new AssertionError(e)
  }

  /**
   * Determine whether two atomic values are identical, as determined by XML Schema rules. This is a stronger
   * test than equality (even schema-equality); for example two dateTime values are not identical unless
   * they are in the same timezone.
   * <p>Note that even this check ignores the type annotation of the value. The integer 3 and the short 3
   * are considered identical, even though they are not fully interchangeable. "Identical" means the
   * same point in the value space, regardless of type annotation.</p>
   * <p>NaN is identical to itself.</p>
   *
   * @param v the other value to be compared with this one
   * @return true if the two values are identical, false otherwise.
   */
  override def isIdentical(v: AtomicValue) = v.isInstanceOf[FloatValue] && DoubleSortComparer.getInstance.comparesEqual(this, v.asInstanceOf[FloatValue])

  override def asAtomic = this
}