////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.event.PipelineConfiguration
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.event.SequenceWriter
import net.sf.saxon.expr.parser.Loc
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om._
import net.sf.saxon.trans.XPathException

/**
 * This class implements a Receiver that can receive xsl:message output and send it to a
 * user-supplied MessageListener.
 */
class MessageListener2Proxy protected(var listener: MessageListener2, val pipe: PipelineConfiguration) extends SequenceWriter(pipe) { // See bug 2104. We use the Linked Tree model because the TinyTree can use excessive memory. This
  // is because the initial size allocation is based on the size of source documents, which might be large;
  // also because we store several messages in a single TinyTree; and because we fail to condense the tree.
  setTreeModel(TreeModel.LINKED_TREE)
  private var terminate = false
  private var locationId = null
  private var errorCode = null

  /**
   * Get the wrapped MessageListener
   *
   * @return the wrapped MessageListener
   */
  def getMessageListener = listener

  /**
   * Start of a document node.
   *
   * @param properties
   */
  @throws[XPathException]
  override def startDocument(properties: Int) = {
    terminate = ReceiverOption.contains(properties, ReceiverOption.TERMINATE)
    locationId = null
    errorCode = null
    super.startDocument(properties)
  }

  /**
   * Output an element start tag.
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    if (this.locationId == null) this.locationId = location
    super.startElement(elemName, `type`, attributes, namespaces, location, properties)
  }

  /**
   * Produce text content output. <BR>
   *
   * @param s          The String to be output
   * @param locationId the location of the node in the source, or of the instruction that created it
   * @param properties bit-significant flags for extra information, e.g. disable-output-escaping  @throws net.sf.saxon.trans.XPathException
   */
  @throws[XPathException]
  override def characters(s: CharSequence, locationId: Location, properties: Int) = {
    if (this.locationId == null) this.locationId = locationId
    super.characters(s, locationId, properties)
  }

  @throws[XPathException]
  override def processingInstruction(target: String, data: CharSequence, locationId: Location, properties: Int) = if (target == "error-code" && errorCode == null) errorCode = StructuredQName.fromEQName(data)
  else super.processingInstruction(target, data, locationId, properties)

  /**
   * Append an item to the sequence, performing any necessary type-checking and conversion
   */
  @throws[XPathException]
  override def append(item: Item, locationId: Location, copyNamespaces: Int) = {
    if (this.locationId == null) this.locationId = locationId
    super.append(item, locationId, copyNamespaces)
  }

  /**
   * Abstract method to be supplied by subclasses: output one item in the sequence.
   *
   * @param item the item to be written to the sequence
   */
  @throws[XPathException]
  override def write(item: Item) = {
    var loc = null
    if (locationId == null) loc = Loc.NONE
    else loc = locationId.saveLocation
    listener.message(new XdmNode(item.asInstanceOf[NodeInfo]), new QName(errorCode), terminate, loc)
  }
}