////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.Type
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * An xsl:stylesheet or xsl:transform element in the stylesheet. <br>
 * Note this element represents a stylesheet module, not necessarily
 * the whole stylesheet. However, much of the functionality (and the fields)
 * are relevant only to the top-level module.
 */
class XSLStylesheet extends XSLModuleRoot {
  override protected def mayContainParam = true

  /**
   * Prepare the attributes on the stylesheet element
   */
  override def prepareAttributes() = {
    processDefaultCollationAttribute()
    processDefaultMode()
    var inputTypeAnnotationsAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "version" =>
        // already processed
        case "id" =>
        //
        case "extension-element-prefixes" =>
        case "exclude-result-prefixes" =>
        case "input-type-annotations" =>
          inputTypeAnnotationsAtt = value
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (version == -1 && (getParent == null || getParent.getNodeKind == Type.DOCUMENT)) reportAbsence("version")
    if (inputTypeAnnotationsAtt != null) inputTypeAnnotationsAtt match {
      case "strip" =>
      //setInputTypeAnnotations(ANNOTATION_STRIP);
      case "preserve" =>
      //setInputTypeAnnotations(ANNOTATION_PRESERVE);
      case "unspecified" =>
      case _ =>
        invalidAttribute("input-type-annotations", "strip|preserve|unspecified")
    }
  }

  /**
   * Validate this element
   *
   * @param decl Not used
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    if (validationError != null) compileError(validationError)
    if (getParent != null && getParent.getNodeKind != Type.DOCUMENT) compileError(getDisplayName + " must be the outermost element", "XTSE0010")
    import scala.collection.JavaConversions._
    for (curr <- children) {
      if (curr.getNodeKind == Type.TEXT || (curr.isInstanceOf[StyleElement] && curr.asInstanceOf[StyleElement].isDeclaration) || curr.isInstanceOf[DataElement]) {
        // all is well
      }
      else if (curr.isInstanceOf[StyleElement]) if (!(NamespaceConstant.XSLT == curr.getURI) && !("" == curr.getURI)) {
        // elements in other namespaces are allowed and ignored
      }
      else if (curr.isInstanceOf[AbsentExtensionElement] && curr.asInstanceOf[StyleElement].forwardsCompatibleModeIsEnabled) {
        // this is OK: an unknown XSLT element is allowed in forwards compatibility mode
      }
      else if (NamespaceConstant.XSLT == curr.getURI) curr.asInstanceOf[StyleElement].compileError("Element " + curr.getDisplayName + " must not appear directly within " + getDisplayName, "XTSE0010")
      else curr.asInstanceOf[StyleElement].compileError("Element " + curr.getDisplayName + " must not appear directly within " + getDisplayName + " because it is not in a namespace", "XTSE0130")
    }
  }
}