////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.xpath

import javax.xml.namespace.QName
import javax.xml.transform.sax.SAXSource
import javax.xml.xpath.{XPathConstants, XPathExpression, XPathExpressionException}
import net.sf.saxon.expr._
import net.sf.saxon.expr.instruct.{Executable, SlotManager}
import net.sf.saxon.functions.Number_1
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.wrapper.VirtualNode
import net.sf.saxon.value.{AtomicValue, NumericValue}
import org.xml.sax.InputSource

/**
 * <p>The JAXP XPathExpression interface represents a compiled XPath expression that can be repeatedly
 * evaluated. This class is Saxon's implementation of that interface.</p>
 * <p>The class also includes some methods retained from Saxon's original XPath API. When these methods
 * are used, the object contains the context node and other state, so it is not thread-safe.</p>
 *
 * @author Michael H. Kay
 */
class XPathExpressionImpl protected(var expression: Nothing, var executable: Executable)

/**
 * The constructor is protected, to ensure that instances can only be
 * created using the compile() method of XPathEvaluator
 *
 * @param exp  the compiled expression
 * @param exec the executable
 */
/*@NotNull*/ extends XPathExpression {
  configuration = executable.getConfiguration
  private var config = null
  private var atomizer = null
  private var stackFrameMap = null

  /**
   * Define the number of slots needed for local variables within the expression.
   * This method is for internal use only.
   *
   * @param map description of the stack frame
   */
  protected def setStackFrameMap(map: SlotManager) = stackFrameMap = map

  /**
   * Get the stack frame map. This holds information about the allocation of slots to variables.
   * This is needed by applications using low-level interfaces for evaluating the expression
   *
   * @return a description of the stack frame
   */
  def getStackFrameMap = stackFrameMap

  /**
   * Get the Configuration under which this XPath expression was compiled
   *
   * @return the Saxon configuration
   */
  def getConfiguration = config

  /**
   * JAXP 1.3 evaluate() method
   *
   * @param node The context node. This must use a representation of nodes that this implementation understands.
   *             This may be a Saxon NodeInfo, or a node in one of the external object models supported, for example
   *             DOM, DOM4J, JDOM, or XOM, provided the support module for that object model is loaded.
   *             <p>An instance of { @link TreeInfo} is also accepted.</p>
   *
   *                                       <p><b>Contrary to the interface specification, Saxon does not supply an empty
   *                                       document when the value is null. This is because XPath 2.0 allows the context
   *                                       item to be "absent" (null). So Saxon executes the XPath expression with the
   *                                       context item undefined.</b></p>
   * @param qName Indicates the type of result required. This must be one of the constants defined in
   *              the JAXP { @link XPathConstants} class.
   *                               Saxon will attempt to convert the actual result of the expression to the required type using the
   *                               XPath 1.0 conversion rules.
   * @return the result of the evaluation, as a Java object of the appropriate type. Saxon interprets the
   *         rules as follows:
   *         <table>
   *         <thead><tr><td>QName</td><td>Return Value</td></thead>
   *         <tbody>
   *         <tr><td valign="top">BOOLEAN</td>
   *         <td>The effective boolean value of the actual result,
   *         as a Java Boolean object</td></tr>
   *         <tr><td valign="top">STRING</td>
   *         <td>The result of applying the string() function to the actual result,
   *         as a Java String object</td></tr>
   *         <tr><td valign="top">NUMBER</td>
   *         <td>The result of applying the number() function to the actual result,
   *         as a Java Double object</td></tr>
   *         <tr><td valign="top">NODE</td>
   *         <td>A single node, in the native data model supplied as input. If the
   *         expression returns more than one node, the first is returned. If
   *         the expression returns an empty sequence, null is returned. If the
   *         expression returns an atomic value, or if the first item in the
   *         result sequence is an atomic value, an exception is thrown.</td></tr>
   *         <tr><td valign="top">NODESET</td>
   *         <td>This is interpreted as allowing any sequence, of nodes or atomic values.
   *         If the first argument is a wrapper around a DOM Node, then the result is
   *         returned as a DOM NodeList, and an exception is then thrown if the result sequence
   *         contains a value that is not a DOM Node. In all other cases
   *         the result is returned as a Java List object, unless it is empty, in which
   *         case null is returned. The contents of the list may be node objects (in the
   *         native data model supplied as input), or Java objects representing the XPath
   *         atomic values in the actual result: String for an xs:string, Double for a xs:double,
   *         Long for an xs:integer, and so on. (For safety, cast the values to a type
   *         such as xs:string within the XPath expression). </td></tr></tbody></table>
   * @throws XPathExpressionException if evaluation of the expression fails or if the
   *                                  result cannot be converted to the requested type.
   */
  /*@Nullable*/ @throws[XPathExpressionException]
  override def evaluate(node: Any, qName: QName): Any = {
    var contextItem = null
    if (node.isInstanceOf[Nothing]) node = node.asInstanceOf[Nothing].head
    if (node.isInstanceOf[Nothing]) node = node.asInstanceOf[Nothing].getRootNode
    if (node.isInstanceOf[Nothing]) {
      if (!(node.asInstanceOf[Nothing]).getConfiguration.isCompatible(config)) throw new XPathExpressionException("Supplied node must be built using the same or a compatible Configuration")
      if (node.isInstanceOf[Nothing] && node.asInstanceOf[Nothing].isTyped && !executable.isSchemaAware) throw new XPathExpressionException("The expression was compiled to handled untyped data, but the input is typed")
      contextItem = node.asInstanceOf[Nothing]
    }
    else if (node.isInstanceOf[Nothing]) contextItem = node.asInstanceOf[Nothing]
    else {
      val converter = JPConverter.allocate(node.getClass, null, config)
      var `val` = null
      try `val` = converter.convert(node, new Nothing(config))
      catch {
        case e: XPathException =>
          throw new XPathExpressionException("Failure converting a node of class " + node.getClass.getName + ": " + e.getMessage)
      }
      if (`val`.isInstanceOf[Nothing]) {
        if (!(`val`.asInstanceOf[Nothing]).getConfiguration.isCompatible(config)) throw new XPathExpressionException("Supplied node must be built using the same or a compatible Configuration")
        if (`val`.asInstanceOf[Nothing].getTreeInfo.isTyped && !executable.isSchemaAware) throw new XPathExpressionException("The expression was compiled to handled untyped data, but the input is typed")
        contextItem = `val`.asInstanceOf[Nothing]
      }
      else throw new XPathExpressionException("Cannot locate an object model implementation for nodes of class " + node.getClass.getName)
    }
    val context = new Nothing(contextItem, executable)
    context.openStackFrame(stackFrameMap)
    try if (qName == XPathConstants.BOOLEAN) expression.effectiveBooleanValue(context)
    else if (qName == XPathConstants.STRING) {
      val iter = expression.iterate(context)
      val first = iter.next
      if (first == null) return ""
      first.getStringValue
    }
    else if (qName == XPathConstants.NUMBER) {
      if (atomizer == null) atomizer = Atomizer.makeAtomizer(expression, null)
      val iter = atomizer.iterate(context)
      val first = iter.next
      if (first == null) return Double.NaN
      if (first.isInstanceOf[NumericValue]) first.asInstanceOf[NumericValue].getDoubleValue
      else {
        val v = Number_1.convert(first.asInstanceOf[AtomicValue], getConfiguration)
        v.getDoubleValue
      }
    }
    else if (qName == XPathConstants.NODE) {
      val iter = expression.iterate(context)
      val first = iter.next
      if (first.isInstanceOf[VirtualNode]) return first.asInstanceOf[VirtualNode].getRealNode
      if (first == null || first.isInstanceOf[Nothing]) return first
      throw new XPathExpressionException("Expression result is not a node")
    }
    else if (qName == XPathConstants.NODESET) {
      context.openStackFrame(stackFrameMap)
      val iter = expression.iterate(context)
      val extent = iter.materialize
      val converter = PJConverter.allocateNodeListCreator(config, node)
      converter.convert(extent, classOf[Any], context)
    }
    else throw new IllegalArgumentException("qName: Unknown type for expected result")
    catch {
      case e: XPathException =>
        throw new XPathExpressionException(e)
    }
  }

  /**
   * Evaluate the expression to return a string value
   *
   * @param node the initial context node. This must be either an instance of NodeInfo or a node
   *             recognized by a known external object model.
   *             <p><b>Contrary to the interface specification, Saxon does not supply an empty
   *             document when the value is null. This is because XPath 2.0 allows the context
   *             item to be "absent" (null). So Saxon executes the XPath expression with the
   *             context item undefined.</b></p>
   * @return the results of the expression, converted to a String
   * @throws XPathExpressionException if evaluation fails
   */
  @throws[XPathExpressionException]
  override def evaluate(node: Any) = evaluate(node, XPathConstants.STRING).asInstanceOf[String]

  /**
   * Evaluate the XPath expression against an input source to obtain a result of a specified type
   *
   * @param inputSource The input source document against which the expression is evaluated.
   *                    <p>If any error occurs reading or parsing this document, the error is notified
   *                    to the { @link ErrorListener} registered with the { @link Configuration},
   *                                   and also causes an exception to be thrown. </p>
   *                                   <p>(Note that there is no caching. This will be parsed, and
   *                                   the parsed result will be discarded.) </p>
   *                                   <p>If the supplied value is null then (contrary to the JAXP specifications), the XPath expression
   *                                   is evaluated with the context item undefined.</p>
   * @param qName The type required, identified by a constant in { @link XPathConstants}
   * @return the result of the evaluation, as a Java object of the appropriate type:
   *         see { @link #evaluate(Object, javax.xml.namespace.QName)}
   * @throws XPathExpressionException
   */
  @throws[XPathExpressionException]
  override def evaluate(inputSource: InputSource, qName: QName) = {
    if (qName == null) throw new NullPointerException("qName")
    try {
      var doc = null
      if (inputSource != null) doc = config.buildDocumentTree(new SAXSource(inputSource)).getRootNode
      evaluate(doc, qName)
    } catch {
      case e: XPathException =>
        throw new XPathExpressionException(e)
    }
  }

  /**
   * Evaluate the XPath expression against an input source to obtain a string result.
   *
   * @param inputSource The input source document against which the expression is evaluated.
   *                    <p>If any error occurs reading or parsing this document, the error is notified
   *                    to the { @link ErrorListener} registered with the { @link Configuration},
   *                                   and also causes an exception to be thrown. </p>
   *                                   <p>(Note that there is no caching. This will be parsed, and
   *                                   the parsed result will be discarded.) </p>
   *                                   <p>If the supplied value is null then (contrary to the JAXP specifications), the XPath expression
   *                                   is evaluated with the context item undefined.</p>
   * @return the result of the evaluation, converted to a String
   * @throws XPathExpressionException in the event of an XPath dynamic error
   * @throws NullPointerException     If  <code>inputSource</code> is <code>null</code>.
   */
  @throws[XPathExpressionException]
  override def evaluate(inputSource: InputSource) = {
    if (inputSource == null) throw new NullPointerException("inputSource")
    try {
      val doc = config.buildDocumentTree(new SAXSource(inputSource)).getRootNode
      evaluate(doc, XPathConstants.STRING).asInstanceOf[String]
    } catch {
      case e: XPathException =>
        throw new XPathExpressionException(e)
    }
  }

  /**
   * Low-level method to get the internal Saxon expression object. This exposes a wide range of
   * internal methods that may be needed by specialized applications, and allows greater control
   * over the dynamic context for evaluating the expression.
   *
   * @return the underlying Saxon expression object.
   */
  def getInternalExpression = expression
}