////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException

/**
 * Handler for xsl:matching-substring and xsl:non-matching-substring elements in stylesheet.
 * New at XSLT 2.0<BR>
 */
class XSLMatchingSubstring extends StyleElement {
  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      checkUnknownAttribute(attName)
    }
  }

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = if (!getParent.isInstanceOf[XSLAnalyzeString]) compileError(getDisplayName + " must be immediately within xsl:analyze-string", "XTSE0010")

  /*@NotNull*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = throw new UnsupportedOperationException("XSLMatchingSubstring#compile() should not be called")
}