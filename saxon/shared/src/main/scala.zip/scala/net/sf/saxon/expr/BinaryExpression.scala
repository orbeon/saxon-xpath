////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser._
import net.sf.saxon.model.AtomicType
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.Item
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.jiter.PairIterator
import net.sf.saxon.value.Cardinality
import java.util

/**
 * Binary Expression: a numeric or boolean expression consisting of the
 * two operands and an operator
 */
object BinaryExpression {
  /**
   * Determine whether a binary operator is commutative, that is, A op B = B op A.
   *
   * @param operator the operator, for example { @link Token#PLUS}
   * @return true if the operator is commutative
   */
    protected def isCommutative(operator: Int) = operator == Token.AND || operator == Token.OR || operator == Token.UNION || operator == Token.INTERSECT || operator == Token.PLUS || operator == Token.MULT || operator == Token.EQUALS || operator == Token.FEQ || operator == Token.NE || operator == Token.FNE

  /**
   * Determine whether an operator is associative, that is, ((a^b)^c) = (a^(b^c))
   *
   * @param operator the operator, for example { @link Token#PLUS}
   * @return true if the operator is associative
   */
  protected def isAssociative(operator: Int) = operator == Token.AND || operator == Token.OR || operator == Token.UNION || operator == Token.INTERSECT || operator == Token.PLUS || operator == Token.MULT

  /**
   * Test if one operator is the inverse of another, so that (A op1 B) is
   * equivalent to (B op2 A). Commutative operators are the inverse of themselves
   * and are therefore not listed here.
   *
   * @param op1 the first operator
   * @param op2 the second operator
   * @return true if the operators are the inverse of each other
   */
  protected def isInverse(op1: Int, op2: Int) = op1 != op2 && op1 == Token.inverse(op2)
}

abstract class BinaryExpression(val p0: Expression, var operator: Int // represented by the token number from class Tokenizer
                                , val p1: Expression)

/**
 * Create a binary expression identifying the two operands and the operator
 *
 * @param p0 the left-hand operand
 * @param op the operator, as a token returned by the Tokenizer (e.g. Token.AND)
 * @param p1 the right-hand operand
 */
  extends Expression { //        p0.verifyParentPointers();
  //        p1.verifyParentPointers();
  lhs = new Operand(this, p0, getOperandRole(0))
  rhs = new Operand(this, e1, getOperandRole(1))
  adoptChildExpression(p0)
  adoptChildExpression(e1)
  private var lhs = null
  private var rhs = null

  override final def operands = () => new PairIterator[Operand](lhs, rhs)

  /**
   * Get the operand role
   *
   * @param arg which argument: 0 for the lhs, 1 for the rhs
   * @return the operand role
   */
  protected def getOperandRole(arg: Int) = OperandRole.SINGLE_ATOMIC

  /**
   * Get the left-hand operand
   *
   * @return the left-hand operand
   */
  def getLhs = lhs

  /**
   * Get the left-hand operand expression
   *
   * @return the left-hand operand child expression
   */
  final def getLhsExpression = lhs.getChildExpression

  /**
   * Set the left-hand operand expression
   *
   * @param child the left-hand operand expression
   */
  def setLhsExpression(child: Expression) = lhs.setChildExpression(child)

  /**
   * Get the right-hand operand
   *
   * @return the right-hand operand
   */
  def getRhs = rhs

  /**
   * Get the right-hand operand expression
   *
   * @return the right-hand operand expression
   */
  final def getRhsExpression = rhs.getChildExpression

  /**
   * Set the right-hand operand expression
   *
   * @param child the right-hand operand expression
   */
  def setRhsExpression(child: Expression) = rhs.setChildExpression(child)

  /**
   * Type-check the expression. Default implementation for binary operators that accept
   * any kind of operand
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    resetLocalStaticProperties()
    lhs.typeCheck(visitor, contextInfo)
    rhs.typeCheck(visitor, contextInfo)
    // if both operands are known, pre-evaluate the expression
    try if (getLhsExpression.isInstanceOf[Literal] && getRhsExpression.isInstanceOf[Literal]) {
      val v = evaluateItem(visitor.getStaticContext.makeEarlyEvaluationContext).materialize
      return Literal.makeLiteral(v, this)
    }
    catch {
      case err: XPathException =>

      // if early evaluation fails, suppress the error: the value might
      // not be needed at run-time
    }
    this
  }

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor         an expression visitor
   * @param contextItemType the static type of "." at the point where this expression is invoked.
   *                        The parameter is set to null if it is known statically that the context item will be undefined.
   *                        If the type of the context item is not known statically, the argument is set to
   *                        { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   * @throws XPathException if an error is discovered during this phase
   *                        (typically a type error)
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    lhs.optimize(visitor, contextItemType)
    rhs.optimize(visitor, contextItemType)
    try {
      val opt = visitor.obtainOptimizer
      if (opt.isOptionSet(OptimizerOptions.CONSTANT_FOLDING) && getLhsExpression.isInstanceOf[Literal] && getRhsExpression.isInstanceOf[Literal]) {
        val item = evaluateItem(visitor.getStaticContext.makeEarlyEvaluationContext)
        if (item != null) {
          val v = item.materialize
          return Literal.makeLiteral(v, this)
        }
      }
    } catch {
      case err: XPathException =>
    }
    this
  }

  /**
   * Mark an expression as being "flattened". This is a collective term that includes extracting the
   * string value or typed value, or operations such as simple value construction that concatenate text
   * nodes before atomizing. The implication of all of these is that although the expression might
   * return nodes, the identity of the nodes has no significance. This is called during type checking
   * of the parent expression.
   *
   * @param flattened set to true if the result of the expression is atomized or otherwise turned into
   *                  an atomic value
   */
  override def setFlattened(flattened: Boolean) = {
    getLhsExpression.setFlattened(flattened)
    getRhsExpression.setFlattened(flattened)
  }

  /**
   * Get the operator
   *
   * @return the operator, for example { @link Token#PLUS}
   */
  def getOperator = operator

  /**
   * Determine the static cardinality. Default implementation returns [0..1] if either operand
   * can be empty, or [1..1] otherwise, provided that the arguments are of atomic type. This
   * caveat is necessary because the method can be called before type-checking, and a node
   * or array with cardinality [1..n] might be atomized to an empty sequence.
   */
  override def computeCardinality = {
    val lhs = getLhsExpression
    val rhs = getRhsExpression
    if (!Cardinality.allowsZero(lhs.getCardinality) && lhs.getItemType.isInstanceOf[AtomicType] && !Cardinality.allowsZero(rhs.getCardinality) && rhs.getItemType.isInstanceOf[AtomicType]) StaticProperty.EXACTLY_ONE
    else StaticProperty.ALLOWS_ZERO_OR_ONE
  }

  /**
   * Determine the special properties of this expression
   *
   * @return { @link StaticProperty#NO_NODES_NEWLY_CREATED}. This is overridden
   *                 for some subclasses.
   */
  override def computeSpecialProperties = {
    val p = super.computeSpecialProperties
    p | StaticProperty.NO_NODES_NEWLY_CREATED
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = EVALUATE_METHOD | ITERATE_METHOD

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any): Boolean = {
    if (other.isInstanceOf[BinaryExpression] && hasCompatibleStaticContext(other.asInstanceOf[Expression])) {
      val b = other.asInstanceOf[BinaryExpression]
      val lhs1 = getLhsExpression
      val rhs1 = getRhsExpression
      val lhs2 = b.getLhsExpression
      val rhs2 = b.getRhsExpression
      if (operator == b.operator) {
        if (lhs1.isEqual(lhs2) && rhs1.isEqual(rhs2)) return true
        if (BinaryExpression.isCommutative(operator) && lhs1.isEqual(rhs2) && rhs1.isEqual(lhs2)) return true
        if (BinaryExpression.isAssociative(operator) && pairwiseEqual(flattenExpression(new util.ArrayList[Expression](4)), b.flattenExpression(new util.ArrayList[Expression](4)))) return true
      }
      return BinaryExpression.isInverse(operator, b.operator) && lhs1.isEqual(rhs2) && rhs1.isEqual(lhs2)
    }
    false
  }

  /**
   * Flatten an expression with respect to an associative operator: for example
   * the expression (a+b) + (c+d) becomes list(a,b,c,d), with the list in canonical
   * order (sorted by hashCode)
   *
   * @param list a list provided by the caller to contain the result
   * @return the list of expressions
   */
  private def flattenExpression(list: util.List[Expression]) = {
    if (getLhsExpression.isInstanceOf[BinaryExpression] && getLhsExpression.asInstanceOf[BinaryExpression].operator == operator) getLhsExpression.asInstanceOf[BinaryExpression].flattenExpression(list)
    else {
      val h = getLhsExpression.hashCode
      list.add(getLhsExpression)
      var i = list.size - 1
      while ( {
        i > 0 && h > list.get(i - 1).hashCode
      }) {
        list.set(i, list.get(i - 1))
        list.set(i - 1, getLhsExpression)
        i -= 1
      }
    }
    if (getRhsExpression.isInstanceOf[BinaryExpression] && getRhsExpression.asInstanceOf[BinaryExpression].operator == operator) getRhsExpression.asInstanceOf[BinaryExpression].flattenExpression(list)
    else {
      val h = getRhsExpression.hashCode
      list.add(getRhsExpression)
      var i = list.size - 1
      while ( {
        i > 0 && h > list.get(i - 1).hashCode
      }) {
        list.set(i, list.get(i - 1))
        list.set(i - 1, getRhsExpression)
        i -= 1
      }
    }
    list
  }

  /**
   * Compare whether two lists of expressions are pairwise equal
   *
   * @param a the first list of expressions
   * @param b the second list of expressions
   * @return true if the two lists are equal
   */
  private def pairwiseEqual(a: util.List[_], b: util.List[_]): Boolean = {
    if (a.size != b.size) return false
    for (i <- 0 until a.size) {
      if (!(a.get(i) == b.get(i))) return false
    }
    true
  }

  /**
   * Get a hashCode for comparing two expressions. Note that this hashcode gives the same
   * result for (A op B) and for (B op A), whether or not the operator is commutative.
   */
  override def computeHashCode = { // Ensure that an operator and its inverse get the same hash code,
    // so that (A lt B) has the same hash code as (B gt A)
    val op = Math.min(operator, Token.inverse(operator))
    ("BinaryExpression " + op).hashCode ^ getLhsExpression.hashCode ^ getRhsExpression.hashCode
  }

  /**
   * Represent the expression as a string. The resulting string will be a valid XPath 3.0 expression
   * with no dependencies on namespace bindings other than the binding of the prefix "xs" to the XML Schema
   * namespace.
   *
   * @return the expression as a string in XPath 3.0 syntax
   */
  override def toString = ExpressionTool.parenthesize(getLhsExpression) + " " + displayOperator + " " + ExpressionTool.parenthesize(getRhsExpression)

  override def toShortString = parenthesize(getLhsExpression) + " " + displayOperator + " " + parenthesize(getRhsExpression)

  private def parenthesize(operand: Expression) = {
    var operandStr = operand.toShortString
    if (operand.isInstanceOf[BinaryExpression] && XPathParser.operatorPrecedence(operand.asInstanceOf[BinaryExpression].operator) < XPathParser.operatorPrecedence(operator)) operandStr = "(" + operandStr + ")"
    operandStr
  }

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   *
   * @param out the output destination for the displayed expression tree
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    out.startElement(tag, this)
    out.emitAttribute("op", displayOperator)
    explainExtraAttributes(out)
    getLhsExpression.`export`(out)
    getRhsExpression.`export`(out)
    out.endElement
  }

  /**
   * Get the element name used to identify this expression in exported expression format
   *
   * @return the element name used to identify this expression
   */
  protected def tag = "operator"

  /**
   * Add subclass-specific attributes to the expression tree explanation. Default implementation
   * does nothing; this is provided for subclasses to override.
   *
   * @param out the output destination for the displayed expression tree
   */
  protected def explainExtraAttributes(out: ExpressionPresenter) = {
  }

  /**
   * Display the operator used by this binary expression
   *
   * @return String representation of the operator (for diagnostic display only)
   */
  protected def displayOperator = Token.tokens(operator)
}