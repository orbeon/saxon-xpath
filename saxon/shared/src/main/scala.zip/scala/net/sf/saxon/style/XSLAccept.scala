////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.StandardNames
import net.sf.saxon.pattern.NameTest
import net.sf.saxon.pattern.QNameTest
import net.sf.saxon.trans.ComponentTest
import net.sf.saxon.trans.SymbolicName
import net.sf.saxon.trans.Visibility
import net.sf.saxon.trans.XPathException

/**
 * Represents an xsl:accept element in an XSLT 3.0 package manifest.
 */
object XSLAccept {
  def isCompatible(declared: Visibility, exposed: Visibility) = { //        if (declared == null || declared == exposed) {
    //            return true;
    //        }
    declared match {
      case PUBLIC =>
        (exposed eq Visibility.PUBLIC) || (exposed eq Visibility.PRIVATE) || (exposed eq Visibility.FINAL) || (exposed eq Visibility.HIDDEN)
      case ABSTRACT =>
        (exposed eq Visibility.ABSTRACT) || (exposed eq Visibility.HIDDEN)
      case FINAL =>
        (exposed eq Visibility.PRIVATE) || (exposed eq Visibility.FINAL) || (exposed eq Visibility.HIDDEN)
      case _ =>
        false
    }
  }
}

class XSLAccept extends XSLAcceptExpose {
  override protected def prepareAttributes() = super.prepareAttributes()

  /**
   * Check that the stylesheet element is valid. This is called once for each element, after
   * the entire tree has been built. As well as validation, it can perform first-time
   * initialisation. The default implementation does nothing; it is normally overriden
   * in subclasses.
   *
   * @param decl the declaration to be validated
   * @throws net.sf.saxon.trans.XPathException
   * if any error is found during validation
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration): Unit = {
    val parent = getParent
    if (!parent.isInstanceOf[XSLUsePackage]) {
      compileError("Parent of xsl:accept must be xsl:use-package")
      return
    }
    val pack = parent.asInstanceOf[XSLUsePackage].getUsedPackage
    if (pack != null) {
      import scala.collection.JavaConversions._
      for (test <- getExplicitComponentTests) {
        val nameTest = test.getQNameTest
        if (nameTest.isInstanceOf[NameTest]) {
          val kind = test.getComponentKind
          var sName = if (kind == StandardNames.XSL_FUNCTION) new SymbolicName.F(nameTest.asInstanceOf[NameTest].getMatchingNodeName, test.getArity)
          else new SymbolicName(kind, nameTest.asInstanceOf[NameTest].getMatchingNodeName)
          var comp = pack.getComponent(sName)
          var found = false
          if (comp == null) if (kind == StandardNames.XSL_FUNCTION && test.getArity == -1) { // This will match any function of the required name, regardless of arity
            for (i <- 0 to pack.getMaxFunctionArity) {
              sName = new SymbolicName.F(nameTest.asInstanceOf[NameTest].getMatchingNodeName, i)
              comp = pack.getComponent(sName)
              if (comp != null) {
                checkCompatibility(sName, comp.getVisibility, getVisibility)
                found = true
              }
            }
          }
          else {
            checkCompatibility(sName, comp.getVisibility, getVisibility)
            found = true
          }
          if (!found) compileError("No " + sName.toString + " exists in the used package", "XTSE3030")
        }
      }
    }
  }

  protected def checkCompatibility(name: SymbolicName, declared: Visibility, exposed: Visibility) = if (!XSLAccept.isCompatible(declared, exposed)) {
    val code = "XTSE3040"
    compileError("The " + name + " is declared as " + declared.show + " and cannot be accepted as " + exposed.show, code)
  }
}