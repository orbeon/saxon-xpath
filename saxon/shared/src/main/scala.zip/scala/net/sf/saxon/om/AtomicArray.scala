////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AtomicIterator
import net.sf.saxon.tree.iter.ListIterator
import net.sf.saxon.tree.iter.UnfailingIterator
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.EmptySequence
import java.util
import java.util.{ArrayList, Collections}

/**
 * A sequence of atomic values, implemented using an underlying arrayList.
 * <p>Often used for representing the typed value of a list-valued node.</p>
 *
 * @since 9.5
 */
object AtomicArray {
  private val emptyAtomicList = Collections.emptyList
  var EMPTY_ATOMIC_ARRAY = new AtomicArray(emptyAtomicList)
}

class AtomicArray extends AtomicSequence {
  private var content = null

  /**
   * Create an AtomicArray over a supplied arrayList of atomic values
   *
   * @param content the supplied arrayList. The caller warrants that the contents of this array will not change.
   */
  def this(content: util.List[AtomicValue]) {
    this()
    this.content = content
  }

  /**
   * Create an AtomicArray supplying the contents as an iterator
   *
   * @param iter the iterator that supplies the atomic values (which must be position
   *             at the start of the sequence, and which will be consumed by the method).
   * @throws XPathException     if evaluation of the SequenceIterator fails
   * @throws ClassCastException if any of the items returned by the SequenceIterator is not atomic
   */
  def this(iter: SequenceIterator) = {
    this()
    val list = new util.ArrayList[AtomicValue](10)
    iter.forEachOrFail((item: Item) => list.add(item.asInstanceOf[AtomicValue]))
    this.content = list
  }

  override def head = if (content.isEmpty) null
  else content.get(0)

  override def iterate = new ListIterator.Atomic(content)

  /**
   * Get the n'th item in the sequence (base-zero addressing)
   *
   * @param n the index of the required item, the first item being zero
   * @return the n'th item if n is in range, or null otherwise
   */
  override def itemAt(n: Int) = if (n >= 0 && n < content.size) content.get(n)
  else null

  /**
   * Get the length of the sequence
   *
   * @return the number of items in the sequence
   */
  override def getLength = content.size

  /**
   * Get a subsequence of this sequence
   *
   * @param start  the index of the first item to be included in the result, counting from zero.
   *               A negative value is taken as zero. If the value is beyond the end of the sequence, an empty
   *               sequence is returned
   * @param length the number of items to be included in the result. Specify Integer.MAX_VALUE to
   *               get the subsequence up to the end of the base sequence. If the value is negative, an empty sequence
   *               is returned. If the value goes off the end of the sequence, the result returns items up to the end
   *               of the sequence
   * @return the required subsequence
   */
  override def subsequence(start: Int, length: Int) = {
    if (start < 0) start = 0
    if (start + length > content.size) length = content.size - start
    new AtomicArray(content.subList(start, start + length))
  }

  /**
   * Get the canonical lexical representation as defined in XML Schema. This is not always the same
   * as the result of casting to a string according to the XPath rules.
   *
   * @return the canonical lexical representation if defined in XML Schema; otherwise, the result
   *         of casting to string according to the XPath 2.0 rules
   */
  override def getCanonicalLexicalRepresentation = getStringValueCS

  /**
   * Get the value of the item as a CharSequence. This is in some cases more efficient than
   * the version of the method that returns a String.
   */
  override def getStringValueCS = {
    val fsb = new FastStringBuffer(FastStringBuffer.C64)
    var first = true
    import scala.collection.JavaConversions._
    for (av <- content) {
      if (!first) fsb.cat(' ')
      else first = false
      fsb.cat(av.getStringValueCS)
    }
    fsb.condense
  }

  override def getStringValue = getStringValueCS.toString

  @throws[XPathException]
  override def effectiveBooleanValue = ExpressionTool.effectiveBooleanValue(iterate)

  /**
   * Get a Comparable value that implements the XML Schema ordering comparison semantics for this value.
   * The default implementation is written to compare sequences of atomic values.
   * This method is overridden for AtomicValue and its subclasses.
   * <p>In the case of data types that are partially ordered, the returned Comparable extends the standard
   * semantics of the compareTo() method by returning the value {@link SequenceTool#INDETERMINATE_ORDERING} when there
   * is no defined order relationship between two given values.</p>
   * <p>For comparing key/keyref values, XSD 1.1 defines that a singleton list is equal to its only member. To
   * achieve this, this method returns the schema comparable of the singleton member if the list has length one.
   * This won't give the correct ordering semantics, but we rely on lists never taking part in ordering comparisons.</p>
   *
   * @return a Comparable that follows XML Schema comparison rules
   */
  override def getSchemaComparable = if (content.size == 1) content.get(0).getSchemaComparable
  else new AtomicArray#ValueSchemaComparable

  private class ValueSchemaComparable extends Comparable[AtomicArray#ValueSchemaComparable] {
    def getValue = thisAtomicArray

    override def compareTo(obj: AtomicArray#ValueSchemaComparable): Int = {
      val iter1 = getValue.iterate
      val iter2 = obj.getValue.iterate
      while ( {
        true
      }) {
        val item1 = iter1.next.asInstanceOf[AtomicValue]
        val item2 = iter2.next.asInstanceOf[AtomicValue]
        if (item1 == null && item2 == null) return 0
        if (item1 == null) return -1
        else if (item2 == null) return +1
        val c = item1.getSchemaComparable.compareTo(item2.getSchemaComparable)
        if (c != 0) return c
      }
    }

    override def equals(/*@NotNull*/ obj: Any) = classOf[AtomicArray#ValueSchemaComparable].isAssignableFrom(obj.getClass) && compareTo(obj.asInstanceOf[AtomicArray#ValueSchemaComparable]) == 0

    override def hashCode: Int = try {
      var hash = 0x06639662 // arbitrary seed
      val iter = getValue.iterate
      while ( {
        true
      }) {
        val item = iter.next
        if (item == null) return hash
        if (item.isInstanceOf[AtomicValue]) hash ^= item.asInstanceOf[AtomicValue].getSchemaComparable.hashCode
      }
    } catch {
      case e: XPathException =>
        0
    }
  }

  /**
   * Reduce the sequence to its simplest form. If the value is an empty sequence, the result will be
   * EmptySequence.getInstance(). If the value is a single atomic value, the result will be an instance
   * of AtomicValue. If the value is a single item of any other kind, the result will be an instance
   * of SingletonItem. Otherwise, the result will typically be unchanged.
   *
   * @return the simplified sequence
   */
  override def reduce = {
    val len = getLength
    if (len == 0) EmptySequence.getInstance
    else if (len == 1) itemAt(0).asInstanceOf[AtomicValue]
    else this
  }

  /**
   * Returns a Java iterator over the atomic sequence.
   *
   * @return an Iterator.
   */
  override def iterator = content.iterator
}