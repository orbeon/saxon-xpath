////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.Literal
import net.sf.saxon.expr.sort.SortExpression
import net.sf.saxon.expr.sort.SortKeyDefinitionList
import net.sf.saxon.model.Type
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * Handler for xsl:perform-sort elements in stylesheet (XSLT 2.0). <br>
 */
class XSLPerformSort extends StyleElement {
  /*@Nullable*/ private[style] var select = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  /**
   * Specify that xsl:sort is a permitted child
   */
  override protected def isPermittedChild(child: StyleElement) = child.isInstanceOf[XSLSort]

  override def prepareAttributes() = {
    var selectAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val value = att.getValue
      val f = attName.getDisplayName
      if (f == "select") {
        selectAtt = value
        select = makeExpression(selectAtt, att)
      }
      else checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    checkSortComesFirst(true)
    if (select != null) { // if there is a select attribute, check that there are no children other than xsl:sort and xsl:fallback
      import scala.collection.JavaConversions._
      for (child <- children) {
        if (child.isInstanceOf[XSLSort] || child.isInstanceOf[XSLFallback]) {
          // no action
        }
        else if (child.getNodeKind == Type.TEXT && !Whitespace.isWhite(child.getStringValueCS)) { // with xml:space=preserve, white space nodes may still be there
          compileError("Within xsl:perform-sort, significant text must not appear if there is a select attribute", "XTSE1040")
        }
        else child.asInstanceOf[StyleElement].compileError("Within xsl:perform-sort, child instructions are not allowed if there is a select attribute", "XTSE1040")
      }
    }
    select = typeCheck("select", select)
  }

  @throws[XPathException]
  override def compile(compilation: Compilation, decl: ComponentDeclaration) = {
    val sortKeys = makeSortKeys(compilation, decl)
    if (select != null) new SortExpression(select, sortKeys)
    else {
      var body = compileSequenceConstructor(compilation, decl, true)
      if (body == null) body = Literal.makeEmptySequence
      try new SortExpression(body.simplify, sortKeys)
      catch {
        case e: XPathException =>
          compileError(e)
          null
      }
    }
  }
}