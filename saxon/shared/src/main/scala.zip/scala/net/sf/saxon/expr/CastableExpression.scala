////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.ContextItemStaticInfo
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.ExpressionVisitor
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.BooleanValue
import net.sf.saxon.value.Cardinality

/**
 * Castable Expression: implements "Expr castable as atomic-type?".
 * The implementation simply wraps a cast expression with a try/catch.
 */
final class CastableExpression(val source: Expression, val target: AtomicType, val allowEmpty: Boolean)

/**
 * Create a "castable" expression of the form "source castable as target"
 *
 * @param source     The source expression
 * @param target     The type being tested against
 * @param allowEmpty true if an empty sequence is acceptable, that is if the expression
 *                   was written as "source castable as target?"
 */
  extends CastingExpression(source, target, allowEmpty) {
  /**
   * Type-check the expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    getOperand.typeCheck(visitor, contextInfo)
    // We need to take care here. The usual strategy of wrapping the operand in an expression that
    // does type-checking doesn't work here, because an error in the type checking should be caught,
    // while an error in evaluating the expression as written should not.
    val operand = getBaseExpression
    val sourceItemType = operand.getItemType
    val atomizedType = sourceItemType.getAtomizedItemType.getPrimitiveItemType.asInstanceOf[AtomicType]
    if (!(atomizedType eq BuiltInAtomicType.ANY_ATOMIC)) {
      converter = visitor.getConfiguration.getConversionRules.getConverter(atomizedType, getTargetType)
      if (converter == null) if (!allowsEmpty || !Cardinality.allowsZero(operand.getCardinality)) { // Conversion from source to target type will never succeed
        return Literal.makeLiteral(BooleanValue.FALSE, this)
      }
      else {
        if (getTargetPrimitiveType.isNamespaceSensitive) converter = converter.setNamespaceResolver(getRetainedStaticContext)
        if (converter.isAlwaysSuccessful && !allowsEmpty && operand.getCardinality == StaticProperty.ALLOWS_ONE) return Literal.makeLiteral(BooleanValue.TRUE, this)
      }
    }
    setBaseExpression(operand)
    if (operand.isInstanceOf[Literal]) return preEvaluate
    this
  }

  @throws[XPathException]
  protected def preEvaluate: Expression = {
    val literalOperand = getBaseExpression.asInstanceOf[Literal].getValue
    if (literalOperand.isInstanceOf[AtomicValue] && converter != null) {
      val result = converter.convert(literalOperand.asInstanceOf[AtomicValue])
      return Literal.makeLiteral(BooleanValue.get(!result.isInstanceOf[ValidationFailure]), this)
    }
    val length = literalOperand.getLength
    if (length == 0) return Literal.makeLiteral(BooleanValue.get(allowsEmpty), this)
    if (length > 1) return Literal.makeLiteral(BooleanValue.FALSE, this)
    this
  }

  /**
   * Optimize the expression
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    optimizeChildren(visitor, contextInfo)
    if (getBaseExpression.isInstanceOf[Literal]) return preEvaluate
    this
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = EVALUATE_METHOD

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any) = other.isInstanceOf[CastableExpression] && getBaseExpression.isEqual(other.asInstanceOf[CastableExpression].getBaseExpression) && (getTargetType eq other.asInstanceOf[CastableExpression].getTargetType) && allowsEmpty == other.asInstanceOf[CastableExpression].allowsEmpty

  /**
   * get HashCode for comparing two expressions. Note that this hashcode gives the same
   * result for (A op B) and for (B op A), whether or not the operator is commutative.
   */
  override def computeHashCode = super.computeHashCode ^ 0x5555

  /**
   * Determine the data type of the result of the Castable expression
   */
  override def getItemType = BuiltInAtomicType.BOOLEAN

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType
   */
  override def getStaticUType(contextItemType: UType) = UType.BOOLEAN

  override def computeCardinality = StaticProperty.EXACTLY_ONE

  override def copy(rebindings: RebindingMap) = {
    val ce = new CastableExpression(getBaseExpression.copy(rebindings), getTargetType, allowsEmpty)
    ExpressionTool.copyLocationInfo(this, ce)
    ce.setRetainedStaticContext(getRetainedStaticContext)
    ce.converter = converter
    ce
  }

  /**
   * Evaluate the expression
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext) = BooleanValue.get(effectiveBooleanValue(context))

  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext): Boolean = { // This method does its own atomization so that it can distinguish between atomization
    // failures and casting failures
    var count = 0
    val iter = getBaseExpression.iterate(context)
    var item = null
    while ( {
      (item = iter.next) != null
    }) if (item.isInstanceOf[NodeInfo]) {
      val atomizedValue = item.atomize
      val length = SequenceTool.getLength(atomizedValue)
      count += length
      if (count > 1) return false
      if (length != 0) {
        val av = atomizedValue.head
        if (!isCastable(av, getTargetType, context)) return false
      }
    }
    else if (item.isInstanceOf[AtomicValue]) {
      val av = item.asInstanceOf[AtomicValue]
      count += 1
      if (count > 1) return false
      if (!isCastable(av, getTargetType, context)) return false
    }
    else throw new XPathException("Input to cast cannot be atomized", "XPTY0004")
    count != 0 || allowsEmpty
  }

  /**
   * Determine whether a value is castable to a given type
   *
   * @param value      the value to be tested
   * @param targetType the type to be tested against
   * @param context    XPath dynamic context
   * @return true if the value is castable to the required type
   */
  private def isCastable(value: AtomicValue, targetType: AtomicType, context: XPathContext): Boolean = {
    var converter = this.converter
    if (converter == null) {
      converter = context.getConfiguration.getConversionRules.getConverter(value.getPrimitiveType, targetType)
      if (converter == null) return false
      if (converter.isAlwaysSuccessful) return true
      if (getTargetType.isNamespaceSensitive) converter = converter.setNamespaceResolver(getRetainedStaticContext)
    }
    !converter.convert(value).isInstanceOf[ValidationFailure]
  }

  override def getExpressionName = "castable"

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   */
  override def toString = getBaseExpression.toString + " castable as " + getTargetType.getEQName

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = {
    `export`(out, "castable")
    //        out.startElement("castable", this);
    //        out.emitAttribute("as", getTargetType().toExportString());
    //        out.emitAttribute("code", getTargetType().getBasicAlphaCode());
    //        out.emitAttribute("emptiable", allowsEmpty() ? "1" : "0");
    //        getBaseExpression().export(out);
    //        out.endElement();
  }
}