////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.ApplyImports
import net.sf.saxon.expr.instruct.WithParam
import net.sf.saxon.model.Type
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.linked.NodeImpl
import net.sf.saxon.value.Whitespace

/**
 * An xsl:apply-imports element in the stylesheet
 */
class XSLApplyImports extends StyleElement {
  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
    override def isInstruction = true

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = { //checkWithinTemplate();
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLWithParam]) {
        // OK;
      }
      else if (child.getNodeKind == Type.TEXT) { // with xml:space=preserve, white space nodes may still be there
        if (!Whitespace.isWhite(child.getStringValueCS)) compileError("No character data is allowed within xsl:apply-imports", "XTSE0010")
      }
      else compileError("Child element " + child.getDisplayName + " is not allowed as a child of xsl:apply-imports", "XTSE0010")
    }
    var parent = getParent
    while ( {
      parent != null
    }) {
      if (parent.isInstanceOf[XSLOverride]) compileError("xsl:apply-imports cannot be used in a template rule declared within xsl:override", "XTSE3460")
      parent = parent.getParent
    }
  }

  /*@NotNull*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val inst = new ApplyImports
    val nonTunnels = getWithParamInstructions(inst, exec, decl, false)
    val tunnels = getWithParamInstructions(inst, exec, decl, true)
    inst.setActualParams(nonTunnels)
    inst.setTunnelParams(tunnels)
    inst
  }
}