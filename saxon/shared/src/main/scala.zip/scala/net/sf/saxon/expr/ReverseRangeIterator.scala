////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AtomicIterator
import net.sf.saxon.tree.iter.LookaheadIterator
import net.sf.saxon.tree.iter.ReversibleIterator
import net.sf.saxon.value.Int64Value
import net.sf.saxon.value.IntegerValue
import java.util

/**
 * Iterator that produces numeric values in a monotonic sequence,
 * ascending or descending. Although a range expression (N to M) is always
 * in ascending order, applying the reverse() function will produce
 * a RangeIterator that works in descending order.
 */
class ReverseRangeIterator @throws[XPathException]
(var start: Long, var limit: Long)

/**
 * Create an iterator over a range of integers in monotonic descending order
 *
 * @param start the first integer to be delivered (the highest in the range)
 * @param end   the last integer to be delivered (the lowest in the range). Must be &lt;= start
 * @throws XPathException if the values are inconsistent or if the length is greater than 2^31
 **/
  extends AtomicIterator[IntegerValue] with ReversibleIterator with LastPositionFinder with LookaheadIterator {
  if (start - limit > Integer.MAX_VALUE) throw new XPathException("Saxon limit on sequence length exceeded (2^31)", "XPDY0130")
  currentValue = start + 1
  private[expr] var currentValue = 0L

  override def hasNext = currentValue > limit

  /*@Nullable*/ override def next: IntegerValue = {
    if ( {
      currentValue -= 1; currentValue
    } < limit) return null
    Int64Value.makeIntegerValue(currentValue)
  }

  override def getLength = ((start - limit) + 1).toInt

  /**
   * Get properties of this iterator, as a bit-significant integer.
   *
   * @return the properties of this iterator. This will be some combination of
   *         properties such as { @link net.sf.saxon.om.SequenceIterator.Property#GROUNDED}, { @link net.sf.saxon.om.SequenceIterator.Property#LAST_POSITION_FINDER},
   *                                    and { @link net.sf.saxon.om.SequenceIterator.Property#LOOKAHEAD}. It is always
   *                                    acceptable to return the value zero, indicating that there are no known special properties.
   *                                    It is acceptable for the properties of the iterator to change depending on its state.
   */
  override def getProperties = util.EnumSet.of(Property.LOOKAHEAD, Property.LAST_POSITION_FINDER)

  override def getReverseIterator = new RangeIterator(limit, start)
}