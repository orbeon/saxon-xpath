////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.event.Outputter
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.LastPositionFinder
import net.sf.saxon.expr.RangeIterator
import net.sf.saxon.expr.ReverseRangeIterator
import net.sf.saxon.expr.StaticProperty
import net.sf.saxon.functions.Count
import net.sf.saxon.model._
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.tree.iter.UnfailingIterator
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.tree.wrapper.VirtualNode
import net.sf.saxon.value._

/**
 * Utility class for manipulating sequences. Some of these methods should be regarded
 * as temporary scaffolding while the model is in transition.
 */
object SequenceTool {
  /**
   * Constant returned by compareTo() method to indicate an indeterminate ordering between two values
   */
    val INDETERMINATE_ORDERING = Integer.MIN_VALUE

  /**
   * Produce a GroundedValue containing the same values as a supplied sequence.
   *
   * @param iterator the supplied sequence. The iterator may or may not be consumed as a result of
   *                 passing it to this method.
   * @return a GroundedValue containing the same items
   * @throws XPathException if a failure occurs reading the input iterator
   */
  @throws[XPathException]
  def toGroundedValue[T <: Item](iterator: SequenceIterator) = iterator.materialize

  /**
   * Produce a Sequence containing the same values as a supplied sequence; the input is
   * read progressively as required, and saved in a buffer as it is read in case it is needed
   * again. But if the iterator is already backed by a grounded value, we return that value.
   *
   * @param iterator the supplied sequence. The iterator may or may not be consumed as a result of
   *                 passing it to this method.
   * @return a Sequence containing the same items
   * @throws XPathException if a failure occurs reading the input iterator
   */
  @throws[XPathException]
  def toMemoSequence(iterator: SequenceIterator) = if (iterator.isInstanceOf[EmptyIterator]) EmptySequence.getInstance
  else if (iterator.getProperties.contains(SequenceIterator.Property.GROUNDED)) iterator.materialize
  else new MemoSequence(iterator)

  /**
   * Construct a sequence capable of returning the same items as an iterator,
   * without incurring the cost of evaluating the iterator and storing all
   * the items.
   *
   * @param iterator the supplied sequence. The iterator may or may not be consumed as a result of
   *                 passing it to this method.
   * @return a Sequence containing the same items as the supplied iterator
   * @throws XPathException if a failure occurs reading the input iterator
   */
  @throws[XPathException]
  def toLazySequence(iterator: SequenceIterator) = if (iterator.getProperties.contains(SequenceIterator.Property.GROUNDED) && !iterator.isInstanceOf[RangeIterator] && !iterator.isInstanceOf[ReverseRangeIterator]) iterator.materialize
  else new LazySequence(iterator)

  @throws[XPathException]
  def toLazySequence2(iterator: SequenceIterator) = if (iterator.getProperties.contains(SequenceIterator.Property.GROUNDED) && !iterator.isInstanceOf[RangeIterator] && !iterator.isInstanceOf[ReverseRangeIterator]) iterator.materialize
  else new LazySequence(iterator)

  def isUnrepeatable(seq: Sequence) = seq.isInstanceOf[LazySequence] || (seq.isInstanceOf[Closure] && !(seq.isInstanceOf[MemoClosure] || seq.isInstanceOf[SingletonClosure]))

  /**
   * Get the length of a sequence (the number of items it contains)
   *
   * @param sequence the sequence
   * @return the length in items
   * @throws XPathException if an error occurs (due to lazy evaluation)
   */
  @throws[XPathException]
  def getLength(sequence: Sequence): Int = {
    if (sequence.isInstanceOf[GroundedValue]) return sequence.asInstanceOf[GroundedValue].getLength()
    Count.count(sequence.iterate)
  }

  /**
   * Ask whether the length of a sequence is exactly N
   *
   * @param iter   an iterator over the sequence in question (which is typically consumed)
   * @param length the supposed length
   * @return true if and only if the length of the sequence is the supposed length
   */
  @throws[XPathException]
  def hasLength(iter: SequenceIterator, length: Int): Boolean = if (iter.getProperties.contains(SequenceIterator.Property.LAST_POSITION_FINDER)) iter.asInstanceOf[LastPositionFinder].getLength == length
  else {
    var n = 0
    while ( {
      iter.next != null
    }) if ( {
      n += 1; n - 1
    } == length) {
      iter.close()
      return false
    }
    length == 0
  }

  /**
   * Determine whether two sequences have the same number of items. This is more efficient
   * than comparing the counts, because the longer sequence is evaluated only as far as the
   * length of the shorter sequence. The method consumes the supplied iterators.
   *
   * @param a iterator over the first sequence
   * @param b iterator over the second sequece
   * @return true if the lengths of the two sequences are the same
   */
  @throws[XPathException]
  def sameLength(a: SequenceIterator, b: SequenceIterator): Boolean = if (a.getProperties.contains(SequenceIterator.Property.LAST_POSITION_FINDER)) hasLength(b, a.asInstanceOf[LastPositionFinder].getLength)
  else if (b.getProperties.contains(SequenceIterator.Property.LAST_POSITION_FINDER)) hasLength(a, b.asInstanceOf[LastPositionFinder].getLength)
  else while ( {
    true
  }) {
    val itA = a.next
    val itB = b.next
    if (itA == null || itB == null) {
      if (itA != null) a.close()
      if (itB != null) b.close()
      return itA == null && itB == null
    }
  }

  /**
   * Get the item at a given offset in a sequence. Uses zero-base indexing
   *
   * @param sequence the input sequence
   * @param index    the 0-based subscript
   * @return the n'th item if it exists, or null otherwise
   * @throws XPathException for example if the value is a closure that needs to be
   *                        evaluated, and evaluation fails
   */
  @throws[XPathException]
  def itemAt(sequence: Sequence, index: Int): Item = {
    if (sequence.isInstanceOf[Item] && index == 0) return sequence.asInstanceOf[Item]
    sequence.materialize.itemAt(index)
  }

  /**
   * Static method to make an Item from a Value
   *
   * @param sequence the value to be converted
   * @return null if the value is an empty sequence; or the only item in the value
   *         if it is a singleton sequence
   * @throws net.sf.saxon.trans.XPathException if the supplied Sequence contains multiple items
   */
  /*@Nullable*/ @throws[XPathException]
  def asItem(sequence: Sequence): Item = {
    if (sequence.isInstanceOf[Item]) return sequence.asInstanceOf[Item]
    val iter = sequence.iterate
    val first = iter.next
    if (first == null) return null
    if (iter.next != null) throw new XPathException("Sequence contains more than one item")
    first
  }

  /**
   * Convert an XPath value to a Java object.
   * An atomic value is returned as an instance
   * of the best available Java class. If the item is a node, the node is "unwrapped",
   * to return the underlying node in the original model (which might be, for example,
   * a DOM or JDOM node).
   *
   * @param item the item to be converted
   * @return the value after conversion
   * @throws net.sf.saxon.trans.XPathException if an error occurs: for example, if the XPath value is
   *                                           an integer and is too big to fit in a Java long
   */
  @throws[XPathException]
  def convertToJava(/*@NotNull*/ item: Item) = if (item.isInstanceOf[NodeInfo]) {
    var node = item
    while ( {
      node.isInstanceOf[VirtualNode]
    }) { // strip off any layers of wrapping
      node = node.asInstanceOf[VirtualNode].getRealNode
    }
    node
  }
  else if (item.isInstanceOf[Function]) item
  else if (item.isInstanceOf[ExternalObject[_]]) item.asInstanceOf[ExternalObject[_]].getObject
  else {
    val value = item.asInstanceOf[AtomicValue]
    value.getItemType.getPrimitiveType match {
      case StandardNames.XS_STRING =>
      case StandardNames.XS_UNTYPED_ATOMIC =>
      case StandardNames.XS_ANY_URI =>
      case StandardNames.XS_DURATION =>
        value.getStringValue
      case StandardNames.XS_BOOLEAN =>
        if (value.asInstanceOf[BooleanValue].getBooleanValue) Boolean.TRUE
        else Boolean.FALSE
      case StandardNames.XS_DECIMAL =>
        value.asInstanceOf[BigDecimalValue].getDecimalValue
      case StandardNames.XS_INTEGER =>
        value.asInstanceOf[NumericValue].longValue
      case StandardNames.XS_DOUBLE =>
        value.asInstanceOf[DoubleValue].getDoubleValue
      case StandardNames.XS_FLOAT =>
        value.asInstanceOf[FloatValue].getFloatValue
      case StandardNames.XS_DATE_TIME =>
        value.asInstanceOf[DateTimeValue].getCalendar.getTime
      case StandardNames.XS_DATE =>
        value.asInstanceOf[DateValue].getCalendar.getTime
      case StandardNames.XS_TIME =>
        value.getStringValue
      case StandardNames.XS_BASE64_BINARY =>
        value.asInstanceOf[Base64BinaryValue].getBinaryValue
      case StandardNames.XS_HEX_BINARY =>
        value.asInstanceOf[HexBinaryValue].getBinaryValue
      case _ =>
        item
    }
  }

  /**
   * Get the string value of a sequence. For an item, this is same as the result
   * of calling the XPath string() function. For a sequence of more than one item,
   * it is the concatenation of the individual string values of the items in the sequence,
   * space-separated.
   *
   * @param sequence the input sequence
   * @return a string representation of the items in the supplied sequence
   * @throws XPathException if the sequence contains an item with no string value,
   *                        for example a function item
   */
  @throws[XPathException]
  def getStringValue(sequence: Sequence) = {
    val fsb = new FastStringBuffer(FastStringBuffer.C64)
    sequence.iterate.forEachOrFail((item: Item) => {
      def foo(item: Item) = {
        if (!fsb.isEmpty) fsb.cat(' ')
        fsb.cat(item.getStringValueCS)
      }

      foo(item)
    })
    fsb.toString
  }

  /**
   * Get the item type of the items in a sequence. If the sequence is heterogeneous,
   * the method returns the lowest common supertype. If the sequence is empty, it returns
   * ErrorType (the type to which no instance can belong)
   *
   * @param sequence the input sequence
   * @param th       the Type Hierarchy cache
   * @return the lowest common supertype of the types of the items in the sequence
   */
  def getItemType(sequence: Sequence, th: TypeHierarchy) = if (sequence.isInstanceOf[Item]) Type.getItemType(sequence.asInstanceOf[Item], th)
  else if (sequence.isInstanceOf[GroundedValue]) try {
    var `type` = null
    val iter = sequence.iterate
    var item = null
    while ( {
      (item = iter.next) != null
    }) {
      if (`type` == null) `type` = Type.getItemType(item, th)
      else `type` = Type.getCommonSuperType(`type`, Type.getItemType(item, th), th)
      if (`type` eq AnyItemType.getInstance) break //todo: break is not supported
    }
    if (`type` == null) ErrorType.getInstance
    else `type`
  } catch {
    case err: XPathException =>
      AnyItemType.getInstance
  }
  else AnyItemType.getInstance

  /**
   * Get the UType of the items in a sequence. If the sequence is heterogeneous,
   * the method returns the lowest common supertype. If the sequence is empty, it returns
   * ErrorType (the type to which no instance can belong)
   *
   * @param sequence the input sequence
   * @return the lowest common supertype of the types of the items in the sequence
   */
  def getUType(sequence: Sequence) = if (sequence.isInstanceOf[Item]) UType.getUType(sequence.asInstanceOf[Item])
  else if (sequence.isInstanceOf[GroundedValue]) {
    var `type` = UType.VOID
    val iter = sequence.asInstanceOf[GroundedValue].iterate()
    var item = null
    while ( {
      (item = iter.next) != null
    }) {
      `type` = `type`.union(UType.getUType(item))
      if (`type` eq UType.ANY) break //todo: break is not supported
    }
    `type`
  }
  else UType.ANY

  /**
   * Get the cardinality of a sequence
   *
   * @param sequence the supplied sequence
   * @return the cardinality, as one of the constants { @link StaticProperty#ALLOWS_ZERO} (for an empty sequence)
   *                                                          { @link StaticProperty#EXACTLY_ONE} (for a singleton), or { @link StaticProperty#ALLOWS_ONE_OR_MORE} (for
   *                                                          a sequence with more than one item)
   */
  def getCardinality(sequence: Sequence): Int = {
    if (sequence.isInstanceOf[Item]) return StaticProperty.EXACTLY_ONE
    if (sequence.isInstanceOf[GroundedValue]) {
      val len = sequence.asInstanceOf[GroundedValue].getLength()
      len match {
        case 0 =>
          return StaticProperty.ALLOWS_ZERO
        case 1 =>
          return StaticProperty.EXACTLY_ONE
        case _ =>
          return StaticProperty.ALLOWS_ONE_OR_MORE
      }
    }
    try {
      val iter = sequence.iterate
      var item = iter.next
      if (item == null) return StaticProperty.ALLOWS_ZERO
      item = iter.next
      if (item == null) StaticProperty.EXACTLY_ONE
      else StaticProperty.ALLOWS_ONE_OR_MORE
    } catch {
      case err: XPathException =>
        StaticProperty.ALLOWS_ONE_OR_MORE
    }
  }

  /**
   * Process a supplied value by copying it to the current output destination
   *
   * @param value      the sequence to be processed
   * @param output     the destination for the result
   * @param locationId (can be set to -1 if absent) information about the location of the value,
   *                   which can be resolved by reference to the PipelineConfiguration of the current output
   *                   destination
   * @throws net.sf.saxon.trans.XPathException if an error occurs (for example if the value is
   *                                           a closure that needs to be evaluated)
   */
  @throws[XPathException]
  def process(value: Sequence, output: Outputter, locationId: Location) = value.iterate.forEachOrFail((it: Item) => output.append(it, locationId, ReceiverOption.ALL_NAMESPACES))

  /**
   * Make an array of general-purpose Sequence objects of a given length
   *
   * @param length the length of the returned array
   */
  def makeSequenceArray(length: Int) = new Array[Sequence](length).asInstanceOf[Array[Sequence]]

  /**
   * Make an array of general-purpose Sequence objects with supplied contents
   */
  def fromItems(items: Item*) = {
    val seq = new Array[Sequence](items.length).asInstanceOf[Array[Sequence]]
    System.arraycopy(items, 0, seq, 0, items.length)
    seq
  }
}