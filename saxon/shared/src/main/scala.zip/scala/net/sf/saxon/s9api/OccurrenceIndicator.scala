////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.expr.StaticProperty
import net.sf.saxon.value.Cardinality

/**
 * Represents one of the possible occurrence indicators in a SequenceType. The four standard values are
 * ONE (no occurrence indicator), ZERO_OR_ONE (?), ZERO_OR_MORE (*), ONE_OR_MORE (+). In addition the
 * value ZERO is supported: this is used only in the type empty-sequence() which matches an empty sequence
 * and nothing else.
 */
object OccurrenceIndicator extends Enumeration {
  type OccurrenceIndicator = Value
  val ZERO, ZERO_OR_ONE, ZERO_OR_MORE, ONE, ONE_OR_MORE = Value

  protected def getCardinality = this match {
    case ZERO =>
      StaticProperty.EMPTY
    case ZERO_OR_ONE =>
      StaticProperty.ALLOWS_ZERO_OR_ONE
    case ZERO_OR_MORE =>
      StaticProperty.ALLOWS_ZERO_OR_MORE
    case ONE =>
      StaticProperty.ALLOWS_ONE
    case ONE_OR_MORE =>
      StaticProperty.ALLOWS_ONE_OR_MORE
    case _ =>
      StaticProperty.EMPTY
  }

  protected

  def getOccurrenceIndicator(cardinality: Int) = cardinality match {
    case StaticProperty.EMPTY =>
      ZERO
    case StaticProperty.ALLOWS_ZERO_OR_ONE =>
      ZERO_OR_ONE
    case StaticProperty.ALLOWS_ZERO_OR_MORE =>
      ZERO_OR_MORE
    case StaticProperty.ALLOWS_ONE =>
      ONE
    case StaticProperty.ALLOWS_ONE_OR_MORE =>
      ONE_OR_MORE
    case _ =>
      ZERO_OR_MORE
  }

  /**
   * Ask whether this occurrence indicator permits an empty sequence.
   *
   * @return true if the occurrence indicator is one of { @link #ZERO}, { @link #ZERO_OR_ONE},
   *                                                            or { @link #ZERO_OR_MORE}
   * @since 9.2
   */
  def allowsZero = Cardinality.allowsZero(getCardinality)

  /**
   * Ask whether this occurrence indicator permits a sequence containing more than one item.
   *
   * @return true if the occurrence indicator is one of { @link #ZERO_OR_MORE} or { @link #ONE_OR_MORE}
   * @since 9.2
   */
  def allowsMany = Cardinality.allowsMany(getCardinality)

  /**
   * Ask whether one occurrence indicator subsumes another. Specifically,
   * <code>A.subsumes(B)</code> is true if every sequence that satisfies the occurrence
   * indicator B also satisfies the occurrence indicator A.
   *
   * @param other The other occurrence indicator
   * @return true if this occurrence indicator subsumes the other occurrence indicator
   * @since 9.1
   */
  def subsumes(/*@NotNull*/ other: OccurrenceIndicator) = Cardinality.subsumes(getCardinality, other.getCardinality)

  /**
   * Return a string representation of the occurrence indicator: one of "*", "+", "?", "0" (exactly zero)
   * or empty string (exactly one)
   *
   * @return a string representation of the occurrence indicator
   * @since 9.5
   */
  override def toString = this match {
    case ZERO =>
      "0"
    case ZERO_OR_ONE =>
      "?"
    case ZERO_OR_MORE =>
      "*"
    case ONE =>
      ""
    case ONE_OR_MORE =>
      "+"
    case _ =>
      "!!!"
  }
}