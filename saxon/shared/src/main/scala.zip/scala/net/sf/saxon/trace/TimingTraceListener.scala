////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.trace

import net.sf.saxon.Configuration
import net.sf.saxon.Controller
import net.sf.saxon.PreparedStylesheet
import net.sf.saxon.event.PushToReceiver
import net.sf.saxon.event.Receiver
import net.sf.saxon.event.TransformerReceiver
import net.sf.saxon.expr.XPathContext
import net.sf.saxon.expr.instruct._
import net.sf.saxon.lib.Logger
import net.sf.saxon.lib.StandardLogger
import net.sf.saxon.lib.TraceListener
import net.sf.saxon.om.Item
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.s9api.HostLanguage
import net.sf.saxon.s9api.Push
import net.sf.saxon.s9api.SaxonApiException
import net.sf.saxon.serialize.SerializationProperties
import net.sf.saxon.style.Compilation
import net.sf.saxon.trans.CompilerInfo
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XsltController
import net.sf.saxon.value.StringValue
import javax.xml.transform.TransformerException
import javax.xml.transform.stream.StreamSource
import java.io.InputStream
import java.util._

/**
 * A trace listener that records timing information for templates and functions, outputting this
 * information as an HTML report to a specified destination when the transformation completes.
 */
object TimingTraceListener {

  private class ComponentMetrics {
    private[trace] val component = null
    private[trace] val properties = null
    private[trace] val gross = 0L
    private[trace] val net = 0L
    private[trace] val count = 0L
  }

}

class TimingTraceListener extends TraceListener {
  private var runs = 0
  private var out = new StandardLogger
  private var t_total = 0L
  private val metrics = new util.Stack[TimingTraceListener.ComponentMetrics]
  private val instructMap = new util.HashMap[Traceable, TimingTraceListener.ComponentMetrics]
  protected var config = null
  private val recursionDepth = new util.HashMap[Traceable, Integer]
  private var lang = HostLanguage.XSLT

  /**
   * Set the PrintStream to which the output will be written.
   *
   * @param stream the PrintStream to be used for output. By default, the output is written
   *               to System.err.
   */
  override def setOutputDestination(stream: Logger) = out = stream

  /**
   * Called at start
   */
  override def open(/*@NotNull*/ controller: Controller) = {
    config = controller.getConfiguration
    lang = controller.getExecutable.getHostLanguage
    t_total = System.nanoTime
  }

  /**
   * Called at end. This method builds the XML out and analyzed html output
   */
  override def close() = {
    t_total = System.nanoTime - t_total
    runs += 1
    try {
      val sheet = this.getStyleSheet
      val controller = sheet.newController
      val props = new SerializationProperties
      props.setProperty("method", "html")
      props.setProperty("indent", "yes")
      controller.setTraceListener(null)
      val tr = new TransformerReceiver(controller)
      controller.initializeController(new GlobalParameterSet)
      tr.open()
      val result = config.getSerializerFactory.getReceiver(out.asStreamResult, props, controller.makePipelineConfiguration)
      tr.setDestination(result)
      val push = new PushToReceiver(tr)
      val doc = push.document(true)
      val trace = doc.element("trace").attribute("t-total", Double.toString(t_total.toDouble / 1000000))
      import scala.collection.JavaConversions._
      for (ins <- instructMap.values) {
        val fn = trace.element("fn")
        var name = null
        if (ins.component.getObjectName != null) {
          name = ins.component.getObjectName.getDisplayName
          fn.attribute("name", name)
        }
        else if (ins.properties.get("name") != null) {
          name = ins.properties.get("name").toString
          fn.attribute("name", name)
        }
        if (ins.properties.get("match") != null) {
          name = ins.properties.get("match").toString
          fn.attribute("match", name)
        }
        if (ins.properties.get("mode") != null) {
          name = ins.properties.get("mode").toString
          fn.attribute("mode", name)
        }
        fn.attribute("construct", ins.component.getTracingTag).attribute("file", ins.component.getLocation.getSystemId).attribute("count", Long.toString(ins.count / runs)).attribute("t-sum-net", Double.toString(ins.net.toDouble / runs / 1000000)).attribute("t-avg-net", Double.toString(ins.net / ins.count.toDouble / 1000000)).attribute("t-sum", Double.toString(ins.gross.toDouble / runs / 1000000)).attribute("t-avg", Double.toString(ins.gross / ins.count.toDouble / 1000000)).attribute("line", Long.toString(ins.component.getLocation.getLineNumber)).close()
      }
      doc.close()
    } catch {
      case e: TransformerException =>
        System.err.println("Unable to transform timing profile information: " + e.getMessage)
      case e: SaxonApiException =>
        System.err.println("Unable to generate timing profile information: " + e.getMessage)
    }
  }

  /**
   * Called when an instruction in the stylesheet gets processed
   */
  override def enter(instruction: Traceable, properties: util.Map[String, AnyRef], context: XPathContext) = if (isTarget(instruction)) {
    val start = System.nanoTime
    val metric = new TimingTraceListener.ComponentMetrics
    metric.component = instruction.asInstanceOf[TraceableComponent]
    metric.properties = properties
    metric.gross = start
    metrics.add(metric)
    val depth = recursionDepth.get(instruction)
    if (depth == null) recursionDepth.put(instruction, 0)
    else recursionDepth.put(instruction, depth + 1)
  }

  private def isTarget(traceable: Traceable) = traceable.isInstanceOf[UserFunction] || traceable.isInstanceOf[GlobalVariable] || traceable.isInstanceOf[NamedTemplate] || traceable.isInstanceOf[TemplateRule]

  /**
   * Called after an instruction of the stylesheet got processed
   *
   * @param instruction the instruction or other construct that has now finished execution
   */
  override def leave(instruction: Traceable) = if (isTarget(instruction)) {
    val metric = metrics.peek
    val duration = System.nanoTime - metric.gross
    metric.net = duration - metric.net
    metric.gross = duration
    val foundInstructDetails = instructMap.get(instruction)
    if (foundInstructDetails == null) {
      metric.count = 1
      instructMap.put(instruction, metric)
    }
    else {
      foundInstructDetails.count += 1
      var depth = recursionDepth.get(instruction)
      recursionDepth.put(instruction, {
        depth -= 1; depth
      })
      if (depth eq 0) foundInstructDetails.gross = foundInstructDetails.gross + metric.gross
      foundInstructDetails.net = foundInstructDetails.net + metric.net
    }
    metrics.pop
    if (!metrics.isEmpty) {
      val parentInstruct = metrics.peek
      parentInstruct.net = parentInstruct.net + duration
    }
  }

  /**
   * Called when an item becomes current
   */
  override def startCurrentItem(item: Item) = {
  }

  /**
   * Called after a node of the source tree got processed
   */
  override def endCurrentItem(item: Item) = {
  }

  /**
   * Prepare Stylesheet to render the analyzed XML data out.
   * This method can be overridden in a subclass to produce the output in a different format.
   */
  @throws[XPathException]
  private def getStyleSheet = {
    val in = getStylesheetInputStream
    val ss = new StreamSource(in, "profile.xsl")
    val info = config.getDefaultXsltCompilerInfo
    info.setParameter(new StructuredQName("", "", "lang"), new StringValue(if (this.lang eq HostLanguage.XSLT) "XSLT"
    else "XQuery"))
    Compilation.compileSingletonPackage(config, info, ss)
  }

  /**
   * Get an input stream containing the stylesheet used for formatting results
   *
   * @return the input stream
   */
  private def getStylesheetInputStream = {
    val messages = new util.ArrayList[String]
    val classLoaders = new util.ArrayList[ClassLoader]
    Configuration.locateResource("profile.xsl", messages, classLoaders)
  }
}