////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.model.FunctionItemType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.PlainType
import net.sf.saxon.value.SequenceType

/**
 * Defines the role of a child expression relative to its parent expression. The properties
 * of an operand role depend only on the kind of expression and not on the actual arguments
 * supplied to a specific instance of the kind of operand.
 */
object OperandRole {
  val SETS_NEW_FOCUS = 1
  val USES_NEW_FOCUS = 2
  val HIGHER_ORDER = 4
  val IN_CHOICE_GROUP = 8
  val CONSTRAINED_CLASS = 16
  val SINGLETON = 32 // set only where HIGHER_ORDER would otherwise imply repeated evaluation
  val HAS_SPECIAL_FOCUS_RULES = 64
  val SAME_FOCUS_ACTION = new OperandRole(0, OperandUsage.TRANSMISSION, SequenceType.ANY_SEQUENCE)
  val FOCUS_CONTROLLING_SELECT = new OperandRole(OperandRole.SETS_NEW_FOCUS, OperandUsage.INSPECTION, SequenceType.ANY_SEQUENCE)
  val FOCUS_CONTROLLED_ACTION = new OperandRole(OperandRole.USES_NEW_FOCUS | OperandRole.HIGHER_ORDER, OperandUsage.TRANSMISSION, SequenceType.ANY_SEQUENCE)
  val INSPECT = new OperandRole(0, OperandUsage.INSPECTION, SequenceType.ANY_SEQUENCE)
  val ABSORB = new OperandRole(0, OperandUsage.ABSORPTION, SequenceType.ANY_SEQUENCE)
  val REPEAT_INSPECT = new OperandRole(OperandRole.HIGHER_ORDER, OperandUsage.INSPECTION, SequenceType.ANY_SEQUENCE)
  val NAVIGATE = new OperandRole(0, OperandUsage.NAVIGATION, SequenceType.ANY_SEQUENCE)
  val REPEAT_NAVIGATE = new OperandRole(OperandRole.HIGHER_ORDER, OperandUsage.NAVIGATION, SequenceType.ANY_SEQUENCE)
  val REPEAT_NAVIGATE_CONSTRAINED = new OperandRole(OperandRole.HIGHER_ORDER | OperandRole.CONSTRAINED_CLASS, OperandUsage.NAVIGATION, SequenceType.ANY_SEQUENCE)
  val SINGLE_ATOMIC = new OperandRole(0, OperandUsage.ABSORPTION, SequenceType.SINGLE_ATOMIC)
  val ATOMIC_SEQUENCE = new OperandRole(0, OperandUsage.ABSORPTION, SequenceType.ATOMIC_SEQUENCE)
  val NEW_FOCUS_ATOMIC = new OperandRole(OperandRole.USES_NEW_FOCUS | OperandRole.HIGHER_ORDER, OperandUsage.ABSORPTION, SequenceType.ATOMIC_SEQUENCE)
  val PATTERN = new OperandRole(OperandRole.USES_NEW_FOCUS | OperandRole.HIGHER_ORDER | OperandRole.CONSTRAINED_CLASS, OperandUsage.ABSORPTION, SequenceType.ATOMIC_SEQUENCE)

  /**
   * Static method to get the type-determined usage for a particular ItemType
   *
   * @param type the required type
   * @return the type-determined operand usage
   */
  def getTypeDeterminedUsage(`type`: ItemType) = if (`type`.isInstanceOf[FunctionItemType]) OperandUsage.INSPECTION
  else if (`type`.isInstanceOf[PlainType]) OperandUsage.ABSORPTION
  else OperandUsage.NAVIGATION
}

class OperandRole {
  private[expr] var properties = 0
  private var usage = null
  private var requiredType = SequenceType.ANY_SEQUENCE

  def this(properties: Int, usage: OperandUsage.type) {
    this()
    this.properties = properties
    this.usage = usage
  }

  def this(properties: Int, usage: OperandUsage.type, requiredType: SequenceType) {
    this()
    this.properties = properties
    this.usage = usage
    this.requiredType = requiredType
  }

  /**
   * Ask whether the child expression sets the focus for evaluation of other child expressions
   *
   * @return true if the child expression is evaluated with the same focus as its parent expression
   */
  def setsNewFocus = (properties & OperandRole.SETS_NEW_FOCUS) != 0

  /**
   * Ask whether the child expression is evaluated with the same focus as its parent expression
   *
   * @return true if the child expression is evaluated with the same focus as its parent expression
   */
  def hasSameFocus = (properties & (OperandRole.USES_NEW_FOCUS | OperandRole.HAS_SPECIAL_FOCUS_RULES)) == 0

  def hasSpecialFocusRules = (properties & OperandRole.HAS_SPECIAL_FOCUS_RULES) != 0

  /**
   * Ask whether the operand is a higher-order operand
   *
   * @return true if the operand is higher-order
   */
  def isHigherOrder = (properties & OperandRole.HIGHER_ORDER) != 0

  /**
   * Ask whether the operand is a evaluated repeatedly during a single evaluation of the
   * parent expression
   *
   * @return true if the operand is evaluated repeatedly
   */
  def isEvaluatedRepeatedly = ((properties & OperandRole.HIGHER_ORDER) != 0) && ((properties & OperandRole.SINGLETON) == 0)

  /**
   * Ask whether the operand is constrained to be of a particular class (preventing
   * substitution of a variable binding)
   *
   * @return true if the operand expression is constrained to be of a particular class
   */
  def isConstrainedClass = (properties & OperandRole.CONSTRAINED_CLASS) != 0

  /**
   * Get the usage of the operand
   *
   * @return the usage
   */
  def getUsage = usage

  /**
   * Get the required type of the operand
   *
   * @return the required type
   */
  def getRequiredType = requiredType

  /**
   * Ask whether the operand is a member of a choice group
   *
   * @return true if the operand is in a choice group
   */
  def isInChoiceGroup = (properties & OperandRole.IN_CHOICE_GROUP) != 0

  def modifyProperty(property: Int, on: Boolean) = {
    val newProp = if (on) properties | property
    else properties & ~(property)
    new OperandRole(newProp, usage, requiredType)
  }

  def getProperties = properties
}