////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr._
import net.sf.saxon.expr.instruct.DocumentInstr
import net.sf.saxon.expr.instruct.GlobalVariable
import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.expr.instruct.ValueOf
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.Affinity
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.model.UType
import net.sf.saxon.om._
import net.sf.saxon.pattern.NodeKindTest
import net.sf.saxon.s9api.XmlProcessingError
import net.sf.saxon.trans.Visibility
import net.sf.saxon.trans.XPathException
import net.sf.saxon.trans.XmlProcessingException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.StringValue
import net.sf.saxon.value.Whitespace
import java.util
import net.sf.saxon.style.SourceBinding.BindingProperty.SELECT

/**
 * Helper class for xsl:variable and xsl:param elements. <br>
 */
object SourceBinding {

  object BindingProperty extends Enumeration {
    type BindingProperty = Value
    val PRIVATE, GLOBAL, PARAM, TUNNEL, REQUIRED, IMPLICITLY_REQUIRED, ASSIGNABLE, SELECT, AS, DISALLOWS_CONTENT, STATIC, VISIBILITY, IMPLICITLY_DECLARED = Value
  }

}

class SourceBinding(var sourceElement: StyleElement) {
  private var name = null
  private var select = null
  private var declaredType = null
  private var inferredType = null
  protected var slotManager = null // used only for global variable declarations
  private var visibility = null
  private var constantValue = null
  private val properties = util.EnumSet.noneOf(classOf[SourceBinding.BindingProperty])
  // List of VariableReference objects that reference this XSLVariableDeclaration
  private val references = new util.ArrayList[BindingReference](10)

  def prepareAttributes(permittedAttributes: util.EnumSet[SourceBinding.BindingProperty]) = {
    val atts = sourceElement.attributes
    var selectAtt = null
    var asAtt = null
    var extraAsAtt = null
    var requiredAtt = null
    var tunnelAtt = null
    var assignableAtt = null
    var staticAtt = null
    var visibilityAtt = null
    import scala.collection.JavaConversions._
    for (att <- atts) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      if (f == "name") if (name == null || name == errorName) processVariableName(att.getValue)
      else if (f == "select") if (permittedAttributes.contains(SELECT)) selectAtt = att
      else sourceElement.compileErrorInAttribute("The select attribute is not permitted on a function parameter", "XTSE0760", "select")
      else if (f == "as" && permittedAttributes.contains(SourceBinding.BindingProperty.AS)) asAtt = att.getValue
      else if (f == "required" && permittedAttributes.contains(SourceBinding.BindingProperty.REQUIRED)) requiredAtt = Whitespace.trim(att.getValue)
      else if (f == "tunnel") tunnelAtt = Whitespace.trim(att.getValue)
      else if (f == "static" && permittedAttributes.contains(SourceBinding.BindingProperty.STATIC)) staticAtt = Whitespace.trim(att.getValue)
      else if (f == "visibility" && permittedAttributes.contains(SourceBinding.BindingProperty.VISIBILITY)) visibilityAtt = Whitespace.trim(att.getValue)
      else if (NamespaceConstant.SAXON == attName.getURI) if (sourceElement.isExtensionAttributeAllowed(attName.getDisplayName)) if (attName.getLocalPart == "assignable" && permittedAttributes.contains(SourceBinding.BindingProperty.ASSIGNABLE)) assignableAtt = Whitespace.trim(att.getValue)
      else if (attName.getLocalPart == "as") extraAsAtt = att.getValue
      else sourceElement.checkUnknownAttribute(att.getNodeName)
      else sourceElement.checkUnknownAttribute(att.getNodeName)
    }
    if (name == null) {
      sourceElement.reportAbsence("name")
      name = errorName
    }
    if (selectAtt != null) select = sourceElement.makeExpression(selectAtt.getValue, selectAtt)
    if (requiredAtt != null) {
      val required = sourceElement.processBooleanAttribute("required", requiredAtt)
      setProperty(SourceBinding.BindingProperty.REQUIRED, required)
      if (required && select != null) sourceElement.compileError("xsl:param: cannot supply a default value when required='yes'")
    }
    if (tunnelAtt != null) {
      val tunnel = sourceElement.processBooleanAttribute("tunnel", tunnelAtt)
      if (tunnel && !permittedAttributes.contains(SourceBinding.BindingProperty.TUNNEL)) sourceElement.compileErrorInAttribute("The only permitted value of the 'tunnel' attribute is 'no'", "XTSE0020", "tunnel")
      setProperty(SourceBinding.BindingProperty.TUNNEL, tunnel)
    }
    if (assignableAtt != null) {
      val assignable = sourceElement.processBooleanAttribute("saxon:assignable", assignableAtt)
      setProperty(SourceBinding.BindingProperty.ASSIGNABLE, assignable)
    }
    if (staticAtt != null) {
      val statick = sourceElement.processBooleanAttribute("static", staticAtt)
      setProperty(SourceBinding.BindingProperty.STATIC, statick)
      if (statick) setProperty(SourceBinding.BindingProperty.DISALLOWS_CONTENT, true)
      if (statick && !hasProperty(SourceBinding.BindingProperty.GLOBAL)) sourceElement.compileErrorInAttribute("Only global declarations can be static", "XTSE0020", "static")
    }
    declaredType = combineTypeDeclarations(asAtt, extraAsAtt)
    if (visibilityAtt != null) {
      if (hasProperty(SourceBinding.BindingProperty.PARAM)) sourceElement.compileErrorInAttribute("The visibility attribute is not allowed on xsl:param", "XTSE0020", "visibility")
      else visibility = sourceElement.interpretVisibilityValue(visibilityAtt, "")
      if (!hasProperty(SourceBinding.BindingProperty.GLOBAL)) sourceElement.compileErrorInAttribute("The visibility attribute is allowed only on global declarations", "XTSE0020", "visibility")
    }
    if (hasProperty(SourceBinding.BindingProperty.STATIC) && (visibility ne Visibility.PRIVATE) && visibilityAtt != null) sourceElement.compileErrorInAttribute("A static variable or parameter must be private", "XTSE0020", "static")
  }

  /**
   * This method is called to establish basic signature information for local parameters of a named template,
   * so that this can be checked against xsl:call-template instructions. It is called while a named template
   * is being indexed: see bug 3722.
   */
  def prepareTemplateSignatureAttributes() = {
    val atts = sourceElement.attributes
    var asAtt = null
    var extraAsAtt = null
    import scala.collection.JavaConversions._
    for (att <- atts) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      if (f == "name") if (name == null || name == errorName) processVariableName(att.getValue)
      else if (f == "as") asAtt = att.getValue
      else if (f == "required") {
        val requiredAtt = Whitespace.trim(att.getValue)
        val required = sourceElement.processBooleanAttribute("required", requiredAtt)
        setProperty(SourceBinding.BindingProperty.REQUIRED, required)
      }
      else if (f == "tunnel") {
        val tunnelAtt = Whitespace.trim(att.getValue)
        val tunnel = sourceElement.processBooleanAttribute("tunnel", tunnelAtt)
        setProperty(SourceBinding.BindingProperty.TUNNEL, tunnel)
      }
      else if (NamespaceConstant.SAXON == attName.getURI) if (attName.getLocalPart == "as") extraAsAtt = att.getValue
    }
    if (name == null) {
      sourceElement.reportAbsence("name")
      name = errorName
    }
    declaredType = combineTypeDeclarations(asAtt, extraAsAtt)
  }

  private def combineTypeDeclarations(asAtt: String, extraAsAtt: String) = {
    var declaredType = null
    if (asAtt != null) try declaredType = sourceElement.makeSequenceType(asAtt)
    catch {
      case e: XPathException =>
        sourceElement.compileErrorInAttribute(e.getMessage, e.getErrorCodeLocalPart, "as")
    }
    if (extraAsAtt != null) {
      var extraResultType = null
      try extraResultType = sourceElement.makeExtendedSequenceType(extraAsAtt)
      catch {
        case e: XPathException =>
          sourceElement.compileErrorInAttribute(e.getMessage, e.getErrorCodeLocalPart, "saxon:as")
          extraResultType = SequenceType.ANY_SEQUENCE
      }
      if (asAtt != null) {
        val rel = sourceElement.getConfiguration.getTypeHierarchy.sequenceTypeRelationship(extraResultType, declaredType)
        if ((rel eq Affinity.SAME_TYPE) || (rel eq Affinity.SUBSUMED_BY)) declaredType = extraResultType
        else sourceElement.compileErrorInAttribute("When both are present, @saxon:as must be a subtype of @as", "SXER7TBA", "as")
      }
      else declaredType = extraResultType
    }
    declaredType
  }

  /**
   * Get the declaration in the stylesheet
   *
   * @return the node in the stylesheet containing this variable binding
   */
  def getSourceElement = sourceElement

  /**
   * Set the name of the variable
   *
   * @param name the name of the variable as a QName
   */
  def setVariableQName(name: StructuredQName) = this.name = name

  /**
   * Set the declared type of the variable
   *
   * @param declaredType the declared type
   */
  def setDeclaredType(declaredType: SequenceType) = this.declaredType = declaredType

  /**
   * Process the QName of the variable. Validate the name and place it in the "name" field;
   * if invalid, construct an error message and place a dummy name in the "name" field for
   * recovery purposes.
   *
   * @param nameAttribute the lexical QName
   */
  private def processVariableName(nameAttribute: String) = if (nameAttribute != null) {
    if (nameAttribute.startsWith("$")) {
      sourceElement.compileErrorInAttribute("Invalid variable name (no '$' sign needed)", "XTSE0020", "name")
      nameAttribute = nameAttribute.substring(1)
    }
    name = sourceElement.makeQName(nameAttribute, null, "name")
  }

  /**
   * Fallback name to be returned if there is anything wrong with the variable's real name
   * (after reporting an error)
   *
   * @return a fallback name
   */
  private def errorName = new StructuredQName("saxon", NamespaceConstant.SAXON, "error-variable-name")

  /**
   * Validate the declaration
   *
   * @throws XPathException if the declaration is invalid
   */
  @throws[XPathException]
  def validate() = {
    if (select != null && sourceElement.hasChildNodes) sourceElement.compileError("An " + sourceElement.getDisplayName + " element with a select attribute must be empty", "XTSE0620")
    if (hasProperty(SourceBinding.BindingProperty.DISALLOWS_CONTENT) && sourceElement.hasChildNodes) if (isStatic) sourceElement.compileError("A static variable or parameter must have no content", "XTSE0010")
    else sourceElement.compileError("Within xsl:function, an xsl:param element must have no content", "XTSE0620")
    if ((visibility eq Visibility.ABSTRACT) && (select != null || sourceElement.hasChildNodes)) sourceElement.compileError("An abstract variable must have no select attribute and no content", "XTSE0620")
  }

  /**
   * Hook to allow additional validation of a parent element immediately after its
   * children have been validated.
   *
   * @throws XPathException if the declaration is invalid
   */
  @throws[XPathException]
  def postValidate() = {
    checkAgainstRequiredType(declaredType)
    if (select == null && !hasProperty(SourceBinding.BindingProperty.DISALLOWS_CONTENT) && (visibility ne Visibility.ABSTRACT)) {
      val kids = sourceElement.iterateAxis(AxisInfo.CHILD)
      val first = kids.next
      if (first == null) if (declaredType == null) {
        select = new StringLiteral(StringValue.EMPTY_STRING)
        select.setRetainedStaticContext(sourceElement.makeRetainedStaticContext)
      }
      else if (sourceElement.isInstanceOf[XSLLocalParam] || sourceElement.isInstanceOf[XSLGlobalParam]) if (!hasProperty(SourceBinding.BindingProperty.REQUIRED)) if (Cardinality.allowsZero(declaredType.getCardinality)) {
        select = Literal.makeEmptySequence
        select.setRetainedStaticContext(sourceElement.makeRetainedStaticContext)
      }
      else { // The implicit default value () is not valid for the required type, so
        // it is treated as if there is no default
        setProperty(SourceBinding.BindingProperty.IMPLICITLY_REQUIRED, true)
      }
      else if (Cardinality.allowsZero(declaredType.getCardinality)) {
        select = Literal.makeEmptySequence
        select.setRetainedStaticContext(sourceElement.makeRetainedStaticContext)
      }
      else sourceElement.compileError("The implicit value () is not valid for the declared type", "XTTE0570")
    }
    select = sourceElement.typeCheck("select", select)
  }

  def isStatic = hasProperty(SourceBinding.BindingProperty.STATIC)

  /**
   * Check the supplied select expression against the required type.
   *
   * @param required The type required by the variable declaration, or in the case
   *                 of xsl:with-param, the signature of the called template
   */
  def checkAgainstRequiredType(required: SequenceType) = if (visibility ne Visibility.ABSTRACT) try if (required != null) { // check that the expression is consistent with the required type
    if (select != null) {
      var category = RoleDiagnostic.VARIABLE
      var errorCode = "XTTE0570"
      if (sourceElement.isInstanceOf[XSLLocalParam]) {
        category = RoleDiagnostic.PARAM
        errorCode = "XTTE0600"
      }
      else if (sourceElement.isInstanceOf[XSLWithParam] || sourceElement.isInstanceOf[XSLGlobalParam]) {
        category = RoleDiagnostic.PARAM
        errorCode = "XTTE0590"
      }
      val role = new RoleDiagnostic(category, name.getDisplayName, 0)
      //role.setSourceLocator(new ExpressionLocation(this));
      role.setErrorCode(errorCode)
      select = sourceElement.getConfiguration.getTypeChecker(false).staticTypeCheck(select, required, role, sourceElement.makeExpressionVisitor)
    }
    else {
      // do the check later
    }
  }
  catch {
    case err: XPathException =>
      err.setLocator(sourceElement) // because the expression wasn't yet linked into the module
      sourceElement.compileError(err)
      select = new ErrorExpression(new XmlProcessingException(err))
  }

  /**
   * Get the name of the variable
   *
   * @return the variable's name
   */
  def getVariableQName = {
    if (name == null) processVariableName(sourceElement.getAttributeValue("", "name"))
    name
  }

  /**
   * Set a boolean property of the variable
   *
   * @param prop the property to be set (e.g. { @link BindingProperty#TUNNEL})
   * @param flag true to set the property on, false to set it off
   */
  def setProperty(prop: SourceBinding.BindingProperty, flag: Boolean) = if (flag) properties.add(prop)
  else properties.remove(prop)

  /**
   * Get a boolean property of the variable
   *
   * @param prop the property whose value is required
   * @return true if the variable has the specified property, otherwise false
   */
  def hasProperty(prop: SourceBinding.BindingProperty) = properties.contains(prop)

  /**
   * Get all the known references to this variable
   *
   * @return the list of references
   */
  def getReferences = references

  /**
   * Get the SlotManager associated with this stylesheet construct. The SlotManager contains the
   * information needed to manage the local stack frames used by run-time instances of the code.
   *
   * @return the associated SlotManager object
   */
  def getSlotManager = slotManager

  /**
   * If the element contains a sequence constructor, convert this to an expression and assign it to the
   * select attribute
   *
   * @param compilation the compilation episode
   * @param decl        the declaration being compiled
   * @throws XPathException if a static error is found, for example a type error
   */
  @throws[XPathException]
  def handleSequenceConstructor(compilation: Compilation, decl: ComponentDeclaration) = { // handle the "temporary tree" case by creating a Document sub-instruction
    // to construct and return a document node.
    if (sourceElement.hasChildNodes) if (declaredType == null) {
      var b = sourceElement.compileSequenceConstructor(compilation, decl, true)
      if (b == null) b = Literal.makeEmptySequence
      val textonly = UType.TEXT.subsumes(b.getItemType.getUType)
      var constant = null // bug 3748
      if (textonly && b.isInstanceOf[ValueOf] && b.asInstanceOf[ValueOf].getSelect.isInstanceOf[StringLiteral]) constant = (b.asInstanceOf[ValueOf]).getSelect.asInstanceOf[StringLiteral].getStringValue
      val doc = new DocumentInstr(textonly, constant)
      doc.setContentExpression(b)
      doc.setRetainedStaticContext(sourceElement.makeRetainedStaticContext)
      select = doc
    }
    else {
      select = sourceElement.compileSequenceConstructor(compilation, decl, true)
      if (select == null) select = Literal.makeEmptySequence
      try {
        val role = new RoleDiagnostic(RoleDiagnostic.VARIABLE, name.getDisplayName, 0)
        role.setErrorCode("XTTE0570")
        select = select.simplify
        select = sourceElement.getConfiguration.getTypeChecker(false).staticTypeCheck(select, declaredType, role, sourceElement.makeExpressionVisitor)
      } catch {
        case err: XPathException =>
          err.setLocator(sourceElement)
          val error = new XmlProcessingException(err)
          sourceElement.compileError(error)
          select = new ErrorExpression(error)
      }
    }
  }

  /**
   * Get the type actually declared for the attribute
   *
   * @return the type appearing in the "as" attribute, or null if the attribute was absent
   */
  def getDeclaredType: SequenceType = {
    if (declaredType == null) { // may be handling a forwards reference - see hof-038
      val asAtt = sourceElement.getAttributeValue("", "as")
      if (asAtt == null) return null
      else try declaredType = sourceElement.makeSequenceType(asAtt)
      catch {
        case err: XPathException =>

        // the error will be reported when we get round to processing the function declaration
      }
    }
    declaredType
  }

  /**
   * Get the select expression actually appearing in the variable declaration
   *
   * @return the select expression as it appears, or null if it is absent
   */
  def getSelectExpression = select

  /**
   * Get the best available static type of the variable.
   *
   * @param useContentRules set to true if the standard rules for xsl:variable and similar elements apply,
   *                        whereby the element's contained sequence constructor substitutes for the select attribute
   * @return the static type declared for the variable, or inferred from its initialization
   */
  def getInferredType(useContentRules: Boolean): SequenceType = {
    if (inferredType != null) return inferredType
    val visibility = sourceElement.getVisibility
    if (hasProperty(SourceBinding.BindingProperty.PARAM) || hasProperty(SourceBinding.BindingProperty.ASSIGNABLE) || !((visibility eq Visibility.PRIVATE) || (visibility eq Visibility.FINAL))) {
      val declared = getDeclaredType
      return inferredType = if (declared == null) SequenceType.ANY_SEQUENCE
      else declared
    }
    if (select != null) {
      val th = sourceElement.getConfiguration.getTypeHierarchy
      if (Literal.isEmptySequence(select)) { // returning Type.EMPTY gives problems with static type checking
        return inferredType = if (declaredType == null) SequenceType.ANY_SEQUENCE
        else declaredType
      }
      var actual = select.getItemType
      var card = select.getCardinality
      if (declaredType != null) {
        if (!th.isSubType(actual, declaredType.getPrimaryType)) actual = declaredType.getPrimaryType
        if (!Cardinality.subsumes(declaredType.getCardinality, card)) card = declaredType.getCardinality
      }
      inferredType = SequenceType.makeSequenceType(actual, card)
      return inferredType
    }
    if (useContentRules) if (sourceElement.hasChildNodes) if (declaredType == null) return SequenceType.makeSequenceType(NodeKindTest.DOCUMENT, StaticProperty.EXACTLY_ONE)
    else return declaredType
    else if (declaredType == null) { // no select attribute or content: value is an empty string
      return SequenceType.SINGLE_STRING
    }
    else return declaredType
    declaredType
  }

  /**
   * Method called by VariableReference to register the variable reference for
   * subsequent fixup
   *
   * @param ref the variable reference being registered
   */
  def registerReference(ref: BindingReference) = references.add(ref)

  def getConstantValue = {
    if (constantValue == null) {
      val `type` = getInferredType(true)
      val th = sourceElement.getConfiguration.getTypeHierarchy
      if (!hasProperty(SourceBinding.BindingProperty.ASSIGNABLE) && !hasProperty(SourceBinding.BindingProperty.PARAM) && !((visibility eq Visibility.PUBLIC) || (visibility eq Visibility.ABSTRACT))) if (select.isInstanceOf[Literal]) { // we can't rely on the constant value because it hasn't yet been type-checked,
        // which could change it (eg by numeric promotion). Rather than attempt all the type-checking
        // now, we do a quick check. See test bug64
        val relation = th.relationship(select.getItemType, `type`.getPrimaryType)
        if ((relation eq Affinity.SAME_TYPE) || (relation eq Affinity.SUBSUMED_BY)) constantValue = select.asInstanceOf[Literal].getValue
      }
    }
    constantValue
  }

  /**
   * Notify all references to this variable of the data type
   *
   * @param compiledGlobalVariable null if this is a local variable; otherwise, the compiled global variable
   */
  def fixupReferences(compiledGlobalVariable: GlobalVariable) = {
    val `type` = getInferredType(true)
    val th = sourceElement.getConfiguration.getTypeHierarchy
    val constantValue = null
    var properties = 0
    if (!hasProperty(SourceBinding.BindingProperty.ASSIGNABLE) && !hasProperty(SourceBinding.BindingProperty.PARAM) && !((visibility eq Visibility.PUBLIC) || (visibility eq Visibility.ABSTRACT))) {
      /*if (select instanceof Literal) {
                     // we can't rely on the constant value because it hasn't yet been type-checked,
                     // which could change it (eg by numeric promotion). Rather than attempt all the type-checking
                     // now, we do a quick check. See test bug64
                     int relation = th.relationship(select.getItemType(), type.getPrimaryType());
                     if (relation == TypeHierarchy.SAME_TYPE || relation == TypeHierarchy.SUBSUMED_BY) {
                         constantValue = ((Literal) select).getValue();
                     }
                 } */ if (select != null) properties = select.getSpecialProperties
    }
    import scala.collection.JavaConversions._
    for (reference <- references) {
      if (compiledGlobalVariable != null) reference.fixup(compiledGlobalVariable)
      reference.setStaticType(`type`, getConstantValue, properties)
    }
  }

  /**
   * Notify all variable references of the Binding instruction
   *
   * @param binding the Binding that represents this variable declaration in the executable code tree
   */
  protected def fixupBinding(binding: Binding) = {
    import scala.collection.JavaConversions._
    for (reference <- references) {
      reference.fixup(binding)
    }
  }
}