////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.model.FunctionItemType
import net.sf.saxon.model.SpecificFunctionType
import net.sf.saxon.model.UnionType
import net.sf.saxon.om._
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.AtomicValue
import net.sf.saxon.value.BooleanValue
import net.sf.saxon.value.SequenceType

/**
 * Function to test castability to a union type
 */
class UnionCastableFunction(val targetType: UnionType, val resolver: NamespaceResolver, val allowEmpty: Boolean)

/**
 * Create a cast expression to a union type
 *
 * @param targetType the union type that is the result of the cast
 * @param resolver   namespace resolver in case the type is namespace-sensitive
 * @param allowEmpty true if an empty sequence may be supplied as input, converting to an empty sequence on output
 */
  extends UnionConstructorFunction(targetType, resolver, allowEmpty) {
  /**
   * Get the item type of the function item
   *
   * @return the function item's type
   */
  override def getFunctionItemType = { // The function accepts any sequence as input, so it can do its own atomization
    new SpecificFunctionType(Array[SequenceType](SequenceType.ANY_SEQUENCE), SequenceType.SINGLE_BOOLEAN)
  }

  /**
   * Get the name of the function, or null if it is anonymous
   *
   * @return the function name, or null for an anonymous function
   */
  override def getFunctionName = null

  /**
   * Get the effective boolean value of the expression
   *
   * @param context The context in which the expression is to be evaluated
   * @return the effective boolean value
   * @throws XPathException if an error occurs evaluating the operand
   */
  @throws[XPathException]
  private def effectiveBooleanValue(iter: SequenceIterator, context: XPathContext): Boolean = { // This method does its own atomization so that it can distinguish between atomization
    // failures and casting failures
    var count = 0
    var item = null
    while ( {
      (item = iter.next) != null
    }) if (item.isInstanceOf[NodeInfo]) {
      val atomizedValue = item.atomize
      val length = SequenceTool.getLength(atomizedValue)
      count += length
      if (count > 1) return false
      if (length != 0) {
        val av = atomizedValue.head
        if (!castable(av, context)) return false
      }
    }
    else if (item.isInstanceOf[AtomicValue]) {
      val av = item.asInstanceOf[AtomicValue]
      count += 1
      if (count > 1) return false
      if (!castable(av, context)) return false
    }
    else throw new XPathException("Input to 'castable' operator cannot be atomized", "XPTY0004")
    count != 0 || allowEmpty
  }

  /**
   * Method to perform the castable check of an atomic value to a union type
   *
   * @param value   the input value to be converted. Must not be null.
   * @param context the XPath dynamic evaluation context
   * @return the result of the conversion (may be a sequence if the union includes list types in its membership)
   */
  private def castable(value: AtomicValue, context: XPathContext) = try {
    cast(value, context)
    true
  } catch {
    case err: XPathException =>
      false
  }

  /**
   * Invoke the function
   *
   * @param context the XPath dynamic evaluation context
   * @param args    the actual arguments to be supplied
   * @return the result of invoking the function
   * @throws net.sf.saxon.trans.XPathException if a dynamic error occurs within the function
   */
  @throws[XPathException]
  override def call(context: XPathContext, args: Array[Sequence]) = {
    val value = effectiveBooleanValue(args(0).iterate, context)
    BooleanValue.get(value)
  }
}