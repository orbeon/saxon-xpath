////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.Configuration
import net.sf.saxon.expr.Component
import net.sf.saxon.expr.ErrorExpression
import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.StaticProperty
import net.sf.saxon.expr.instruct.NamedTemplate
import net.sf.saxon.expr.instruct.SlotManager
import net.sf.saxon.expr.instruct.TemplateRule
import net.sf.saxon.expr.parser._
import net.sf.saxon.lib.Feature
import net.sf.saxon.lib.Logger
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.Affinity
import net.sf.saxon.model.AnyItemType
import net.sf.saxon.model.ErrorType
import net.sf.saxon.model.ItemType
import net.sf.saxon.om._
import net.sf.saxon.pattern.Pattern
import net.sf.saxon.s9api.HostLanguage
import net.sf.saxon.trans._
import net.sf.saxon.trans.rules.Rule
import net.sf.saxon.trans.rules.RuleManager
import net.sf.saxon.value.BigDecimalValue
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace
import java.util._

/**
 * An xsl:template element in the style sheet.
 */
final class XSLTemplate extends StyleElement with StylesheetComponent {
  private var matchAtt = null
  private var modeAtt = null
  private var nameAtt = null
  private var priorityAtt = null
  private var asAtt = null
  private var visibilityAtt = null
  private var modeNames = null
  private var diagnosticId = null
  private var `match` = null
  private var prioritySpecified = false
  private var priority = .0
  private var stackFrameMap = null
  // A compiled named template exists if the template has a name
  private var compiledNamedTemplate = null
  // A set of compiled template rules exists if the template has a match pattern: one TemplateRule for each mode
  private val compiledTemplateRules = new util.HashMap[StructuredQName, TemplateRule]
  private var requiredType = SequenceType.ANY_SEQUENCE
  private var declaresRequiredType = false
  private var hasRequiredParams = false
  private var isTailRecursive = false
  private var visibility = Visibility.PRIVATE
  private var requiredContextItemType = AnyItemType.getInstance
  private var mayOmitContextItem = true
  //private boolean maySupplyContextItem = true;
  private var absentFocus = false
  private var jitCompilationDone = false
  private var explaining = false

  /**
   * Get the corresponding NamedTemplate object that results from the compilation of this
   * StylesheetComponent
   */
  override def getActor = compiledNamedTemplate

  override def setCompilation(compilation: Compilation) = {
    super.setCompilation(compilation)
    //compiledNamedTemplate.setPackageData(compilation.getPackageData());
  }

  /**
   * Ask whether this node is a declaration, that is, a permitted child of xsl:stylesheet
   * (including xsl:include and xsl:import).
   *
   * @return true for this element
   */
  override def isDeclaration = true

  /**
   * Ask whether the compilation of the template should be deferred
   *
   * @param compilation the compilation
   * @return true if compilation should be deferred
   */
  def isDeferredCompilation(compilation: Compilation) = compilation.isPreScan && getTemplateName == null && !compilation.isLibraryPackage

  /**
   * Determine whether this type of element is allowed to contain a template-body
   *
   * @return true: yes, it may contain a template-body
   */
  override def mayContainSequenceConstructor = true

  override protected def mayContainParam = true

  override protected def isWithinDeclaredStreamableConstruct: Boolean = {
    try{

    for (m <- getApplicableModes) {
      if (m.isDeclaredStreamable) return true
    }
    }
    catch
    {
      case e: XPathException =>
        return false
    }
    false
  }

  /**
   * Set the required context item type. Used when there is an xsl:context-item child element
   *
   * @param type         the required context item type
   * @param mayBeOmitted true if the context item may be absent
   * @param absentFocus  true if use=absent is specified
   */
  def setContextItemRequirements(`type`: ItemType, mayBeOmitted: Boolean, absentFocus: Boolean) = {
    requiredContextItemType = `type`
    mayOmitContextItem = mayBeOmitted
    this.absentFocus = absentFocus
  }

  /**
   * Specify that xsl:param and xsl:context-item are permitted children
   */
  override protected def isPermittedChild(child: StyleElement) = child.isInstanceOf[XSLLocalParam] || child.getFingerprint == StandardNames.XSL_CONTEXT_ITEM

  /**
   * Return the name of this template. Note that this may
   * be called before prepareAttributes has been called.
   *
   * @return the name of the template as a Structured QName.
   */
  /*@Nullable*/ def getTemplateName = {
    if (getObjectName == null) { // allow for forwards references
      val nameAtt = getAttributeValue("", "name")
      if (nameAtt != null) setObjectName(makeQName(nameAtt, null, "name"))
    }
    getObjectName
  }

  override def getSymbolicName = if (getTemplateName == null) null
  else new SymbolicName(StandardNames.XSL_TEMPLATE, getTemplateName)

  def getRequiredContextItemType = requiredContextItemType

  def isMayOmitContextItem = mayOmitContextItem

  override def checkCompatibility(component: Component): Unit = {
    val other = component.getActor.asInstanceOf[NamedTemplate]
    if (!(getSymbolicName == other.getSymbolicName)) throw new IllegalArgumentException
    val req = if (requiredType == null) SequenceType.ANY_SEQUENCE
    else requiredType
    if (!(req == other.getRequiredType)) {
      compileError("The overriding template has a different required type from the overridden template", "XTSE3070")
      return
    }
    if (!(requiredContextItemType == other.getRequiredContextItemType) || mayOmitContextItem != other.isMayOmitContextItem || absentFocus != other.isAbsentFocus) {
      compileError("The required context item for the overriding template differs from that of the overridden template", "XTSE3070")
      return
    }
    val otherParams = other.getLocalParamDetails
    val overriddenParams = new util.HashSet[StructuredQName]
    import scala.collection.JavaConversions._
    for (lp0 <- otherParams) {
      val lp1 = getParam(lp0.name)
      if (lp1 == null) {
        if (!lp0.isTunnel) compileError("The overridden template declares a parameter " + lp0.name.getDisplayName + " which is not declared in the overriding template", "XTSE3070")
        return
      }
      if (!(lp1.getRequiredType == lp0.requiredType)) {
        lp1.compileError("The parameter " + lp0.name.getDisplayName + " has a different required type in the overridden template", "XTSE3070")
        return
      }
      if (lp1.isRequiredParam != lp0.isRequired && !lp0.isTunnel) {
        lp1.compileError("The parameter " + lp0.name.getDisplayName + " is " + (if (lp1.isRequiredParam) "required"
        else "optional") + " in the overriding template, but " + (if (lp0.isRequired) "required"
        else "optional") + " in the overridden template", "XTSE3070")
        return
      }
      if (lp1.isTunnelParam != lp0.isTunnel) {
        lp1.compileError("The parameter " + lp0.name.getDisplayName + " is a " + (if (lp1.isTunnelParam) "tunnel"
        else "non-tunnel") + " parameter in the overriding template, but " + (if (lp0.isTunnel) "tunnel"
        else "non-tunnel") + " parameter in the overridden template", "XTSE3070")
        return
      }
      overriddenParams.add(lp0.name)
    }
    import scala.collection.JavaConversions._
    for (param <- children(classOf[XSLLocalParam].isInstance)) {
      if (!overriddenParams.contains((param.asInstanceOf[XSLLocalParam]).getObjectName) && param.asInstanceOf[XSLLocalParam].isRequiredParam) param.asInstanceOf[XSLLocalParam].compileError("An overriding template cannot introduce a required parameter that is not declared in the overridden template", "XTSE3070")
    }
  }

  def getParam(name: StructuredQName): XSLLocalParam = {
    import scala.collection.JavaConversions._
    for (param <- children(classOf[XSLLocalParam].isInstance)) {
      if (name == param.asInstanceOf[XSLLocalParam].getObjectName) return param.asInstanceOf[XSLLocalParam]
    }
    null
  }

  override def prepareAttributes() = {
    val atts = attributes
    var extraAsAtt = null
    import scala.collection.JavaConversions._
    for (att <- atts) {
      val name = att.getNodeName
      val f = name.getDisplayName
      if (f == "mode") modeAtt = Whitespace.trim(att.getValue)
      else if (f == "name") nameAtt = Whitespace.trim(att.getValue)
      else if (f == "match") matchAtt = att.getValue
      else if (f == "priority") priorityAtt = Whitespace.trim(att.getValue)
      else if (f == "as") asAtt = att.getValue
      else if (f == "visibility") visibilityAtt = Whitespace.trim(att.getValue)
      else if (name.hasURI(NamespaceConstant.SAXON)) {
        isExtensionAttributeAllowed(name.getDisplayName)
        if (name.getLocalPart == "as") extraAsAtt = att.getValue
        else if (name.getLocalPart == "explain") explaining = isYes(Whitespace.trim(att.getValue))
      }
      else checkUnknownAttribute(name)
    }
    try if (modeAtt == null) if (matchAtt != null) { // XSLT 3.0 allows the default mode to be specified on any element
      var defaultMode = getDefaultMode
      if (defaultMode == null) defaultMode = Mode.UNNAMED_MODE_NAME
      modeNames = new Array[StructuredQName](1)
      modeNames(0) = defaultMode
    }
    else {
      if (matchAtt == null) compileError("The mode attribute must be absent if the match attribute is absent", "XTSE0500")
      getModeNames
    }
    catch {
      case err: XPathException =>
        err.maybeSetErrorCode("XTSE0280")
        if (err.getErrorCodeLocalPart == "XTSE0020") err.setErrorCode("XTSE0550")
        err.setIsStaticError(true)
        compileError(err)
    }
    if (nameAtt != null) {
      if (getObjectName == null) {
        val qName = makeQName(nameAtt, "XTSE0280", "name")
        setObjectName(qName)
      }
      if (compiledNamedTemplate != null) compiledNamedTemplate.setTemplateName(getObjectName)
      diagnosticId = nameAtt
    }
    prioritySpecified = priorityAtt != null
    if (prioritySpecified) {
      if (matchAtt == null) compileError("The priority attribute must be absent if the match attribute is absent", "XTSE0500")
      try { // it's got to be a valid decimal, but we want it as a double, so parse it twice
        if (!BigDecimalValue.castableAsDecimal(priorityAtt)) compileError("Invalid numeric value for priority (" + priority + ')', "XTSE0530")
        priority = priorityAtt.toDouble
      } catch {
        case err: NumberFormatException =>
          // shouldn't happen
          compileError("Invalid numeric value for priority (" + priority + ')', "XTSE0530")
      }
    }
    if (matchAtt != null) {
      `match` = makePattern(matchAtt, "match")
      if (diagnosticId == null) {
        diagnosticId = "match=\"" + matchAtt + '\"'
        if (modeAtt != null) diagnosticId += " mode=\"" + modeAtt + '\"'
      }
    }
    if (`match` == null && nameAtt == null) compileError("xsl:template must have a name or match attribute (or both)", "XTSE0500")
    if (asAtt != null) try {
      requiredType = makeSequenceType(asAtt)
      declaresRequiredType = true
    } catch {
      case e: XPathException =>
        compileErrorInAttribute(e.getMessage, e.getErrorCodeLocalPart, "as")
    }
    if (extraAsAtt != null) {
      var extraResultType = null
      declaresRequiredType = true
      try extraResultType = makeExtendedSequenceType(extraAsAtt)
      catch {
        case e: XPathException =>
          compileErrorInAttribute(e.getMessage, e.getErrorCodeLocalPart, "saxon:as")
          extraResultType = requiredType // error recovery
      }
      if (asAtt != null) {
        val rel = getConfiguration.getTypeHierarchy.sequenceTypeRelationship(extraResultType, requiredType)
        if ((rel eq Affinity.SAME_TYPE) || (rel eq Affinity.SUBSUMED_BY)) requiredType = extraResultType
        else compileErrorInAttribute("When both are present, @saxon:as must be a subtype of @as", "SXER7TBA", "saxon:as")
      }
      else requiredType = extraResultType
    }
    if (visibilityAtt != null) {
      visibility = interpretVisibilityValue(visibilityAtt, "")
      if (nameAtt == null) compileError("xsl:template/@visibility can be specified only if the template has a @name attribute", "XTSE0020")
      else compiledNamedTemplate.setDeclaredVisibility(getVisibility)
    }
  }

  @throws[XPathException]
  override def processAllAttributes() = { //        String mode = getAttributeValue("mode");
    //        mode = mode == null ? "" : Whitespace.trim(mode);
    if (!isDeferredCompilation(getCompilation)) super.processAllAttributes() //TODO - sort out the duplicated code. This repeats the code below
    else {
      processDefaultCollationAttribute()
      processDefaultMode()
      staticContext = new ExpressionContext(this, null)
      processAttributes()
    }
  }

  /**
   * Return the list of mode names to which this template rule is applicable.
   *
   * @return the list of mode names. If the mode attribute is absent, #default is assumed.
   *         If #default is present explicitly or implicitly, it is replaced by the default mode, taken
   *         from the in-scope default-modes attribute, which defaults to #unnamed. The unnamed mode
   *         is represented by { @link Mode#UNNAMED_MODE_NAME}. The token #all translates to
   *                                   { @link Mode#OMNI_MODE}.
   * @throws XPathException if the attribute is invalid.
   */
  @throws[XPathException]
  def getModeNames = {
    if (modeNames == null) { // modeAtt is a space-separated list of mode names, or "#default", or "#all"
      if (modeAtt == null) {
        modeAtt = getAttributeValue("mode")
        if (modeAtt == null) modeAtt = "#default"
      }
      var allModes = false
      val tokens = Whitespace.trim(modeAtt).split("[ \t\n\r]+")
      var count = tokens.length
      modeNames = new Array[StructuredQName](count)
      count = 0
      for (s <- tokens) {
        var mname = null
        if ("#default" == s) {
          mname = getDefaultMode
          if (mname == null) mname = Mode.UNNAMED_MODE_NAME
        }
        else if ("#unnamed" == s) mname = Mode.UNNAMED_MODE_NAME
        else if ("#all" == s) {
          allModes = true
          mname = Mode.OMNI_MODE
        }
        else mname = makeQName(s, "XTSE0550", "mode")
        for (e <- 0 until count) {
          if (modeNames(e) == mname) compileError("In the list of modes, the value " + s + " is duplicated", "XTSE0550")
        }
        modeNames({
          count += 1; count - 1
        }) = mname
      }
      if (allModes && (count > 1)) compileError("mode='#all' cannot be combined with other modes", "XTSE0550")
    }
    modeNames
  }

  /**
   * Get the modes to which this template rule applies
   *
   * @return the set of modes to which it applies
   * @throws XPathException should not happen
   */
  @throws[XPathException]
  def getApplicableModes = {
    val names = getModeNames
    val modes = new util.HashSet[Mode](names.length)
    val mgr = getPrincipalStylesheetModule.getRuleManager
    for (name <- names) {
      if (name == Mode.OMNI_MODE) {
        modes.add(mgr.getUnnamedMode)
        modes.addAll(mgr.getAllNamedModes)
      }
      else {
        val mode = mgr.obtainMode(name, false)
        if (mode != null) modes.add(mode)
      }
    }
    modes
  }

  /**
   * Ask whether this is a template rule with mode="#all
   */
  @throws[XPathException]
  def isOmniMode: Boolean = {
    for (name <- getModeNames) {
      if (name == Mode.OMNI_MODE) return true
    }
    false
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    stackFrameMap = getConfiguration.makeSlotManager
    checkTopLevel("XTSE0010", true)
    // the check for duplicates is now done in the buildIndexes() method of XSLStylesheet
    if (`match` != null) {
      `match` = typeCheck("match", `match`)
      if (`match`.getItemType.isInstanceOf[ErrorType]) issueWarning(new XPathException("Pattern will never match anything", SaxonErrorCode.SXWN9015, this))
      if (getPrincipalStylesheetModule.isDeclaredModes) {
        val manager = getPrincipalStylesheetModule.getRuleManager
        if (modeNames != null) for (name <- modeNames) {
          if (name == Mode.UNNAMED_MODE_NAME && !manager.isUnnamedModeExplicit) compileError("The unnamed mode has not been declared in an xsl:mode declaration", "XTSE3085")
          if (manager.obtainMode(name, false) == null) compileError("Mode name " + name.getDisplayName + " has not been declared in an xsl:mode declaration", "XTSE3085")
        }
        else if (!manager.isUnnamedModeExplicit) compileError("The unnamed mode has not been declared in an xsl:mode declaration", "XTSE3085")
      }
      if (visibility eq Visibility.ABSTRACT) compileError("An abstract template must have no match attribute")
    }
    // See if there are any required parameters.
    var hasContent = false
    import scala.collection.JavaConversions._
    for (param <- children(classOf[StyleElement].isInstance)) {
      if (param.getFingerprint == StandardNames.XSL_CONTEXT_ITEM) {
        // no action
      }
      else if (param.isInstanceOf[XSLLocalParam]) if (param.asInstanceOf[XSLLocalParam].isRequiredParam) hasRequiredParams = true
      else hasContent = true
    }
    if ((visibility eq Visibility.ABSTRACT) && hasContent) compileError("A template with visibility='abstract' must have no body")
  }

  @throws[XPathException]
  override def validateSubtree(decl: ComponentDeclaration, excludeStylesheet: Boolean) = if (!isDeferredCompilation(getCompilation)) super.validateSubtree(decl, excludeStylesheet)
  else try validate(decl)
  catch {
    case err: XPathException =>
      compileError(err)
  }

  @throws[XPathException]
  override def index(decl: ComponentDeclaration, top: PrincipalStylesheetModule) = if (getTemplateName != null) {
    if (compiledNamedTemplate == null) compiledNamedTemplate = new NamedTemplate(getTemplateName)
    top.indexNamedTemplate(decl)
  }

  /**
   * Mark tail-recursive calls on templates and functions.
   */
  override def markTailCalls = {
    val last = getLastChildInstruction
    last != null && last.markTailCalls
  }

  /**
   * Compile: creates the executable form of the template
   */
  @throws[XPathException]
  override def compileDeclaration(compilation: Compilation, decl: ComponentDeclaration): Unit = {
    if (isDeferredCompilation(compilation)) {
      createSkeletonTemplate(compilation, decl)
      //System.err.println("Deferred - " + ++lazy);
      return
    }
    if (compilation.getCompilerInfo.getOptimizerOptions.isSet(OptimizerOptions.TAIL_CALLS)) isTailRecursive = markTailCalls
    val body = compileSequenceConstructor(compilation, decl, true)
    body.restoreParentPointers()
    val rsc = makeRetainedStaticContext
    if (body.getRetainedStaticContext == null) body.setRetainedStaticContext(rsc) // bug 2608
    if (`match` != null && compilation.getConfiguration.getBooleanProperty(Feature.STRICT_STREAMABILITY) && isWithinDeclaredStreamableConstruct) checkStrictStreamability(body)
    if (getTemplateName != null) compileNamedTemplate(compilation, body, decl)
    if (`match` != null) { //System.err.println("Rules compiled - " + ++eager);
      compileTemplateRule(compilation, body, decl)
    }
  }

  @throws[XPathException]
  private def checkStrictStreamability(body: Expression) = getConfiguration.checkStrictStreamability(this, body)

  @throws[XPathException]
  private def compileNamedTemplate(compilation: Compilation, body: Expression, decl: ComponentDeclaration) = {
    val rsc = body.getRetainedStaticContext
    compiledNamedTemplate.setPackageData(rsc.getPackageData)
    compiledNamedTemplate.setBody(body)
    compiledNamedTemplate.setStackFrameMap(stackFrameMap)
    compiledNamedTemplate.setSystemId(getSystemId)
    compiledNamedTemplate.setLineNumber(getLineNumber)
    compiledNamedTemplate.setHasRequiredParams(hasRequiredParams)
    compiledNamedTemplate.setRequiredType(requiredType)
    compiledNamedTemplate.setContextItemRequirements(requiredContextItemType, mayOmitContextItem, absentFocus)
    compiledNamedTemplate.setRetainedStaticContext(rsc)
    compiledNamedTemplate.setDeclaredVisibility(getDeclaredVisibility)
    val overridden = getOverriddenComponent
    if (overridden != null) checkCompatibility(overridden)
    val cisi = getConfiguration.makeContextItemStaticInfo(requiredContextItemType, mayOmitContextItem)
    val body2 = refineTemplateBody(body, cisi)
    compiledNamedTemplate.setBody(body2)
    if (getCompilation.getCompilerInfo.getCodeInjector != null) getCompilation.getCompilerInfo.getCodeInjector.process(compiledNamedTemplate)
  }

  private def refineTemplateBody(body: Expression, cisi: ContextItemStaticInfo) = {
    val old = body
    try body = body.simplify
    catch {
      case e: XPathException =>
        if (e.isReportableStatically) compileError(e)
        else {
          body = new ErrorExpression(new XmlProcessingException(e))
          ExpressionTool.copyLocationInfo(old, body)
        }
    }
    val config = getConfiguration
    if (visibility ne Visibility.ABSTRACT) try if (requiredType != null && (requiredType ne SequenceType.ANY_SEQUENCE)) {
      val role = new RoleDiagnostic(RoleDiagnostic.TEMPLATE_RESULT, diagnosticId, 0)
      role.setErrorCode("XTTE0505")
      body = config.getTypeChecker(false).staticTypeCheck(body, requiredType, role, makeExpressionVisitor)
    }
    catch {
      case err: XPathException =>
        if (err.isReportableStatically) compileError(err)
        body = new ErrorExpression(new XmlProcessingException(err))
        ExpressionTool.copyLocationInfo(old, body)
    }
    try {
      val visitor = makeExpressionVisitor
      body = body.typeCheck(visitor, cisi)
    } catch {
      case e: XPathException =>
        compileError(e)
    }
    body
  }

  def compileTemplateRule(compilation: Compilation, body: Expression, decl: ComponentDeclaration) = {
    val config = getConfiguration
    if (getTemplateName != null) body = body.copy(new RebindingMap)
    var contextItemType = null
    var cisi = null
    // the template can't be called by name, so the context item must match the match pattern
    contextItemType = `match`.getItemType
    if (contextItemType == ErrorType.getInstance) { // if the match pattern can't match anything, we produce a warning, not a hard error
      contextItemType = AnyItemType.getInstance
    }
    cisi = config.makeContextItemStaticInfo(contextItemType, false)
    body = refineTemplateBody(body, cisi)
    var needToCopy = false
    import scala.collection.JavaConversions._
    for (rule <- compiledTemplateRules.values) {
      if (needToCopy) body = body.copy(new RebindingMap)
      setCompiledTemplateRuleProperties(rule, body)
      needToCopy = true
      rule.updateSlaveCopies()
    }
    // following code needed only for diagnostics
    //body.verifyParentPointers();
  }

  @throws[XPathException]
  private def createSkeletonTemplate(compilation: Compilation, decl: ComponentDeclaration) = {
    var modes = modeNames
    if (isOmniMode) {
      val all = new util.ArrayList[StructuredQName]
      all.add(Mode.UNNAMED_MODE_NAME)
      val mgr = getCompilation.getPrincipalStylesheetModule.getRuleManager
      import scala.collection.JavaConversions._
      for (m <- mgr.getAllNamedModes) {
        all.add(m.getModeName)
      }
      modes = all.toArray(new Array[StructuredQName](0))
    }
    for (modeName <- modes) {
      var templateRule = compiledTemplateRules.get(modeName)
      if (templateRule == null) templateRule = getConfiguration.makeTemplateRule
      templateRule.prepareInitializer(compilation, decl, modeName)
      compiledTemplateRules.put(modeName, templateRule)
      val rsc = makeRetainedStaticContext
      templateRule.setPackageData(rsc.getPackageData)
      setCompiledTemplateRuleProperties(templateRule, null)
    }
  }

  private def setCompiledTemplateRuleProperties(templateRule: TemplateRule, body: Expression) = {
    templateRule.setMatchPattern(`match`)
    templateRule.setBody(body)
    templateRule.setStackFrameMap(stackFrameMap)
    templateRule.setSystemId(getSystemId)
    templateRule.setLineNumber(getLineNumber)
    templateRule.setHasRequiredParams(hasRequiredParams)
    templateRule.setRequiredType(requiredType)
    templateRule.setContextItemRequirements(requiredContextItemType, absentFocus)
  }

  /**
   * Code executed when the template is first executed under JIT. If the template is defined in several
   * modes, then this may be called several times, but it only does anything the first time. Mode-specific
   * processing is done in the TemplateRuleInitializer.
   *
   * @param compilation the compilation episode
   * @param decl        the template rule declaration
   * @throws XPathException if anything goes wrong
   */
  @throws[XPathException]
  def jitCompile(compilation: Compilation, decl: ComponentDeclaration) = if (!jitCompilationDone) {
    jitCompilationDone = true
    compilation.setPreScan(false)
    processAllAttributes()
    checkForJitCompilationErrors(compilation)
    validateSubtree(decl, false)
    checkForJitCompilationErrors(compilation)
    compileDeclaration(compilation, decl)
    checkForJitCompilationErrors(compilation)
  }

  @throws[XPathException]
  private def checkForJitCompilationErrors(compilation: Compilation) = if (compilation.getErrorCount > 0) {
    val e = new XPathException("Errors were reported during JIT compilation of template rule with match=\"" + matchAtt + "\"", SaxonErrorCode.SXST0001, this)
    e.setHasBeenReported(true) // only intended as an exception message, not something to report to ErrorListener
    throw e
  }

  /**
   * Registers the template rule with each Mode that it belongs to.
   *
   * @param declaration Associates this template with a stylesheet module (in principle an xsl:template
   *                    element can be in a document that is imported more than once; these are separate declarations)
   * @throws XPathException if a failure occurs
   */
  @throws[XPathException]
  def register(declaration: ComponentDeclaration): Unit = if (`match` != null) {
    val module = declaration.getModule
    val mgr = getCompilation.getPrincipalStylesheetModule.getRuleManager
    val visitor = ExpressionVisitor.make(getStaticContext)
    for (modeName <- getModeNames) {
      var mode = mgr.obtainMode(modeName, false)
      if (mode == null) if (mgr.existsOmniMode) {
        val omniMode = mgr.obtainMode(Mode.OMNI_MODE, true)
        mode = mgr.obtainMode(modeName, true)
        SimpleMode.copyRules(omniMode.getActivePart, mode.getActivePart)
      }
      else mode = mgr.obtainMode(modeName, true)
      else {
        val ok = getPrincipalStylesheetModule.checkAcceptableModeForPackage(this, mode)
        if (!ok) return
      }
      var match1 = `match`.copy(new RebindingMap)
      val typed = mode.getActivePart.getPropertyValue("typed")
      if ("strict" == typed || "lax" == typed) {
        var match2 = null
        try match2 = match1.convertToTypedPattern(typed)
        catch {
          case e: XPathException =>
            e.maybeSetLocation(this)
            throw e
        }
        if (match2 ne match1) {
          val info = getConfiguration.makeContextItemStaticInfo(AnyItemType.getInstance, false)
          ExpressionTool.copyLocationInfo(`match`, match2)
          match2.setOriginalText(`match`.toString)
          match2 = match2.typeCheck(visitor, info)
          match1 = match2
        }
        if (modeNames.length == 1) { // If this is the only mode for the template, then we can use this enhanced match pattern
          // for subsequent type-checking of the template body.
          // TODO: we can now do this for all modes...
          // TODO: but we need to take account of mode=#all, where modeNames.length==1
          `match` = match2
        }
      }
      var rule = compiledTemplateRules.get(modeName)
      if (rule == null) {
        rule = getConfiguration.makeTemplateRule
        compiledTemplateRules.put(modeName, rule)
      }
      val prio = if (prioritySpecified) priority
      else Double.NaN
      mgr.registerRule(match1, rule, mode, module, prio, mgr.allocateSequenceNumber, 0)
      if (mode.isDeclaredStreamable) {
        rule.setDeclaredStreamable(true)
        if (!match1.isMotionless) {
          val fallback = getConfiguration.getBooleanProperty(Feature.STREAMING_FALLBACK)
          var message = "Template rule is declared streamable but the match pattern is not motionless"
          if (fallback) {
            message += "\n  * Falling back to non-streaming implementation"
            getStaticContext.issueWarning(message, this)
            rule.setDeclaredStreamable(false)
            getCompilation.setFallbackToNonStreaming(true)
          }
          else throw new XPathException(message, "XTSE3430", this)
        }
      }
      if (mode.getDefaultResultType != null && !declaresRequiredType) rule.setRequiredType(mode.getDefaultResultType)
      // if adding a rule to the omniMode (mode='all') add it to all
      // the other modes as well. For all but the first, it needs to
      // be copied because the external component bindings might
      // differ from one mode to another.
      if (mode.getModeName == Mode.OMNI_MODE) {
        compiledTemplateRules.put(Mode.UNNAMED_MODE_NAME, rule)
        mgr.registerRule(match1, rule, mgr.getUnnamedMode, module, prio, mgr.allocateSequenceNumber, 0)
        import scala.collection.JavaConversions._
        for (m <- mgr.getAllNamedModes) {
          if (m.isInstanceOf[SimpleMode]) {
            val ruleCopy = rule.copy
            if (m.isDeclaredStreamable) ruleCopy.setDeclaredStreamable(true)
            compiledTemplateRules.put(m.getModeName, ruleCopy)
            mgr.registerRule(match1.copy(new RebindingMap), ruleCopy, m, module, prio, mgr.allocateSequenceNumber, 0)
          }
        }
      }
    }
  }

  /**
   * Allocate slot numbers to any local variables declared within a predicate within the match pattern
   */
  def allocatePatternSlotNumbers() = if (`match` != null) {
    import scala.collection.JavaConversions._
    for (templateRule <- compiledTemplateRules.values) {
      import scala.collection.JavaConversions._
      for (r <- templateRule.getRules) { // In the case of a union pattern, allocate slots separately for each branch
        val `match` = r.getPattern
        // first slot in pattern is reserved for current()
        var nextFree = 0
        if ((`match`.getDependencies & StaticProperty.DEPENDS_ON_CURRENT_ITEM) != 0) nextFree = 1
        var slots = `match`.allocateSlots(getSlotManager, nextFree)
        // if the pattern calls user-defined functions, allocate at least one slot,
        // to force a new context to be created for evaluating patterns (bug 3706)
        if (slots == 0 && ((`match`.getDependencies & StaticProperty.DEPENDS_ON_USER_FUNCTIONS) != 0)) slots = 1
        if (slots > 0) {
          val mgr = getCompilation.getPrincipalStylesheetModule.getRuleManager
          var appliesToAll = false
          for (nc <- modeNames) {
            if (nc == Mode.OMNI_MODE) {
              appliesToAll = true
              break //todo: break is not supported
            }
            val mode = mgr.obtainMode(nc, true)
            mode.getActivePart.allocatePatternSlots(slots)
          }
          if (appliesToAll) {
            import scala.collection.JavaConversions._
            for (m <- mgr.getAllNamedModes) {
              m.getActivePart.allocatePatternSlots(slots)
            }
            mgr.getUnnamedMode.getActivePart.allocatePatternSlots(slots)
          }
        }
      }
    }
  }

  /**
   * This method is a bit of a misnomer, because it does more than invoke optimization of the template body.
   * In particular, it also registers the template rule with each Mode that it belongs to.
   *
   * @param declaration Associates this template with a stylesheet module (in principle an xsl:template
   *                    element can be in a document that is imported more than once; these are separate declarations)
   * @throws XPathException if errors are found
   */
  @throws[XPathException]
  override def optimize(declaration: ComponentDeclaration) = {
    val config = getConfiguration
    if (compiledNamedTemplate != null) {
      var body = compiledNamedTemplate.getBody
      val cisi = getConfiguration.makeContextItemStaticInfo(requiredContextItemType, mayOmitContextItem)
      val visitor = makeExpressionVisitor
      body = body.typeCheck(visitor, cisi)
      body = ExpressionTool.optimizeComponentBody(body, getCompilation, visitor, cisi, true)
      compiledNamedTemplate.setBody(body)
      allocateLocalSlots(body)
      if (explaining) {
        val err = getConfiguration.getLogger
        err.info("Optimized expression tree for named template at line " + getLineNumber + " in " + getSystemId + ':')
        body.explain(err)
      }
      body.restoreParentPointers()
      if (config.isDeferredByteCode(HostLanguage.XSLT) && !isTailRecursive) {
        val opt = config.obtainOptimizer
        val evaluationModes = Expression.ITERATE_METHOD | Expression.PROCESS_METHOD
        compiledNamedTemplate.setBody(opt.makeByteCodeCandidate(compiledNamedTemplate, body, diagnosticId, evaluationModes))
      }
    }
    if (`match` != null) {
      val contextItemType = getContextItemTypeForTemplateRule
      val cisi = config.makeContextItemStaticInfo(contextItemType, false)
      cisi.setContextPostureStriding()
      val visitor = makeExpressionVisitor
      `match`.resetLocalStaticProperties()
      `match` = `match`.optimize(visitor, cisi)
      if (!isDeferredCompilation(getCompilation)) {
        val body = compiledTemplateRules.values.stream.findFirst.map(TemplateRule.getBody).orElse(null)
        // Until now, all template rules share the same body.
        ExpressionTool.resetPropertiesWithinSubtree(body)
        //        visitor.setOptimizeForStreaming(compiledNamedTemplate.isDeclaredStreamable());
        val opt = getConfiguration.obtainOptimizer
        try {// We've already done the typecheck of each XPath expression, but it's worth doing again at this
        // level because we have more information now.
        //                body = body.typeCheck(visitor, cit);
        //                ExpressionTool.resetPropertiesWithinSubtree(body);

        for (compiledTemplateRule <- compiledTemplateRules.values) {
          var templateRuleBody = if (compiledTemplateRules.size > 1) body.copy(new RebindingMap)
          else body
          visitor.setOptimizeForStreaming(compiledTemplateRule.isDeclaredStreamable)
          templateRuleBody = templateRuleBody.typeCheck(visitor, cisi)
          templateRuleBody = ExpressionTool.optimizeComponentBody(templateRuleBody, getCompilation, visitor, cisi, true)
          compiledTemplateRule.setBody(templateRuleBody)
          opt.checkStreamability(this, compiledTemplateRule)
          allocateLocalSlots(templateRuleBody)
          import scala.collection.JavaConversions._
          for (r <- compiledTemplateRule.getRules) {
            val `match` = r.getPattern
            val info = getConfiguration.makeContextItemStaticInfo(`match`.getItemType, false)
            info.setContextPostureStriding()
            var m2 = `match`.optimize(visitor, info)
            if (compiledTemplateRules.size > 1) m2 = m2.copy(new RebindingMap)
            if (m2 ne `match`) r.setPattern(m2)
          }
          if (visitor.getConfiguration.isDeferredByteCode(HostLanguage.XSLT) && !isTailRecursive) {
            val evaluationModes = Expression.ITERATE_METHOD | Expression.PROCESS_METHOD
            compiledTemplateRule.setBody(opt.makeByteCodeCandidate(compiledTemplateRule, templateRuleBody, diagnosticId, evaluationModes))
          }
          if (explaining) {
            val err = getConfiguration.getLogger
            err.info("Optimized expression tree for template rule at line " + getLineNumber + " in " + getSystemId + ':')
            templateRuleBody.explain(err)
          }
        }
        }
        catch
        {
          case e: XPathException =>
            e.maybeSetLocation(this)
            compileError(e)
        }
      }
    }
  }

  @throws[XPathException]
  def getContextItemTypeForTemplateRule = {
    val config = getConfiguration
    var contextItemType = `match`.getItemType
    if (contextItemType == ErrorType.getInstance) contextItemType = AnyItemType.getInstance
    if (requiredContextItemType ne AnyItemType.getInstance) {
      val rel = config.getTypeHierarchy.relationship(contextItemType, requiredContextItemType)
      rel match {
        case DISJOINT =>
          val e = new XPathException("The declared context item type is inconsistent with the match pattern", "XPTY0004", this)
          e.setIsTypeError(true)
          throw e
        case SUBSUMED_BY =>
        case OVERLAPS =>
        case SAME_TYPE =>
        case SUBSUMES =>
          contextItemType = requiredContextItemType
      }
    }
    contextItemType
  }

  /**
   * Generate byte code for the template (if appropriate)
   *
   * @param opt the optimizer
   * @throws XPathException if byte code generation fails
   */
  @throws[XPathException]
  override def generateByteCode(opt: Optimizer) = { // Generate byte code if appropriate
    if (getCompilation.getCompilerInfo.isGenerateByteCode && !isTailRecursive) {
      val compilerService = getConfiguration.makeCompilerService(HostLanguage.XSLT)
      if (getTemplateName != null) try {
        val exp = compiledNamedTemplate.getBody
        val cbody = opt.compileToByteCode(compilerService, exp, nameAtt, Expression.PROCESS_METHOD)
        if (cbody != null) compiledNamedTemplate.setBody(cbody)
      } catch {
        case e: Exception =>
          System.err.println("Failed while compiling named template " + nameAtt)
          e.printStackTrace()
          throw new XPathException(e)
      }
      import scala.collection.JavaConversions._
      for (compiledTemplateRule <- compiledTemplateRules.values) {
        if (!compiledTemplateRule.isDeclaredStreamable) try {
          val exp = compiledTemplateRule.getBody
          if (exp != null) {
            val cbody = opt.compileToByteCode(compilerService, exp, matchAtt, Expression.PROCESS_METHOD)
            if (cbody != null) compiledTemplateRule.setBody(cbody)
          }
        } catch {
          case e: Exception =>
            System.err.println("Failed while compiling template rule with match = '" + matchAtt + "'")
            e.printStackTrace()
            throw new XPathException(e)
        }
      }
    }
  }

  /**
   * Get associated Procedure (for details of stack frame)
   */
  override def getSlotManager = stackFrameMap

  /**
   * Get the compiled template
   *
   * @return the compiled template
   */
  def getCompiledNamedTemplate = compiledNamedTemplate

  def getMatch = `match`

  def getTemplateRulesByMode = compiledTemplateRules
}