////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.tree.iter.ConstrainedIterator
import net.sf.saxon.value._

/**
 * A sequence containing exactly one item. The main use of this class is in declaring the expected arguments
 * of reflexive method calls, where the use of One(T) rather than T emphasizes that the value must not be null/empty,
 * and generates type-checking code to ensure that it is not empty.
 *
 * <p>To extract the wrapped item, use {@link #head()}.</p>
 */
object One {
  /**
   * Convenience function to create a singleton boolean value
   *
   * @param value the boolean value
   * @return the boolean value wrapped as a One&lt;BooleanValue&gt;
   */
    def bool(value: Boolean) = new One[BooleanValue](BooleanValue.get(value))

  /**
   * Convenience function to create a singleton string value
   *
   * @param value the string value.. If null, the result will represent a zero-length string
   * @return the string value wrapped as a One&lt;StringValue&gt;
   */
  def string(value: String) = new One[StringValue](new StringValue(value))

  /**
   * Convenience function to create a singleton integer value
   *
   * @param value the integer value
   * @return the integer value wrapped as a One&lt;IntegerValue&gt;
   */
  def integer(value: Long) = new One[IntegerValue](new Int64Value(value))

  /**
   * Convenience function to create a singleton double value
   *
   * @param value the double value
   * @return the double value wrapped as a One&lt;DoubleValue&gt;
   */
  def dbl(value: Double) = new One[DoubleValue](new DoubleValue(value))
}

class One[T <: Item](val item: T)

/**
 * Create an instance of the class
 *
 * @param item The single item to be contained in the sequence. Must not be null.
 * @throws NullPointerException if item is null.
 */
  extends ZeroOrOne[T](item) {
  if (item == null) throw new NullPointerException

  /**
   * Return an iterator over this value.
   */
  override def iterate = new ConstrainedIterator[T]() {
    private[om] var gone = false
    override

    def hasNext: Boolean = return !gone

    override

    def next: T = if (gone) return null
    else {
      gone = true
      return head
    }

    override

    def getLength: Int = return 1

    override

    def materialize: GroundedValue = return head

    override

    def getResidue: GroundedValue = return if (gone) EmptySequence.getInstance
    else head

    override

    def getReverseIterator: SequenceIterator = return iterate
  }
}