////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Component
import net.sf.saxon.expr.instruct.GlobalVariable
import net.sf.saxon.expr.instruct.NamedTemplate
import net.sf.saxon.expr.instruct.UserFunction
import net.sf.saxon.om.StandardNames
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.pattern.NameTest
import net.sf.saxon.pattern.QNameTest
import net.sf.saxon.trans._
import java.util

/**
 * Represents an xsl:expose element in an XSLT 3.0 package manifest.
 */
object XSLExpose {
  def isCompatible(declared: Visibility, exposed: Visibility): Boolean = {
    if (declared == null || (declared eq exposed)) return true
    declared match {
      case PUBLIC =>
        (exposed eq Visibility.PUBLIC) || (exposed eq Visibility.PRIVATE) || (exposed eq Visibility.FINAL) || (exposed eq Visibility.HIDDEN)
      case ABSTRACT =>
        (exposed eq Visibility.ABSTRACT) || (exposed eq Visibility.HIDDEN)
      case FINAL =>
        (exposed eq Visibility.PRIVATE) || (exposed eq Visibility.FINAL) || (exposed eq Visibility.HIDDEN)
      case _ =>
        false
    }
  }
}

class XSLExpose extends XSLAcceptExpose {
  protected def checkCompatibility(name: SymbolicName, declared: Visibility, exposed: Visibility) = if (!XSLExpose.isCompatible(declared, exposed)) {
    val code = "XTSE3010"
    compileError("The " + name + " is declared as " + declared.show + " and cannot be exposed as " + exposed.show, code)
  }

  /**
   * Check that the stylesheet element is valid. This is called once for each element, after
   * the entire tree has been built. As well as validation, it can perform first-time
   * initialisation. The default implementation does nothing; it is normally overriden
   * in subclasses.
   *
   * @param decl the declaration to be validated
   * @throws net.sf.saxon.trans.XPathException
   * if any error is found during validation
   */
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    val psm = getPrincipalStylesheetModule
    val exposedVisibility = getVisibility
    // The following code checks that explicit references to components (as distinct from
    // wildcards) refer to actual components, and that the exposed visibility is consistent
    // with the declared visibility. It doesn't actually change the component's visibility property.
    // This is done later, in PrincipalStylesheetModuleEE#adjustExposedVisibility.
    import scala.collection.JavaConversions._
    for (test <- getExplicitComponentTests) {
      val nameTest = test.getQNameTest
      if (nameTest.isInstanceOf[NameTest]) {
        val qName = nameTest.asInstanceOf[NameTest].getMatchingNodeName
        val kind = test.getComponentKind
        var sName = if (kind == StandardNames.XSL_FUNCTION) new SymbolicName.F(nameTest.asInstanceOf[NameTest].getMatchingNodeName, test.getArity)
        else new SymbolicName(kind, nameTest.asInstanceOf[NameTest].getMatchingNodeName)
        var found = false
        kind match {
          case StandardNames.XSL_TEMPLATE =>
            val template = psm.getNamedTemplate(qName)
            found = template != null
            if (found) {
              val declared = template.getDeclaredVisibility
              checkCompatibility(template.getSymbolicName, declared, exposedVisibility)
              //template.getDeclaringComponent().setVisibility(exposedVisibility, false);
            }
          case StandardNames.XSL_VARIABLE =>
            val binding = psm.getGlobalVariableBinding(qName)
            if (binding != null && !binding.getSourceElement.isInstanceOf[XSLGlobalParam]) found = true
            if (found) {
              val `var` = binding.getSourceElement.asInstanceOf[XSLGlobalVariable].getCompiledVariable
              val declared = `var`.getDeclaredVisibility
              checkCompatibility(`var`.getSymbolicName, declared, getVisibility)
              //var.getDeclaringComponent().setVisibility(exposedVisibility, false);
            }
          case StandardNames.XSL_ATTRIBUTE_SET =>
            val declarations = psm.getAttributeSetDeclarations(qName)
            found = declarations != null && !declarations.isEmpty
            if (found) {
              val declared = declarations.get(0).getSourceElement.getDeclaredVisibility
              checkCompatibility(sName, declared, getVisibility)
            }
          case StandardNames.XSL_MODE =>
            val mode = psm.getRuleManager.obtainMode(qName, false)
            found = mode != null
            if (found) checkCompatibility(sName, mode.getDeclaredVisibility, getVisibility)
            if (getVisibility eq Visibility.ABSTRACT) { // obviously wrong, though I don't see a rule in the spec
              compileError("The visibility of a mode cannot be abstract")
            }
          case StandardNames.XSL_FUNCTION =>
            val pack = psm.getStylesheetPackage
            if (test.getArity == -1) { // This will match any function of the required name, regardless of arity
              for (i <- 0 to pack.getMaxFunctionArity) {
                sName = new SymbolicName.F(nameTest.asInstanceOf[NameTest].getMatchingNodeName, i)
                val fn = pack.getComponent(sName)
                if (fn != null) {
                  found = true
                  val userFunction = fn.getActor.asInstanceOf[UserFunction]
                  checkCompatibility(sName, userFunction.getDeclaredVisibility, getVisibility)
                }
              }
            }
            else {
              val fn = pack.getComponent(sName)
              found = fn != null
              if (found) {
                val userFunction = fn.getActor.asInstanceOf[UserFunction]
                checkCompatibility(sName, userFunction.getDeclaredVisibility, getVisibility)
              }
            }
        }
        if (!found) compileError("No " + sName.toString + " exists in the containing package", "XTSE3020")
      }
    }
  }
}