////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

/**
 * A SequenceType is the combination of an ItemType and an OccurrenceIndicator
 */
object SequenceType {
  /**
   * Constant representing the universal sequence type <code>item()*</code>, which permits any value
   */
    val ANY = new SequenceType(ItemType.ANY_ITEM, OccurrenceIndicator.ZERO_OR_MORE)
  /**
   * Constant representing the sequence type <code>empty-sequence()</code>, which permits only one
   * value, namely the empty sequence
   */
  val EMPTY = new SequenceType(ItemType.ERROR, OccurrenceIndicator.ZERO)

  /**
   * Factory method to construct a SequenceType
   *
   * @param itemType            the ItemType
   * @param occurrenceIndicator the permitted number of occurrences of the item in the sequence
   * @return the constricted SequenceType
   */
  /*@NotNull*/ def makeSequenceType(itemType: ItemType, occurrenceIndicator: OccurrenceIndicator.type) = new SequenceType(itemType, occurrenceIndicator)

  /**
   * Factory method to construct a s9api {@code SequenceType} from an underlying
   * instance of {@link net.sf.saxon.value.SequenceType}
   *
   * @since 10.0
   */
  def fromUnderlyingSequenceType(processor: Processor, st: SequenceType) = {
    val factory = new ItemTypeFactory(processor)
    val it = factory.exposeItemType(st.getPrimaryType)
    val oc = OccurrenceIndicator.getOccurrenceIndicator(st.getCardinality)
    makeSequenceType(it, oc)
  }
}


/**
 * Construct a SequenceType
 *
 * @param itemType            the ItemType
 * @param occurrenceIndicator the permitted number of occurrences of the item in the sequence
 */
class SequenceType private(var itemType: ItemType, var occurrenceIndicator: OccurrenceIndicator.type){
  /**
   * Get the item type
   *
   * @return the item type
   */
  def getItemType = itemType

  /**
   * Get the occurrence indicator
   *
   * @return the occurrence indicator
   */
  def getOccurrenceIndicator = occurrenceIndicator

  /**
   * Test whether two SequenceType objects represent the same type
   *
   * @param other the other SequenceType object
   * @return true if the other object is a SequenceType representing the same type
   * @since 9.5
   */
  override final def equals(other: Any) = other.isInstanceOf[SequenceType] && other.asInstanceOf[SequenceType].getOccurrenceIndicator == getOccurrenceIndicator && other.asInstanceOf[SequenceType].getItemType == getItemType

  /**
   * Get a hash code with semantics corresponding to the equals() method
   *
   * @return the hash code
   * @since 9.5
   */
  override final def hashCode = getItemType.hashCode ^ (getOccurrenceIndicator.hashCode << 17)

  /**
   * Get the underlying internal SequenceType
   *
   * @return the equivalent instance of { @link net.sf.saxon.value.SequenceType}
   */
  @SuppressWarnings(Array("WeakerAccess")) def getUnderlyingSequenceType = net.sf.saxon.value.SequenceType.makeSequenceType(itemType.getUnderlyingItemType, occurrenceIndicator.getCardinality)
}