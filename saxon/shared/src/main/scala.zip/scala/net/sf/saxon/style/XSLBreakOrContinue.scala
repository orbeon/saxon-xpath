////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.tree.iter.AxisIterator

/**
 * Abstract class containing functionality common to xsl:break and xsl:next-iteration
 */
abstract class XSLBreakOrContinue extends StyleElement {
  /*@Nullable*/ protected var xslIterate = null

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Set the attribute list for the element. This is called to process the attributes (note
   * the distinction from processAttributes in the superclass).
   * Must be supplied in a subclass
   */
  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      checkUnknownAttribute(attName)
    }
  }

  /**
   * Test that this xsl:next-iteration or xsl:break instruction appears in a valid position
   */
  protected def validatePosition(): Unit = {
    var inst = this
    var isLast = true
    while ( {
      true
    }) {
      if (!inst.isInstanceOf[XSLWhen]) {
        val sibs = inst.iterateAxis(AxisInfo.FOLLOWING_SIBLING)
        while ( {
          true
        }) {
          val sib = sibs.next
          if (sib == null) break //todo: break is not supported
          if (sib.isInstanceOf[XSLFallback] || sib.isInstanceOf[XSLCatch]) continue //todo: continue is not supported
          isLast = false
        }
      }
      inst = inst.getParent
      if (inst.isInstanceOf[XSLIterate]) {
        xslIterate = inst.asInstanceOf[XSLIterate]
        break //todo: break is not supported
      }
      else if (inst.isInstanceOf[XSLTry] || inst.isInstanceOf[XSLCatch]) {
        //compilable = false;
      }
      else if (inst.isInstanceOf[XSLWhen] || inst.isInstanceOf[XSLOtherwise] || inst.isInstanceOf[XSLIf] || inst.isInstanceOf[XSLChoose]) {
        // continue;
      }
      else if (inst == null) {
        compileError(getDisplayName + " is not allowed at outermost level", "XTSE3120") //XTSE0010
        return
      }
      else {
        compileError(getDisplayName + " is not allowed within " + inst.getDisplayName, "XTSE3120")
        return
      }
    }
    if (!isLast) compileError(getDisplayName + " must be the last instruction in the xsl:iterate loop", "XTSE3120")
  }
}