////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.s9api

import net.sf.saxon.ma.arrays.ArrayFunctionSet
import net.sf.saxon.ma.arrays.ArrayItem
import net.sf.saxon.ma.arrays.SimpleArrayItem
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.Sequence
import net.sf.saxon.trans.XPathException
import java.util
import java.util.{ArrayList, List}

/**
 * An array in the XDM data model. An array is a list of zero or more members, each of which
 * is an arbitrary XDM value. The array itself is an XDM item.
 * <p>An XdmArray is immutable.</p>
 *
 * @since 9.8
 */
object XdmArray {
  /**
   * Make an XDM array from a Java array. Each member of the supplied array
   * is converted to a single member in the result array using the method
   * {@link XdmValue#makeValue(Object)}
   *
   * @return the result of the conversion if successful
   * @throws IllegalArgumentException if conversion is not possible
   */
    @throws[IllegalArgumentException]
    def makeArray(input: Array[AnyRef]) = {
      val result = new util.ArrayList[XdmValue](input.length)
      for (o <- input) {
        result.add(XdmValue.makeValue(o))
      }
      new XdmArray(result)
    }

  /**
   * Make an XdmArray whose members are xs:boolean values
   *
   * @param input the input array of booleans
   * @return an XdmArray whose members are xs:boolean values corresponding one-to-one with the input
   */
  def makeArray(input: Array[Boolean]) = {
    val result = new util.ArrayList[XdmValue](input.length)
    for (o <- input) {
      result.add(new XdmAtomicValue(o))
    }
    new XdmArray(result)
  }

  /**
   * Make an XdmArray whose members are xs:long values
   *
   * @param input the input array of integers
   * @return an XdmArray whose members are xs:integer values corresponding one-to-one with the input
   */
  def makeArray(input: Array[Long]) = {
    val result = new util.ArrayList[XdmValue](input.length)
    for (o <- input) {
      result.add(new XdmAtomicValue(o))
    }
    new XdmArray(result)
  }

  /**
   * Make an XdmArray whose members are xs:integer values
   *
   * @param input the input array of integers
   * @return an XdmArray whose members are xs:integer values corresponding one-to-one with the input
   */
  def makeArray(input: Array[Int]) = {
    val result = new util.ArrayList[XdmValue](input.length)
    for (o <- input) {
      result.add(new XdmAtomicValue(o))
    }
    new XdmArray(result)
  }

  def makeArray(input: Array[Short]) = {
    val result = new util.ArrayList[XdmValue](input.length)
    for (o <- input) {
      result.add(new XdmAtomicValue(o))
    }
    new XdmArray(result)
  }

  def makeArray(input: Array[Byte]) = {
    val result = new util.ArrayList[XdmValue](input.length)
    for (o <- input) {
      result.add(new XdmAtomicValue(o))
    }
    new XdmArray(result)
  }
}

class XdmArray()

/**
 * Create an empty XdmArray
 */
  extends XdmFunctionItem {
  setValue(SimpleArrayItem.EMPTY_ARRAY)

  /**
   * Create an XdmArray that wraps a supplied ArrayItem
   *
   * @param array the ArrayItem to be encapsulated
   */
  def this(array: ArrayItem) {
    this()
    setValue(array)
  }

  /**
   * Create an XdmArray supplying the members as an array of XdmValue objects
   *
   * @param members an array of XdmValue objects. Note that subsequent changes to the array will have no effect
   *                on the XdmValue.
   */
  def this(members: Array[XdmValue]) = {
    this()
    val values = new util.ArrayList[GroundedValue]
    for (member <- members) {
      values.add(member.getUnderlyingValue)
    }
    setValue(new SimpleArrayItem(values))
  }

  /**
   * Create an XdmArray supplying the members as a collection of XdmValue objects
   *
   * @param members a sequence of XdmValue objects. Note that if this is supplied as a list or similar
   *                collection, subsequent changes to the list/collection will have no effect on the XdmValue.
   *                Note that the argument can be a single XdmValue representing a sequence, in which case the
   *                constructed array will have one member for each item in the supplied sequence.
   */
  def this(members: Iterable[_ <: XdmValue])={
    this()
    val values = new util.ArrayList[GroundedValue]
    import scala.collection.JavaConversions._
    for (member <- members) {
      values.add(member.getUnderlyingValue)
    }
    setValue(new SimpleArrayItem(values))
  }

  /**
   * Get the number of members in the array
   *
   * @return the number of members in the array. (Note that the { @link #size()} method returns 1 (one),
   *                                                                    because an XDM array is an item.)
   */
  def arrayLength = getUnderlyingValue.arrayLength

  /**
   * Get the n'th member in the array, counting from zero.
   *
   * @param n the member that is required, counting the first member in the array as member zero
   * @return the n'th member in the sequence making up the array, counting from zero
   * @throws IndexOutOfBoundsException if n is less than zero or greater than or equal to the number
   *                                   of members in the array
   */
  @throws[IndexOutOfBoundsException]
  def get(n: Int) = {
    val member = getUnderlyingValue.get(n)
    XdmValue.wrap(member)
  }

  /**
   * Create a new array in which one member is replaced with a new value.
   *
   * @param n     the position of the member that is to be replaced, counting the first member
   *              in the array as member zero
   * @param value the new value for this member
   * @return a new array, the same length as the original, with one member replaced
   *         by a new value
   * @throws IndexOutOfBoundsException if n is less than zero or greater than or equal to the number
   *                                   of members in the array
   */
  @throws[IndexOutOfBoundsException]
  def put(n: Int, value: XdmValue) = {
    val member = value.getUnderlyingValue
    XdmValue.wrap(getUnderlyingValue.put(n, member)).asInstanceOf[XdmArray]
  }

  /**
   * Append a new member to an array
   *
   * @param value the new member
   * @return a new array, one item longer than the original
   * @throws SaxonApiUncheckedException if the value is lazily evaluated, and evaluation fails
   * @since 9.9. (See bug 3968: on first release of 9.9, the method was mistakenly named <code>append</code>).
   */
  def addMember(value: XdmValue) = try {
    val member = value.getUnderlyingValue
    val newArray = ArrayFunctionSet.ArrayAppend.append(getUnderlyingValue, member)
    XdmValue.wrap(newArray).asInstanceOf[XdmArray]
  } catch {
    case e: XPathException =>
      throw new SaxonApiUncheckedException(e)
  }

  /**
   * Concatenate another array
   *
   * @param value the other array
   * @return a new array, containing the members of this array followed by the members of the
   *         other array
   * @since 9.9
   */
  def concat(value: XdmArray) = {
    val other = value.getUnderlyingValue
    val newArray = getUnderlyingValue.concat(other)
    XdmValue.wrap(newArray).asInstanceOf[XdmArray]
  }

  /**
   * Get the members of the array in the form of a list.
   *
   * @return a list of the members of this array.
   */
  def asList = {
    val members = getUnderlyingValue.members.iterator
    val result = new util.ArrayList[XdmValue](getUnderlyingValue.getLength)
    while ( {
      members.hasNext
    }) result.add(XdmValue.wrap(members.next))
    result
  }

  /**
   * Get the underlying implementation object representing the value. This method allows
   * access to lower-level Saxon functionality, including classes and methods that offer
   * no guarantee of stability across releases.
   *
   * @return the underlying implementation object representing the value
   */
  override def getUnderlyingValue = super.getUnderlyingValue.asInstanceOf[ArrayItem]
}