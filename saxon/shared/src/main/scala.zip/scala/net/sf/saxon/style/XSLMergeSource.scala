////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.accum.Accumulator
import net.sf.saxon.expr.accum.AccumulatorRegistry
import net.sf.saxon.expr.sort.MergeInstr
import net.sf.saxon.lib.Validation
import net.sf.saxon.model.SchemaType
import net.sf.saxon.model.Type
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NameChecker
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace
import java.util

/**
 * Implements the xsl:merge-source element available in XSLT 3.0 as a child of xsl:merge.
 * <p>March 2012: xsl:merge-source and xsl:merge-input combined into a single element</p>
 */
class XSLMergeSource extends StyleElement {
  private var forEachItem = null
  private var forEachSource = null
  private var select = null
  private var sortBeforeMerge = false
  private var mergeKeyCount = 0
  private var sourceName = null
  private var validationAction = Validation.STRIP
  private var schemaType = null
  private var streamable = false
  private var accumulators = new util.HashSet[Accumulator]

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = false

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return false: no, it may not contain a sequence constructor
   */
  override def mayContainSequenceConstructor = false

  /**
   * Get the for-each-item expression, if it exists
   *
   * @return the for-each-item expression, if defined, or null otherwise
   */
  def getForEachItem = forEachItem

  /**
   * Get the for-each-source expression, if it exists
   *
   * @return the for-each-source expression, if defined, or null otherwise
   */
  def getForEachSource = forEachSource

  /**
   * Get the select expression
   *
   * @return the select expression. Never null.
   */
  def getSelect = select

  /**
   * Ask whether the sort-before-merge option is set
   *
   * @return true if the input sequence is to be sorted before merging
   */
  def isSortBeforeMerge = sortBeforeMerge

  /**
   * Get the name of the merge source, or null if not specified
   *
   * @return the value of the @name attribute, or null if the attribute was absent
   */
  def getSourceName = sourceName

  /**
   * Get the value of the validation attribute, if present
   *
   * @return the value of the validation attribute
   */
  def getValidationAction = validationAction

  /**
   * Get the value of the type attribute, if present
   *
   * @return the value of the type attribute
   */
  def getSchemaTypeAttribute = schemaType

  def makeMergeSource(mi: MergeInstr, select: Expression) = {
    val ms = new MergeInstr.MergeSource(mi)
    if (forEachItem != null) ms.initForEachItem(mi, forEachItem)
    if (forEachSource != null) ms.initForEachStream(mi, forEachSource)
    if (select != null) {
      this.select = select
      ms.initRowSelect(mi, select)
    }
    ms.baseURI = getBaseURI
    ms.sourceName = sourceName
    ms.validation = validationAction
    ms.schemaType = schemaType
    ms.setStreamable(streamable)
    ms.accumulators = accumulators
    ms
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = null

  override protected def prepareAttributes() = {
    var selectAtt = null
    var forEachItemAtt = null
    var forEachSourceAtt = null
    var validationAtt = null
    var typeAtt = null
    var streamableAtt = null
    var useAccumulatorsAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "for-each-item" =>
          forEachItemAtt = value
          forEachItem = makeExpression(forEachItemAtt, att)
        case "for-each-source" =>
          forEachSourceAtt = value
          forEachSource = makeExpression(forEachSourceAtt, att)
        case "select" =>
          selectAtt = value
          select = makeExpression(selectAtt, att)
        case "sort-before-merge" =>
          sortBeforeMerge = processBooleanAttribute("sort-before-merge", value)
        case "name" =>
          val nameAtt = Whitespace.trim(value)
          if (NameChecker.isValidNCName(nameAtt)) sourceName = nameAtt
          else compileError("xsl:merge-source/@name (" + nameAtt + ") is not a valid NCName", "XTSE0020")
        case "validation" =>
          validationAtt = Whitespace.trim(value)
        case "type" =>
          typeAtt = Whitespace.trim(value)
        case "streamable" =>
          streamableAtt = value
        case "use-accumulators" =>
          useAccumulatorsAtt = Whitespace.trim(value)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (sourceName == null) sourceName = "saxon-merge-source-" + hashCode
    if (forEachItemAtt != null) if (forEachSourceAtt != null) compileError("The for-each-item and for-each-source attributes must not both be present", "XTSE3195")
    if (selectAtt == null) reportAbsence("select")
    if (validationAtt == null) validationAction = getDefaultValidation
    else validationAction = validateValidationAttribute(validationAtt)
    if (typeAtt != null) {
      if (!isSchemaAware) compileError("The @type attribute is available only with a schema-aware XSLT processor", "XTSE1660")
      schemaType = getSchemaType(typeAtt)
      validationAction = Validation.BY_TYPE
    }
    if (typeAtt != null && validationAtt != null) compileError("The @validation and @type attributes are mutually exclusive", "XTSE1505")
    if ((typeAtt != null || validationAtt != null) && forEachSourceAtt == null) compileError("The @type and @validation attributes can be used only when @for-each-stream is specified", "XTSE0020")
    if (streamableAtt != null) {
      streamable = processStreamableAtt(streamableAtt)
      if (streamable && forEachSource == null) compileError("Streaming on xsl:merge-source is possible only when @for-each-source is used", "XTSE3195")
    }
    else if (forEachSource != null) streamable = false
    if (useAccumulatorsAtt == null) useAccumulatorsAtt = ""
    val registry = getPrincipalStylesheetModule.getStylesheetPackage.getAccumulatorRegistry
    accumulators = registry.getUsedAccumulators(useAccumulatorsAtt, this)
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    forEachItem = typeCheck("for-each-item", forEachItem)
    forEachSource = typeCheck("for-each-source", forEachSource)
    select = typeCheck("select", select)
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLMergeKey]) mergeKeyCount += 1
      else if (child.getNodeKind == Type.TEXT) { // with xml:space=preserve, white space nodes may still be there
        if (!Whitespace.isWhite(child.getStringValueCS)) compileError("No character data is allowed within xsl:merge-source", "XTSE0010")
      }
      else if (child.isInstanceOf[StyleElement]) child.asInstanceOf[StyleElement].compileError("No children other than xsl:merge-key are allowed within xsl:merge-source", "XTSE0010")
    }
    if (mergeKeyCount == 0) compileError("xsl:merge-source must have exactly at least one xsl:merge-key child element", "XTSE0010")
  }
}