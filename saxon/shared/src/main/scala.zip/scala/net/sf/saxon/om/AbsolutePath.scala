////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.Type
import net.sf.saxon.trans.Err
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.tree.util.Navigator
import java.util

/**
 * Represents the path from the root of an XDM tree to a specific node, as a sequence of (name, position) pairs
 */
object AbsolutePath {
  /**
   * Create an absolute path given a Node
   *
   * @param node the node whose path is required
   */
    def pathToNode(node: NodeInfo) = {
      val list = new util.LinkedList[AbsolutePath.PathElement]
      while ( {
        node != null && node.getNodeKind != Type.DOCUMENT
      }) {
        val pe = new AbsolutePath.PathElement(node.getNodeKind, NameOfNode.makeName(node), Navigator.getNumberSimple(node, null))
        list.addFirst(pe)
        node = node.getParent
      }
      new AbsolutePath(list)
    }

  /**
   * Inner class representing one step in the path
   */
  class PathElement(var nodeKind: Int, var name: NodeName, var index: Int)

  /**
   * Create a path element
   *
   * @param nodeKind the kind of node
   * @param name     the name of the node
   * @param index    the position of the node relative to siblings of the same node kind and name.
   *                 The value -1 indicates "not known", which will typically be the case for streamed nodes.
   */ {
    /**
     * Get the node kind
     *
     * @return the node kind, as a constant from { @link net.sf.saxon.model.Type}
     */
    def getNodeKind = nodeKind

    /**
     * Get the name of the node
     *
     * @return the node name
     */
    def getName = name

    /**
     * Get the position of the node
     *
     * @return the position relative to siblings of the same node kind and name.
     *         The value -1 indicates "not known", which will typically be the case for streamed nodes.
     */
    def getIndex = index

    /**
     * Get a string representation of the path
     *
     * @param fsb    buffer into which the string representation will be written
     * @param option for representing namespaces:
     *               'p': use namepace prefix. 'u': use full URI. 's': use abbreviated URI
     */
    def toString(fsb: FastStringBuffer, option: Char) = nodeKind match {
      case Type.DOCUMENT =>
        fsb.append("(/)")
      case Type.ATTRIBUTE =>
        fsb.cat('@')
        if (!name.getURI.isEmpty) if (option == 'u') {
          fsb.append("Q{")
          fsb.append(name.getURI)
          fsb.append("}")
        }
        else if (option == 'p') {
          val prefix = name.getPrefix
          if (!prefix.isEmpty) {
            fsb.append(prefix)
            fsb.cat(':')
          }
        }
        else if (option == 's') {
          fsb.append("Q{")
          fsb.append(Err.abbreviateURI(name.getURI))
          fsb.append("}")
        }
        fsb.append(getName.getLocalPart)
      case Type.ELEMENT =>
        if (option == 'u') {
          fsb.append("Q{")
          fsb.append(name.getURI)
          fsb.append("}")
        }
        else if (option == 'p') {
          val prefix = name.getPrefix
          if (!prefix.isEmpty) {
            fsb.append(prefix)
            fsb.cat(':')
          }
        }
        else if (option == 's') if (!name.getURI.isEmpty) {
          fsb.append("Q{")
          fsb.append(Err.abbreviateURI(name.getURI))
          fsb.append("}")
        }
        fsb.append(name.getLocalPart)
        appendPredicate(fsb)
      case Type.TEXT =>
        fsb.append("text()")
      case Type.COMMENT =>
        fsb.append("comment()")
        appendPredicate(fsb)
      case Type.PROCESSING_INSTRUCTION =>
        fsb.append("processing-instruction(")
        fsb.append(name.getLocalPart)
        fsb.append(")")
        appendPredicate(fsb)
      case Type.NAMESPACE =>
        fsb.append("namespace::")
        if (name.getLocalPart.isEmpty) fsb.append("*[Q{" + NamespaceConstant.FN + "}local-name()=\"\"]")
        else fsb.append(name.getLocalPart)
      case _ =>
    }

    def appendPredicate(fsb: FastStringBuffer) = {
      val index = getIndex
      if (index != -1) {
        fsb.cat('[')
        fsb.append(getIndex + "")
        fsb.cat(']')
      }
    }
  }

}
/**
 * Create an absolute path given a list of path elements
 *
 * @param path the list of path elements, starting from the root. It is not necessary to include a path element
 *             for the document node.
 */
class AbsolutePath(val path: List[AbsolutePath.PathElement])
{
  this.path = new util.ArrayList[AbsolutePath.PathElement](path)
  private var path = null
  private var systemId = null

  /**
   * Append an attribute name to the path
   *
   * @param attributeName the name of the attribute
   */
  def appendAttributeName(attributeName: NodeName) = {
    if (!path.isEmpty) {
      val last = path.get(path.size - 1)
      if (last.getNodeKind == Type.ATTRIBUTE) path.remove(path.size - 1)
    }
    val att = new AbsolutePath.PathElement(Type.ATTRIBUTE, attributeName, 1)
    path.add(att)
  }

  /**
   * Get a string representing the path using namespace prefixes to represent QNames
   *
   * @return the path in the form <code>/prefix:local[n]/prefix:local[m]/...</code>
   */
  def getPathUsingPrefixes = {
    val fsb = new FastStringBuffer(FastStringBuffer.C256)
    import scala.collection.JavaConversions._
    for (pe <- path) {
      fsb.cat('/')
      pe.toString(fsb, 'p')
    }
    fsb.toString
  }

  /**
   * Get a string representing the path using namespace URIs to represent QNames
   *
   * @return the path in the form <code>/Q{uri}local[n]/Q{uri}local[m]/...</code>
   */
  def getPathUsingUris = {
    val fsb = new FastStringBuffer(FastStringBuffer.C256)
    import scala.collection.JavaConversions._
    for (pe <- path) {
      fsb.cat('/')
      pe.toString(fsb, 'u')
    }
    fsb.toString
  }

  /**
   * Get a string representing the path using abbreviated namespace URIs to represent QNames
   *
   * @return the path in the form <code>/Q{uri}local[n]/Q{uri}local[m]/...</code>, with the URIs shortened
   */
  def getPathUsingAbbreviatedUris = {
    val fsb = new FastStringBuffer(FastStringBuffer.C256)
    import scala.collection.JavaConversions._
    for (pe <- path) {
      fsb.cat('/')
      pe.toString(fsb, 's')
    }
    fsb.toString
  }

  override def toString = getPathUsingUris

  override def equals(obj: Any) = obj.isInstanceOf[AbsolutePath] && obj.toString == toString

  override def hashCode = toString.hashCode

  def setSystemId(systemId: String) = this.systemId = systemId

  def getSystemId = systemId
}