////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.xpath

import net.sf.saxon.Configuration

import net.sf.saxon.expr.Expression

import net.sf.saxon.expr.PackageData

import net.sf.saxon.expr.instruct.SlotManager

import net.sf.saxon.lib.NamespaceConstant

import net.sf.saxon.model.SchemaException

import net.sf.saxon.om.NamespaceResolver

import net.sf.saxon.om.StructuredQName

import net.sf.saxon.sxpath.AbstractStaticContext

import net.sf.saxon.trans.XPathException

import javax.xml.XMLConstants

import javax.xml.namespace.NamespaceContext

import javax.xml.transform.Source

import javax.xml.xpath.XPathFunctionResolver

import javax.xml.xpath.XPathVariableResolver

import java.util.Arrays

import java.util.Iterator

import java.util.Set

import JAXPXPathStaticContext._

import scala.beans.{BeanProperty, BooleanBeanProperty}

//remove if not needed
import scala.collection.JavaConversions._

object JAXPXPathStaticContext {

  private class MinimalNamespaceContext
    extends NamespaceContext
      with NamespaceResolver {

    /*@Nullable*/

    def getNamespaceURI(prefix: String): String =
      if (prefix == null) {
        throw new IllegalArgumentException("prefix")
      } else if (prefix == XMLConstants.DEFAULT_NS_PREFIX) {
        //XMLConstants.NULL_NS_URI;
        ""
      } else if (prefix.==("xml")) {
        NamespaceConstant.XML
      } else if (prefix.==("xs")) {
        NamespaceConstant.SCHEMA
      } else if (prefix.==("xsi")) {
        NamespaceConstant.SCHEMA_INSTANCE
      } else if (prefix.==("saxon")) {
        NamespaceConstant.SAXON
      } else {
        null
      }

    /*@NotNull*/

    def getPrefix(namespaceURI: String): String =
      throw new UnsupportedOperationException()

    /*@NotNull*/

    def getPrefixes(namespaceURI: String): Iterator =
      throw new UnsupportedOperationException()

    def iteratePrefixes(): Iterator[String] = {
      val prefixes: Array[String] = Array("", "xml", "xs", "xsi", "saxon")
      Arrays.asList(prefixes: _*).iterator()
    }

    /*@Nullable*/

    def getURIForPrefix(prefix: String, useDefault: Boolean): String =
      getNamespaceURI(prefix)

  }

}

class JAXPXPathStaticContext(config: Configuration)
  extends AbstractStaticContext
    with NamespaceResolver {

  @BeanProperty
  var stackFrameMap: SlotManager = config.makeSlotManager()

  private var xpathFunctionLibrary: XPathFunctionLibrary =
    new XPathFunctionLibrary()

  @BeanProperty
  var namespaceContext: NamespaceContext = new MinimalNamespaceContext()

  private var variableResolver: XPathVariableResolver = _

  this.configuration = config

  this.defaultFunctionLibrary = 31

  addFunctionLibrary(xpathFunctionLibrary)

  this.packageData = new PackageData(getConfiguration)

  def setXPathVariableResolver(resolver: XPathVariableResolver): Unit = {
    this.variableResolver = resolver
  }

  def getXPathVariableResolver(): XPathVariableResolver = variableResolver

  def setXPathFunctionResolver(
                                xPathFunctionResolver: XPathFunctionResolver): Unit = {
    if (xpathFunctionLibrary != null) {
      xpathFunctionLibrary.setXPathFunctionResolver(xPathFunctionResolver)
    }
  }

  /*@Nullable*/

  def getXPathFunctionResolver(): XPathFunctionResolver =
    if (xpathFunctionLibrary != null) {
      xpathFunctionLibrary.getXPathFunctionResolver
    } else {
      null
    }

  /*@NotNull*/

  def getNamespaceResolver(): NamespaceResolver = this

  def getURIForPrefix(prefix: String, useDefault: Boolean): String =
    if (prefix.isEmpty) {
      if (useDefault) {
        getDefaultElementNamespace
      } else {
        NamespaceConstant.NULL
      }
    } else {
      namespaceContext.getNamespaceURI(prefix)
    }

  def iteratePrefixes(): Iterator[String] =
    if (namespaceContext.isInstanceOf[NamespaceResolver]) {
      namespaceContext.asInstanceOf[NamespaceResolver].iteratePrefixes()
    } else {
      throw new UnsupportedOperationException()
    }

  /*@NotNull*/

  def bindVariable(qName: StructuredQName): Expression = // which will call the variableResolver when called upon to return the run-time value
    if (variableResolver != null) {
      // Note that despite its name, JAXPVariableReference is not actually a VariableReference
      new JAXPVariableReference(qName, variableResolver)
    } else {
      throw new XPathException(
        "Variable is used in XPath expression, but no JAXP VariableResolver is available")
    }

  def importSchema(source: Source): Unit = {
    getConfiguration.addSchemaSource(source,
      getConfiguration.makeErrorReporter())
    this.schemaAware = true
  }

  def isImportedSchema(namespace: String): Boolean =
    getConfiguration.isSchemaAvailable(namespace)

  def getImportedSchemaNamespaces(): Set[String] =
    getConfiguration.getImportedNamespaces

}

// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * A JAXPXPathStaticContext provides a context for parsing an XPath expression
 * in a context other than a stylesheet. In particular, it is used to support
 * the JAXP 1.3 XPath API. The JAXP API does not actually expose the StaticContext
 * object directly; rather, the static context (namespaces, variables, and functions)
 * is manipulated through the XPath object, implemented in Saxon by the {@link XPathEvaluator}
 */
