////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.ItemType
import net.sf.saxon.model.TypeHierarchy
import net.sf.saxon.model.UType
import net.sf.saxon.om.Item
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException

/**
 * A mapping function for use in conjunction with an {@link ItemMappingIterator} that checks that
 * all the items in a sequence are instances of a given item type
 *
 */
class ItemTypeCheckingFunction extends ItemMappingFunction {
  private var requiredItemType = null
  private var role = null
  private var location = null
  private var failingExpression = null
  private var config = null

  /**
   * Create the type-checking function
   *
   * @param requiredItemType  the item type that all items in the sequence must conform to
   * @param role              information for error messages
   * @param failingExpression the location of the expression for error messages
   * @param config            the Saxon configuration
   */
  def this(requiredItemType: ItemType, role: RoleDiagnostic, failingExpression: Expression, config: Configuration) {
    this()
    this.requiredItemType = requiredItemType
    this.role = role
    this.failingExpression = failingExpression
    this.location = failingExpression.getLocation
    this.config = config
  }

  def this(requiredItemType: ItemType, role: RoleDiagnostic, locator: Location, config: Configuration) {
    this()
    this.requiredItemType = requiredItemType
    this.role = role
    this.location = locator
    this.config = config
  }

  @throws[XPathException]
  override def mapItem(item: Item) = {
    testConformance(item, config)
    item
  }

  @throws[XPathException]
  private def testConformance(item: Item, config: Configuration) = {
    val th = config.getTypeHierarchy
    if (requiredItemType.matches(item, th)) {
      // OK, no action
    }
    else if (requiredItemType.getUType.subsumes(UType.STRING) && BuiltInAtomicType.ANY_URI.matches(item, th)) {
    }
    else {
      val message = role.composeErrorMessage(requiredItemType, item, th)
      val errorCode = role.getErrorCode
      if ("XPDY0050" == errorCode) { // error in "treat as" assertion
        val te = new XPathException(message, errorCode)
        te.setFailingExpression(failingExpression)
        te.setLocator(location)
        te.setIsTypeError(false)
        throw te
      }
      else {
        val te = new XPathException(message, errorCode)
        te.setFailingExpression(failingExpression)
        te.setLocator(location)
        te.setIsTypeError(true)
        throw te
      }
    }
  }
}