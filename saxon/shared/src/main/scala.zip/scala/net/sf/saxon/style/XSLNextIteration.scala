////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.LocalVariableReference
import net.sf.saxon.expr.VariableReference
import net.sf.saxon.expr.instruct.LocalParam
import net.sf.saxon.expr.instruct.NextIteration
import net.sf.saxon.expr.instruct.WithParam
import net.sf.saxon.model.Type
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.Err
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.Whitespace

/**
 * An xsl:next-iteration element in the stylesheet
 */
class XSLNextIteration extends XSLBreakOrContinue {
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    validatePosition()
    if (xslIterate == null) compileError("xsl:next-iteration must be a descendant of an xsl:iterate instruction")
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLWithParam]) if (child.asInstanceOf[XSLWithParam].isTunnelParam) compileError("An xsl:with-param element within xsl:iterate must not specify tunnel='yes'", "XTSE0020")
      else if (child.getNodeKind == Type.TEXT) { // with xml:space=preserve, white space nodes may still be there
        if (!Whitespace.isWhite(child.getStringValueCS)) compileError("No character data is allowed within xsl:next-iteration", "XTSE0010")
      }
      else compileError("Child element " + Err.wrap(child.getDisplayName, Err.ELEMENT) + " is not allowed as a child of xsl:next-iteration", "XTSE0010")
    }
  }

  @throws[XPathException]
  override def postValidate(): Unit = {
    if (xslIterate == null) return // previous error already reported
    // check that every supplied parameter is declared in the saxon:iterate instruction
    import scala.collection.JavaConversions._
    for (w <- children(classOf[XSLWithParam].isInstance)) {
      val withParam = w.asInstanceOf[XSLWithParam]
      val formalParams = xslIterate.iterateAxis(AxisInfo.CHILD)
      var ok = false
      var param = null
      while ( {
        (param = formalParams.next) != null
      }) if (param.isInstanceOf[XSLLocalParam] && param.asInstanceOf[XSLLocalParam].getVariableQName == withParam.getVariableQName) {
        ok = true
        val required = param.asInstanceOf[XSLLocalParam].getRequiredType
        withParam.checkAgainstRequiredType(required)
        break //todo: break is not supported
      }
      if (!ok) compileError("Parameter " + withParam.getVariableQName.getDisplayName + " is not declared in the containing xsl:iterate instruction", "XTSE3130")
    }
  }

  def getDeclaredParamType(name: StructuredQName): SequenceType = {
    import scala.collection.JavaConversions._
    for (param <- xslIterate.children(classOf[XSLLocalParam].isInstance)) {
      if (param.asInstanceOf[XSLLocalParam].getVariableQName == name) return param.asInstanceOf[XSLLocalParam].getRequiredType
    }
    null
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val call = new NextIteration
    call.setRetainedStaticContext(makeRetainedStaticContext)
    var actualParams = getWithParamInstructions(call, exec, decl, false)
    call.setParameters(actualParams)
    // For all declared parameters of the xsl:iterate instruction that are not present in the
    // actual parameters of the xsl:next-iteration, add an implicit <xsl:with-param name="p" select="$p"/>
    if (xslIterate != null) {
      val declaredParams = xslIterate.iterateAxis(AxisInfo.CHILD)
      var param = null
      while ( {
        (param = declaredParams.next) != null
      }) if (param.isInstanceOf[XSLLocalParam]) {
        val pdecl = param.asInstanceOf[XSLLocalParam]
        val paramName = pdecl.getVariableQName
        val lp = pdecl.getCompiledParam
        var found = false
        for (actualParam <- actualParams) {
          if (paramName == actualParam.getVariableQName) {
            actualParam.setSlotNumber(lp.getSlotNumber)
            found = true
            break //todo: break is not supported
          }
        }
        if (!found) {
          val wp = new WithParam
          wp.setVariableQName(paramName)
          val ref = new LocalVariableReference(lp)
          wp.setSelectExpression(call, ref)
          //wp.setParameterId(psm.allocateUniqueParameterNumber(paramName));
          wp.setSlotNumber(lp.getSlotNumber)
          ref.setStaticType(pdecl.getRequiredType, null, 0)
          val p2 = new Array[WithParam](actualParams.length + 1)
          p2(0) = wp
          System.arraycopy(actualParams, 0, p2, 1, actualParams.length)
          actualParams = p2
        }
      }
    }
    call
  }
}