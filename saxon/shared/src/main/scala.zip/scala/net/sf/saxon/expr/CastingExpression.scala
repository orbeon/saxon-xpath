////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.parser.XPathParser
import net.sf.saxon.model.AtomicType
import net.sf.saxon.model.BuiltInAtomicType
import net.sf.saxon.model.Converter
import net.sf.saxon.om.NamespaceResolver
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType

/**
 * Casting Expression: abstract superclass for "cast as X" and "castable as X", which share a good deal of logic
 */
abstract class CastingExpression(val source: Expression, var targetType: AtomicType, val allowEmpty: Boolean)

/**
 * Create a cast expression
 *
 * @param source     expression giving the value to be converted
 * @param target     the type to which the value is to be converted
 * @param allowEmpty true if the expression allows an empty sequence as input, producing
 *                   an empty sequence as output. If false, an empty sequence is a type error.
 */
  extends UnaryExpression(source) {
  this.allowEmpty = allowEmpty
  targetPrimitiveType = targetType.getPrimitiveItemType
  private var targetPrimitiveType = null
  private var allowEmpty = false
  protected var converter = null
  private var operandIsStringLiteral = false

  /**
   * Get the primitive base type of the target type of the cast
   *
   * @return the primitive type of the target type
   */
  def getTargetPrimitiveType = targetPrimitiveType

  /**
   * Set the target type
   *
   * @param type the target type for the cast
   */
  def setTargetType(`type`: AtomicType) = targetType = `type`

  /**
   * Get the target type (the result type)
   *
   * @return the target type
   */
  def getTargetType = targetType

  override protected def getOperandRole = OperandRole.SINGLE_ATOMIC

  /**
   * Say whether the expression accepts an empty sequence as input (producing an empty sequence as output)
   *
   * @param allow true if an empty sequence is accepted
   */
  def setAllowEmpty(allow: Boolean) = allowEmpty = allow

  /**
   * Ask whether the expression accepts an empty sequence as input (producing an empty sequence as output)
   *
   * @return true if an empty sequence is accepted
   */
  def allowsEmpty = allowEmpty

  /**
   * Say whether the operand to the cast expression was supplied in the form of a string literal. This is
   * relevant only for XPath 2.0 / XQuery 1.0, and then only when the target type is a QName or NOTATION.
   *
   * @param option true if the operand was supplied as a string literal
   */
  def setOperandIsStringLiteral(option: Boolean) = operandIsStringLiteral = option

  /**
   * Ask whether the operand to the cast expression was supplied in the form of a string literal. This is
   * relevant only for XPath 2.0 / XQuery 1.0, and then only when the target type is a QName or NOTATION.
   *
   * @return true if the operand was supplied as a string literal
   */
  def isOperandIsStringLiteral = operandIsStringLiteral

  /**
   * Get the Converter allocated to implement this cast expression, if any
   *
   * @return the Converter if one has been statically allocated, or null if not
   */
  def getConverter = converter

  /**
   * Get the namespace resolver, if any
   *
   * @return the namespace resolver that was statically allocated if the target type is namespace-sensitive
   */
  def getNamespaceResolver = getRetainedStaticContext

  /**
   * Get the expression's dependencies. If the target type is namespace-sensitive, then the expression
   * has a dependency on the namespace bindings in the static context
   *
   * @return the expression's dependencies.
   */
  override def getIntrinsicDependencies = if (getTargetType.isNamespaceSensitive) StaticProperty.DEPENDS_ON_STATIC_CONTEXT
  else 0

  /**
   * Simplify the expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def simplify = {
    if (targetType.isInstanceOf[BuiltInAtomicType]) {
      val s = XPathParser.whyDisallowedType(getPackageData, targetType.asInstanceOf[BuiltInAtomicType])
      if (s != null) { // this is checked here because the ConstructorFunctionLibrary doesn't have access to the static
        // context at bind time
        val err = new XPathException(s, "XPST0080", this.getLocation)
        err.setIsStaticError(true)
        throw err
      }
    }
    setBaseExpression(getBaseExpression.simplify)
    this
  }

  /**
   * Determine the special properties of this expression
   *
   * @return { @link net.sf.saxon.expr.StaticProperty#NO_NODES_NEWLY_CREATED}.
   */
  override def computeSpecialProperties = {
    val p = super.computeSpecialProperties
    p | StaticProperty.NO_NODES_NEWLY_CREATED
  }

  /**
   * Export expression structure to SEF file. The abstract expression tree
   * is written to the supplied output destination. Helper method for subclasses.
   *
   * @param out      the destination of the output
   * @param elemName the element name to be used in the SEF file
   * @throws XPathException if output fails
   */
  @throws[XPathException]
  protected def `export`(out: ExpressionPresenter, elemName: String) = {
    out.startElement(elemName, this)
    val card = if (allowsEmpty) StaticProperty.ALLOWS_ZERO_OR_ONE
    else StaticProperty.EXACTLY_ONE
    val st = SequenceType.makeSequenceType(getTargetType, card)
    out.emitAttribute("flags", "a" + (if (allowsEmpty) "e"
    else ""))
    out.emitAttribute("as", st.toAlphaCode)
    getBaseExpression.`export`(out)
    out.endElement
  }
}