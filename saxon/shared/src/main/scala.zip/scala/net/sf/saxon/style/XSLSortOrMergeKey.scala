////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr._
import net.sf.saxon.expr.parser.ExpressionTool
import net.sf.saxon.expr.parser.RoleDiagnostic
import net.sf.saxon.expr.sort.CodepointCollator
import net.sf.saxon.expr.sort.SortKeyDefinition
import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.lib.StringCollator
import net.sf.saxon.model.StringConverter
import net.sf.saxon.model.ValidationFailure
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.SequenceType
import net.sf.saxon.value.StringValue
import net.sf.saxon.value.Whitespace
import java.net.URI
import java.net.URISyntaxException

abstract class XSLSortOrMergeKey extends StyleElement {
  protected var sortKeyDefinition = null
  protected var select = null
  protected var order = null
  protected var dataType = null
  protected var caseOrder = null
  protected var lang = null
  protected var collationName = null
  protected var stable = null
  protected var useDefaultCollation = true

  /**
   * Determine whether this type of element is allowed to contain a sequence constructor
   *
   * @return true: yes, it may contain a sequence constructor
   */
  override def mayContainSequenceConstructor = true

  protected def getErrorCode = "XTSE1015"

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    if (select != null && hasChildNodes) compileError("An " + getDisplayName + " element with a select attribute must be empty", getErrorCode)
    if (select == null && !hasChildNodes) {
      select = new ContextItemExpression
      select.setRetainedStaticContext(getStaticContext.makeRetainedStaticContext)
    }
    // Get the named or default collation
    if (useDefaultCollation) collationName = new StringLiteral(getDefaultCollationName)
    var stringCollator = null
    if (collationName.isInstanceOf[StringLiteral]) {
      var collationString = collationName.asInstanceOf[StringLiteral].getStringValue
      try {
        var collationURI = new URI(collationString)
        if (!collationURI.isAbsolute) {
          val base = new URI(getBaseURI)
          collationURI = base.resolve(collationURI)
          collationString = collationURI.toString
        }
      } catch {
        case err: URISyntaxException =>
          compileError("Collation name '" + collationString + "' is not a valid URI")
          collationString = NamespaceConstant.CODEPOINT_COLLATION_URI
      }
      stringCollator = findCollation(collationString, getBaseURI)
      if (stringCollator == null) {
        compileError("Collation " + collationString + " has not been defined", "XTDE1035")
        stringCollator = CodepointCollator.getInstance // for recovery paths
      }
    }
    select = typeCheck("select", select)
    order = typeCheck("order", order)
    caseOrder = typeCheck("case-order", caseOrder)
    lang = typeCheck("lang", lang)
    dataType = typeCheck("data-type", dataType)
    collationName = typeCheck("collation", collationName)
    if (select != null) try {
      val role = new RoleDiagnostic(RoleDiagnostic.INSTRUCTION, getDisplayName + "//select", 0)
      select = getConfiguration.getTypeChecker(false).staticTypeCheck(select, SequenceType.ATOMIC_SEQUENCE, role, makeExpressionVisitor)
    } catch {
      case err: XPathException =>
        compileError(err)
    }
    sortKeyDefinition = new SortKeyDefinition
    sortKeyDefinition.setOrder(order)
    sortKeyDefinition.setCaseOrder(caseOrder)
    sortKeyDefinition.setLanguage(lang)
    sortKeyDefinition.setSortKey(select, true)
    sortKeyDefinition.setDataTypeExpression(dataType)
    sortKeyDefinition.setCollationNameExpression(collationName)
    sortKeyDefinition.setCollation(stringCollator)
    sortKeyDefinition.setBaseURI(getBaseURI)
    sortKeyDefinition.setStable(stable)
    sortKeyDefinition.setBackwardsCompatible(xPath10ModeIsEnabled)
  }

  protected def getStable = stable

  override protected def prepareAttributes() = {
    var selectAtt = null
    var orderAtt = null
    var dataTypeAtt = null
    var caseOrderAtt = null
    var langAtt = null
    var collationAtt = null
    var stableAtt = null
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      val f = attName.getDisplayName
      val value = att.getValue
      f match {
        case "select" =>
          selectAtt = value
          select = makeExpression(selectAtt, att)
        case "order" =>
          orderAtt = Whitespace.trim(value)
          order = makeAttributeValueTemplate(orderAtt, att)
        case "data-type" =>
          dataTypeAtt = Whitespace.trim(value)
          dataType = makeAttributeValueTemplate(dataTypeAtt, att)
        case "case-order" =>
          caseOrderAtt = Whitespace.trim(value)
          caseOrder = makeAttributeValueTemplate(caseOrderAtt, att)
        case "lang" =>
          langAtt = Whitespace.trim(value)
          lang = makeAttributeValueTemplate(langAtt, att)
        case "collation" =>
          collationAtt = Whitespace.trim(value)
          collationName = makeAttributeValueTemplate(collationAtt, att)
        case "stable" =>
          stableAtt = Whitespace.trim(value)
          stable = makeAttributeValueTemplate(stableAtt, att)
        case _ =>
          checkUnknownAttribute(attName)
      }
    }
    if (orderAtt == null) order = new StringLiteral("ascending")
    else checkAttributeValue("order", orderAtt, true, Array[String]("ascending", "descending"))
    if (dataTypeAtt == null) dataType = null
    if (caseOrderAtt == null) caseOrder = new StringLiteral("#default")
    else {
      checkAttributeValue("case-order", caseOrderAtt, true, Array[String]("lower-first", "upper-first"))
      useDefaultCollation = false
    }
    if (langAtt == null || langAtt == "") lang = new StringLiteral(StringValue.EMPTY_STRING)
    else {
      useDefaultCollation = false
      if (lang.isInstanceOf[StringLiteral]) {
        val s = lang.asInstanceOf[StringLiteral].getStringValue
        if (s.length != 0) {
          val vf = StringConverter.StringToLanguage.INSTANCE.validate(s)
          if (vf != null) {
            compileError("The lang attribute must be a valid language code", "XTDE0030")
            lang = new StringLiteral(StringValue.EMPTY_STRING)
          }
        }
      }
    }
    if (stableAtt == null) stable = null
    else checkAttributeValue("stable", stableAtt, true, StyleElement.YES_NO)
    if (collationAtt != null) useDefaultCollation = false
  }

  /*@Nullable*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    if (select == null) {
      var b = compileSequenceConstructor(exec, decl, true)
      if (b == null) {
        b = Literal.makeEmptySequence
        b.setRetainedStaticContext(makeRetainedStaticContext)
      }
      try {
        var atomizedSortKey = Atomizer.makeAtomizer(b, null)
        atomizedSortKey = atomizedSortKey.simplify
        ExpressionTool.copyLocationInfo(b, atomizedSortKey)
        sortKeyDefinition.setSortKey(atomizedSortKey, true)
        select = atomizedSortKey
      } catch {
        case e: XPathException =>
          compileError(e)
      }
    }
    // Simplify the sort key definition - this is especially important in the case where
    // all aspects of the sort key are known statically.
    sortKeyDefinition = sortKeyDefinition.simplify.asInstanceOf[SortKeyDefinition]
    // not an executable instruction
    null
  }

  def getSortKeyDefinition = sortKeyDefinition
}