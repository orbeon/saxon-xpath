////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.om

import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.model.{MissingComponentException, SimpleType}
import net.sf.saxon.s9api.Location

/**
 * This class contains immutable information about an attribute. An {@code AttributeInfo} is not a node:
 * it has no identity and no navigation capability to the parent element or to any other nodes on the tree.
 */
object AttributeInfo {

  /**
   * AttributeInfo.Deleted is a subclass used to mark a deleted attribute (in XQuery Update)
   */
  class Deleted(val att: AttributeInfo) extends AttributeInfo(att.getNodeName, att.getType, att.getValue, att.getLocation, att.getProperties) {
  }

}


/**
 * Create an immutable AttributeInfo object
 *
 * @param nodeName   the name of the attribute
 * @param type       the type annotation of the attribute
 * @param value      the string value of the attribute
 * @param location   the location of the attribute within a source document (if known)
 * @param properties additional bitwise properties of the attribute, enumerated in class
 *                   { @link ReceiverOption}
 */
class AttributeInfo(var nodeName: NodeName, var `type`: SimpleType, var value: String, var location: Location, var properties: Int){
  /**
   * Get the name of the attribute
   *
   * @return the name of the attribute
   */
  def getNodeName = nodeName

  /**
   * Get the type annotation of the attribute
   *
   * @return the type annotation
   */
  def getType = `type`

  /**
   * Get the string value of the attribute
   *
   * @return the string value
   */
  def getValue = value

  /**
   * Get the location of the attribute, if known
   *
   * @return the location of the attribute (or { @link Loc#NONE} if unknown)
   */
  def getLocation = location

  /**
   * Get properties of the attribute
   *
   * @return properties of the attribute, identified by constants in { @link ReceiverOption}
   */
  def getProperties = properties

  /**
   * Ask whether this is an ID attribute
   *
   * @return true if the name is xml:id, or the properties include the IS_ID property, or the
   *         type annotation is an ID type.
   */
  def isId = try StandardNames.XML_ID_NAME.equals(nodeName) || ReceiverOption.contains(getProperties, ReceiverOption.IS_ID) || getType.isIdType
  catch {
    case e: MissingComponentException =>
      false
  }

  def withNodeName(newName: NodeName) = new AttributeInfo(newName, `type`, value, location, properties)
}