////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.instruct.CopyOf
import net.sf.saxon.expr.parser._
import net.sf.saxon.expr.sort.DocumentSorter
import net.sf.saxon.functions.Doc
import net.sf.saxon.functions.DocumentFn
import net.sf.saxon.functions.KeyFn
import net.sf.saxon.model._
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.pattern._
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Cardinality
import net.sf.saxon.value.IntegerValue
import net.sf.saxon.value.SequenceType
import java.util

/**
 * A slash expression is any expression using the binary slash operator "/". The parser initially generates a slash
 * expression for all occurrences of the binary "/" operator, wrapped in a documentSort() function to do the sorting
 * and de-duplication required by the semantics of path expressions. The documentSort() is subsequently stripped off
 * by the optimizer if sorting and deduplication is found to be unnecessary. The slash expression itself, therefore,
 * does not perform sorting or de-duplication.
 */
class SlashExpression(val start: Expression, val step: Expression)

/**
 * Constructor
 *
 * @param start The left hand operand (which must always select a sequence of nodes).
 * @param step  The step to be followed from each node in the start expression to yield a new
 *              sequence; this may return either nodes or atomic values (but not a mixture of the two)
 */
  extends BinaryExpression(start, Token.SLASH, step) with ContextSwitchingExpression {
  private[expr] var contextFree = false

  override protected def getOperandRole(arg: Int) = if (arg == 0) OperandRole.FOCUS_CONTROLLING_SELECT
  else OperandRole.FOCUS_CONTROLLED_ACTION

  /**
   * Get the left-hand operand
   *
   * @return the left-hand operand
   */
  def getStart = getLhsExpression

  /**
   * Set the left-hand operand
   *
   * @param start the left-hand operand
   */
  def setStart(start: Expression) = setLhsExpression(start)

  /**
   * Get the right-hand operand
   *
   * @return the right-hand operand
   */
  def getStep = getRhsExpression

  /**
   * Set the right-hand operand
   *
   * @param step the right-hand operand
   */
  def setStep(step: Expression) = setRhsExpression(step)

  override def getExpressionName = "pathExpression"

  /**
   * Get the start expression (the left-hand operand)
   *
   * @return the first operand
   */
  override def getSelectExpression = getStart

  /**
   * Get the step expression (the right-hand operand)
   *
   * @return the second operand
   */
  override def getActionExpression = getStep

  /**
   * Determine the data type of the items returned by this exprssion
   *
   * @return the type of the step
   */
  /*@NotNull*/ override final def getItemType = getStep.getItemType

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   * @param contextItemType
   */
  override def getStaticUType(contextItemType: UType) = getStep.getStaticUType(getStart.getStaticUType(contextItemType))

  /**
   * For an expression that returns an integer or a sequence of integers, get
   * a lower and upper bound on the values of the integers that may be returned, from
   * static analysis. The default implementation returns null, meaning "unknown" or
   * "not applicable". Other implementations return an array of two IntegerValue objects,
   * representing the lower and upper bounds respectively. The values
   * UNBOUNDED_LOWER and UNBOUNDED_UPPER are used by convention to indicate that
   * the value may be arbitrarily large. The values MAX_STRING_LENGTH and MAX_SEQUENCE_LENGTH
   * are used to indicate values limited by the size of a string or the size of a sequence.
   *
   * @return the lower and upper bounds of integer values in the result, or null to indicate
   *         unknown or not applicable.
   */
  override def getIntegerBounds = getStep.getIntegerBounds

  /**
   * Type-check the expression
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    getLhs.typeCheck(visitor, contextInfo)
    // If the first expression is known to be empty, just return empty without checking the step expression.
    // (Checking the step expression can cause spurious errors, such as "the context item is absent")
    if (Literal.isEmptySequence(getStart)) return getStart
    // The first operand must be of type node()*
    val config = visitor.getConfiguration
    val tc = config.getTypeChecker(false)
    val role0 = new RoleDiagnostic(RoleDiagnostic.BINARY_EXPR, "/", 0)
    role0.setErrorCode("XPTY0019")
    setStart(tc.staticTypeCheck(getStart, SequenceType.NODE_SEQUENCE, role0, visitor))
    // Now check the second operand
    val startType = getStart.getItemType
    if (startType eq ErrorType.getInstance) { // implies the start expression will return an empty sequence, so the whole expression is void
      return Literal.makeEmptySequence
    }
    val cit = config.makeContextItemStaticInfo(startType, false)
    cit.setContextSettingExpression(getStart)
    getRhs.typeCheck(visitor, cit)
    // If the expression has the form (a//descendant-or-self::node())/b, try to simplify it to
    // use the descendant axis
    val e2 = simplifyDescendantPath(visitor.getStaticContext)
    if (e2 != null) return e2.typeCheck(visitor, contextInfo)
    if (getStart.isInstanceOf[ContextItemExpression] && getStep.hasSpecialProperty(StaticProperty.ORDERED_NODESET)) return getStep
    if (getStep.isInstanceOf[ContextItemExpression] && getStart.hasSpecialProperty(StaticProperty.ORDERED_NODESET)) return getStart
    if (getStep.isInstanceOf[AxisExpression] && getStep.asInstanceOf[AxisExpression].getAxis == AxisInfo.SELF && config.getTypeHierarchy.isSubType(startType, getStep.getItemType)) return getStart
    this
  }

  def simplifyDescendantPath(env: StaticContext): SlashExpression = {
    var underlyingStep = getStep
    while ( {
      underlyingStep.isInstanceOf[FilterExpression]
    }) {
      if (underlyingStep.asInstanceOf[FilterExpression].isPositional(env.getConfiguration.getTypeHierarchy)) return null
      underlyingStep = underlyingStep.asInstanceOf[FilterExpression].getSelectExpression
    }
    if (!underlyingStep.isInstanceOf[AxisExpression]) return null
    var st = getStart
    // detect .//x as a special case; this will appear as descendant-or-self::node()/x
    if (st.isInstanceOf[AxisExpression]) {
      val stax = st.asInstanceOf[AxisExpression]
      if (stax.getAxis != AxisInfo.DESCENDANT_OR_SELF) return null
      val cie = new ContextItemExpression
      ExpressionTool.copyLocationInfo(this, cie)
      st = ExpressionTool.makePathExpression(cie, stax.copy(new RebindingMap))
      ExpressionTool.copyLocationInfo(this, st)
    }
    if (!st.isInstanceOf[SlashExpression]) return null
    val startPath = st.asInstanceOf[SlashExpression]
    if (!startPath.getStep.isInstanceOf[AxisExpression]) return null
    val mid = startPath.getStep.asInstanceOf[AxisExpression]
    if (mid.getAxis != AxisInfo.DESCENDANT_OR_SELF) return null
    val test = mid.getNodeTest
    if (!(test == null || test.isInstanceOf[AnyNodeTest])) return null
    val underlyingAxis = underlyingStep.asInstanceOf[AxisExpression].getAxis
    if (underlyingAxis == AxisInfo.CHILD || underlyingAxis == AxisInfo.DESCENDANT || underlyingAxis == AxisInfo.DESCENDANT_OR_SELF) {
      val newAxis = if (underlyingAxis == AxisInfo.DESCENDANT_OR_SELF) AxisInfo.DESCENDANT_OR_SELF
      else AxisInfo.DESCENDANT
      var newStep = new AxisExpression(newAxis, underlyingStep.asInstanceOf[AxisExpression].getNodeTest)
      ExpressionTool.copyLocationInfo(this, newStep)
      underlyingStep = getStep
      // Add any filters to the new expression. We know they aren't
      // positional, so the order of the filters doesn't technically matter
      // (XPath section 2.3.4 explicitly allows us to change it.)
      // However, in the interests of predictable execution, hand-optimization, and
      // diagnosable error behaviour, we retain the original order.
      val filters = new util.Stack[Expression]
      while ( {
        underlyingStep.isInstanceOf[FilterExpression]
      }) {
        filters.add(underlyingStep.asInstanceOf[FilterExpression].getFilter)
        underlyingStep = underlyingStep.asInstanceOf[FilterExpression].getSelectExpression
      }
      while ( {
        !filters.isEmpty
      }) {
        newStep = new FilterExpression(newStep, filters.pop)
        ExpressionTool.copyLocationInfo(getStep, newStep)
      }
      //System.err.println("Simplified this:");
      //    display(10);
      //System.err.println("as this:");
      //    new PathExpression(startPath.start, newStep).display(10);
      val newPath = ExpressionTool.makePathExpression(startPath.getStart, newStep)
      if (!newPath.isInstanceOf[SlashExpression]) return null
      ExpressionTool.copyLocationInfo(this, newPath)
      return newPath.asInstanceOf[SlashExpression]
    }
    if (underlyingAxis == AxisInfo.ATTRIBUTE) { // turn the expression a//@b into a/descendant-or-self::*/@b
      val newStep = new AxisExpression(AxisInfo.DESCENDANT_OR_SELF, NodeKindTest.ELEMENT)
      ExpressionTool.copyLocationInfo(this, newStep)
      val e2 = ExpressionTool.makePathExpression(startPath.getStart, newStep)
      val e3 = ExpressionTool.makePathExpression(e2, getStep)
      if (!e3.isInstanceOf[SlashExpression]) return null
      ExpressionTool.copyLocationInfo(this, e3)
      return e3.asInstanceOf[SlashExpression]
    }
    null
  }

  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    val opt = visitor.obtainOptimizer
    getLhs.optimize(visitor, contextItemType)
    val cit = visitor.getConfiguration.makeContextItemStaticInfo(getStart.getItemType, false)
    cit.setContextSettingExpression(getStart)
    getRhs.optimize(visitor, cit)
    if (Literal.isEmptySequence(getStart) || Literal.isEmptySequence(getStep)) return Literal.makeEmptySequence
    if (getStart.isInstanceOf[RootExpression] && th.isSubType(contextItemType.getItemType, NodeKindTest.DOCUMENT)) { // remove unnecessary leading "/" - helps streaming
      return getStep
    }
    // Try to simplify descendant-or-self::node()/child::node
    var e2 = simplifyDescendantPath(visitor.getStaticContext)
    if (e2 != null) return e2.optimize(visitor, contextItemType)
    // Rewrite a/b[filter] as (a/b)[filter] to improve the chance of indexing
    val firstStep = getFirstStep
    if (!(firstStep.isCallOn(classOf[Doc]) || firstStep.isCallOn(classOf[DocumentFn]))) { // Avoid the rewrite if the path starts with doc() for streaming reasons
      val lastStep = getLastStep
      if (lastStep.isInstanceOf[FilterExpression] && !(lastStep.asInstanceOf[FilterExpression]).isPositional(th)) {
        val leading = getLeadingSteps
        val p2 = ExpressionTool.makePathExpression(leading, lastStep.asInstanceOf[FilterExpression].getSelectExpression)
        val f2 = new FilterExpression(p2, lastStep.asInstanceOf[FilterExpression].getFilter)
        ExpressionTool.copyLocationInfo(this, f2)
        return f2.optimize(visitor, contextItemType)
      }
    }
    if (!visitor.isOptimizeForStreaming) {
      val k = opt.convertPathExpressionToKey(this, visitor)
      if (k != null) return k.typeCheck(visitor, contextItemType).optimize(visitor, contextItemType)
    }
    // Replace //x/y by descendant::y[parent::x] to eliminate the need for sorting
    // into document order, and to make the expression streamable
    e2 = tryToMakeSorted(visitor, contextItemType)
    if (e2 != null) return e2
    // Replace $x/child::abcd by a SimpleStepExpression, to avoid the need for creating
    // a new dynamic context at run-time.
    if (getStep.isInstanceOf[AxisExpression]) if (!Cardinality.allowsMany(getStart.getCardinality)) {
      val sse = new SimpleStepExpression(getStart, getStep)
      ExpressionTool.copyLocationInfo(this, sse)
      sse.setParentExpression(getParentExpression)
      return sse
    }
    else contextFree = true
    if (getStart.isInstanceOf[RootExpression] && getStep.isCallOn(classOf[KeyFn])) { // This happens after optimizations to convert filter expressions to key() calls
      val keyCall = getStep.asInstanceOf[SystemFunctionCall]
      if (keyCall.getArity == 3 && keyCall.getArg(2).isInstanceOf[ContextItemExpression]) {
        keyCall.setArg(2, new RootExpression)
        keyCall.setParentExpression(getParentExpression)
        ExpressionTool.resetStaticProperties(keyCall)
        return keyCall
      }
    }
    val k = promoteFocusIndependentSubexpressions(visitor, contextItemType)
    if (k ne this) return k
    if (visitor.isOptimizeForStreaming) { // rewrite a/copy-of(.) as copy-of(a)
      val rawStep = ExpressionTool.unfilteredExpression(getStep, true)
      if (rawStep.isInstanceOf[CopyOf] && rawStep.asInstanceOf[CopyOf].getSelect.isInstanceOf[ContextItemExpression]) {
        rawStep.asInstanceOf[CopyOf].setSelect(getStart)
        rawStep.resetLocalStaticProperties()
        getStep.resetLocalStaticProperties()
        return getStep
      }
    }
    this
  }

  /**
   * Test whether a path expression is an absolute path - that is, a path whose first step selects a
   * document node; if not, see if it can be converted to an absolute path. This is possible in cases where
   * the path expression has the form a/b/c and it is known that the context item is a document node; in this
   * case it is safe to change the path expression to /a/b/c
   *
   * @return the path expression if it is absolute; the converted path expression if it can be made absolute;
   *         or null if neither condition applies.
   */
  def tryToMakeAbsolute: SlashExpression = {
    val first = getFirstStep
    if (first.getItemType.getPrimitiveType == Type.DOCUMENT) return this
    if (first.isInstanceOf[AxisExpression]) { // This second test allows keys to be built. See XMark q9.
      val contextItemType = first.asInstanceOf[AxisExpression].getContextItemType
      if (contextItemType != null && contextItemType.getPrimitiveType == Type.DOCUMENT) {
        val root = new RootExpression
        ExpressionTool.copyLocationInfo(this, root)
        val path = ExpressionTool.makePathExpression(root, this.copy(new RebindingMap))
        if (!path.isInstanceOf[SlashExpression]) return null
        ExpressionTool.copyLocationInfo(this, path)
        return path.asInstanceOf[SlashExpression]
      }
    }
    if (first.isInstanceOf[DocumentSorter] && first.asInstanceOf[DocumentSorter].getBaseExpression.isInstanceOf[SlashExpression]) { // see test case filter-001 in xqts-extra
      val se = first.asInstanceOf[DocumentSorter].getBaseExpression.asInstanceOf[SlashExpression]
      val se2 = se.tryToMakeAbsolute
      if (se2 != null) if (se2 eq se) return this
      else {
        val rest = getRemainingSteps
        val ds = new DocumentSorter(se2)
        return new SlashExpression(ds, rest)
      }
    }
    null
  }

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   *
   * @return the cost estimate
   */
  override def getCost = {
    val factor = if (Cardinality.allowsMany(getLhsExpression.getCardinality)) 5
    else 1
    val lh = getLhsExpression.getCost + 1
    val rh = getRhsExpression.getCost
    val product = lh + factor * rh
    Math.max(product, MAX_COST)
  }

  @throws[XPathException]
  def tryToMakeSorted(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo): Expression = {
    val config = visitor.getConfiguration
    val th = config.getTypeHierarchy
    val opt = visitor.obtainOptimizer
    val s1 = ExpressionTool.unfilteredExpression(getStart, false)
    if (!(s1.isInstanceOf[AxisExpression] && (s1.asInstanceOf[AxisExpression]).getAxis == AxisInfo.DESCENDANT)) return null
    val s2 = ExpressionTool.unfilteredExpression(getStep, false)
    if (!(s2.isInstanceOf[AxisExpression] && (s2.asInstanceOf[AxisExpression]).getAxis == AxisInfo.CHILD)) return null
    // We're in business; construct the new expression
    val x = getStart.copy(new RebindingMap)
    val ax = ExpressionTool.unfilteredExpression(x, false).asInstanceOf[AxisExpression]
    ax.setAxis(AxisInfo.PARENT)
    val y = getStep.copy(new RebindingMap)
    val ay = ExpressionTool.unfilteredExpression(y, false).asInstanceOf[AxisExpression]
    ay.setAxis(AxisInfo.DESCENDANT)
    var k = new FilterExpression(y, x)
    // If we're not starting at the root, ensure we go down at least one level
    if (!th.isSubType(contextItemType.getItemType, NodeKindTest.DOCUMENT)) {
      k = new SlashExpression(new AxisExpression(AxisInfo.CHILD, NodeKindTest.ELEMENT), k)
      ExpressionTool.copyLocationInfo(this, k)
      opt.trace("Rewrote descendant::X/child::Y as child::*/descendant::Y[parent::X]", k)
    }
    else {
      ExpressionTool.copyLocationInfo(this, k)
      opt.trace("Rewrote descendant::X/child::Y as descendant::Y[parent::X]", k)
    }
    k
  }

  /**
   * If any subexpressions within the step are not dependent on the focus,
   * and if they are not "creative" expressions (expressions that can create new nodes), then
   * promote them: this causes them to be evaluated once, outside the path expression
   *
   * @param visitor         the expression visitor
   * @param contextItemType the type of the context item for evaluating the start expression
   * @return the rewritten expression, or the original expression if no rewrite was possible
   * @throws net.sf.saxon.trans.XPathException
   * if a static error is detected
   */
  @throws[XPathException]
  protected def promoteFocusIndependentSubexpressions(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo) = { //        Optimizer opt = getConfiguration().obtainOptimizer();
    //
    //        PromotionOffer offer = new PromotionOffer(opt);
    //        offer.action = PromotionOffer.FOCUS_INDEPENDENT;
    //        offer.promoteDocumentDependent = (getStart().getSpecialProperties() & StaticProperty.CONTEXT_DOCUMENT_NODESET) != 0;
    //        offer.containingExpression = this;
    //        setStep(doPromotion(getStep(), offer));
    //        ExpressionTool.resetStaticProperties(this);
    //        if (offer.containingExpression != this) {
    //            offer.containingExpression =
    //                    offer.containingExpression.typeCheck(visitor, contextItemType).optimize(visitor, contextItemType);
    //            return offer.containingExpression;
    //        }
    this
  }

  /**
   * Replace this expression by a simpler expression that delivers the results without regard
   * to order.
   *
   * @param retainAllNodes set to true if the result must contain exactly the same nodes as the
   *                       original; set to false if the result can eliminate (or introduce) duplicates.
   * @param forStreaming   set to true if optimizing for streaming
   */
  @throws[XPathException]
  override def unordered(retainAllNodes: Boolean, forStreaming: Boolean) = {
    setStart(getStart.unordered(retainAllNodes, forStreaming))
    setStep(getStep.unordered(retainAllNodes, forStreaming))
    this
  }

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   *
   * @param pathMap the PathMap to which the expression should be added
   * @param pathMapNodeSet
   * @return the pathMapNode representing the focus established by this expression, in the case where this
   *         expression is the first operand of a path expression or filter expression
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = {
    val target = getStart.addToPathMap(pathMap, pathMapNodeSet)
    getStep.addToPathMap(pathMap, target)
  }

  /**
   * An implementation of Expression must provide at least one of the methods evaluateItem(), iterate(), or process().
   * This method indicates which of these methods is provided directly. The other methods will always be available
   * indirectly, using an implementation that relies on one of the other methods.
   *
   * @return the implementation method, for example { @link #ITERATE_METHOD} or { @link #EVALUATE_METHOD} or
   *                                                        { @link #PROCESS_METHOD}
   */
  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @return the copy of the original expression
   * @param rebindings
   */
  override def copy(rebindings: RebindingMap) = {
    val exp = ExpressionTool.makePathExpression(getStart.copy(rebindings), getStep.copy(rebindings))
    ExpressionTool.copyLocationInfo(this, exp)
    exp
  }

  /**
   * Get the static properties of this expression (other than its type). The result is
   * bit-signficant. These properties are used for optimizations. In general, if
   * property bit is set, it is true, but if it is unset, the value is unknown.
   */
  override def computeSpecialProperties: Int = {
    var startProperties = getStart.getSpecialProperties
    var stepProperties = getStep.getSpecialProperties
    if ((stepProperties & StaticProperty.ALL_NODES_NEWLY_CREATED) ne 0) { // Deem copies/snapshots to be in document order
      return StaticProperty.ORDERED_NODESET | StaticProperty.PEER_NODESET | StaticProperty.NO_NODES_NEWLY_CREATED
    }
    //        System.err.println("====" + toShortString() + "====");
    //        System.err.println("START: " + StaticProperty.display(startProperties));
    //        System.err.println("STEP: " + StaticProperty.display(stepProperties));
    var p = 0
    if (!Cardinality.allowsMany(getStart.getCardinality)) startProperties |= StaticProperty.ORDERED_NODESET | StaticProperty.PEER_NODESET | StaticProperty.SINGLE_DOCUMENT_NODESET
    if (!Cardinality.allowsMany(getStep.getCardinality)) stepProperties |= StaticProperty.ORDERED_NODESET | StaticProperty.PEER_NODESET | StaticProperty.SINGLE_DOCUMENT_NODESET
    if ((startProperties & stepProperties & StaticProperty.CONTEXT_DOCUMENT_NODESET) ne 0) p |= StaticProperty.CONTEXT_DOCUMENT_NODESET
    if (((startProperties & StaticProperty.SINGLE_DOCUMENT_NODESET) ne 0) && ((stepProperties & StaticProperty.CONTEXT_DOCUMENT_NODESET) ne 0)) p |= StaticProperty.SINGLE_DOCUMENT_NODESET
    if ((startProperties & stepProperties & StaticProperty.PEER_NODESET) ne 0) p |= StaticProperty.PEER_NODESET
    if ((startProperties & stepProperties & StaticProperty.SUBTREE_NODESET) ne 0) p |= StaticProperty.SUBTREE_NODESET
    if (testNaturallySorted(startProperties, stepProperties)) p |= StaticProperty.ORDERED_NODESET
    if (testNaturallyReverseSorted) p |= StaticProperty.REVERSE_DOCUMENT_ORDER
    if ((startProperties & stepProperties & StaticProperty.NO_NODES_NEWLY_CREATED) ne 0) p |= StaticProperty.NO_NODES_NEWLY_CREATED
    p
  }

  /**
   * Determine if we can guarantee that the nodes are delivered in document order.
   * This is true if the start nodes are sorted peer nodes
   * and the step is based on an Axis within the subtree rooted at each node.
   * It is also true if the start is a singleton node and the axis is sorted.
   *
   * @param startProperties the properties of the left-hand expression
   * @param stepProperties  the properties of the right-hand expression
   * @return true if the natural nested-loop evaluation strategy for the expression
   *         is known to deliver results with no duplicates and in document order, that is,
   *         if no additional sort is required
   */
  private def testNaturallySorted(startProperties: Int, stepProperties: Int): Boolean = { // System.err.println("**** Testing pathExpression.isNaturallySorted()");
    // display(20);
    // System.err.println("Start is ordered node-set? " + start.isOrderedNodeSet());
    // System.err.println("Start is naturally sorted? " + start.isNaturallySorted());
    // System.err.println("Start is singleton? " + start.isSingleton());
    if ((stepProperties & StaticProperty.ORDERED_NODESET) eq 0) return false
    if (Cardinality.allowsMany(getStart.getCardinality)) if ((startProperties & StaticProperty.ORDERED_NODESET) eq 0) return false
    else { //if ((stepProperties & StaticProperty.ORDERED_NODESET) != 0) {
      return true
      //}
    }
    // We know now that both the start and the step are sorted. But this does
    // not necessarily mean that the combination is sorted.
    // The result is sorted if the start is sorted and the step selects attributes
    // or namespaces
    if ((stepProperties & StaticProperty.ATTRIBUTE_NS_NODESET) ne 0) return true
    // The result is sorted if the step is creative (e.g. a call to copy-of())
    if ((stepProperties & StaticProperty.ALL_NODES_NEWLY_CREATED) ne 0) return true
    // The result is sorted if the start selects "peer nodes" (that is, a node-set in which
    // no node is an ancestor of another) and the step selects within the subtree rooted
    // at the context node
    ((startProperties & StaticProperty.PEER_NODESET) ne 0) && ((stepProperties & StaticProperty.SUBTREE_NODESET) ne 0)
  }

  /**
   * Determine if the path expression naturally returns nodes in reverse document order
   *
   * @return true if the natural nested-loop evaluation strategy returns nodes in reverse
   *         document order
   */
  private def testNaturallyReverseSorted: Boolean = { // Some examples of path expressions that are naturally reverse sorted:
    //     ancestor::*/@x
    //     ../preceding-sibling::x
    //     $x[1]/preceding-sibling::node()
    // This information is used to do a simple reversal of the nodes
    // instead of a full sort, which is significantly cheaper, especially
    // when using tree models (such as DOM and JDOM) in which comparing
    // nodes in document order is an expensive operation.
    if (!Cardinality.allowsMany(getStart.getCardinality) && getStep.isInstanceOf[AxisExpression]) return !AxisInfo.isForwards((getStep.asInstanceOf[AxisExpression]).getAxis)
    !Cardinality.allowsMany(getStep.getCardinality) && getStart.isInstanceOf[AxisExpression] && !AxisInfo.isForwards((getStart.asInstanceOf[AxisExpression]).getAxis)
  }

  /**
   * Determine the static cardinality of the expression
   */
  override def computeCardinality = {
    val c1 = getStart.getCardinality
    val c2 = getStep.getCardinality
    Cardinality.multiply(c1, c2)
  }

  /**
   * Convert this expression to an equivalent XSLT pattern
   *
   * @param config the Saxon configuration
   * @return the equivalent pattern
   * @throws net.sf.saxon.trans.XPathException
   * if conversion is not possible
   */
  @throws[XPathException]
  override def toPattern(config: Configuration): Pattern = {
    val head = getLeadingSteps
    val tail = getLastStep
    if (head.isInstanceOf[ItemChecker]) { // No need to typecheck the context item
      val checker = head.asInstanceOf[ItemChecker]
      if (checker.getBaseExpression.isInstanceOf[ContextItemExpression]) return tail.toPattern(config)
    }
    val tailPattern = tail.toPattern(config)
    if (tailPattern.isInstanceOf[NodeTestPattern]) if (tailPattern.getItemType.isInstanceOf[ErrorType]) return tailPattern
    else if (tailPattern.isInstanceOf[GeneralNodePattern]) return new GeneralNodePattern(this, tailPattern.getItemType.asInstanceOf[NodeTest])
    var axis = AxisInfo.PARENT
    var headPattern = null
    if (head.isInstanceOf[SlashExpression]) {
      val start = head.asInstanceOf[SlashExpression]
      if (start.getActionExpression.isInstanceOf[AxisExpression]) {
        val mid = start.getActionExpression.asInstanceOf[AxisExpression]
        if (mid.getAxis == AxisInfo.DESCENDANT_OR_SELF && (mid.getNodeTest == null || mid.getNodeTest.isInstanceOf[AnyNodeTest])) {
          axis = AxisInfo.ANCESTOR
          headPattern = start.getSelectExpression.toPattern(config)
        }
      }
    }
    if (headPattern == null) {
      axis = PatternMaker.getAxisForPathStep(tail)
      headPattern = head.toPattern(config)
    }
    new AncestorQualifiedPattern(tailPattern, headPattern, axis)
  }

  /**
   * A SlashExpression is context free if the right-hand argument is an AxisExpression.
   * This allows evaluation without creating a new XPathContext or FocusTrackingIterator;
   * the expression can be evaluated as a simple flat-mapping function from nodes to nodes.
   *
   * @return true if the expression has been assessed as context-free, that is, if the
   *         right-hand operand is an AxisExpression
   */
  def isContextFree = contextFree

  /**
   * Mark this expression as being context free (or not). This is done during reloading from a SEF file.
   *
   * @param free true if the expression has been assessed as context-free, that is, if the
   *             right-hand operand is an AxisExpression
   */
  def setContextFree(free: Boolean) = this.contextFree = free

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any): Boolean = {
    if (!other.isInstanceOf[SlashExpression]) return false
    val p = other.asInstanceOf[SlashExpression]
    getStart.isEqual(p.getStart) && getStep.isEqual(p.getStep)
  }

  /**
   * get HashCode for comparing two expressions
   */
  override def computeHashCode = "SlashExpression".hashCode + getStart.hashCode + getStep.hashCode

  /**
   * Iterate the path-expression in a given context
   *
   * @param context the evaluation context
   */
  @throws[XPathException]
  override def iterate(context: XPathContext): SequenceIterator = { // This class delivers the result of the path expression in unsorted order,
    // without removal of duplicates. If sorting and deduplication are needed,
    // this is achieved by wrapping the path expression in a DocumentSorter
    if (contextFree) return new MappingIterator(getStart.iterate(context), (item: Item) => getRhsExpression.asInstanceOf[AxisExpression].iterate(item.asInstanceOf[NodeInfo]))
    val context2 = context.newMinorContext
    context2.trackFocus(getStart.iterate(context))
    new ContextMappingIterator((c1: XPathContext) => getStep.iterate(c1), context2)
  }

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("slash", this)
    if (this.isInstanceOf[SimpleStepExpression]) destination.emitAttribute("simple", "1")
    else if (isContextFree) destination.emitAttribute("simple", "2")
    getStart.`export`(destination)
    getStep.`export`(destination)
    destination.endElement
  }

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   *
   * @return a representation of the expression as a string
   */
  override def toString = ExpressionTool.parenthesize(getStart) + "/" + ExpressionTool.parenthesize(getStep)

  override def toShortString = ExpressionTool.parenthesizeShort(getStart) + "/" + ExpressionTool.parenthesizeShort(getStep)

  /**
   * Get the first step in this expression. A path expression A/B/C is represented as (A/B)/C, but
   * the first step is A
   *
   * @return the first step in the expression, after expanding any nested path expressions
   */
  def getFirstStep = if (getStart.isInstanceOf[SlashExpression]) getStart.asInstanceOf[SlashExpression].getFirstStep
  else getStart

  /**
   * Get all steps after the first.
   * This is complicated by the fact that A/B/C is represented as ((A/B)/C; we are required
   * to return B/C
   *
   * @return a path expression containing all steps in this path expression other than the first,
   *         after expanding any nested path expressions
   */
  def getRemainingSteps = if (getStart.isInstanceOf[SlashExpression]) {
    val list = new util.ArrayList[Expression](8)
    gatherSteps(list)
    val rem = rebuildSteps(list.subList(1, list.size))
    ExpressionTool.copyLocationInfo(this, rem)
    rem
  }
  else getStep

  /**
   * Flatten the path expression into a flat list of steps
   *
   * @param list a list of expressions making up this path expression
   */
  private def gatherSteps(list: util.List[Expression]) = {
    if (getStart.isInstanceOf[SlashExpression]) getStart.asInstanceOf[SlashExpression].gatherSteps(list)
    else list.add(getStart)
    if (getStep.isInstanceOf[SlashExpression]) getStep.asInstanceOf[SlashExpression].gatherSteps(list)
    else list.add(getStep)
  }

  /**
   * Build a tree from a flat list of steps
   *
   * @param list the list of steps
   * @return an Expression, generally a right-heavy binary tree
   */
  private def rebuildSteps(list: util.List[Expression]) = if (list.size == 1) list.get(0).copy(new RebindingMap)
  else new SlashExpression(list.get(0).copy(new RebindingMap), rebuildSteps(list.subList(1, list.size)))

  /**
   * Get the last step of the path expression
   *
   * @return the last step in the expression, after expanding any nested path expressions
   */
  def getLastStep = if (getStep.isInstanceOf[SlashExpression]) getStep.asInstanceOf[SlashExpression].getLastStep
  else getStep

  /**
   * Get a path expression consisting of all steps except the last
   *
   * @return a path expression containing all steps in this path expression other than the last,
   *         after expanding any nested path expressions
   */
  def getLeadingSteps = if (getStep.isInstanceOf[SlashExpression]) {
    val list = new util.ArrayList[Expression](8)
    gatherSteps(list)
    val rem = rebuildSteps(list.subList(0, list.size - 1))
    ExpressionTool.copyLocationInfo(this, rem)
    rem
  }
  else getStart

  /**
   * Test whether a path expression is an absolute path - that is, a path whose first step selects a
   * document node
   *
   * @return true if the first step in this path expression selects a document node
   */
  def isAbsolute = getFirstStep.getItemType.getPrimitiveType == Type.DOCUMENT

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "ForEach" // sic
}