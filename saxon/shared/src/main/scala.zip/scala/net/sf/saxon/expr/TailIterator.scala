////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.om.EnumSetTool
import net.sf.saxon.om.GroundedValue
import net.sf.saxon.om.Item
import net.sf.saxon.om.SequenceIterator
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.ArrayIterator
import net.sf.saxon.tree.iter.EmptyIterator
import net.sf.saxon.tree.iter.LookaheadIterator
import java.util

/**
 * TailIterator iterates over a base sequence starting at an element other than the first.
 * The base sequence is represented by an iterator which is consumed in the process
 */
object TailIterator {
  /**
   * Static factory method. Creates a TailIterator, unless the base Iterator is an
   * ArrayIterator, in which case it optimizes by creating a new ArrayIterator directly over the
   * underlying array. This optimization is important when doing recursion over a node-set using
   * repeated calls of <code>$nodes[position()&gt;1]</code>
   *
   * @param base  An iteration of the items to be filtered
   * @param start The position of the first item to be included (base 1). If &lt;= 1, the whole of the
   *              base sequence is returned
   * @return an iterator over the items in the sequence from the start item to the end of the sequence.
   *         The returned iterator will not necessarily be an instance of this class.
   * @throws net.sf.saxon.trans.XPathException
   * if a dynamic error occurs
   */
    @throws[XPathException]
    def make[T <: Item](base: SequenceIterator, start: Int): SequenceIterator = if (start <= 1) base
    else if (base.isInstanceOf[ArrayIterator[_ <: Item]]) base.asInstanceOf[ArrayIterator[_ <: Item]].makeSliceIterator(start, Integer.MAX_VALUE)
    else if (base.getProperties.contains(SequenceIterator.Property.GROUNDED)) {
      val value = base.materialize
      if (start > value.getLength) EmptyIterator.emptyIterator
      else new ValueTailIterator(value, start - 1)
    }
    else { // discard the first n-1 items from the underlying iterator
      for (i <- 0 until start - 1) {
        val b = base.next
        if (b == null) return EmptyIterator.emptyIterator
      }
      new TailIterator(base, start)
    }
}

class TailIterator private(var base: SequenceIterator, var start: Int)

/**
 * Private constructor: external callers should use the public factory method.
 * Create a TailIterator, an iterator that starts at position N in a sequence and iterates
 * to the end of the sequence
 *
 * @param base  the base sequence of which we want to select the tail. Unusually, this iterator
 *              should be supplied pre-positioned so that the next call on next() returns the first item to
 *              be returned by the TailIterator
 * @param start the index of the first required item in the sequence, starting from one. To
 *              include all items in the sequence except the first, set start = 2. This value is used only
 *              when cloning the iterator or when calculating the value of last().
 */
  extends SequenceIterator with LastPositionFinder with LookaheadIterator {
  @throws[XPathException]
  override def next = base.next

  override def hasNext = base.asInstanceOf[LookaheadIterator].hasNext

  @throws[XPathException]
  override def getLength = {
    val bl = base.asInstanceOf[LastPositionFinder].getLength - start + 1
    if (bl > 0) bl
    else 0
  }

  override def close() = base.close()

  /**
   * Get properties of this iterator, as a bit-significant integer.
   *
   * @return the properties of this iterator. This will be some combination of
   *         properties such as { @link net.sf.saxon.om.SequenceIterator.Property#GROUNDED}, { @link net.sf.saxon.om.SequenceIterator.Property#LAST_POSITION_FINDER},
   *                                    and { @link net.sf.saxon.om.SequenceIterator.Property#LOOKAHEAD}. It is always
   *                                    acceptable to return the value zero, indicating that there are no known special properties.
   *                                    It is acceptable for the properties of the iterator to change depending on its state.
   */
  override def getProperties = EnumSetTool.intersect(base.getProperties, util.EnumSet.of(Property.LAST_POSITION_FINDER, Property.LOOKAHEAD))
}