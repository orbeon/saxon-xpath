////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.NextMatch
import net.sf.saxon.model.Type
import net.sf.saxon.om.AttributeInfo
import net.sf.saxon.om.NodeInfo
import net.sf.saxon.om.NodeName
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.Whitespace

/**
 * An xsl:next-match element in the stylesheet
 */
class XSLNextMatch extends StyleElement {
  private var useTailRecursion = false

  /**
   * Determine whether this node is an instruction.
   *
   * @return true - it is an instruction
   */
  override def isInstruction = true

  /**
   * Determine whether this type of element is allowed to contain an xsl:fallback
   * instruction
   */
  override def mayContainFallback = true

  override def prepareAttributes() = {
    import scala.collection.JavaConversions._
    for (att <- attributes) {
      val attName = att.getNodeName
      checkUnknownAttribute(attName)
    }
  }

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    import scala.collection.JavaConversions._
    for (child <- children) {
      if (child.isInstanceOf[XSLWithParam] || child.isInstanceOf[XSLFallback]) {
        // OK;
      }
      else if (child.getNodeKind == Type.TEXT) { // with xml:space=preserve, white space nodes may still be there
        if (!Whitespace.isWhite(child.getStringValueCS)) compileError("No character data is allowed within xsl:next-match", "XTSE0010")
      }
      else compileError("Child element " + child.getDisplayName + " is not allowed as a child of xsl:next-match", "XTSE0010")
    }
  }

  /**
   * Mark tail-recursive calls on templates and functions.
   * For most instructions, this does nothing.
   */
  override protected def markTailCalls = {
    useTailRecursion = true
    true
  }

  /*@NotNull*/ @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val inst = new NextMatch(useTailRecursion)
    inst.setLocation(allocateLocation)
    inst.setActualParams(getWithParamInstructions(inst, exec, decl, false))
    inst.setTunnelParams(getWithParamInstructions(inst, exec, decl, true))
    inst
  }
}