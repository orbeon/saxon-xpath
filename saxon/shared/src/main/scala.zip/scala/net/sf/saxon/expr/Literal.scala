////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.event.Outputter
import net.sf.saxon.event.ReceiverOption
import net.sf.saxon.expr.parser._
import net.sf.saxon.functions.hof.FunctionLiteral
import net.sf.saxon.ma.arrays.ArrayItem
import net.sf.saxon.ma.map.KeyValuePair
import net.sf.saxon.ma.map.MapItem
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.pattern.NodeTestPattern
import net.sf.saxon.pattern.Pattern
import net.sf.saxon.query.QueryResult
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value._
import javax.xml.transform.stream.StreamResult
import java.io.StringWriter
import java.util
import java.util.Properties

/**
 * A Literal is an expression whose value is constant: it is a class that implements the {@link Expression}
 * interface as a wrapper around a {@link GroundedValue}. This may derive from an actual literal in an XPath expression
 * or query, or it may be the result of evaluating a constant subexpression such as true() or xs:date('2007-01-16')
 */
object Literal {
  /**
   * Create a Literal containing a sequence of strings
   *
   * @param strings the strings to be wrapped
   * @return a Literal of the string sequence
   */
    def makeStringsLiteral(strings: util.List[String]) = {
      val values = new util.ArrayList[StringValue]
      import scala.collection.JavaConversions._
      for (s <- strings) {
        values.add(new StringValue(s))
      }
      val gv = SequenceExtent.makeSequenceExtent(values)
      makeLiteral(gv)
    }

  @throws[XPathException]
  def exportValue(value: Sequence, out: ExpressionPresenter) = if (value.head == null) {
    out.startElement("empty")
    out.endElement
  }
  else if (value.isInstanceOf[AtomicValue]) exportAtomicValue(value.asInstanceOf[AtomicValue], out)
  else if (value.isInstanceOf[IntegerRange]) {
    out.startElement("range")
    out.emitAttribute("from", "" + value.asInstanceOf[IntegerRange].getStart)
    out.emitAttribute("to", "" + value.asInstanceOf[IntegerRange].getEnd)
    out.endElement
  }
  else if (value.isInstanceOf[NodeInfo]) {
    out.startElement("node")
    val nodeKind = value.asInstanceOf[NodeInfo].getNodeKind
    out.emitAttribute("kind", nodeKind + "")
    if (out.getOptions.asInstanceOf[ExpressionPresenter.ExportOptions].explaining) {
      val name = value.asInstanceOf[NodeInfo].getDisplayName
      if (!name.isEmpty) out.emitAttribute("name", name)
    }
    else nodeKind match {
      case Type.DOCUMENT =>
      case Type.ELEMENT =>
        val sw = new StringWriter
        val props = new Properties
        props.setProperty("method", "xml")
        props.setProperty("indent", "no")
        props.setProperty("omit-xml-declaration", "yes")
        QueryResult.serialize(value.asInstanceOf[NodeInfo], new StreamResult(sw), props)
        out.emitAttribute("content", sw.toString)
        out.emitAttribute("baseUri", value.asInstanceOf[NodeInfo].getBaseURI)
      case Type.TEXT =>
      case Type.COMMENT =>
        out.emitAttribute("content", value.asInstanceOf[NodeInfo].getStringValue)
      case Type.ATTRIBUTE =>
      case Type.NAMESPACE =>
      case Type.PROCESSING_INSTRUCTION =>
        val name = NameOfNode.makeName(value.asInstanceOf[NodeInfo]).getStructuredQName
        if (!name.getLocalPart.isEmpty) out.emitAttribute("localName", name.getLocalPart)
        if (!name.getPrefix.isEmpty) out.emitAttribute("prefix", name.getPrefix)
        if (!name.getURI.isEmpty) out.emitAttribute("ns", name.getURI)
        out.emitAttribute("content", value.asInstanceOf[NodeInfo].getStringValue)
      case _ =>
        assert(false)
    }
    out.endElement
  }
  else if (value.isInstanceOf[MapItem]) {
    out.startElement("map")
    out.emitAttribute("size", "" + value.asInstanceOf[MapItem].size)
    import scala.collection.JavaConversions._
    for (kvp <- value.asInstanceOf[MapItem].keyValuePairs) {
      exportAtomicValue(kvp.key, out)
      exportValue(kvp.value, out)
    }
    out.endElement
  }
  else if (value.isInstanceOf[Function]) value.asInstanceOf[Function].`export`(out)
  else if (value.isInstanceOf[ExternalObject[_]]) if (out.getOptions.asInstanceOf[ExpressionPresenter.ExportOptions].explaining) {
    out.startElement("externalObject")
    out.emitAttribute("class", value.asInstanceOf[ExternalObject[_]].getObject.getClass.getName)
    out.endElement
  }
  else throw new XPathException("Cannot export a stylesheet containing literal values bound to external Java objects")
  else {
    out.startElement("literal")
    if (value.isInstanceOf[GroundedValue]) out.emitAttribute("count", value.asInstanceOf[GroundedValue].getLength + "")
    value.iterate.forEachOrFail((it: Item) => exportValue(it, out))
    out.endElement
  }

  @throws[XPathException]
  def exportAtomicValue(value: AtomicValue, out: ExpressionPresenter) = {
    if ("JS" == out.getOptions.asInstanceOf[ExpressionPresenter.ExportOptions].target) value.checkValidInJavascript()
    val `type` = value.getItemType
    val `val` = value.getStringValue
    if (`type` == BuiltInAtomicType.STRING) {
      out.startElement("str")
      out.emitAttribute("val", `val`)
      out.endElement
    }
    else if (`type` == BuiltInAtomicType.INTEGER) {
      out.startElement("int")
      out.emitAttribute("val", `val`)
      out.endElement
    }
    else if (`type` == BuiltInAtomicType.DECIMAL) {
      out.startElement("dec")
      out.emitAttribute("val", `val`)
      out.endElement
    }
    else if (`type` == BuiltInAtomicType.DOUBLE) {
      out.startElement("dbl")
      out.emitAttribute("val", `val`)
      out.endElement
    }
    else if (`type` == BuiltInAtomicType.BOOLEAN) {
      out.startElement(if (value.asInstanceOf[BooleanValue].effectiveBooleanValue) "true"
      else "false")
      out.endElement
    }
    else if (value.isInstanceOf[QualifiedNameValue]) {
      out.startElement("qName")
      out.emitAttribute("pre", value.asInstanceOf[QualifiedNameValue].getPrefix)
      out.emitAttribute("uri", value.asInstanceOf[QualifiedNameValue].getNamespaceURI)
      out.emitAttribute("loc", value.asInstanceOf[QualifiedNameValue].getLocalName)
      if (!(`type` == BuiltInAtomicType.QNAME)) out.emitAttribute("type", `type`.getEQName)
      out.endElement
    }
    else {
      out.startElement("atomic")
      out.emitAttribute("val", `val`)
      out.emitAttribute("type", AlphaCode.fromItemType(`type`))
      out.endElement
    }
  }

  /**
   * Test whether the literal wraps an atomic value. (Note, if this method returns false,
   * this still leaves the possibility that the literal wraps a sequence that happens to contain
   * a single atomic value).
   *
   * @param exp an expression
   * @return true if the expression is a literal and the literal wraps an AtomicValue
   */
  def isAtomic(exp: Expression) = exp.isInstanceOf[Literal] && exp.asInstanceOf[Literal].getValue.isInstanceOf[AtomicValue]

  /**
   * Test whether the literal explicitly wraps an empty sequence. (Note, if this method returns false,
   * this still leaves the possibility that the literal wraps a sequence that happens to be empty).
   *
   * @param exp an expression
   * @return true if the expression is a literal and the value of the literal is an empty sequence
   */
  def isEmptySequence(exp: Expression) = exp.isInstanceOf[Literal] && exp.asInstanceOf[Literal].getValue.getLength == 0

  /**
   * Test if a literal represents the boolean value true
   *
   * @param exp   an expression
   * @param value true or false
   * @return true if the expression is a literal and the literal represents the boolean value given in the
   *         second argument
   */
  def isConstantBoolean(exp: Expression, value: Boolean): Boolean = {
    if (exp.isInstanceOf[Literal]) {
      val b = exp.asInstanceOf[Literal].getValue
      return b.isInstanceOf[BooleanValue] && b.asInstanceOf[BooleanValue].getBooleanValue == value
    }
    false
  }

  /**
   * Test if a literal has the effective boolean value true (or false)
   *
   * @param exp   an expression
   * @param value true or false
   * @return true if the expression is a literal and the literal represents the boolean value given in the
   *         second argument
   */
  def hasEffectiveBooleanValue(exp: Expression, value: Boolean): Boolean = {
    if (exp.isInstanceOf[Literal]) try return value == exp.asInstanceOf[Literal].getValue.effectiveBooleanValue
    catch {
      case err: XPathException =>
        return false
    }
    false
  }

  /**
   * Test if a literal represents the integer value 1
   *
   * @param exp an expression
   * @return true if the expression is a literal and the literal represents the integer value 1
   */
  def isConstantOne(exp: Expression): Boolean = {
    if (exp.isInstanceOf[Literal]) {
      val v = exp.asInstanceOf[Literal].getValue
      return v.isInstanceOf[Int64Value] && v.asInstanceOf[Int64Value].longValue == 1
    }
    false
  }

  /**
   * Factory method to make an empty-sequence literal
   *
   * @return a literal whose value is the empty sequence
   */
  def makeEmptySequence = new Literal(EmptySequence.getInstance)

  /**
   * Factory method to create a literal as a wrapper around a Value (factory method)
   *
   * @param value the value of this literal
   * @return the Literal
   */
  def makeLiteral[T <: Item](value: GroundedValue) = {
    value = value.reduce
    if (value.isInstanceOf[StringValue]) new StringLiteral(value.asInstanceOf[StringValue])
    else if (value.isInstanceOf[Function] && !(value.isInstanceOf[MapItem] || value.isInstanceOf[ArrayItem])) new FunctionLiteral(value.asInstanceOf[Function])
    else new Literal(value)
  }

  /**
   * Make a literal, taking the retained static context and location information from another
   * expression which is being simplified/optimized
   *
   * @param value  the literal value
   * @param origin the expression whose context and location information is to be retained
   * @return the Literal
   */
  def makeLiteral(value: GroundedValue, origin: Expression) = {
    val lit = makeLiteral(value)
    //lit.setRetainedStaticContextLocally(origin.getLocalRetainedStaticContext());
    ExpressionTool.copyLocationInfo(origin, lit)
    lit
  }
}

class Literal protected(val value: GroundedValue)

/**
 * Create a literal as a wrapper around a Value
 *
 * @param value the value of this literal
 */
  extends Expression {
  this.value = value.reduce
  private var value = null

  /**
   * Get the value represented by this Literal
   *
   * @return the constant value
   */
  def getValue = value

  /**
   * TypeCheck an expression
   *
   * @return for a Value, this always returns the value unchanged
   */
  /*@NotNull*/ @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = this

  /**
   * Optimize an expression
   *
   * @return for a Value, this always returns the value unchanged
   */
  @throws[XPathException]
  override def optimize(visitor: ExpressionVisitor, contextItemType: ContextItemStaticInfo) = this

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   */
  override def getNetCost = 0

  /**
   * Determine the data type of the items in the expression, if possible
   *
   * @return for the default implementation: AnyItemType (not known)
   */
  override def getItemType = { // Avoid getting the configuration if we can: it's a common source of NPE's
    if (value.isInstanceOf[AtomicValue]) value.asInstanceOf[AtomicValue].getItemType
    else if (value.getLength == 0) ErrorType.getInstance
    else {
      val th = getConfiguration.getTypeHierarchy
      SequenceTool.getItemType(value, th)
    }
  }

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @param contextItemType the static context item type
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   */
  override def getStaticUType(contextItemType: UType) = if (value.getLength == 0) UType.VOID
  else if (value.isInstanceOf[AtomicValue]) value.asInstanceOf[AtomicValue].getUType
  else if (value.isInstanceOf[Function]) UType.FUNCTION
  else super.getStaticUType(contextItemType)

  /**
   * Determine the cardinality
   */
  override def computeCardinality: Int = {
    if (value.getLength == 0) return StaticProperty.EMPTY
    else if (value.isInstanceOf[AtomicValue]) return StaticProperty.EXACTLY_ONE
    try {
      val iter = value.iterate
      val next = iter.next
      if (next == null) StaticProperty.EMPTY
      else if (iter.next != null) StaticProperty.ALLOWS_MANY
      else StaticProperty.EXACTLY_ONE
    } catch {
      case err: XPathException =>
        // can't actually happen
        StaticProperty.ALLOWS_ZERO_OR_MORE
    }
  }

  /**
   * Compute the static properties of this expression (other than its type). For a
   * Value, the only special property is {@link StaticProperty#NO_NODES_NEWLY_CREATED}.
   *
   * @return the value { @link StaticProperty#NO_NODES_NEWLY_CREATED}
   */
  override def computeSpecialProperties: Int = {
    if (value.getLength == 0) { // An empty sequence has all special properties except "has side effects".
      return StaticProperty.SPECIAL_PROPERTY_MASK & ~StaticProperty.HAS_SIDE_EFFECTS
    }
    StaticProperty.NO_NODES_NEWLY_CREATED
  }

  /**
   * For an expression that returns an integer or a sequence of integers, get
   * a lower and upper bound on the values of the integers that may be returned, from
   * static analysis. The default implementation returns null, meaning "unknown" or
   * "not applicable". Other implementations return an array of two IntegerValue objects,
   * representing the lower and upper bounds respectively. The values
   * UNBOUNDED_LOWER and UNBOUNDED_UPPER are used by convention to indicate that
   * the value may be arbitrarily large. The values MAX_STRING_LENGTH and MAX_SEQUENCE_LENGTH
   * are used to indicate values limited by the size of a string or the size of a sequence.
   *
   * @return the lower and upper bounds of integer values in the result, or null to indicate
   *         unknown or not applicable.
   */
  /*@Nullable*/ override def getIntegerBounds = if (value.isInstanceOf[IntegerValue]) Array[IntegerValue](value.asInstanceOf[IntegerValue], value.asInstanceOf[IntegerValue])
  else if (value.isInstanceOf[IntegerRange]) Array[IntegerValue](Int64Value.makeIntegerValue(value.asInstanceOf[IntegerRange].getStart), Int64Value.makeIntegerValue(value.asInstanceOf[IntegerRange].getEnd))
  else null

  /**
   * Determine whether this is a vacuous expression as defined in the XQuery update specification
   *
   * @return true if this expression is vacuous
   */
  override def isVacuousExpression = value.getLength == 0

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @param rebindings variables that need to be re-bound
   * @return a copy of the original literal. Note that the
   *         underlying value is not copied; the code relies on the caller
   *         treating the underlying value as immutable.
   */
  override def copy(rebindings: RebindingMap) = {
    val l2 = new Literal(value)
    ExpressionTool.copyLocationInfo(this, l2)
    l2
  }

  /**
   * Convert this expression to an equivalent XSLT pattern
   *
   * @param config the Saxon configuration
   * @return the equivalent pattern
   * @throws net.sf.saxon.trans.XPathException if conversion is not possible
   */
  @throws[XPathException]
  override def toPattern(config: Configuration) = if (Literal.isEmptySequence(this)) new NodeTestPattern(ErrorType.getInstance)
  else super.toPattern(config)

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   *
   * @param pathMap        the PathMap to which the expression should be added
   * @param pathMapNodeSet the set of nodes within the path map
   * @return the pathMapNode representing the focus established by this expression, in the case where this
   *         expression is the first operand of a path expression or filter expression
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = pathMapNodeSet

  /**
   * Determine which aspects of the context the expression depends on. The result is
   * a bitwise-or'ed value composed from constants such as StaticProperty.VARIABLES and
   * StaticProperty.CURRENT_NODE
   *
   * @return for a Value, this always returns zero.
   */
  override final def getDependencies = 0

  /**
   * Return an Iterator to iterate over the values of a sequence. The value of every
   * expression can be regarded as a sequence, so this method is supported for all
   * expressions. This default implementation handles iteration for expressions that
   * return singleton values: for non-singleton expressions, the subclass must
   * provide its own implementation.
   *
   * @param context supplies the context for evaluation
   * @return a SequenceIterator that can be used to iterate over the result
   *         of the expression
   * @throws net.sf.saxon.trans.XPathException if any dynamic error occurs evaluating the
   *                                           expression
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = value.iterate

  /**
   * Return an Iterator to iterate over the values of a sequence. The value of every
   * expression can be regarded as a sequence, so this method is supported for all
   * expressions. This default implementation handles iteration for expressions that
   * return singleton values: for non-singleton expressions, the subclass must
   * provide its own implementation.
   *
   * @return a SequenceIterator that can be used to iterate over the result
   *         of the expression
   * @throws net.sf.saxon.trans.XPathException if any dynamic error occurs evaluating the
   *                                           expression
   */
  @throws[XPathException]
  def iterate = value.iterate

  /**
   * Evaluate as a singleton item (or empty sequence). Note: this implementation returns
   * the first item in the sequence. The method should not be used unless appropriate type-checking
   * has been done to ensure that the value will be a singleton.
   */
  @throws[XPathException]
  override def evaluateItem(context: XPathContext) = value.head

  /**
   * Process the value as an instruction, without returning any tail calls
   *
   * @param output  the destination for the result
   * @param context The dynamic context, giving access to the current node,
   */
  @throws[XPathException]
  override def process(output: Outputter, context: XPathContext) = if (value.isInstanceOf[Item]) output.append(value.asInstanceOf[Item], getLocation, ReceiverOption.ALL_NAMESPACES)
  else value.iterate.forEachOrFail((it: Item) => output.append(it, getLocation, ReceiverOption.ALL_NAMESPACES))

  override def getImplementationMethod = ITERATE_METHOD | PROCESS_METHOD | EVALUATE_METHOD

  @throws[XPathException]
  override def evaluateAsString(context: XPathContext): CharSequence = {
    val value = evaluateItem(context).asInstanceOf[AtomicValue]
    if (value == null) return ""
    value.getStringValueCS
  }

  /**
   * Get the effective boolean value of the expression. This returns false if the value
   * is the empty sequence, a zero-length string, a number equal to zero, or the boolean
   * false. Otherwise it returns true.
   *
   * @param context The context in which the expression is to be evaluated
   * @return the effective boolean value
   * @throws net.sf.saxon.trans.XPathException if any dynamic error occurs evaluating the
   *                                           expression
   */
  @throws[XPathException]
  override def effectiveBooleanValue(context: XPathContext) = value.effectiveBooleanValue

  /**
   * Evaluate an updating expression, adding the results to a Pending Update List.
   * The default implementation of this method, which is used for non-updating expressions,
   * throws an UnsupportedOperationException. The implementation for a literal representing
   * an empty sequence, however, is a no-op.
   *
   * @param context the XPath dynamic evaluation context
   * @param pul     the pending update list to which the results should be written
   */
  @throws[XPathException]
  override def evaluatePendingUpdates(context: XPathContext, pul: PendingUpdateList) = if (value.getLength == 0) {
    // do nothing
  }
  else super.evaluatePendingUpdates(context, pul)

  /**
   * Determine whether two literals are equal, when considered as expressions.
   *
   * @param obj the other expression
   * @return true if the two literals are equal. The test here requires (a) identity in the
   *         sense defined by XML Schema (same value in the same value space), and (b) identical type
   * annotations. For example the literal xs:int(3) is not equal (as an expression) to xs:short(3),
   *         because the two expressions are not interchangeable.
   */
  override def equals(obj: Any): Boolean = {
    if (!obj.isInstanceOf[Literal]) return false
    val v0 = value
    val v1 = obj.asInstanceOf[Literal].value
    try {
      val i0 = v0.iterate
      val i1 = v1.iterate
      while ( {
        true
      }) {
        val m0 = i0.next
        val m1 = i1.next
        if (m0 == null && m1 == null) return true
        if (m0 == null || m1 == null) return false
        if (m0 eq m1) continue //todo: continue is not supported
        val n0 = m0.isInstanceOf[NodeInfo]
        val n1 = m1.isInstanceOf[NodeInfo]
        if (n0 != n1) return false
        if (n0) if (m0 == m1) continue //todo: continue is not supported
        else return false
        val a0 = m0.isInstanceOf[AtomicValue]
        val a1 = m1.isInstanceOf[AtomicValue]
        if (a0 != a1) return false
        if (a0) if (m0.asInstanceOf[AtomicValue].isIdentical(m1.asInstanceOf[AtomicValue]) && (m0.asInstanceOf[AtomicValue].getItemType eq m1.asInstanceOf[AtomicValue].getItemType)) continue //todo: continue is not supported
        else return false
        // don't attempt to compare functions, maps, and arrays
        return false
      }
    } catch {
      case err: XPathException =>
        false
    }
  }

  /**
   * Return a hash code to support the equals() function
   */
  override def computeHashCode = if (value.isInstanceOf[AtomicSequence]) value.asInstanceOf[AtomicSequence].getSchemaComparable.hashCode
  else super.computeHashCode

  /**
   * The toString() method for an expression attempts to give a representation of the expression
   * in an XPath-like form, but there is no guarantee that the syntax will actually be true XPath.
   * In the case of XSLT instructions, the toString() method gives an abstracted view of the syntax
   */
  override def toString = value.toString

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(out: ExpressionPresenter) = Literal.exportValue(value, out)

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in export() output displaying the expression.
   */
  override def getExpressionName = "literal"

  /**
   * Produce a short string identifying the expression for use in error messages
   *
   * @return a short string, sufficient to identify the expression
   */
  override def toShortString = if (value.getLength == 0) "()"
  else if (value.getLength == 1) value.toShortString
  else "(" + value.head.toShortString + ", ...{" + value.getLength + "})"

  /**
   * Determine whether the expression can be evaluated without reference to the part of the context
   * document outside the subtree rooted at the context node.
   *
   * @return true if the expression has no dependencies on the context node, or if the only dependencies
   *         on the context node are downward selections using the self, child, descendant, attribute, and namespace
   *         axes.
   */
  override def isSubtreeExpression = true

  /**
   * Get the (partial) name of a class that supports streaming of this kind of expression
   *
   * @return the partial name of a class that can be instantiated to provide streaming support in Saxon-EE,
   *         or null if there is no such class
   */
  override def getStreamerName = "Literal"
}