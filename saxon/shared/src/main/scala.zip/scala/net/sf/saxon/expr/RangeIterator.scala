////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.om.GroundedValue
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter._
import net.sf.saxon.value.BigIntegerValue
import net.sf.saxon.value.Int64Value
import net.sf.saxon.value.IntegerRange
import net.sf.saxon.value.IntegerValue
import java.util

/**
 * An Iterator that produces numeric values in a monotonic sequence,
 * ascending or descending. Although a range expression (N to M) is always
 * in ascending order, applying the reverse() function will produce
 * a RangeIterator that works in descending order.
 */
object RangeIterator {
  @throws[XPathException]
  def makeRangeIterator(start: IntegerValue, end: IntegerValue): AtomicIterator[IntegerValue] = if (start == null || end == null) EmptyIterator.ofAtomic
  else {
    if (start.compareTo(end) > 0) return EmptyIterator.ofAtomic
    if (start.isInstanceOf[BigIntegerValue] || end.isInstanceOf[BigIntegerValue]) new BigRangeIterator(start.asBigInteger, end.asBigInteger)
    else {
      val startVal = start.longValue
      val endVal = end.longValue
      if (endVal - startVal > Integer.MAX_VALUE) throw new XPathException("Saxon limit on sequence length exceeded (2^31)", "XPDY0130")
      new RangeIterator(startVal, endVal)
    }
  }
}

class RangeIterator(var start: Long, var limit: Long)

/**
 * Create an iterator over a range of monotonically increasing integers
 *
 * @param start the first integer in the sequence
 * @param end   the last integer in the sequence. Must be &gt;= start.
 */
  extends AtomicIterator[IntegerValue] with ReversibleIterator with LastPositionFinder with LookaheadIterator with GroundedIterator {
  currentValue = start - 1
  private[expr] var currentValue = 0L

  override def hasNext = currentValue < limit

  /*@Nullable*/ override def next: IntegerValue = {
    if ( {
      currentValue += 1; currentValue
    } > limit) return null
    Int64Value.makeIntegerValue(currentValue)
  }

  override def getLength = ((limit - start) + 1).toInt

  /**
   * Get properties of this iterator, as a bit-significant integer.
   *
   * @return the properties of this iterator. This will be some combination of
   *         properties such as { @link net.sf.saxon.om.SequenceIterator.Property#GROUNDED}, { @link net.sf.saxon.om.SequenceIterator.Property#LAST_POSITION_FINDER},
   *                                    and { @link net.sf.saxon.om.SequenceIterator.Property#LOOKAHEAD}. It is always
   *                                    acceptable to return the value zero, indicating that there are no known special properties.
   *                                    It is acceptable for the properties of the iterator to change depending on its state.
   */
  override def getProperties = util.EnumSet.of(Property.LOOKAHEAD, Property.LAST_POSITION_FINDER, Property.GROUNDED)

  override def getReverseIterator = try new ReverseRangeIterator(limit, start)
  catch {
    case err: XPathException =>
      throw new AssertionError(err)
  }

  /**
   * Return a Value containing all the items in the sequence returned by this
   * SequenceIterator. This should be an "in-memory" value, not a Closure.
   *
   * @return the corresponding Value
   */
  override def materialize = new IntegerRange(start, limit)

  override def getResidue = new IntegerRange(currentValue, limit)
}