////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.lib.NamespaceConstant
import net.sf.saxon.model.SchemaType
import net.sf.saxon.om.AttributeMap
import net.sf.saxon.om.NamespaceMap
import net.sf.saxon.om.NodeName
import net.sf.saxon.s9api.Location
import net.sf.saxon.trans.XPathException
import javax.xml.transform.OutputKeys

/**
 * This class generates HTML 5.0 output
 */
class HTML50Emitter()

/**
 * Constructor
 */
  extends HTMLEmitter {
  version = 5

  /**
   * Decide whether an element is "serialized as an HTML element" in the language of the 3.0 specification
   *
   * @return true if the element is to be serialized as an HTML element
   */
  override protected def isHTMLElement(name: NodeName) = {
    val uri = name.getURI
    uri == "" || uri == NamespaceConstant.XHTML
  }

  @throws[XPathException]
  override protected def openDocument() = {
    version = 5
    super.openDocument()
  }

  /**
   * Output the document type declaration
   *
   * @param displayName The element name
   * @param systemId    The DOCTYPE system identifier
   * @param publicId    The DOCTYPE public identifier
   */
  @throws[XPathException]
  override protected def writeDocType(name: NodeName, displayName: String, systemId: String, publicId: String) = try if (systemId == null && publicId == null) writer.write("<!DOCTYPE HTML>")
  else super.writeDocType(name, displayName, systemId, publicId)
  catch {
    case err: IOException =>
      throw new XPathException(err)
  }

  override protected def writeDocTypeWithNullSystemId = true

  /**
   * Output element start tag
   *
   * @param elemName
   * @param type
   * @param attributes
   * @param namespaces
   * @param location
   * @param properties
   */
  @throws[XPathException]
  override def startElement(elemName: NodeName, `type`: SchemaType, attributes: AttributeMap, namespaces: NamespaceMap, location: Location, properties: Int) = {
    if (!started) {
      openDocument()
      var systemId = outputProperties.getProperty(OutputKeys.DOCTYPE_SYSTEM)
      var publicId = outputProperties.getProperty(OutputKeys.DOCTYPE_PUBLIC)
      // Treat "" as equivalent to absent. This goes beyond what the spec strictly allows.
      if ("" == systemId) systemId = null
      if ("" == publicId) publicId = null
      writeDocType(null, "html", systemId, publicId)
      started = true
    }
    super.startElement(elemName, `type`, attributes, namespaces, location, properties)
  }

  /**
   * Ask whether control characters should be rejected: true for HTML4, false for HTML5
   *
   * @return true if control characters should be rejected
   */
  override protected def rejectControlCharacters = false
}