////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.serialize

import net.sf.saxon.event._
import net.sf.saxon.lib.SaxonOutputKeys
import javax.xml.transform.OutputKeys
import java.util.Properties

/**
 * Define a set of serialization properties. These may contain simple output properties such as {@code method}
 * or {@code indent}, Saxon extensions such as {@code saxon:indent-spaces}, and may also contain an index
 * of character maps.
 */


/**
 * Create a set of defaulted serialization parameters
 */
class SerializationProperties(){
  this.properties = new Properties
  private[serialize] var properties = null
  private[serialize] var charMapIndex = null
  private[serialize] var validationFactory = null

  /**
   * Create a set of serialization parameters based on defined output properties,
   * with no character maps
   */
  def this(props: Properties) {
    this()
    this.properties = props
  }

  /**
   * Create a set of serialization parameters based on defined output properties,
   * with an index of named character maps that may be referred to from the
   * {@code USE_CHARACTER_MAPS} property
   */
  def this(props: Properties, charMapIndex: CharacterMapIndex) {
    this()
    this.properties = props
    this.charMapIndex = charMapIndex
  }

  /**
   * Set the value of a serialization property.
   *
   * @param name the property name in Clark notation (if this is constant, the available
   *             constants are defined in classes { @link OutputKeys} and { @link SaxonOutputKeys}).
   * @param value the property value. In the case of QName-valued properties, such as
   *              { @code cdata-section-elements}, these should be in Clark notation
   */
  def setProperty(name: String, value: String) = properties.setProperty(name, value)

  /**
   * Get the value of a serialization property
   *
   * @param name the property name in Clark notation (if this is constant, the available
   *             constants are defined in classes { @link OutputKeys} and { @link SaxonOutputKeys}).
   * @return the property value. In the case of QName-valued properties, such as
   *         { @code cdata-section-elements}, these should be in Clark notation
   */
  def getProperty(name: String) = getProperties.getProperty(name)

  /**
   * Get the simple output properties defined in these serialization parameters. The property
   * names will be in clark-name format, for example {@code "indent"} or
   * {@code "{http://saxon.sf.net/}indent-spaces"}
   *
   * @return the output properties
   */
  def getProperties = properties

  /**
   * Get the character map index, if any
   *
   * @return the character map index, if one is present, otherwise null
   */
  def getCharacterMapIndex = charMapIndex

  /**
   * Although validation is not normally part of serialization, the {@code xsl:result-document}
   * instruction allows a validator to be inserted into the serialization pipeline. This is achieved
   * by adding a request to insert a validation stage to the serialization parameters. The request
   * is in the form of a factory function that constructs the required validator
   *
   * @param validationFactory a function that inserts a validator into a { @code Receiver} pipeline
   */
  def setValidationFactory(validationFactory: FilterFactory) = this.validationFactory = validationFactory

  /**
   * Get any validation factory that was added to the serialization parameters using
   * {@link #setValidationFactory(FilterFactory)}
   *
   * @return the validation factory, or null if there is none.
   */
  def getValidationFactory = validationFactory

  /**
   * Convenience method to create an appropriate SequenceNormalizer, based
   * on the item-separator appearing in the serialization parameters. If the
   * serialization parameters include a request for validation, then a validator
   * will also be inserted into the pipeline immediately after the SequenceNormalizer,
   * as required by the rules for {@code xsl:result-document}.
   *
   * @param next the next { @code Receiver in the pipeline}
   * @return the new { @code SequenceNormalizer}, feeding into the supplied { @code Receiver},
   *                         possibly via a new validating filter.
   */
  def makeSequenceNormalizer(next: Receiver) = {
    if (getValidationFactory != null) next = getValidationFactory.makeFilter(next)
    val itemSeparator = properties.getProperty(SaxonOutputKeys.ITEM_SEPARATOR)
    if (itemSeparator == null || "#absent" == itemSeparator) new SequenceNormalizerWithSpaceSeparator(next)
    else new SequenceNormalizerWithItemSeparator(next, itemSeparator)
  }

  /**
   * Combine these serialization parameters with a set of default serialization
   * parameters to create a new set of serialization parameters. Neither of the
   * input parameter sets is modified
   *
   * @param defaults the parameters to use when no explicit values are supplied
   */
  def combineWith(defaults: SerializationProperties) = {
    var charMap = this.charMapIndex
    if (charMap == null || charMap.isEmpty) charMap = defaults.getCharacterMapIndex
    var validationFactory = this.validationFactory
    if (validationFactory == null) validationFactory = defaults.validationFactory
    val props = new Properties(defaults.getProperties)
    import scala.collection.JavaConversions._
    for (prop <- this.getProperties.stringPropertyNames) {
      val value = this.getProperties.getProperty(prop)
      if (prop == OutputKeys.CDATA_SECTION_ELEMENTS || prop == SaxonOutputKeys.SUPPRESS_INDENTATION) {
        val existing = defaults.getProperty(prop)
        if (existing == null || existing == value) props.setProperty(prop, value)
        else props.setProperty(prop, existing + " " + value)
      }
      else props.setProperty(prop, value)
    }
    val newParams = new SerializationProperties(props, charMap)
    newParams.setValidationFactory(validationFactory)
    newParams
  }

  override def toString = {
    val sb = new StringBuilder
    import scala.collection.JavaConversions._
    for (k <- properties.stringPropertyNames) {
      sb.append(k).append("=").append(properties.getProperty(k)).append(" ")
    }
    if (charMapIndex != null) {
      import scala.collection.JavaConversions._
      for (cm <- charMapIndex) {
        sb.append(cm.getName.getEQName).append("={").append(cm.toString).append("} ")
      }
    }
    sb.toString
  }
}