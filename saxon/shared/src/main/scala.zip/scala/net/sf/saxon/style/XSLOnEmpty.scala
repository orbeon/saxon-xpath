////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.instruct.OnEmptyExpr
import net.sf.saxon.om.AxisInfo
import net.sf.saxon.trans.XPathException

/**
 * An xsl:on-empty element in the stylesheet. The rules are identical to xsl:sequence.
 */
final class XSLOnEmpty extends XSLSequence {
  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    super.validate(decl)
    iterateAxis(AxisInfo.FOLLOWING_SIBLING).forEachOrFail((next: Item) => {
      def foo(next: Item) =
        if (!(next.isInstanceOf[XSLFallback] || next.isInstanceOf[XSLCatch])) compileError("xsl:on-empty must be the last instruction in the sequence constructor")

      foo(next)
    })
  }

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val e = super.compile(exec, decl)
    new OnEmptyExpr(e)
  }
}