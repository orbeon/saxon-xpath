////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.expr.instruct.GlobalVariable
import net.sf.saxon.expr.parser.RebindingMap
import net.sf.saxon.om.Sequence
import net.sf.saxon.om.StructuredQName
import net.sf.saxon.trans.XPathException

/**
 * Variable reference: a reference to a local variable. This subclass of VariableReference
 * bypasses the Binding object to get the value directly from the relevant slot in the local
 * stackframe.
 */
class LocalVariableReference extends VariableReference {
  private[expr] var slotNumber = -999

  def this(name: StructuredQName) {
    this()
    this.setVariableName(name)
  }

  def this(binding: GlobalVariable) {
    this()
    this.setVariableName(binding.getVariableQName)
    fixup(binding)
  }

  /**
   * Create a clone copy of this VariableReference
   *
   * @return the cloned copy
   * @param rebindings a mutable list of (old binding, new binding) pairs
   *                   that is used to update the bindings held in any
   *                   local variable references that are copied.
   */
  /*@NotNull*/ override def copy(rebindings: RebindingMap) = {
    if (binding == null) throw new UnsupportedOperationException("Cannot copy a variable reference whose binding is unknown")
    //        if (slotNumber < 0) {
    //            // slot numbers have not yet been allocated. This is messy. For the time being, the safest
    //            // thing is to reuse the existing variable reference, which usually works, rather than copying
    //            // it, which will almost certainly fail. See XSLT streaming test case si-attribute-053
    //            return this;
    //        }
    val ref = new LocalVariableReference(getVariableName)
    ref.copyFrom(this)
    ref.slotNumber = slotNumber
    val newBinding = rebindings.get(binding)
    if (newBinding != null) ref.binding = newBinding
    ref.binding.addReference(ref, isInLoop)
    ref
  }

  def setBinding(binding: LocalBinding) = this.binding = binding

  override def getBinding = super.getBinding.asInstanceOf[LocalBinding]

  /**
   * Set the slot number for this local variable, that is, its position in the local stack frame
   *
   * @param slotNumber the slot number to be used
   */
  def setSlotNumber(slotNumber: Int) = this.slotNumber = slotNumber

  /**
   * Get the slot number allocated to this local variable
   *
   * @return the slot number
   */
  def getSlotNumber = slotNumber

  /**
   * Return the value of the variable
   *
   * @param c the XPath dynamic context
   * @return the value of the variable
   * @throws XPathException if any dynamic error occurs while evaluating the variable
   */
  @throws[XPathException]
  override def evaluateVariable(c: XPathContext): Sequence = try c.getStackFrame.slots(slotNumber)
  catch {
    case err: ArrayIndexOutOfBoundsException =>
      if (slotNumber == -999) {
        if (binding != null) try {
          slotNumber = getBinding.getLocalSlotNumber
          return c.getStackFrame.slots(slotNumber)
        } catch {
          case err2: ArrayIndexOutOfBoundsException =>

          // fall through
        }
        throw new ArrayIndexOutOfBoundsException("Local variable $" + getDisplayName + " has not been allocated a stack frame slot")
      }
      else {
        val actual = c.getStackFrame.slots.length
        throw new ArrayIndexOutOfBoundsException("Local variable $" + getDisplayName + " uses slot " + slotNumber + " but " + (if (actual == 0) "no"
        else "only " + c.getStackFrame.slots.length) + " slots" + " are allocated on the stack frame")
      }
  }

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in export() output displaying the expression.
   */
  override def getExpressionName = "locVarRef"

  /**
   * Replace this VariableReference where appropriate by a more efficient implementation. This
   * can only be done after all slot numbers are allocated. The efficiency is gained by binding the
   * VariableReference directly to a local or global slot, rather than going via the Binding object
   *
   * @param parent the parent expression of this variable reference
   */
  //    public void refineVariableReference(Expression parent) {
  //        // no-op
  //    }
}