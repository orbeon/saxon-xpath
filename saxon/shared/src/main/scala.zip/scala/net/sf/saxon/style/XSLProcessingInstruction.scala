////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.style

import net.sf.saxon.expr.Expression
import net.sf.saxon.expr.StringLiteral
import net.sf.saxon.expr.instruct.ProcessingInstruction
import net.sf.saxon.trans.XPathException
import net.sf.saxon.value.StringValue

/**
 * An xsl:processing-instruction element in the stylesheet.
 */
class XSLProcessingInstruction extends XSLLeafNodeConstructor {
  private[style] var name = null

  override def prepareAttributes() = name = prepareAttributesNameAndSelect

  @throws[XPathException]
  override def validate(decl: ComponentDeclaration) = {
    name = typeCheck("name", name)
    select = typeCheck("select", select)
    super.validate(decl)
  }

  /**
   * Get the error code to be returned when the element has a select attribute but is not empty.
   *
   * @return the error code defined for this condition, for this particular instruction
   */
  override protected def getErrorCodeForSelectPlusContent = "XTSE0880"

  @throws[XPathException]
  override def compile(exec: Compilation, decl: ComponentDeclaration) = {
    val inst = new ProcessingInstruction(name)
    compileContent(exec, decl, inst, new StringLiteral(StringValue.SINGLE_SPACE))
    inst
  }
}