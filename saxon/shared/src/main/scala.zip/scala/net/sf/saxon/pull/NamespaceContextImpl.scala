////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.pull

import net.sf.saxon.om.NamespaceResolver
import javax.xml.namespace.NamespaceContext
import java.util

/**
 * This class bridges between the JAXP 1.3 NamespaceContext interface and Saxon's
 * equivalent NamespaceResolver interface. It allows any implementation of the Saxon
 * NamespaceResolver to be wrapped as a JAXP NamespaceContext.
 */
class NamespaceContextImpl(var resolver: NamespaceResolver)

/**
 * Constructor: wrap a Saxon NamespaceResolver as a JAXP NamespaceContext
 *
 * @param resolver the Saxon NamespaceResolver
 */
  extends NamespaceContext with NamespaceResolver {
  /**
   * Get the namespace URI corresponding to a given prefix. Return null
   * if the prefix is not in scope.
   *
   * @param prefix     the namespace prefix
   * @param useDefault true if the default namespace is to be used when the
   *                   prefix is ""
   * @return the uri for the namespace, or null if the prefix is not in scope
   */
  /*@Nullable*/ override def getURIForPrefix(prefix: String, useDefault: Boolean) = resolver.getURIForPrefix(prefix, useDefault)

  /**
   * Get an iterator over all the prefixes declared in this namespace context. This will include
   * the default namespace (prefix="") and the XML namespace where appropriate
   */
  override def iteratePrefixes = resolver.iteratePrefixes

  /**
   * Implement the JAXP getNamespaceURI() method in terms of the Saxon-specific methods
   *
   * @param prefix a namespace prefix
   * @return the corresponding URI, if the prefix is bound, or "" otherwise
   */
  override def getNamespaceURI(prefix: String): String = {
    if (prefix == "xmlns") return "http://www.w3.org/2000/xmlns/"
    resolver.getURIForPrefix(prefix, true)
  }

  /**
   * Get the prefix bound to a particular namespace URI, if there is one, or null if not (JAXP method)
   *
   * @param uri the namespace URI
   * @return the prefix bound to the URI if there is one, or null if not
   */
  override def getPrefix(uri: String): String = {
    val prefixes = iteratePrefixes
    while ( {
      prefixes.hasNext
    }) {
      val p = prefixes.next.asInstanceOf[String]
      val u = resolver.getURIForPrefix(p, true)
      if (u == uri) return p
    }
    null
  }

  /**
   * Get all the prefixes mapped to a given namespace URI (JAXP method)
   *
   * @param uri the namespace URI
   * @return an iterator over all the prefixes bound to this namespace URI
   */
  override def getPrefixes(uri: String) = {
    val list = new util.ArrayList[String](4)
    val prefixes = iteratePrefixes
    prefixes.forEachRemaining((p: String) => {
      def foo(p: String) = {
        val u = resolver.getURIForPrefix(p, true)
        if (u == uri) list.add(p)
      }

      foo(p)
    })
    list.iterator
  }
}