////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2020 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
package net.sf.saxon.expr

import net.sf.saxon.Configuration
import net.sf.saxon.expr.parser._
import net.sf.saxon.model._
import net.sf.saxon.om._
import net.sf.saxon.pattern._
import net.sf.saxon.trace.ExpressionPresenter
import net.sf.saxon.trans.XPathException
import net.sf.saxon.tree.iter.AxisIterator
import net.sf.saxon.tree.util.FastStringBuffer
import net.sf.saxon.value.Cardinality
import net.sf.saxon.z.IntHashSet
import net.sf.saxon.z.IntIterator
import net.sf.saxon.z.IntSet
import java.util._

/**
 * An AxisExpression is always obtained by simplifying a PathExpression.
 * It represents a PathExpression that starts at the context node, and uses
 * a simple node-test with no filters. For example "*", "title", "./item",
 * "@*", or "ancestor::chapter*".
 * <p>An AxisExpression delivers nodes in axis order (not in document order).
 * To get nodes in document order, in the case of a reverse axis, the expression
 * should be wrapped in a call on reverse().</p>
 */
object AxisExpression {
  private def getDiagnosticName(name: StructuredQName, env: StaticContext): String = {
    val uri = name.getURI
    if (uri == "") return name.getLocalPart
    else {
      val resolver = env.getNamespaceResolver
      val it = resolver.iteratePrefixes
      while ( {
        it.hasNext
      }) {
        val prefix = it.next
        if (uri == resolver.getURIForPrefix(prefix, true)) if (prefix.isEmpty) return "Q{" + uri + "}" + name.getLocalPart
        else return prefix + ":" + name.getLocalPart
      }
    }
    "Q{" + uri + "}" + name.getLocalPart
  }

  private def getStartingNodeDescription(`type`: SchemaType) = {
    val s = `type`.getDescription
    if (s.startsWith("of element")) "a valid element named" + s.substring("of element".length)
    else if (s.startsWith("of attribute")) "a valid attribute named" + s.substring("of attribute".length)
    else "a node with " + (if (`type`.isSimpleType) "simple"
    else "complex") + " type " + s
  }

  /**
   * Determine whether a node test is a peer node test. A peer node test is one that, if it
   * matches a node, cannot match any of its descendants. For example, text() is a peer node-test.
   *
   * @param test the node test
   * @return true if nodes selected by this node-test will never contain each other as descendants
   */
  private def isPeerNodeTest(test: NodeTest): Boolean = {
    if (test == null) return false
    val uType = test.getUType
    if (uType.overlaps(UType.ELEMENT)) { // can match elements; for the moment, assume these can contain each other
      false
    }
    else if (uType.overlaps(UType.DOCUMENT)) { // can match documents; return false if we can also match non-documents
      uType == UType.DOCUMENT
    }
    else true
  }
}

final class AxisExpression(var axis: Int, /*@Nullable*/ var test: NodeTest)

/**
 * Constructor for an AxisExpression whose origin is the context item
 *
 * @param axis The axis to be used in this AxisExpression: relevant constants are defined
 *             in class { @link net.sf.saxon.om.AxisInfo}.
 * @param nodeTest The conditions to be satisfied by selected nodes. May be null,
 *                 indicating that any node on the axis is acceptable
 * @see net.sf.saxon.om.AxisInfo
 */
  extends Expression {
  private var itemType = null
  private var staticInfo = ContextItemStaticInfo.DEFAULT
  private var doneTypeCheck = false
  private var doneOptimize = false

  /**
   * Set the axis
   *
   * @param axis the new axis
   */
  def setAxis(axis: Int) = this.axis = axis

  /**
   * Get a name identifying the kind of expression, in terms meaningful to a user.
   *
   * @return a name identifying the kind of expression, in terms meaningful to a user.
   *         The name will always be in the form of a lexical XML QName, and should match the name used
   *         in explain() output displaying the expression.
   */
  override def getExpressionName = "axisStep"

  /**
   * Simplify an expression
   */
  /*@NotNull*/ @throws[XPathException]
  override def simplify: Expression = {
    val e2 = super.simplify
    if (e2 ne this) return e2
    if ((test == null || (test eq AnyNodeTest.getInstance)) && (axis == AxisInfo.PARENT || axis == AxisInfo.ANCESTOR)) { // get more precise type information for parent/ancestor nodes
      test = MultipleNodeKindTest.PARENT_NODE
    }
    this
  }

  /**
   * Type-check the expression
   */
  @throws[XPathException]
  override def typeCheck(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo): Expression = {
    val contextItemType = contextInfo.getItemType
    val noWarnings = doneOptimize || (doneTypeCheck && this.staticInfo.getItemType == contextItemType)
    doneTypeCheck = true
    if (contextItemType eq ErrorType.getInstance) { // There is no context item. In principle we could raise XPTY0020 ("Context item is not a node"),
      // which is a type error and therefore can be thrown statically. But many test cases expect
      // XPDY0002 ("Context item absent") which for inexplicable reasons is a dynamic error rather than
      // a type error, and therefore cannot be raised until execution time.
      val err = new XPathException("Axis step " + this + " cannot be used here: the context item is absent")
      //err.setIsTypeError(true);
      err.setErrorCode("XPDY0002")
      err.setLocation(getLocation)
      throw err
    }
    else staticInfo = contextInfo
    val config = visitor.getConfiguration
    if (contextItemType.getGenre ne Genre.NODE) {
      val th = config.getTypeHierarchy
      val relation = th.relationship(contextItemType, AnyNodeTest.getInstance)
      if (relation eq Affinity.DISJOINT) {
        val err = new XPathException("Axis step " + this + " cannot be used here: the context item is not a node")
        err.setIsTypeError(true)
        err.setErrorCode("XPTY0020")
        err.setLocation(getLocation)
        throw err
      }
      else if ((relation eq Affinity.OVERLAPS) || (relation eq Affinity.SUBSUMES)) { // need to insert a dynamic check of the context item type
        val thisExp = checkPlausibility(visitor, contextInfo, !noWarnings)
        if (Literal.isEmptySequence(thisExp)) return thisExp
        val exp = new ContextItemExpression
        ExpressionTool.copyLocationInfo(this, exp)
        val role = new RoleDiagnostic(RoleDiagnostic.AXIS_STEP, "", axis)
        role.setErrorCode("XPTY0020")
        val checker = new ItemChecker(exp, AnyNodeTest.getInstance, role)
        ExpressionTool.copyLocationInfo(this, checker)
        val step = new SimpleStepExpression(checker, thisExp)
        ExpressionTool.copyLocationInfo(this, step)
        return step
      }
    }
    if (visitor.getStaticContext.getOptimizerOptions.isSet(OptimizerOptions.VOID_EXPRESSIONS)) checkPlausibility(visitor, contextInfo, !noWarnings)
    else this
  }

  @throws[XPathException]
  private def checkPlausibility(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo, warnings: Boolean): Expression = {
    val env = visitor.getStaticContext
    val config = env.getConfiguration
    var contextType = contextInfo.getItemType
    if (!contextType.isInstanceOf[NodeTest]) contextType = AnyNodeTest.getInstance
    // New code in terms of UTypes
    // Test whether the requested nodetest is consistent with the requested axis
    if (test != null && !AxisInfo.getTargetUType(UType.ANY_NODE, axis).overlaps(test.getUType)) {
      if (warnings) visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis will never select " + test.getUType.toStringWithIndefiniteArticle, getLocation)
      return Literal.makeEmptySequence
    }
    if (test.isInstanceOf[NameTest] && axis == AxisInfo.NAMESPACE && !(test.asInstanceOf[NameTest]).getNamespaceURI.isEmpty) {
      if (warnings) visitor.issueWarning("The names of namespace nodes are never prefixed, so this axis step will never select anything", getLocation)
      return Literal.makeEmptySequence
    }
    // Test whether the axis ever selects anything, when starting at this context node
    val originUType = contextType.getUType
    var targetUType = AxisInfo.getTargetUType(originUType, axis)
    val testUType = if (test == null) UType.ANY_NODE
    else test.getUType
    if (targetUType == UType.VOID) {
      if (warnings) visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis starting at " + originUType.toStringWithIndefiniteArticle + " will never select anything", getLocation)
      return Literal.makeEmptySequence
    }
    if (contextInfo.isParentless && (axis == AxisInfo.PARENT || axis == AxisInfo.ANCESTOR)) {
      if (warnings) visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis will never select anything because the context item is parentless", getLocation)
      return Literal.makeEmptySequence
    }
    // Test whether the axis ever selects a node of the right kind, when starting at this context node
    if (!targetUType.overlaps(testUType)) {
      if (warnings) visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis starting at " + originUType.toStringWithIndefiniteArticle + " will never select " + test.getUType.toStringWithIndefiniteArticle, getLocation)
      return Literal.makeEmptySequence
    }
    // For an X-or-self axis, if X never selects anything, then substitute the self axis.
    val nonSelf = AxisInfo.excludeSelfAxis(axis)
    val kind = if (test == null) UType.ANY_NODE
    else test.getUType
    if (axis != nonSelf) {
      val nonSelfTarget = AxisInfo.getTargetUType(originUType, nonSelf)
      if (!nonSelfTarget.overlaps(testUType)) {
        axis = AxisInfo.SELF
        targetUType = AxisInfo.getTargetUType(originUType, axis)
      }
    }
    val target = targetUType.toItemType
    if (test == null || test.isInstanceOf[AnyNodeTest]) itemType = target
    else if (target.isInstanceOf[AnyNodeTest] || targetUType.subsumes(test.getUType)) itemType = test
    else itemType = new CombinedNodeTest(target.asInstanceOf[NodeTest], Token.INTERSECT, test)
    val origin = contextType.getPrimitiveType
    if (test != null) { // If the content type of the context item is known, see whether the node test can select anything
      if (contextType.isInstanceOf[DocumentNodeTest] && kind == UType.ELEMENT) {
        val elementTest = contextType.asInstanceOf[DocumentNodeTest].getElementTest
        val outermostElementNames = elementTest.getRequiredNodeNames
        if (outermostElementNames.isPresent) {
          val selectedElementNames = test.getRequiredNodeNames
          if (selectedElementNames.isPresent) if (axis == AxisInfo.CHILD) { // check that the name appearing in the step is one of the names allowed by the nodetest
            if (selectedElementNames.get.intersect(outermostElementNames.get).isEmpty) {
              if (warnings) visitor.issueWarning("Starting at a document node, the step is selecting an element whose name " + "is not among the names of child elements permitted for this document node type", getLocation)
              return Literal.makeEmptySequence
            }
            if (env.getPackageData.isSchemaAware && elementTest.isInstanceOf[SchemaNodeTest] && outermostElementNames.get.size == 1) {
              val oeni = outermostElementNames.get.iterator
              val outermostElementName = if (oeni.hasNext) oeni.next
              else -1
              val decl = config.getElementDeclaration(outermostElementName)
              if (decl == null) {
                if (warnings) visitor.issueWarning("Element " + config.getNamePool.getEQName(outermostElementName) + " is not declared in the schema", getLocation)
                itemType = elementTest
              }
              else {
                val contentType = decl.getType
                itemType = new CombinedNodeTest(elementTest, Token.INTERSECT, new ContentTypeTest(Type.ELEMENT, contentType, config, true))
              }
            }
            else itemType = elementTest
            return this
          }
          else if (axis == AxisInfo.DESCENDANT) {
            val canMatchOutermost = !selectedElementNames.get.intersect(outermostElementNames.get).isEmpty
            if (!canMatchOutermost) { // The expression /descendant::x starting at the document node doesn't match the outermost
              // element, so replace it by child::*/descendant::x, and check that
              val path = ExpressionTool.makePathExpression(new AxisExpression(AxisInfo.CHILD, elementTest), new AxisExpression(AxisInfo.DESCENDANT, test))
              ExpressionTool.copyLocationInfo(this, path)
              return path.typeCheck(visitor, contextInfo)
            }
          }
        }
      }
      val contentType = contextType.asInstanceOf[NodeTest].getContentType
      if (contentType eq AnyType.getInstance) { // fast exit in non-schema-aware case
        return this
      }
      if (!env.getPackageData.isSchemaAware) {
        val ct = test.getContentType
        if (!((ct eq AnyType.getInstance) || (ct eq Untyped.getInstance) || (ct eq AnySimpleType.getInstance) || (ct eq BuiltInAtomicType.ANY_ATOMIC) || (ct eq BuiltInAtomicType.UNTYPED_ATOMIC) || (ct eq BuiltInAtomicType.STRING))) {
          if (warnings) visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis will never select any typed nodes, " + "because the expression is being compiled in an environment that is not schema-aware", getLocation)
          return Literal.makeEmptySequence
        }
      }
      val targetfp = test.getFingerprint
      val targetName = test.getMatchingNodeName
      if (contentType.isSimpleType) if (warnings) if ((axis == AxisInfo.CHILD || axis == AxisInfo.DESCENDANT || axis == AxisInfo.DESCENDANT_OR_SELF) && UType.PARENT_NODE_KINDS.union(UType.ATTRIBUTE).subsumes(kind)) visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis will never select any " + kind + " nodes when starting at " + (if (origin == Type.ATTRIBUTE) "an attribute node"
      else AxisExpression.getStartingNodeDescription(contentType)), getLocation)
      else if (axis == AxisInfo.CHILD && kind == UType.TEXT && getParentExpression.isInstanceOf[Atomizer]) visitor.issueWarning("Selecting the text nodes of an element with simple content may give the " + "wrong answer in the presence of comments or processing instructions. It is usually " + "better to omit the '/text()' step", getLocation)
      else if (axis == AxisInfo.ATTRIBUTE) {
        val extensions = config.getExtensionsOfType(contentType)
        var found = false
        if (targetfp == -1) while ( {
          extensions.hasNext
        }) {
          val extension = extensions.next.asInstanceOf[ComplexType]
          if (extension.allowsAttributes) {
            found = true
            break //todo: break is not supported
          }
        }
        else while ( {
          extensions.hasNext
        }) {
          val extension = extensions.next.asInstanceOf[ComplexType]
          try if (extension.getAttributeUseType(targetName) != null) {
            found = true
            break //todo: break is not supported
          }
          catch {
            case e: SchemaException =>

            // ignore the error
          }
        }
        if (!found) {
          visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis will never select " + (if (targetName == null) "any attribute nodes"
          else "an attribute node named " + AxisExpression.getDiagnosticName(targetName, env)) + " when starting at " + AxisExpression.getStartingNodeDescription(contentType), getLocation)
          // Despite the warning, leave the expression unchanged. This is because
          // we don't necessarily know about all extended types at compile time:
          // in particular, we don't seal the XML Schema namespace to block extensions
          // of built-in types
        }
      }
      else if (contentType.asInstanceOf[ComplexType].isSimpleContent && (axis == AxisInfo.CHILD || axis == AxisInfo.DESCENDANT || axis == AxisInfo.DESCENDANT_OR_SELF) && UType.PARENT_NODE_KINDS.subsumes(kind)) { // We don't need to consider extended types here, because a type with complex content
        // can never be defined as an extension of a type with simple content
        if (warnings) visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis will never select any " + kind + " nodes when starting at " + AxisExpression.getStartingNodeDescription(contentType) + ", as this type requires simple content", getLocation)
        return Literal.makeEmptySequence
      }
      else if (contentType.asInstanceOf[ComplexType].isEmptyContent && (axis == AxisInfo.CHILD || axis == AxisInfo.DESCENDANT || axis == AxisInfo.DESCENDANT_OR_SELF)) {
        val iter = config.getExtensionsOfType(contentType)
        while ( {
          iter.hasNext
        }) {
          val extension = iter.next.asInstanceOf[ComplexType]
          if (!extension.isEmptyContent) return this
        }
        if (warnings) visitor.issueWarning("The " + AxisInfo.axisName(axis) + " axis will never select any" + " nodes when starting at " + AxisExpression.getStartingNodeDescription(contentType) + ", as this type requires empty content", getLocation)
        return Literal.makeEmptySequence
      }
      else if (axis == AxisInfo.ATTRIBUTE) if (targetfp == -1) if (warnings) if (!(contentType.asInstanceOf[ComplexType]).allowsAttributes) visitor.issueWarning("The complex type " + contentType.getDescription + " allows no attributes other than the standard attributes in the xsi namespace", getLocation)
      else try {
        var schemaType = null
        if (targetfp == StandardNames.XSI_TYPE) schemaType = BuiltInAtomicType.QNAME
        else if (targetfp == StandardNames.XSI_SCHEMA_LOCATION) schemaType = BuiltInListType.ANY_URIS
        else if (targetfp == StandardNames.XSI_NO_NAMESPACE_SCHEMA_LOCATION) schemaType = BuiltInAtomicType.ANY_URI
        else if (targetfp == StandardNames.XSI_NIL) schemaType = BuiltInAtomicType.BOOLEAN
        else schemaType = contentType.asInstanceOf[ComplexType].getAttributeUseType(targetName)
        if (schemaType == null) if (warnings) {
          visitor.issueWarning("The complex type " + contentType.getDescription + " does not allow an attribute named " + AxisExpression.getDiagnosticName(targetName, env), getLocation)
          return Literal.makeEmptySequence
        }
        else itemType = new CombinedNodeTest(test, Token.INTERSECT, new ContentTypeTest(Type.ATTRIBUTE, schemaType, config, false))
      } catch {
        case e: SchemaException =>

        // ignore the exception
      }
      else if (axis == AxisInfo.CHILD && kind == UType.ELEMENT) try {
        var childfp = targetfp
        if (targetName == null) { // select="child::*"
          if (contentType.asInstanceOf[ComplexType].containsElementWildcard) return this
          val children = new IntHashSet
          contentType.asInstanceOf[ComplexType].gatherAllPermittedChildren(children, false)
          if (children.isEmpty) {
            if (warnings) visitor.issueWarning("The complex type " + contentType.getDescription + " does not allow children", getLocation)
            return Literal.makeEmptySequence
          }
          //                            if (children.contains(-1)) {
          //                                return this;
          //                            }
          if (children.size == 1) {
            val iter = children.iterator
            if (iter.hasNext) childfp = iter.next
          }
          else return this
        }
        val schemaType = contentType.asInstanceOf[ComplexType].getElementParticleType(childfp, true)
        if (schemaType == null) {
          if (warnings) {
            val childElement = getConfiguration.getNamePool.getStructuredQName(childfp)
            var message = "The complex type " + contentType.getDescription + " does not allow a child element named " + AxisExpression.getDiagnosticName(childElement, env)
            val permitted = new IntHashSet
            contentType.asInstanceOf[ComplexType].gatherAllPermittedChildren(permitted, false)
            if (!permitted.contains(-(1))) {
              val kids = permitted.iterator
              while ( {
                kids.hasNext
              }) {
                val kid = kids.next
                val sq = getConfiguration.getNamePool.getStructuredQName(kid)
                if (sq.getLocalPart == childElement.getLocalPart && kid != childfp) {
                  message += ". Perhaps the namespace is " + (if (childElement.hasURI("")) "missing"
                  else "wrong") + ", and " + sq.getEQName + " was intended?"
                  break //todo: break is not supported
                }
              }
            }
            visitor.issueWarning(message, getLocation)
          }
          return Literal.makeEmptySequence
        }
        else {
          itemType = new CombinedNodeTest(test, Token.INTERSECT, new ContentTypeTest(Type.ELEMENT, schemaType, config, true))
          val computedCardinality = contentType.asInstanceOf[ComplexType].getElementParticleCardinality(childfp, true)
          ExpressionTool.resetStaticProperties(this)
          if (computedCardinality == StaticProperty.ALLOWS_ZERO) { // this shouldn't happen, because we've already checked for this a different way.
            // but it's worth being safe (there was a bug involving an incorrect inference here)
            val childElement = getConfiguration.getNamePool.getStructuredQName(childfp)
            visitor.issueWarning("The complex type " + contentType.getDescription + " appears not to allow a child element named " + AxisExpression.getDiagnosticName(childElement, env), getLocation)
            return Literal.makeEmptySequence
          }
          if (!Cardinality.allowsMany(computedCardinality) && !getParentExpression.isInstanceOf[FirstItemExpression] && !visitor.isOptimizeForPatternMatching) { // if there can be at most one child of this name, create a FirstItemExpression
            // to stop the search after the first one is found
            return FirstItemExpression.makeFirstItemExpression(this)
          }
        }
      } catch {
        case e: SchemaException =>
      }
      else if (axis == AxisInfo.DESCENDANT && kind == UType.ELEMENT && targetfp != -1) { // when searching for a specific element on the descendant axis, try to produce a more
        // specific path that avoids searching branches of the tree where the element cannot occur
        try {
          val descendants = new IntHashSet
          contentType.asInstanceOf[ComplexType].gatherAllPermittedDescendants(descendants)
          if (descendants.contains(-1)) return this
          if (descendants.contains(targetfp)) {
            val children = new IntHashSet
            contentType.asInstanceOf[ComplexType].gatherAllPermittedChildren(children, false)
            val usefulChildren = new IntHashSet
            var considerSelf = false
            var considerDescendants = false
            val kids = children.iterator
            while ( {
              kids.hasNext
            }) {
              val c = kids.next
              if (c == targetfp) {
                usefulChildren.add(c)
                considerSelf = true
              }
              val st = contentType.asInstanceOf[ComplexType].getElementParticleType(c, true)
              if (st == null) throw new AssertionError("Can't find type for child element " + c)
              if (st.isInstanceOf[ComplexType]) {
                val subDescendants = new IntHashSet
                st.asInstanceOf[ComplexType].gatherAllPermittedDescendants(subDescendants)
                if (subDescendants.contains(targetfp)) {
                  usefulChildren.add(c)
                  considerDescendants = true
                }
              }
            }
            itemType = test
            if (considerDescendants) {
              val st = contentType.asInstanceOf[ComplexType].getDescendantElementType(targetfp)
              if (st ne AnyType.getInstance) itemType = new CombinedNodeTest(test, Token.INTERSECT, new ContentTypeTest(Type.ELEMENT, st, config, true))
              //return this;
            }
            if (usefulChildren.size < children.size) {
              val childTest = makeUnionNodeTest(usefulChildren, config.getNamePool)
              val first = new AxisExpression(AxisInfo.CHILD, childTest)
              ExpressionTool.copyLocationInfo(this, first)
              var nextAxis = 0
              if (considerSelf) nextAxis = if (considerDescendants) AxisInfo.DESCENDANT_OR_SELF
              else AxisInfo.SELF
              else nextAxis = AxisInfo.DESCENDANT
              val next = new AxisExpression(nextAxis, itemType.asInstanceOf[NodeTest])
              ExpressionTool.copyLocationInfo(this, next)
              val path = ExpressionTool.makePathExpression(first, next)
              ExpressionTool.copyLocationInfo(this, path)
              return path.typeCheck(visitor, contextInfo)
            }
          }
          else if (warnings) visitor.issueWarning("The complex type " + contentType.getDescription + " does not allow a descendant element named " + AxisExpression.getDiagnosticName(targetName, env), getLocation)
        } catch {
          case e: SchemaException =>
            throw new AssertionError(e)
        }
      }
    }
    this
  }

  /**
   * Make a union node test for a set of supplied element fingerprints
   *
   * @param elements the set of integer element fingerprints to be tested for. Must not
   *                 be empty.
   * @param pool     the name pool
   * @return a NodeTest that returns true if the node is an element whose name is one of the names
   *         in this set
   */
  private def makeUnionNodeTest(elements: IntHashSet, pool: NamePool) = {
    var test = null
    val iter = elements.iterator
    while ( {
      iter.hasNext
    }) {
      val fp = iter.next
      val nextTest = new NameTest(Type.ELEMENT, fp, pool)
      if (test == null) test = nextTest
      else test = new CombinedNodeTest(test, Token.UNION, nextTest)
    }
    test
  }

  /**
   * Get the static type of the context item for this AxisExpression. May be null if not known.
   *
   * @return the statically-inferred type, or null if not known
   */
  def getContextItemType = staticInfo.getItemType

  /**
   * Perform optimisation of an expression and its subexpressions.
   * <p>This method is called after all references to functions and variables have been resolved
   * to the declaration of the function or variable, and after all type checking has been done.</p>
   *
   * @param visitor     an expression visitor
   * @param contextInfo the static type of "." at the point where this expression is invoked.
   *                    The parameter is set to null if it is known statically that the context item will be undefined.
   *                    If the type of the context item is not known statically, the argument is set to
   *                    { @link net.sf.saxon.model.Type#ITEM_TYPE}
   * @return the original expression, rewritten if appropriate to optimize execution
   */
  override def optimize(visitor: ExpressionVisitor, contextInfo: ContextItemStaticInfo) = {
    doneOptimize = true // This ensures no more warnings about empty axes, because (a) we've probably output the
    // warning already, and (b) we're now looking at a different expression from what the user
    // wrote. In particular, prevent spurious warnings after function inlining.
    staticInfo = contextInfo
    this
  }

  /**
   * Return the estimated cost of evaluating an expression. This is a very crude measure based
   * on the syntactic form of the expression (we have no knowledge of data values). We take
   * the cost of evaluating a simple scalar comparison or arithmetic expression as 1 (one),
   * and we assume that a sequence has length 5. The resulting estimates may be used, for
   * example, to reorder the predicates in a filter expression so cheaper predicates are
   * evaluated first.
   *
   * @return the estimated cost
   */
  override def getCost = axis match {
    case AxisInfo.SELF =>
    case AxisInfo.PARENT =>
    case AxisInfo.ATTRIBUTE =>
      1
    case AxisInfo.CHILD =>
    case AxisInfo.FOLLOWING_SIBLING =>
    case AxisInfo.PRECEDING_SIBLING =>
    case AxisInfo.ANCESTOR =>
    case AxisInfo.ANCESTOR_OR_SELF =>
      5
    case _ =>
      20
  }

  /**
   * Is this expression the same as another expression?
   */
  override def equals(other: Any) = other.isInstanceOf[AxisExpression] && axis == other.asInstanceOf[AxisExpression].axis && Objects.equals(test, other.asInstanceOf[AxisExpression].test)

  /**
   * get HashCode for comparing two expressions
   */
  override def computeHashCode = { // generate an arbitrary hash code that depends on the axis and the node test
    var h = 9375162 + axis << 20
    if (test != null) {
      h ^= test.getPrimitiveType << 16
      h ^= test.getFingerprint
    }
    h
  }

  /**
   * Copy an expression. This makes a deep copy.
   *
   * @param rebindings a mutable list of (old binding, new binding) pairs
   *                   that is used to update the bindings held in any
   *                   local variable references that are copied.
   * @return the copy of the original expression
   */
  override def copy(rebindings: RebindingMap) = {
    val a2 = new AxisExpression(axis, test)
    a2.itemType = itemType
    a2.staticInfo = staticInfo
    a2.doneTypeCheck = doneTypeCheck
    a2.doneOptimize = doneOptimize
    ExpressionTool.copyLocationInfo(this, a2)
    a2
  }

  /**
   * Get the static properties of this expression (other than its type). The result is
   * bit-signficant. These properties are used for optimizations. In general, if
   * property bit is set, it is true, but if it is unset, the value is unknown.
   */
  override def computeSpecialProperties = StaticProperty.CONTEXT_DOCUMENT_NODESET | StaticProperty.SINGLE_DOCUMENT_NODESET | StaticProperty.NO_NODES_NEWLY_CREATED | (if (AxisInfo.isForwards(axis)) StaticProperty.ORDERED_NODESET
  else StaticProperty.REVERSE_DOCUMENT_ORDER) | (if (AxisInfo.isPeerAxis(axis) || AxisExpression.isPeerNodeTest(test)) StaticProperty.PEER_NODESET
  else 0) | (if (AxisInfo.isSubtreeAxis(axis)) StaticProperty.SUBTREE_NODESET
  else 0) | (if (axis == AxisInfo.ATTRIBUTE || axis == AxisInfo.NAMESPACE) StaticProperty.ATTRIBUTE_NS_NODESET
  else 0)

  /**
   * Determine the data type of the items returned by this expression
   *
   * @return Type.NODE or a subtype, based on the NodeTest in the axis step, plus
   *         information about the content type if this is known from schema analysis
   */
  override final def getItemType: ItemType = {
    if (itemType != null) return itemType
    val p = AxisInfo.principalNodeType(axis)
    p match {
      case Type.ATTRIBUTE =>
      case Type.NAMESPACE =>
        NodeKindTest.makeNodeKindTest(p)
      case _ =>
        if (test == null) AnyNodeTest.getInstance
        else test
    }
  }

  /**
   * Get the static type of the expression as a UType, following precisely the type
   * inference rules defined in the XSLT 3.0 specification.
   *
   * @param contextItemType the static type of the context item for the expression evaluation
   * @return the static item type of the expression according to the XSLT 3.0 defined rules
   */
  override def getStaticUType(contextItemType: UType) = { // See W3C bug 30032
    val reachable = AxisInfo.getTargetUType(contextItemType, axis)
    if (test == null) reachable
    else reachable.intersection(test.getUType)
  }

  /**
   * Determine the intrinsic dependencies of an expression, that is, those which are not derived
   * from the dependencies of its subexpressions. For example, position() has an intrinsic dependency
   * on the context position, while (position()+1) does not. The default implementation
   * of the method returns 0, indicating "no dependencies".
   *
   * @return a set of bit-significant flags identifying the "intrinsic"
   * dependencies. The flags are documented in class net.sf.saxon.value.StaticProperty
   */
  override def getIntrinsicDependencies = StaticProperty.DEPENDS_ON_CONTEXT_ITEM

  /**
   * Determine the cardinality of the result of this expression
   */
  override final def computeCardinality: Int = {
    var originNodeType = null
    val nodeTest = test
    val contextItemType = staticInfo.getItemType
    if (contextItemType.isInstanceOf[NodeTest]) originNodeType = contextItemType.asInstanceOf[NodeTest]
    else if (contextItemType.isInstanceOf[AnyItemType]) originNodeType = AnyNodeTest.getInstance
    else { // context item not a node - we'll report a type error somewhere along the line
      return StaticProperty.ALLOWS_ZERO_OR_MORE
    }
    if (axis == AxisInfo.ATTRIBUTE && nodeTest.isInstanceOf[NameTest]) {
      val contentType = originNodeType.getContentType
      if (contentType.isInstanceOf[ComplexType]) try return contentType.asInstanceOf[ComplexType].getAttributeUseCardinality(nodeTest.getMatchingNodeName)
      catch {
        case err: SchemaException =>
          // shouldn't happen; play safe
          return StaticProperty.ALLOWS_ZERO_OR_ONE
      }
      else if (contentType.isInstanceOf[SimpleType]) return StaticProperty.EMPTY
      StaticProperty.ALLOWS_ZERO_OR_ONE
    }
    else if (axis == AxisInfo.DESCENDANT && nodeTest.isInstanceOf[NameTest] && nodeTest.getPrimitiveType == Type.ELEMENT) {
      val contentType = originNodeType.getContentType
      if (contentType.isInstanceOf[ComplexType]) try contentType.asInstanceOf[ComplexType].getDescendantElementCardinality(nodeTest.getFingerprint)
      catch {
        case err: SchemaException =>
          StaticProperty.ALLOWS_ZERO_OR_MORE
      }
      else StaticProperty.EMPTY
    }
    else if (axis == AxisInfo.SELF) StaticProperty.ALLOWS_ZERO_OR_ONE
    else StaticProperty.ALLOWS_ZERO_OR_MORE
    // the parent axis isn't handled by this class
  }

  /**
   * Determine whether the expression can be evaluated without reference to the part of the context
   * document outside the subtree rooted at the context node.
   *
   * @return true if the expression has no dependencies on the context node, or if the only dependencies
   *         on the context node are downward selections using the self, child, descendant, attribute, and namespace
   *         axes.
   */
  override def isSubtreeExpression = AxisInfo.isSubtreeAxis(axis)

  /**
   * Get the axis
   *
   * @return the axis number, for example { @link net.sf.saxon.om.AxisInfo#CHILD}
   */
  def getAxis = axis

  /**
   * Get the NodeTest. Returns null if the AxisExpression can return any node.
   *
   * @return the node test, or null if all nodes are returned
   */
  def getNodeTest = test

  /**
   * Add a representation of this expression to a PathMap. The PathMap captures a map of the nodes visited
   * by an expression in a source tree.
   *
   * @param pathMap        the PathMap to which the expression should be added
   * @param pathMapNodeSet the PathMapNodeSet to which the paths embodied in this expression should be added
   * @return the pathMapNode representing the focus established by this expression, in the case where this
   *         expression is the first operand of a path expression or filter expression
   */
  override def addToPathMap(pathMap: PathMap, pathMapNodeSet: PathMap.PathMapNodeSet) = {
    if (pathMapNodeSet == null) {
      val cie = new ContextItemExpression
      //cie.setContainer(getContainer());
      pathMapNodeSet = new PathMap.PathMapNodeSet(pathMap.makeNewRoot(cie))
    }
    pathMapNodeSet.createArc(axis, if (test == null) AnyNodeTest.getInstance
    else test)
  }

  /**
   * Ask whether there is a possibility that the context item will be undefined
   *
   * @return true if this is a possibility
   */
  def isContextPossiblyUndefined = staticInfo.isPossiblyAbsent

  def getContextItemStaticInfo = staticInfo

  /**
   * Convert this expression to an equivalent XSLT pattern
   *
   * @param config the Saxon configuration
   * @return the equivalent pattern
   * @throws net.sf.saxon.trans.XPathException if conversion is not possible
   */
  @throws[XPathException]
  override def toPattern(config: Configuration) = {
    var test = getNodeTest
    var pat = null
    if (test == null) test = AnyNodeTest.getInstance
    if (test.isInstanceOf[AnyNodeTest] && (axis == AxisInfo.CHILD || axis == AxisInfo.DESCENDANT || axis == AxisInfo.SELF)) test = MultipleNodeKindTest.CHILD_NODE
    val kind = test.getPrimitiveType
    if (axis == AxisInfo.SELF) pat = new NodeTestPattern(test)
    else if (axis == AxisInfo.ATTRIBUTE) if (kind == Type.NODE) { // attribute::node() matches any attribute, and only an attribute
      pat = new NodeTestPattern(NodeKindTest.ATTRIBUTE)
    }
    else if (!AxisInfo.containsNodeKind(axis, kind)) { // for example, attribute::comment()
      pat = new NodeTestPattern(ErrorType.getInstance)
    }
    else pat = new NodeTestPattern(test)
    else if (axis == AxisInfo.CHILD || axis == AxisInfo.DESCENDANT || axis == AxisInfo.DESCENDANT_OR_SELF) if (kind != Type.NODE && !AxisInfo.containsNodeKind(axis, kind)) pat = new NodeTestPattern(ErrorType.getInstance)
    else pat = new NodeTestPattern(test)
    else if (axis == AxisInfo.NAMESPACE) if (kind == Type.NODE) { // namespace::node() matches any attribute, and only an attribute
      pat = new NodeTestPattern(NodeKindTest.NAMESPACE)
    }
    else if (!AxisInfo.containsNodeKind(axis, kind)) { // for example, namespace::comment()
      pat = new NodeTestPattern(ErrorType.getInstance)
    }
    else pat = new NodeTestPattern(test)
    else throw new XPathException("Only downwards axes are allowed in a pattern", "XTSE0340")
    ExpressionTool.copyLocationInfo(this, pat)
    pat
  }

  override def getImplementationMethod = ITERATE_METHOD

  /**
   * Evaluate the path-expression in a given context to return a NodeSet
   *
   * @param context the evaluation context
   */
  @throws[XPathException]
  override def iterate(context: XPathContext) = {
    val item = context.getContextItem
    if (item == null) { // Might as well do the test anyway, whether or not contextMaybeUndefined is set
      val err = new XPathException("The context item for axis step " + this + " is absent")
      err.setErrorCode("XPDY0002")
      err.setXPathContext(context)
      err.setLocation(getLocation)
      err.setIsTypeError(true)
      throw err
    }
    try if (test == null) item.asInstanceOf[NodeInfo].iterateAxis(axis)
    else item.asInstanceOf[NodeInfo].iterateAxis(axis, test)
    catch {
      case cce: ClassCastException =>
        val err = new XPathException("The context item for axis step " + this + " is not a node")
        err.setErrorCode("XPTY0020")
        err.setXPathContext(context)
        err.setLocation(getLocation)
        err.setIsTypeError(true)
        throw err
      case err: UnsupportedOperationException =>
        if (err.getCause.isInstanceOf[XPathException]) {
          val ec = err.getCause.asInstanceOf[XPathException]
          ec.maybeSetLocation(getLocation)
          ec.maybeSetContext(context)
          throw ec
        }
        else { // the namespace axis is not supported for all tree implementations
          dynamicError(err.getMessage, "XPST0010", context)
          null
        }
    }
  }

  /**
   * Iterate the axis from a given starting node, without regard to context
   *
   * @param origin the starting node
   * @return the iterator over the axis
   */
  def iterate(origin: NodeInfo) = if (test == null) origin.iterateAxis(axis)
  else origin.iterateAxis(axis, test)

  /**
   * Diagnostic print of expression structure. The abstract expression tree
   * is written to the supplied output destination.
   */
  @throws[XPathException]
  override def `export`(destination: ExpressionPresenter) = {
    destination.startElement("axis", this)
    destination.emitAttribute("name", AxisInfo.axisName(axis))
    destination.emitAttribute("nodeTest", AlphaCode.fromItemType(if (test == null) AnyNodeTest.getInstance
    else test))
    destination.endElement
  }

  /**
   * Represent the expression as a string. The resulting string will be a valid XPath 3.0 expression
   * with no dependencies on namespace bindings other than the binding of the prefix "xs" to the XML Schema
   * namespace.
   *
   * @return the expression as a string in XPath 3.0 syntax
   */
  override def toString = {
    val fsb = new FastStringBuffer(FastStringBuffer.C16)
    fsb.append(AxisInfo.axisName(axis))
    fsb.append("::")
    fsb.append(if (test == null) "node()"
    else test.toString)
    fsb.toString
  }

  override def toShortString = {
    val fsb = new FastStringBuffer(FastStringBuffer.C16)
    if (axis == AxisInfo.CHILD) {
      // no action
    }
    else if (axis == AxisInfo.ATTRIBUTE) fsb.append("@")
    else {
      fsb.append(AxisInfo.axisName(axis))
      fsb.append("::")
    }
    if (test == null) fsb.append("node()")
    else if (test.isInstanceOf[NameTest]) if (test.asInstanceOf[NameTest].getNodeKind != AxisInfo.principalNodeType(axis)) fsb.append(test.toString)
    else fsb.append(test.getMatchingNodeName.getDisplayName)
    else fsb.append(test.toString)
    fsb.toString
  }

  override def getStreamerName = "AxisExpression"

  /**
   * Find any necessary preconditions for the satisfaction of this expression
   * as a set of boolean expressions to be evaluated on the context node
   *
   * @return A set of conditions, or null if none have been computed
   */
  def getPreconditions = {
    val pre = new util.HashSet[Expression](1)
    /*Expression args[] = new Expression[1];
            args[0] = this.copy();
            pre.add(SystemFunctionCall.makeSystemFunction(
                    "exists", args));*/ val a = this.copy(new RebindingMap)
    a.setRetainedStaticContext(getRetainedStaticContext)
    pre.add(a)
    pre
  }
}